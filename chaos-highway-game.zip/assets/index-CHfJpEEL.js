(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))a(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const f of c.addedNodes)f.tagName==="LINK"&&f.rel==="modulepreload"&&a(f)}).observe(document,{childList:!0,subtree:!0});function i(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function a(l){if(l.ep)return;l.ep=!0;const c=i(l);fetch(l.href,c)}})();var dh={exports:{}},Wo={};var Gg;function FS(){if(Gg)return Wo;Gg=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.fragment");function i(a,l,c){var f=null;if(c!==void 0&&(f=""+c),l.key!==void 0&&(f=""+l.key),"key"in l){c={};for(var p in l)p!=="key"&&(c[p]=l[p])}else c=l;return l=c.ref,{$$typeof:r,type:a,key:f,ref:l!==void 0?l:null,props:c}}return Wo.Fragment=t,Wo.jsx=i,Wo.jsxs=i,Wo}var Hg;function zS(){return Hg||(Hg=1,dh.exports=FS()),dh.exports}var B=zS(),ph={exports:{}},xe={};var Vg;function GS(){if(Vg)return xe;Vg=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),f=Symbol.for("react.context"),p=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),v=Symbol.for("react.lazy"),x=Symbol.iterator;function g(I){return I===null||typeof I!="object"?null:(I=x&&I[x]||I["@@iterator"],typeof I=="function"?I:null)}var y={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},b=Object.assign,C={};function S(I,tt,dt){this.props=I,this.context=tt,this.refs=C,this.updater=dt||y}S.prototype.isReactComponent={},S.prototype.setState=function(I,tt){if(typeof I!="object"&&typeof I!="function"&&I!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,I,tt,"setState")},S.prototype.forceUpdate=function(I){this.updater.enqueueForceUpdate(this,I,"forceUpdate")};function _(){}_.prototype=S.prototype;function T(I,tt,dt){this.props=I,this.context=tt,this.refs=C,this.updater=dt||y}var D=T.prototype=new _;D.constructor=T,b(D,S.prototype),D.isPureReactComponent=!0;var U=Array.isArray,P={H:null,A:null,T:null,S:null,V:null},N=Object.prototype.hasOwnProperty;function z(I,tt,dt,St,Nt,Tt){return dt=Tt.ref,{$$typeof:r,type:I,key:tt,ref:dt!==void 0?dt:null,props:Tt}}function A(I,tt){return z(I.type,tt,void 0,void 0,void 0,I.props)}function O(I){return typeof I=="object"&&I!==null&&I.$$typeof===r}function k(I){var tt={"=":"=0",":":"=2"};return"$"+I.replace(/[=:]/g,function(dt){return tt[dt]})}var G=/\/+/g;function Y(I,tt){return typeof I=="object"&&I!==null&&I.key!=null?k(""+I.key):tt.toString(36)}function ct(){}function ut(I){switch(I.status){case"fulfilled":return I.value;case"rejected":throw I.reason;default:switch(typeof I.status=="string"?I.then(ct,ct):(I.status="pending",I.then(function(tt){I.status==="pending"&&(I.status="fulfilled",I.value=tt)},function(tt){I.status==="pending"&&(I.status="rejected",I.reason=tt)})),I.status){case"fulfilled":return I.value;case"rejected":throw I.reason}}throw I}function W(I,tt,dt,St,Nt){var Tt=typeof I;(Tt==="undefined"||Tt==="boolean")&&(I=null);var J=!1;if(I===null)J=!0;else switch(Tt){case"bigint":case"string":case"number":J=!0;break;case"object":switch(I.$$typeof){case r:case t:J=!0;break;case v:return J=I._init,W(J(I._payload),tt,dt,St,Nt)}}if(J)return Nt=Nt(I),J=St===""?"."+Y(I,0):St,U(Nt)?(dt="",J!=null&&(dt=J.replace(G,"$&/")+"/"),W(Nt,tt,dt,"",function(Ft){return Ft})):Nt!=null&&(O(Nt)&&(Nt=A(Nt,dt+(Nt.key==null||I&&I.key===Nt.key?"":(""+Nt.key).replace(G,"$&/")+"/")+J)),tt.push(Nt)),1;J=0;var Mt=St===""?".":St+":";if(U(I))for(var pt=0;pt<I.length;pt++)St=I[pt],Tt=Mt+Y(St,pt),J+=W(St,tt,dt,Tt,Nt);else if(pt=g(I),typeof pt=="function")for(I=pt.call(I),pt=0;!(St=I.next()).done;)St=St.value,Tt=Mt+Y(St,pt++),J+=W(St,tt,dt,Tt,Nt);else if(Tt==="object"){if(typeof I.then=="function")return W(ut(I),tt,dt,St,Nt);throw tt=String(I),Error("Objects are not valid as a React child (found: "+(tt==="[object Object]"?"object with keys {"+Object.keys(I).join(", ")+"}":tt)+"). If you meant to render a collection of children, use an array instead.")}return J}function F(I,tt,dt){if(I==null)return I;var St=[],Nt=0;return W(I,St,"","",function(Tt){return tt.call(dt,Tt,Nt++)}),St}function V(I){if(I._status===-1){var tt=I._result;tt=tt(),tt.then(function(dt){(I._status===0||I._status===-1)&&(I._status=1,I._result=dt)},function(dt){(I._status===0||I._status===-1)&&(I._status=2,I._result=dt)}),I._status===-1&&(I._status=0,I._result=tt)}if(I._status===1)return I._result.default;throw I._result}var rt=typeof reportError=="function"?reportError:function(I){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var tt=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof I=="object"&&I!==null&&typeof I.message=="string"?String(I.message):String(I),error:I});if(!window.dispatchEvent(tt))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",I);return}console.error(I)};function gt(){}return xe.Children={map:F,forEach:function(I,tt,dt){F(I,function(){tt.apply(this,arguments)},dt)},count:function(I){var tt=0;return F(I,function(){tt++}),tt},toArray:function(I){return F(I,function(tt){return tt})||[]},only:function(I){if(!O(I))throw Error("React.Children.only expected to receive a single React element child.");return I}},xe.Component=S,xe.Fragment=i,xe.Profiler=l,xe.PureComponent=T,xe.StrictMode=a,xe.Suspense=m,xe.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=P,xe.__COMPILER_RUNTIME={__proto__:null,c:function(I){return P.H.useMemoCache(I)}},xe.cache=function(I){return function(){return I.apply(null,arguments)}},xe.cloneElement=function(I,tt,dt){if(I==null)throw Error("The argument must be a React element, but you passed "+I+".");var St=b({},I.props),Nt=I.key,Tt=void 0;if(tt!=null)for(J in tt.ref!==void 0&&(Tt=void 0),tt.key!==void 0&&(Nt=""+tt.key),tt)!N.call(tt,J)||J==="key"||J==="__self"||J==="__source"||J==="ref"&&tt.ref===void 0||(St[J]=tt[J]);var J=arguments.length-2;if(J===1)St.children=dt;else if(1<J){for(var Mt=Array(J),pt=0;pt<J;pt++)Mt[pt]=arguments[pt+2];St.children=Mt}return z(I.type,Nt,void 0,void 0,Tt,St)},xe.createContext=function(I){return I={$$typeof:f,_currentValue:I,_currentValue2:I,_threadCount:0,Provider:null,Consumer:null},I.Provider=I,I.Consumer={$$typeof:c,_context:I},I},xe.createElement=function(I,tt,dt){var St,Nt={},Tt=null;if(tt!=null)for(St in tt.key!==void 0&&(Tt=""+tt.key),tt)N.call(tt,St)&&St!=="key"&&St!=="__self"&&St!=="__source"&&(Nt[St]=tt[St]);var J=arguments.length-2;if(J===1)Nt.children=dt;else if(1<J){for(var Mt=Array(J),pt=0;pt<J;pt++)Mt[pt]=arguments[pt+2];Nt.children=Mt}if(I&&I.defaultProps)for(St in J=I.defaultProps,J)Nt[St]===void 0&&(Nt[St]=J[St]);return z(I,Tt,void 0,void 0,null,Nt)},xe.createRef=function(){return{current:null}},xe.forwardRef=function(I){return{$$typeof:p,render:I}},xe.isValidElement=O,xe.lazy=function(I){return{$$typeof:v,_payload:{_status:-1,_result:I},_init:V}},xe.memo=function(I,tt){return{$$typeof:d,type:I,compare:tt===void 0?null:tt}},xe.startTransition=function(I){var tt=P.T,dt={};P.T=dt;try{var St=I(),Nt=P.S;Nt!==null&&Nt(dt,St),typeof St=="object"&&St!==null&&typeof St.then=="function"&&St.then(gt,rt)}catch(Tt){rt(Tt)}finally{P.T=tt}},xe.unstable_useCacheRefresh=function(){return P.H.useCacheRefresh()},xe.use=function(I){return P.H.use(I)},xe.useActionState=function(I,tt,dt){return P.H.useActionState(I,tt,dt)},xe.useCallback=function(I,tt){return P.H.useCallback(I,tt)},xe.useContext=function(I){return P.H.useContext(I)},xe.useDebugValue=function(){},xe.useDeferredValue=function(I,tt){return P.H.useDeferredValue(I,tt)},xe.useEffect=function(I,tt,dt){var St=P.H;if(typeof dt=="function")throw Error("useEffect CRUD overload is not enabled in this build of React.");return St.useEffect(I,tt)},xe.useId=function(){return P.H.useId()},xe.useImperativeHandle=function(I,tt,dt){return P.H.useImperativeHandle(I,tt,dt)},xe.useInsertionEffect=function(I,tt){return P.H.useInsertionEffect(I,tt)},xe.useLayoutEffect=function(I,tt){return P.H.useLayoutEffect(I,tt)},xe.useMemo=function(I,tt){return P.H.useMemo(I,tt)},xe.useOptimistic=function(I,tt){return P.H.useOptimistic(I,tt)},xe.useReducer=function(I,tt,dt){return P.H.useReducer(I,tt,dt)},xe.useRef=function(I){return P.H.useRef(I)},xe.useState=function(I){return P.H.useState(I)},xe.useSyncExternalStore=function(I,tt,dt){return P.H.useSyncExternalStore(I,tt,dt)},xe.useTransition=function(){return P.H.useTransition()},xe.version="19.1.0",xe}var kg;function qd(){return kg||(kg=1,ph.exports=GS()),ph.exports}var Xt=qd(),mh={exports:{}},qo={},gh={exports:{}},vh={};var Xg;function HS(){return Xg||(Xg=1,(function(r){function t(F,V){var rt=F.length;F.push(V);t:for(;0<rt;){var gt=rt-1>>>1,I=F[gt];if(0<l(I,V))F[gt]=V,F[rt]=I,rt=gt;else break t}}function i(F){return F.length===0?null:F[0]}function a(F){if(F.length===0)return null;var V=F[0],rt=F.pop();if(rt!==V){F[0]=rt;t:for(var gt=0,I=F.length,tt=I>>>1;gt<tt;){var dt=2*(gt+1)-1,St=F[dt],Nt=dt+1,Tt=F[Nt];if(0>l(St,rt))Nt<I&&0>l(Tt,St)?(F[gt]=Tt,F[Nt]=rt,gt=Nt):(F[gt]=St,F[dt]=rt,gt=dt);else if(Nt<I&&0>l(Tt,rt))F[gt]=Tt,F[Nt]=rt,gt=Nt;else break t}}return V}function l(F,V){var rt=F.sortIndex-V.sortIndex;return rt!==0?rt:F.id-V.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;r.unstable_now=function(){return c.now()}}else{var f=Date,p=f.now();r.unstable_now=function(){return f.now()-p}}var m=[],d=[],v=1,x=null,g=3,y=!1,b=!1,C=!1,S=!1,_=typeof setTimeout=="function"?setTimeout:null,T=typeof clearTimeout=="function"?clearTimeout:null,D=typeof setImmediate<"u"?setImmediate:null;function U(F){for(var V=i(d);V!==null;){if(V.callback===null)a(d);else if(V.startTime<=F)a(d),V.sortIndex=V.expirationTime,t(m,V);else break;V=i(d)}}function P(F){if(C=!1,U(F),!b)if(i(m)!==null)b=!0,N||(N=!0,Y());else{var V=i(d);V!==null&&W(P,V.startTime-F)}}var N=!1,z=-1,A=5,O=-1;function k(){return S?!0:!(r.unstable_now()-O<A)}function G(){if(S=!1,N){var F=r.unstable_now();O=F;var V=!0;try{t:{b=!1,C&&(C=!1,T(z),z=-1),y=!0;var rt=g;try{e:{for(U(F),x=i(m);x!==null&&!(x.expirationTime>F&&k());){var gt=x.callback;if(typeof gt=="function"){x.callback=null,g=x.priorityLevel;var I=gt(x.expirationTime<=F);if(F=r.unstable_now(),typeof I=="function"){x.callback=I,U(F),V=!0;break e}x===i(m)&&a(m),U(F)}else a(m);x=i(m)}if(x!==null)V=!0;else{var tt=i(d);tt!==null&&W(P,tt.startTime-F),V=!1}}break t}finally{x=null,g=rt,y=!1}V=void 0}}finally{V?Y():N=!1}}}var Y;if(typeof D=="function")Y=function(){D(G)};else if(typeof MessageChannel<"u"){var ct=new MessageChannel,ut=ct.port2;ct.port1.onmessage=G,Y=function(){ut.postMessage(null)}}else Y=function(){_(G,0)};function W(F,V){z=_(function(){F(r.unstable_now())},V)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(F){F.callback=null},r.unstable_forceFrameRate=function(F){0>F||125<F?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):A=0<F?Math.floor(1e3/F):5},r.unstable_getCurrentPriorityLevel=function(){return g},r.unstable_next=function(F){switch(g){case 1:case 2:case 3:var V=3;break;default:V=g}var rt=g;g=V;try{return F()}finally{g=rt}},r.unstable_requestPaint=function(){S=!0},r.unstable_runWithPriority=function(F,V){switch(F){case 1:case 2:case 3:case 4:case 5:break;default:F=3}var rt=g;g=F;try{return V()}finally{g=rt}},r.unstable_scheduleCallback=function(F,V,rt){var gt=r.unstable_now();switch(typeof rt=="object"&&rt!==null?(rt=rt.delay,rt=typeof rt=="number"&&0<rt?gt+rt:gt):rt=gt,F){case 1:var I=-1;break;case 2:I=250;break;case 5:I=1073741823;break;case 4:I=1e4;break;default:I=5e3}return I=rt+I,F={id:v++,callback:V,priorityLevel:F,startTime:rt,expirationTime:I,sortIndex:-1},rt>gt?(F.sortIndex=rt,t(d,F),i(m)===null&&F===i(d)&&(C?(T(z),z=-1):C=!0,W(P,rt-gt))):(F.sortIndex=I,t(m,F),b||y||(b=!0,N||(N=!0,Y()))),F},r.unstable_shouldYield=k,r.unstable_wrapCallback=function(F){var V=g;return function(){var rt=g;g=V;try{return F.apply(this,arguments)}finally{g=rt}}}})(vh)),vh}var Wg;function VS(){return Wg||(Wg=1,gh.exports=HS()),gh.exports}var xh={exports:{}},Bn={};var qg;function kS(){if(qg)return Bn;qg=1;var r=qd();function t(m){var d="https://react.dev/errors/"+m;if(1<arguments.length){d+="?args[]="+encodeURIComponent(arguments[1]);for(var v=2;v<arguments.length;v++)d+="&args[]="+encodeURIComponent(arguments[v])}return"Minified React error #"+m+"; visit "+d+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var a={d:{f:i,r:function(){throw Error(t(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal");function c(m,d,v){var x=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:x==null?null:""+x,children:m,containerInfo:d,implementation:v}}var f=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function p(m,d){if(m==="font")return"";if(typeof d=="string")return d==="use-credentials"?d:""}return Bn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,Bn.createPortal=function(m,d){var v=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!d||d.nodeType!==1&&d.nodeType!==9&&d.nodeType!==11)throw Error(t(299));return c(m,d,null,v)},Bn.flushSync=function(m){var d=f.T,v=a.p;try{if(f.T=null,a.p=2,m)return m()}finally{f.T=d,a.p=v,a.d.f()}},Bn.preconnect=function(m,d){typeof m=="string"&&(d?(d=d.crossOrigin,d=typeof d=="string"?d==="use-credentials"?d:"":void 0):d=null,a.d.C(m,d))},Bn.prefetchDNS=function(m){typeof m=="string"&&a.d.D(m)},Bn.preinit=function(m,d){if(typeof m=="string"&&d&&typeof d.as=="string"){var v=d.as,x=p(v,d.crossOrigin),g=typeof d.integrity=="string"?d.integrity:void 0,y=typeof d.fetchPriority=="string"?d.fetchPriority:void 0;v==="style"?a.d.S(m,typeof d.precedence=="string"?d.precedence:void 0,{crossOrigin:x,integrity:g,fetchPriority:y}):v==="script"&&a.d.X(m,{crossOrigin:x,integrity:g,fetchPriority:y,nonce:typeof d.nonce=="string"?d.nonce:void 0})}},Bn.preinitModule=function(m,d){if(typeof m=="string")if(typeof d=="object"&&d!==null){if(d.as==null||d.as==="script"){var v=p(d.as,d.crossOrigin);a.d.M(m,{crossOrigin:v,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0})}}else d==null&&a.d.M(m)},Bn.preload=function(m,d){if(typeof m=="string"&&typeof d=="object"&&d!==null&&typeof d.as=="string"){var v=d.as,x=p(v,d.crossOrigin);a.d.L(m,v,{crossOrigin:x,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0,type:typeof d.type=="string"?d.type:void 0,fetchPriority:typeof d.fetchPriority=="string"?d.fetchPriority:void 0,referrerPolicy:typeof d.referrerPolicy=="string"?d.referrerPolicy:void 0,imageSrcSet:typeof d.imageSrcSet=="string"?d.imageSrcSet:void 0,imageSizes:typeof d.imageSizes=="string"?d.imageSizes:void 0,media:typeof d.media=="string"?d.media:void 0})}},Bn.preloadModule=function(m,d){if(typeof m=="string")if(d){var v=p(d.as,d.crossOrigin);a.d.m(m,{as:typeof d.as=="string"&&d.as!=="script"?d.as:void 0,crossOrigin:v,integrity:typeof d.integrity=="string"?d.integrity:void 0})}else a.d.m(m)},Bn.requestFormReset=function(m){a.d.r(m)},Bn.unstable_batchedUpdates=function(m,d){return m(d)},Bn.useFormState=function(m,d,v){return f.H.useFormState(m,d,v)},Bn.useFormStatus=function(){return f.H.useHostTransitionStatus()},Bn.version="19.1.0",Bn}var jg;function XS(){if(jg)return xh.exports;jg=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),xh.exports=kS(),xh.exports}var Yg;function WS(){if(Yg)return qo;Yg=1;var r=VS(),t=qd(),i=XS();function a(e){var n="https://react.dev/errors/"+e;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var s=2;s<arguments.length;s++)n+="&args[]="+encodeURIComponent(arguments[s])}return"Minified React error #"+e+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function c(e){var n=e,s=e;if(e.alternate)for(;n.return;)n=n.return;else{e=n;do n=e,(n.flags&4098)!==0&&(s=n.return),e=n.return;while(e)}return n.tag===3?s:null}function f(e){if(e.tag===13){var n=e.memoizedState;if(n===null&&(e=e.alternate,e!==null&&(n=e.memoizedState)),n!==null)return n.dehydrated}return null}function p(e){if(c(e)!==e)throw Error(a(188))}function m(e){var n=e.alternate;if(!n){if(n=c(e),n===null)throw Error(a(188));return n!==e?null:e}for(var s=e,o=n;;){var u=s.return;if(u===null)break;var h=u.alternate;if(h===null){if(o=u.return,o!==null){s=o;continue}break}if(u.child===h.child){for(h=u.child;h;){if(h===s)return p(u),e;if(h===o)return p(u),n;h=h.sibling}throw Error(a(188))}if(s.return!==o.return)s=u,o=h;else{for(var M=!1,R=u.child;R;){if(R===s){M=!0,s=u,o=h;break}if(R===o){M=!0,o=u,s=h;break}R=R.sibling}if(!M){for(R=h.child;R;){if(R===s){M=!0,s=h,o=u;break}if(R===o){M=!0,o=h,s=u;break}R=R.sibling}if(!M)throw Error(a(189))}}if(s.alternate!==o)throw Error(a(190))}if(s.tag!==3)throw Error(a(188));return s.stateNode.current===s?e:n}function d(e){var n=e.tag;if(n===5||n===26||n===27||n===6)return e;for(e=e.child;e!==null;){if(n=d(e),n!==null)return n;e=e.sibling}return null}var v=Object.assign,x=Symbol.for("react.element"),g=Symbol.for("react.transitional.element"),y=Symbol.for("react.portal"),b=Symbol.for("react.fragment"),C=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),_=Symbol.for("react.provider"),T=Symbol.for("react.consumer"),D=Symbol.for("react.context"),U=Symbol.for("react.forward_ref"),P=Symbol.for("react.suspense"),N=Symbol.for("react.suspense_list"),z=Symbol.for("react.memo"),A=Symbol.for("react.lazy"),O=Symbol.for("react.activity"),k=Symbol.for("react.memo_cache_sentinel"),G=Symbol.iterator;function Y(e){return e===null||typeof e!="object"?null:(e=G&&e[G]||e["@@iterator"],typeof e=="function"?e:null)}var ct=Symbol.for("react.client.reference");function ut(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===ct?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case b:return"Fragment";case S:return"Profiler";case C:return"StrictMode";case P:return"Suspense";case N:return"SuspenseList";case O:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case y:return"Portal";case D:return(e.displayName||"Context")+".Provider";case T:return(e._context.displayName||"Context")+".Consumer";case U:var n=e.render;return e=e.displayName,e||(e=n.displayName||n.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case z:return n=e.displayName||null,n!==null?n:ut(e.type)||"Memo";case A:n=e._payload,e=e._init;try{return ut(e(n))}catch{}}return null}var W=Array.isArray,F=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,V=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,rt={pending:!1,data:null,method:null,action:null},gt=[],I=-1;function tt(e){return{current:e}}function dt(e){0>I||(e.current=gt[I],gt[I]=null,I--)}function St(e,n){I++,gt[I]=e.current,e.current=n}var Nt=tt(null),Tt=tt(null),J=tt(null),Mt=tt(null);function pt(e,n){switch(St(J,n),St(Tt,e),St(Nt,null),n.nodeType){case 9:case 11:e=(e=n.documentElement)&&(e=e.namespaceURI)?pg(e):0;break;default:if(e=n.tagName,n=n.namespaceURI)n=pg(n),e=mg(n,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}dt(Nt),St(Nt,e)}function Ft(){dt(Nt),dt(Tt),dt(J)}function $t(e){e.memoizedState!==null&&St(Mt,e);var n=Nt.current,s=mg(n,e.type);n!==s&&(St(Tt,e),St(Nt,s))}function Zt(e){Tt.current===e&&(dt(Nt),dt(Tt)),Mt.current===e&&(dt(Mt),Go._currentValue=rt)}var Pe=Object.prototype.hasOwnProperty,le=r.unstable_scheduleCallback,Ne=r.unstable_cancelCallback,jt=r.unstable_shouldYield,te=r.unstable_requestPaint,ee=r.unstable_now,me=r.unstable_getCurrentPriorityLevel,Ve=r.unstable_ImmediatePriority,j=r.unstable_UserBlockingPriority,Ue=r.unstable_NormalPriority,ge=r.unstable_LowPriority,ke=r.unstable_IdlePriority,Pt=r.log,tn=r.unstable_setDisableYieldValue,L=null,E=null;function $(e){if(typeof Pt=="function"&&tn(e),E&&typeof E.setStrictMode=="function")try{E.setStrictMode(L,e)}catch{}}var ht=Math.clz32?Math.clz32:Ut,Et=Math.log,wt=Math.LN2;function Ut(e){return e>>>=0,e===0?32:31-(Et(e)/wt|0)|0}var ft=256,xt=4194304;function Lt(e){var n=e&42;if(n!==0)return n;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194048;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Gt(e,n,s){var o=e.pendingLanes;if(o===0)return 0;var u=0,h=e.suspendedLanes,M=e.pingedLanes;e=e.warmLanes;var R=o&134217727;return R!==0?(o=R&~h,o!==0?u=Lt(o):(M&=R,M!==0?u=Lt(M):s||(s=R&~e,s!==0&&(u=Lt(s))))):(R=o&~h,R!==0?u=Lt(R):M!==0?u=Lt(M):s||(s=o&~e,s!==0&&(u=Lt(s)))),u===0?0:n!==0&&n!==u&&(n&h)===0&&(h=u&-u,s=n&-n,h>=s||h===32&&(s&4194048)!==0)?n:u}function At(e,n){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&n)===0}function Rt(e,n){switch(e){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function re(){var e=ft;return ft<<=1,(ft&4194048)===0&&(ft=256),e}function fe(){var e=xt;return xt<<=1,(xt&62914560)===0&&(xt=4194304),e}function we(e){for(var n=[],s=0;31>s;s++)n.push(e);return n}function X(e,n){e.pendingLanes|=n,n!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Ct(e,n,s,o,u,h){var M=e.pendingLanes;e.pendingLanes=s,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=s,e.entangledLanes&=s,e.errorRecoveryDisabledLanes&=s,e.shellSuspendCounter=0;var R=e.entanglements,H=e.expirationTimes,it=e.hiddenUpdates;for(s=M&~s;0<s;){var vt=31-ht(s),yt=1<<vt;R[vt]=0,H[vt]=-1;var st=it[vt];if(st!==null)for(it[vt]=null,vt=0;vt<st.length;vt++){var lt=st[vt];lt!==null&&(lt.lane&=-536870913)}s&=~yt}o!==0&&mt(e,o,0),h!==0&&u===0&&e.tag!==0&&(e.suspendedLanes|=h&~(M&~n))}function mt(e,n,s){e.pendingLanes|=n,e.suspendedLanes&=~n;var o=31-ht(n);e.entangledLanes|=n,e.entanglements[o]=e.entanglements[o]|1073741824|s&4194090}function zt(e,n){var s=e.entangledLanes|=n;for(e=e.entanglements;s;){var o=31-ht(s),u=1<<o;u&n|e[o]&n&&(e[o]|=n),s&=~u}}function Dt(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function bt(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Kt(){var e=V.p;return e!==0?e:(e=window.event,e===void 0?32:Pg(e.type))}function he(e,n){var s=V.p;try{return V.p=e,n()}finally{V.p=s}}var Ge=Math.random().toString(36).slice(2),ce="__reactFiber$"+Ge,en="__reactProps$"+Ge,Dn="__reactContainer$"+Ge,fs="__reactEvents$"+Ge,uu="__reactListeners$"+Ge,fl="__reactHandles$"+Ge,Zr="__reactResources$"+Ge,ti="__reactMarker$"+Ge;function hs(e){delete e[ce],delete e[en],delete e[fs],delete e[uu],delete e[fl]}function Ji(e){var n=e[ce];if(n)return n;for(var s=e.parentNode;s;){if(n=s[Dn]||s[ce]){if(s=n.alternate,n.child!==null||s!==null&&s.child!==null)for(e=_g(e);e!==null;){if(s=e[ce])return s;e=_g(e)}return n}e=s,s=e.parentNode}return null}function $i(e){if(e=e[ce]||e[Dn]){var n=e.tag;if(n===5||n===6||n===13||n===26||n===27||n===3)return e}return null}function Oi(e){var n=e.tag;if(n===5||n===26||n===27||n===6)return e.stateNode;throw Error(a(33))}function ta(e){var n=e[Zr];return n||(n=e[Zr]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function rn(e){e[ti]=!0}var Kr=new Set,Qr={};function ea(e,n){Ca(e,n),Ca(e+"Capture",n)}function Ca(e,n){for(Qr[e]=n,e=0;e<n.length;e++)Kr.add(n[e])}var fu=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),hl={},dl={};function hu(e){return Pe.call(dl,e)?!0:Pe.call(hl,e)?!1:fu.test(e)?dl[e]=!0:(hl[e]=!0,!1)}function Vs(e,n,s){if(hu(n))if(s===null)e.removeAttribute(n);else{switch(typeof s){case"undefined":case"function":case"symbol":e.removeAttribute(n);return;case"boolean":var o=n.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(n);return}}e.setAttribute(n,""+s)}}function w(e,n,s){if(s===null)e.removeAttribute(n);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttribute(n,""+s)}}function Z(e,n,s,o){if(o===null)e.removeAttribute(s);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(s);return}e.setAttributeNS(n,s,""+o)}}var ot,at;function nt(e){if(ot===void 0)try{throw Error()}catch(s){var n=s.stack.trim().match(/\n( *(at )?)/);ot=n&&n[1]||"",at=-1<s.stack.indexOf(`
    at`)?" (<anonymous>)":-1<s.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ot+e+at}var Ot=!1;function Ht(e,n){if(!e||Ot)return"";Ot=!0;var s=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(n){var yt=function(){throw Error()};if(Object.defineProperty(yt.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(yt,[])}catch(lt){var st=lt}Reflect.construct(e,[],yt)}else{try{yt.call()}catch(lt){st=lt}e.call(yt.prototype)}}else{try{throw Error()}catch(lt){st=lt}(yt=e())&&typeof yt.catch=="function"&&yt.catch(function(){})}}catch(lt){if(lt&&st&&typeof lt.stack=="string")return[lt.stack,st.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var h=o.DetermineComponentFrameRoot(),M=h[0],R=h[1];if(M&&R){var H=M.split(`
`),it=R.split(`
`);for(u=o=0;o<H.length&&!H[o].includes("DetermineComponentFrameRoot");)o++;for(;u<it.length&&!it[u].includes("DetermineComponentFrameRoot");)u++;if(o===H.length||u===it.length)for(o=H.length-1,u=it.length-1;1<=o&&0<=u&&H[o]!==it[u];)u--;for(;1<=o&&0<=u;o--,u--)if(H[o]!==it[u]){if(o!==1||u!==1)do if(o--,u--,0>u||H[o]!==it[u]){var vt=`
`+H[o].replace(" at new "," at ");return e.displayName&&vt.includes("<anonymous>")&&(vt=vt.replace("<anonymous>",e.displayName)),vt}while(1<=o&&0<=u);break}}}finally{Ot=!1,Error.prepareStackTrace=s}return(s=e?e.displayName||e.name:"")?nt(s):""}function It(e){switch(e.tag){case 26:case 27:case 5:return nt(e.type);case 16:return nt("Lazy");case 13:return nt("Suspense");case 19:return nt("SuspenseList");case 0:case 15:return Ht(e.type,!1);case 11:return Ht(e.type.render,!1);case 1:return Ht(e.type,!0);case 31:return nt("Activity");default:return""}}function Yt(e){try{var n="";do n+=It(e),e=e.return;while(e);return n}catch(s){return`
Error generating stack: `+s.message+`
`+s.stack}}function Vt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function ue(e){var n=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function ve(e){var n=ue(e)?"checked":"value",s=Object.getOwnPropertyDescriptor(e.constructor.prototype,n),o=""+e[n];if(!e.hasOwnProperty(n)&&typeof s<"u"&&typeof s.get=="function"&&typeof s.set=="function"){var u=s.get,h=s.set;return Object.defineProperty(e,n,{configurable:!0,get:function(){return u.call(this)},set:function(M){o=""+M,h.call(this,M)}}),Object.defineProperty(e,n,{enumerable:s.enumerable}),{getValue:function(){return o},setValue:function(M){o=""+M},stopTracking:function(){e._valueTracker=null,delete e[n]}}}}function Qt(e){e._valueTracker||(e._valueTracker=ve(e))}function Be(e){if(!e)return!1;var n=e._valueTracker;if(!n)return!0;var s=n.getValue(),o="";return e&&(o=ue(e)?e.checked?"true":"false":e.value),e=o,e!==s?(n.setValue(e),!0):!1}function Je(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var nn=/[\n"\\]/g;function _e(e){return e.replace(nn,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function gn(e,n,s,o,u,h,M,R){e.name="",M!=null&&typeof M!="function"&&typeof M!="symbol"&&typeof M!="boolean"?e.type=M:e.removeAttribute("type"),n!=null?M==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+Vt(n)):e.value!==""+Vt(n)&&(e.value=""+Vt(n)):M!=="submit"&&M!=="reset"||e.removeAttribute("value"),n!=null?Nn(e,M,Vt(n)):s!=null?Nn(e,M,Vt(s)):o!=null&&e.removeAttribute("value"),u==null&&h!=null&&(e.defaultChecked=!!h),u!=null&&(e.checked=u&&typeof u!="function"&&typeof u!="symbol"),R!=null&&typeof R!="function"&&typeof R!="symbol"&&typeof R!="boolean"?e.name=""+Vt(R):e.removeAttribute("name")}function kt(e,n,s,o,u,h,M,R){if(h!=null&&typeof h!="function"&&typeof h!="symbol"&&typeof h!="boolean"&&(e.type=h),n!=null||s!=null){if(!(h!=="submit"&&h!=="reset"||n!=null))return;s=s!=null?""+Vt(s):"",n=n!=null?""+Vt(n):s,R||n===e.value||(e.value=n),e.defaultValue=n}o=o??u,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=R?e.checked:!!o,e.defaultChecked=!!o,M!=null&&typeof M!="function"&&typeof M!="symbol"&&typeof M!="boolean"&&(e.name=M)}function Nn(e,n,s){n==="number"&&Je(e.ownerDocument)===e||e.defaultValue===""+s||(e.defaultValue=""+s)}function Se(e,n,s,o){if(e=e.options,n){n={};for(var u=0;u<s.length;u++)n["$"+s[u]]=!0;for(s=0;s<e.length;s++)u=n.hasOwnProperty("$"+e[s].value),e[s].selected!==u&&(e[s].selected=u),u&&o&&(e[s].defaultSelected=!0)}else{for(s=""+Vt(s),n=null,u=0;u<e.length;u++){if(e[u].value===s){e[u].selected=!0,o&&(e[u].defaultSelected=!0);return}n!==null||e[u].disabled||(n=e[u])}n!==null&&(n.selected=!0)}}function Hn(e,n,s){if(n!=null&&(n=""+Vt(n),n!==e.value&&(e.value=n),s==null)){e.defaultValue!==n&&(e.defaultValue=n);return}e.defaultValue=s!=null?""+Vt(s):""}function ei(e,n,s,o){if(n==null){if(o!=null){if(s!=null)throw Error(a(92));if(W(o)){if(1<o.length)throw Error(a(93));o=o[0]}s=o}s==null&&(s=""),n=s}s=Vt(n),e.defaultValue=s,o=e.textContent,o===s&&o!==""&&o!==null&&(e.value=o)}function Vn(e,n){if(n){var s=e.firstChild;if(s&&s===e.lastChild&&s.nodeType===3){s.nodeValue=n;return}}e.textContent=n}var Da=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function He(e,n,s){var o=n.indexOf("--")===0;s==null||typeof s=="boolean"||s===""?o?e.setProperty(n,""):n==="float"?e.cssFloat="":e[n]="":o?e.setProperty(n,s):typeof s!="number"||s===0||Da.has(n)?n==="float"?e.cssFloat=s:e[n]=(""+s).trim():e[n]=s+"px"}function an(e,n,s){if(n!=null&&typeof n!="object")throw Error(a(62));if(e=e.style,s!=null){for(var o in s)!s.hasOwnProperty(o)||n!=null&&n.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="");for(var u in n)o=n[u],n.hasOwnProperty(u)&&s[u]!==o&&He(e,u,o)}else for(var h in n)n.hasOwnProperty(h)&&He(e,h,n[h])}function di(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var je=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Ii=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function bi(e){return Ii.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}var ks=null;function du(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Xs=null,Ws=null;function gp(e){var n=$i(e);if(n&&(e=n.stateNode)){var s=e[en]||null;t:switch(e=n.stateNode,n.type){case"input":if(gn(e,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name),n=s.name,s.type==="radio"&&n!=null){for(s=e;s.parentNode;)s=s.parentNode;for(s=s.querySelectorAll('input[name="'+_e(""+n)+'"][type="radio"]'),n=0;n<s.length;n++){var o=s[n];if(o!==e&&o.form===e.form){var u=o[en]||null;if(!u)throw Error(a(90));gn(o,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(n=0;n<s.length;n++)o=s[n],o.form===e.form&&Be(o)}break t;case"textarea":Hn(e,s.value,s.defaultValue);break t;case"select":n=s.value,n!=null&&Se(e,!!s.multiple,n,!1)}}}var pu=!1;function vp(e,n,s){if(pu)return e(n,s);pu=!0;try{var o=e(n);return o}finally{if(pu=!1,(Xs!==null||Ws!==null)&&(Jl(),Xs&&(n=Xs,e=Ws,Ws=Xs=null,gp(n),e)))for(n=0;n<e.length;n++)gp(e[n])}}function Jr(e,n){var s=e.stateNode;if(s===null)return null;var o=s[en]||null;if(o===null)return null;s=o[n];t:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break t;default:e=!1}if(e)return null;if(s&&typeof s!="function")throw Error(a(231,n,typeof s));return s}var na=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),mu=!1;if(na)try{var $r={};Object.defineProperty($r,"passive",{get:function(){mu=!0}}),window.addEventListener("test",$r,$r),window.removeEventListener("test",$r,$r)}catch{mu=!1}var Na=null,gu=null,pl=null;function xp(){if(pl)return pl;var e,n=gu,s=n.length,o,u="value"in Na?Na.value:Na.textContent,h=u.length;for(e=0;e<s&&n[e]===u[e];e++);var M=s-e;for(o=1;o<=M&&n[s-o]===u[h-o];o++);return pl=u.slice(e,1<o?1-o:void 0)}function ml(e){var n=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&n===13&&(e=13)):e=n,e===10&&(e=13),32<=e||e===13?e:0}function gl(){return!0}function _p(){return!1}function Zn(e){function n(s,o,u,h,M){this._reactName=s,this._targetInst=u,this.type=o,this.nativeEvent=h,this.target=M,this.currentTarget=null;for(var R in e)e.hasOwnProperty(R)&&(s=e[R],this[R]=s?s(h):h[R]);return this.isDefaultPrevented=(h.defaultPrevented!=null?h.defaultPrevented:h.returnValue===!1)?gl:_p,this.isPropagationStopped=_p,this}return v(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var s=this.nativeEvent;s&&(s.preventDefault?s.preventDefault():typeof s.returnValue!="unknown"&&(s.returnValue=!1),this.isDefaultPrevented=gl)},stopPropagation:function(){var s=this.nativeEvent;s&&(s.stopPropagation?s.stopPropagation():typeof s.cancelBubble!="unknown"&&(s.cancelBubble=!0),this.isPropagationStopped=gl)},persist:function(){},isPersistent:gl}),n}var ds={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},vl=Zn(ds),to=v({},ds,{view:0,detail:0}),Fx=Zn(to),vu,xu,eo,xl=v({},to,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Su,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==eo&&(eo&&e.type==="mousemove"?(vu=e.screenX-eo.screenX,xu=e.screenY-eo.screenY):xu=vu=0,eo=e),vu)},movementY:function(e){return"movementY"in e?e.movementY:xu}}),Sp=Zn(xl),zx=v({},xl,{dataTransfer:0}),Gx=Zn(zx),Hx=v({},to,{relatedTarget:0}),_u=Zn(Hx),Vx=v({},ds,{animationName:0,elapsedTime:0,pseudoElement:0}),kx=Zn(Vx),Xx=v({},ds,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Wx=Zn(Xx),qx=v({},ds,{data:0}),yp=Zn(qx),jx={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Yx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Zx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Kx(e){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(e):(e=Zx[e])?!!n[e]:!1}function Su(){return Kx}var Qx=v({},to,{key:function(e){if(e.key){var n=jx[e.key]||e.key;if(n!=="Unidentified")return n}return e.type==="keypress"?(e=ml(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Yx[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Su,charCode:function(e){return e.type==="keypress"?ml(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?ml(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Jx=Zn(Qx),$x=v({},xl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Mp=Zn($x),t_=v({},to,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Su}),e_=Zn(t_),n_=v({},ds,{propertyName:0,elapsedTime:0,pseudoElement:0}),i_=Zn(n_),a_=v({},xl,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),s_=Zn(a_),r_=v({},ds,{newState:0,oldState:0}),o_=Zn(r_),l_=[9,13,27,32],yu=na&&"CompositionEvent"in window,no=null;na&&"documentMode"in document&&(no=document.documentMode);var c_=na&&"TextEvent"in window&&!no,bp=na&&(!yu||no&&8<no&&11>=no),Ep=" ",Tp=!1;function Ap(e,n){switch(e){case"keyup":return l_.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function wp(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var qs=!1;function u_(e,n){switch(e){case"compositionend":return wp(n);case"keypress":return n.which!==32?null:(Tp=!0,Ep);case"textInput":return e=n.data,e===Ep&&Tp?null:e;default:return null}}function f_(e,n){if(qs)return e==="compositionend"||!yu&&Ap(e,n)?(e=xp(),pl=gu=Na=null,qs=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return bp&&n.locale!=="ko"?null:n.data;default:return null}}var h_={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Rp(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n==="input"?!!h_[e.type]:n==="textarea"}function Cp(e,n,s,o){Xs?Ws?Ws.push(o):Ws=[o]:Xs=o,n=ac(n,"onChange"),0<n.length&&(s=new vl("onChange","change",null,s,o),e.push({event:s,listeners:n}))}var io=null,ao=null;function d_(e){cg(e,0)}function _l(e){var n=Oi(e);if(Be(n))return e}function Dp(e,n){if(e==="change")return n}var Np=!1;if(na){var Mu;if(na){var bu="oninput"in document;if(!bu){var Up=document.createElement("div");Up.setAttribute("oninput","return;"),bu=typeof Up.oninput=="function"}Mu=bu}else Mu=!1;Np=Mu&&(!document.documentMode||9<document.documentMode)}function Lp(){io&&(io.detachEvent("onpropertychange",Pp),ao=io=null)}function Pp(e){if(e.propertyName==="value"&&_l(ao)){var n=[];Cp(n,ao,e,du(e)),vp(d_,n)}}function p_(e,n,s){e==="focusin"?(Lp(),io=n,ao=s,io.attachEvent("onpropertychange",Pp)):e==="focusout"&&Lp()}function m_(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return _l(ao)}function g_(e,n){if(e==="click")return _l(n)}function v_(e,n){if(e==="input"||e==="change")return _l(n)}function x_(e,n){return e===n&&(e!==0||1/e===1/n)||e!==e&&n!==n}var ni=typeof Object.is=="function"?Object.is:x_;function so(e,n){if(ni(e,n))return!0;if(typeof e!="object"||e===null||typeof n!="object"||n===null)return!1;var s=Object.keys(e),o=Object.keys(n);if(s.length!==o.length)return!1;for(o=0;o<s.length;o++){var u=s[o];if(!Pe.call(n,u)||!ni(e[u],n[u]))return!1}return!0}function Op(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Ip(e,n){var s=Op(e);e=0;for(var o;s;){if(s.nodeType===3){if(o=e+s.textContent.length,e<=n&&o>=n)return{node:s,offset:n-e};e=o}t:{for(;s;){if(s.nextSibling){s=s.nextSibling;break t}s=s.parentNode}s=void 0}s=Op(s)}}function Bp(e,n){return e&&n?e===n?!0:e&&e.nodeType===3?!1:n&&n.nodeType===3?Bp(e,n.parentNode):"contains"in e?e.contains(n):e.compareDocumentPosition?!!(e.compareDocumentPosition(n)&16):!1:!1}function Fp(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var n=Je(e.document);n instanceof e.HTMLIFrameElement;){try{var s=typeof n.contentWindow.location.href=="string"}catch{s=!1}if(s)e=n.contentWindow;else break;n=Je(e.document)}return n}function Eu(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n&&(n==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||n==="textarea"||e.contentEditable==="true")}var __=na&&"documentMode"in document&&11>=document.documentMode,js=null,Tu=null,ro=null,Au=!1;function zp(e,n,s){var o=s.window===s?s.document:s.nodeType===9?s:s.ownerDocument;Au||js==null||js!==Je(o)||(o=js,"selectionStart"in o&&Eu(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),ro&&so(ro,o)||(ro=o,o=ac(Tu,"onSelect"),0<o.length&&(n=new vl("onSelect","select",null,n,s),e.push({event:n,listeners:o}),n.target=js)))}function ps(e,n){var s={};return s[e.toLowerCase()]=n.toLowerCase(),s["Webkit"+e]="webkit"+n,s["Moz"+e]="moz"+n,s}var Ys={animationend:ps("Animation","AnimationEnd"),animationiteration:ps("Animation","AnimationIteration"),animationstart:ps("Animation","AnimationStart"),transitionrun:ps("Transition","TransitionRun"),transitionstart:ps("Transition","TransitionStart"),transitioncancel:ps("Transition","TransitionCancel"),transitionend:ps("Transition","TransitionEnd")},wu={},Gp={};na&&(Gp=document.createElement("div").style,"AnimationEvent"in window||(delete Ys.animationend.animation,delete Ys.animationiteration.animation,delete Ys.animationstart.animation),"TransitionEvent"in window||delete Ys.transitionend.transition);function ms(e){if(wu[e])return wu[e];if(!Ys[e])return e;var n=Ys[e],s;for(s in n)if(n.hasOwnProperty(s)&&s in Gp)return wu[e]=n[s];return e}var Hp=ms("animationend"),Vp=ms("animationiteration"),kp=ms("animationstart"),S_=ms("transitionrun"),y_=ms("transitionstart"),M_=ms("transitioncancel"),Xp=ms("transitionend"),Wp=new Map,Ru="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Ru.push("scrollEnd");function Ei(e,n){Wp.set(e,n),ea(n,[e])}var qp=new WeakMap;function pi(e,n){if(typeof e=="object"&&e!==null){var s=qp.get(e);return s!==void 0?s:(n={value:e,source:n,stack:Yt(n)},qp.set(e,n),n)}return{value:e,source:n,stack:Yt(n)}}var mi=[],Zs=0,Cu=0;function Sl(){for(var e=Zs,n=Cu=Zs=0;n<e;){var s=mi[n];mi[n++]=null;var o=mi[n];mi[n++]=null;var u=mi[n];mi[n++]=null;var h=mi[n];if(mi[n++]=null,o!==null&&u!==null){var M=o.pending;M===null?u.next=u:(u.next=M.next,M.next=u),o.pending=u}h!==0&&jp(s,u,h)}}function yl(e,n,s,o){mi[Zs++]=e,mi[Zs++]=n,mi[Zs++]=s,mi[Zs++]=o,Cu|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function Du(e,n,s,o){return yl(e,n,s,o),Ml(e)}function Ks(e,n){return yl(e,null,null,n),Ml(e)}function jp(e,n,s){e.lanes|=s;var o=e.alternate;o!==null&&(o.lanes|=s);for(var u=!1,h=e.return;h!==null;)h.childLanes|=s,o=h.alternate,o!==null&&(o.childLanes|=s),h.tag===22&&(e=h.stateNode,e===null||e._visibility&1||(u=!0)),e=h,h=h.return;return e.tag===3?(h=e.stateNode,u&&n!==null&&(u=31-ht(s),e=h.hiddenUpdates,o=e[u],o===null?e[u]=[n]:o.push(n),n.lane=s|536870912),h):null}function Ml(e){if(50<Uo)throw Uo=0,Bf=null,Error(a(185));for(var n=e.return;n!==null;)e=n,n=e.return;return e.tag===3?e.stateNode:null}var Qs={};function b_(e,n,s,o){this.tag=e,this.key=s,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ii(e,n,s,o){return new b_(e,n,s,o)}function Nu(e){return e=e.prototype,!(!e||!e.isReactComponent)}function ia(e,n){var s=e.alternate;return s===null?(s=ii(e.tag,n,e.key,e.mode),s.elementType=e.elementType,s.type=e.type,s.stateNode=e.stateNode,s.alternate=e,e.alternate=s):(s.pendingProps=n,s.type=e.type,s.flags=0,s.subtreeFlags=0,s.deletions=null),s.flags=e.flags&65011712,s.childLanes=e.childLanes,s.lanes=e.lanes,s.child=e.child,s.memoizedProps=e.memoizedProps,s.memoizedState=e.memoizedState,s.updateQueue=e.updateQueue,n=e.dependencies,s.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},s.sibling=e.sibling,s.index=e.index,s.ref=e.ref,s.refCleanup=e.refCleanup,s}function Yp(e,n){e.flags&=65011714;var s=e.alternate;return s===null?(e.childLanes=0,e.lanes=n,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=s.childLanes,e.lanes=s.lanes,e.child=s.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=s.memoizedProps,e.memoizedState=s.memoizedState,e.updateQueue=s.updateQueue,e.type=s.type,n=s.dependencies,e.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),e}function bl(e,n,s,o,u,h){var M=0;if(o=e,typeof e=="function")Nu(e)&&(M=1);else if(typeof e=="string")M=TS(e,s,Nt.current)?26:e==="html"||e==="head"||e==="body"?27:5;else t:switch(e){case O:return e=ii(31,s,n,u),e.elementType=O,e.lanes=h,e;case b:return gs(s.children,u,h,n);case C:M=8,u|=24;break;case S:return e=ii(12,s,n,u|2),e.elementType=S,e.lanes=h,e;case P:return e=ii(13,s,n,u),e.elementType=P,e.lanes=h,e;case N:return e=ii(19,s,n,u),e.elementType=N,e.lanes=h,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case _:case D:M=10;break t;case T:M=9;break t;case U:M=11;break t;case z:M=14;break t;case A:M=16,o=null;break t}M=29,s=Error(a(130,e===null?"null":typeof e,"")),o=null}return n=ii(M,s,n,u),n.elementType=e,n.type=o,n.lanes=h,n}function gs(e,n,s,o){return e=ii(7,e,o,n),e.lanes=s,e}function Uu(e,n,s){return e=ii(6,e,null,n),e.lanes=s,e}function Lu(e,n,s){return n=ii(4,e.children!==null?e.children:[],e.key,n),n.lanes=s,n.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},n}var Js=[],$s=0,El=null,Tl=0,gi=[],vi=0,vs=null,aa=1,sa="";function xs(e,n){Js[$s++]=Tl,Js[$s++]=El,El=e,Tl=n}function Zp(e,n,s){gi[vi++]=aa,gi[vi++]=sa,gi[vi++]=vs,vs=e;var o=aa;e=sa;var u=32-ht(o)-1;o&=~(1<<u),s+=1;var h=32-ht(n)+u;if(30<h){var M=u-u%5;h=(o&(1<<M)-1).toString(32),o>>=M,u-=M,aa=1<<32-ht(n)+u|s<<u|o,sa=h+e}else aa=1<<h|s<<u|o,sa=e}function Pu(e){e.return!==null&&(xs(e,1),Zp(e,1,0))}function Ou(e){for(;e===El;)El=Js[--$s],Js[$s]=null,Tl=Js[--$s],Js[$s]=null;for(;e===vs;)vs=gi[--vi],gi[vi]=null,sa=gi[--vi],gi[vi]=null,aa=gi[--vi],gi[vi]=null}var kn=null,ln=null,Fe=!1,_s=null,Bi=!1,Iu=Error(a(519));function Ss(e){var n=Error(a(418,""));throw co(pi(n,e)),Iu}function Kp(e){var n=e.stateNode,s=e.type,o=e.memoizedProps;switch(n[ce]=e,n[en]=o,s){case"dialog":Ae("cancel",n),Ae("close",n);break;case"iframe":case"object":case"embed":Ae("load",n);break;case"video":case"audio":for(s=0;s<Po.length;s++)Ae(Po[s],n);break;case"source":Ae("error",n);break;case"img":case"image":case"link":Ae("error",n),Ae("load",n);break;case"details":Ae("toggle",n);break;case"input":Ae("invalid",n),kt(n,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0),Qt(n);break;case"select":Ae("invalid",n);break;case"textarea":Ae("invalid",n),ei(n,o.value,o.defaultValue,o.children),Qt(n)}s=o.children,typeof s!="string"&&typeof s!="number"&&typeof s!="bigint"||n.textContent===""+s||o.suppressHydrationWarning===!0||dg(n.textContent,s)?(o.popover!=null&&(Ae("beforetoggle",n),Ae("toggle",n)),o.onScroll!=null&&Ae("scroll",n),o.onScrollEnd!=null&&Ae("scrollend",n),o.onClick!=null&&(n.onclick=sc),n=!0):n=!1,n||Ss(e)}function Qp(e){for(kn=e.return;kn;)switch(kn.tag){case 5:case 13:Bi=!1;return;case 27:case 3:Bi=!0;return;default:kn=kn.return}}function oo(e){if(e!==kn)return!1;if(!Fe)return Qp(e),Fe=!0,!1;var n=e.tag,s;if((s=n!==3&&n!==27)&&((s=n===5)&&(s=e.type,s=!(s!=="form"&&s!=="button")||$f(e.type,e.memoizedProps)),s=!s),s&&ln&&Ss(e),Qp(e),n===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(317));t:{for(e=e.nextSibling,n=0;e;){if(e.nodeType===8)if(s=e.data,s==="/$"){if(n===0){ln=Ai(e.nextSibling);break t}n--}else s!=="$"&&s!=="$!"&&s!=="$?"||n++;e=e.nextSibling}ln=null}}else n===27?(n=ln,ja(e.type)?(e=ih,ih=null,ln=e):ln=n):ln=kn?Ai(e.stateNode.nextSibling):null;return!0}function lo(){ln=kn=null,Fe=!1}function Jp(){var e=_s;return e!==null&&(Jn===null?Jn=e:Jn.push.apply(Jn,e),_s=null),e}function co(e){_s===null?_s=[e]:_s.push(e)}var Bu=tt(null),ys=null,ra=null;function Ua(e,n,s){St(Bu,n._currentValue),n._currentValue=s}function oa(e){e._currentValue=Bu.current,dt(Bu)}function Fu(e,n,s){for(;e!==null;){var o=e.alternate;if((e.childLanes&n)!==n?(e.childLanes|=n,o!==null&&(o.childLanes|=n)):o!==null&&(o.childLanes&n)!==n&&(o.childLanes|=n),e===s)break;e=e.return}}function zu(e,n,s,o){var u=e.child;for(u!==null&&(u.return=e);u!==null;){var h=u.dependencies;if(h!==null){var M=u.child;h=h.firstContext;t:for(;h!==null;){var R=h;h=u;for(var H=0;H<n.length;H++)if(R.context===n[H]){h.lanes|=s,R=h.alternate,R!==null&&(R.lanes|=s),Fu(h.return,s,e),o||(M=null);break t}h=R.next}}else if(u.tag===18){if(M=u.return,M===null)throw Error(a(341));M.lanes|=s,h=M.alternate,h!==null&&(h.lanes|=s),Fu(M,s,e),M=null}else M=u.child;if(M!==null)M.return=u;else for(M=u;M!==null;){if(M===e){M=null;break}if(u=M.sibling,u!==null){u.return=M.return,M=u;break}M=M.return}u=M}}function uo(e,n,s,o){e=null;for(var u=n,h=!1;u!==null;){if(!h){if((u.flags&524288)!==0)h=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var M=u.alternate;if(M===null)throw Error(a(387));if(M=M.memoizedProps,M!==null){var R=u.type;ni(u.pendingProps.value,M.value)||(e!==null?e.push(R):e=[R])}}else if(u===Mt.current){if(M=u.alternate,M===null)throw Error(a(387));M.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(e!==null?e.push(Go):e=[Go])}u=u.return}e!==null&&zu(n,e,s,o),n.flags|=262144}function Al(e){for(e=e.firstContext;e!==null;){if(!ni(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Ms(e){ys=e,ra=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function In(e){return $p(ys,e)}function wl(e,n){return ys===null&&Ms(e),$p(e,n)}function $p(e,n){var s=n._currentValue;if(n={context:n,memoizedValue:s,next:null},ra===null){if(e===null)throw Error(a(308));ra=n,e.dependencies={lanes:0,firstContext:n},e.flags|=524288}else ra=ra.next=n;return s}var E_=typeof AbortController<"u"?AbortController:function(){var e=[],n=this.signal={aborted:!1,addEventListener:function(s,o){e.push(o)}};this.abort=function(){n.aborted=!0,e.forEach(function(s){return s()})}},T_=r.unstable_scheduleCallback,A_=r.unstable_NormalPriority,yn={$$typeof:D,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Gu(){return{controller:new E_,data:new Map,refCount:0}}function fo(e){e.refCount--,e.refCount===0&&T_(A_,function(){e.controller.abort()})}var ho=null,Hu=0,tr=0,er=null;function w_(e,n){if(ho===null){var s=ho=[];Hu=0,tr=Xf(),er={status:"pending",value:void 0,then:function(o){s.push(o)}}}return Hu++,n.then(tm,tm),n}function tm(){if(--Hu===0&&ho!==null){er!==null&&(er.status="fulfilled");var e=ho;ho=null,tr=0,er=null;for(var n=0;n<e.length;n++)(0,e[n])()}}function R_(e,n){var s=[],o={status:"pending",value:null,reason:null,then:function(u){s.push(u)}};return e.then(function(){o.status="fulfilled",o.value=n;for(var u=0;u<s.length;u++)(0,s[u])(n)},function(u){for(o.status="rejected",o.reason=u,u=0;u<s.length;u++)(0,s[u])(void 0)}),o}var em=F.S;F.S=function(e,n){typeof n=="object"&&n!==null&&typeof n.then=="function"&&w_(e,n),em!==null&&em(e,n)};var bs=tt(null);function Vu(){var e=bs.current;return e!==null?e:$e.pooledCache}function Rl(e,n){n===null?St(bs,bs.current):St(bs,n.pool)}function nm(){var e=Vu();return e===null?null:{parent:yn._currentValue,pool:e}}var po=Error(a(460)),im=Error(a(474)),Cl=Error(a(542)),ku={then:function(){}};function am(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Dl(){}function sm(e,n,s){switch(s=e[s],s===void 0?e.push(n):s!==n&&(n.then(Dl,Dl),n=s),n.status){case"fulfilled":return n.value;case"rejected":throw e=n.reason,om(e),e;default:if(typeof n.status=="string")n.then(Dl,Dl);else{if(e=$e,e!==null&&100<e.shellSuspendCounter)throw Error(a(482));e=n,e.status="pending",e.then(function(o){if(n.status==="pending"){var u=n;u.status="fulfilled",u.value=o}},function(o){if(n.status==="pending"){var u=n;u.status="rejected",u.reason=o}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw e=n.reason,om(e),e}throw mo=n,po}}var mo=null;function rm(){if(mo===null)throw Error(a(459));var e=mo;return mo=null,e}function om(e){if(e===po||e===Cl)throw Error(a(483))}var La=!1;function Xu(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Wu(e,n){e=e.updateQueue,n.updateQueue===e&&(n.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Pa(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Oa(e,n,s){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(Xe&2)!==0){var u=o.pending;return u===null?n.next=n:(n.next=u.next,u.next=n),o.pending=n,n=Ml(e),jp(e,null,s),n}return yl(e,o,n,s),Ml(e)}function go(e,n,s){if(n=n.updateQueue,n!==null&&(n=n.shared,(s&4194048)!==0)){var o=n.lanes;o&=e.pendingLanes,s|=o,n.lanes=s,zt(e,s)}}function qu(e,n){var s=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,s===o)){var u=null,h=null;if(s=s.firstBaseUpdate,s!==null){do{var M={lane:s.lane,tag:s.tag,payload:s.payload,callback:null,next:null};h===null?u=h=M:h=h.next=M,s=s.next}while(s!==null);h===null?u=h=n:h=h.next=n}else u=h=n;s={baseState:o.baseState,firstBaseUpdate:u,lastBaseUpdate:h,shared:o.shared,callbacks:o.callbacks},e.updateQueue=s;return}e=s.lastBaseUpdate,e===null?s.firstBaseUpdate=n:e.next=n,s.lastBaseUpdate=n}var ju=!1;function vo(){if(ju){var e=er;if(e!==null)throw e}}function xo(e,n,s,o){ju=!1;var u=e.updateQueue;La=!1;var h=u.firstBaseUpdate,M=u.lastBaseUpdate,R=u.shared.pending;if(R!==null){u.shared.pending=null;var H=R,it=H.next;H.next=null,M===null?h=it:M.next=it,M=H;var vt=e.alternate;vt!==null&&(vt=vt.updateQueue,R=vt.lastBaseUpdate,R!==M&&(R===null?vt.firstBaseUpdate=it:R.next=it,vt.lastBaseUpdate=H))}if(h!==null){var yt=u.baseState;M=0,vt=it=H=null,R=h;do{var st=R.lane&-536870913,lt=st!==R.lane;if(lt?(Le&st)===st:(o&st)===st){st!==0&&st===tr&&(ju=!0),vt!==null&&(vt=vt.next={lane:0,tag:R.tag,payload:R.payload,callback:null,next:null});t:{var se=e,ne=R;st=n;var Ke=s;switch(ne.tag){case 1:if(se=ne.payload,typeof se=="function"){yt=se.call(Ke,yt,st);break t}yt=se;break t;case 3:se.flags=se.flags&-65537|128;case 0:if(se=ne.payload,st=typeof se=="function"?se.call(Ke,yt,st):se,st==null)break t;yt=v({},yt,st);break t;case 2:La=!0}}st=R.callback,st!==null&&(e.flags|=64,lt&&(e.flags|=8192),lt=u.callbacks,lt===null?u.callbacks=[st]:lt.push(st))}else lt={lane:st,tag:R.tag,payload:R.payload,callback:R.callback,next:null},vt===null?(it=vt=lt,H=yt):vt=vt.next=lt,M|=st;if(R=R.next,R===null){if(R=u.shared.pending,R===null)break;lt=R,R=lt.next,lt.next=null,u.lastBaseUpdate=lt,u.shared.pending=null}}while(!0);vt===null&&(H=yt),u.baseState=H,u.firstBaseUpdate=it,u.lastBaseUpdate=vt,h===null&&(u.shared.lanes=0),ka|=M,e.lanes=M,e.memoizedState=yt}}function lm(e,n){if(typeof e!="function")throw Error(a(191,e));e.call(n)}function cm(e,n){var s=e.callbacks;if(s!==null)for(e.callbacks=null,e=0;e<s.length;e++)lm(s[e],n)}var nr=tt(null),Nl=tt(0);function um(e,n){e=pa,St(Nl,e),St(nr,n),pa=e|n.baseLanes}function Yu(){St(Nl,pa),St(nr,nr.current)}function Zu(){pa=Nl.current,dt(nr),dt(Nl)}var Ia=0,Me=null,Ye=null,vn=null,Ul=!1,ir=!1,Es=!1,Ll=0,_o=0,ar=null,C_=0;function dn(){throw Error(a(321))}function Ku(e,n){if(n===null)return!1;for(var s=0;s<n.length&&s<e.length;s++)if(!ni(e[s],n[s]))return!1;return!0}function Qu(e,n,s,o,u,h){return Ia=h,Me=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,F.H=e===null||e.memoizedState===null?jm:Ym,Es=!1,h=s(o,u),Es=!1,ir&&(h=hm(n,s,o,u)),fm(e),h}function fm(e){F.H=zl;var n=Ye!==null&&Ye.next!==null;if(Ia=0,vn=Ye=Me=null,Ul=!1,_o=0,ar=null,n)throw Error(a(300));e===null||Tn||(e=e.dependencies,e!==null&&Al(e)&&(Tn=!0))}function hm(e,n,s,o){Me=e;var u=0;do{if(ir&&(ar=null),_o=0,ir=!1,25<=u)throw Error(a(301));if(u+=1,vn=Ye=null,e.updateQueue!=null){var h=e.updateQueue;h.lastEffect=null,h.events=null,h.stores=null,h.memoCache!=null&&(h.memoCache.index=0)}F.H=I_,h=n(s,o)}while(ir);return h}function D_(){var e=F.H,n=e.useState()[0];return n=typeof n.then=="function"?So(n):n,e=e.useState()[0],(Ye!==null?Ye.memoizedState:null)!==e&&(Me.flags|=1024),n}function Ju(){var e=Ll!==0;return Ll=0,e}function $u(e,n,s){n.updateQueue=e.updateQueue,n.flags&=-2053,e.lanes&=~s}function tf(e){if(Ul){for(e=e.memoizedState;e!==null;){var n=e.queue;n!==null&&(n.pending=null),e=e.next}Ul=!1}Ia=0,vn=Ye=Me=null,ir=!1,_o=Ll=0,ar=null}function Kn(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return vn===null?Me.memoizedState=vn=e:vn=vn.next=e,vn}function xn(){if(Ye===null){var e=Me.alternate;e=e!==null?e.memoizedState:null}else e=Ye.next;var n=vn===null?Me.memoizedState:vn.next;if(n!==null)vn=n,Ye=e;else{if(e===null)throw Me.alternate===null?Error(a(467)):Error(a(310));Ye=e,e={memoizedState:Ye.memoizedState,baseState:Ye.baseState,baseQueue:Ye.baseQueue,queue:Ye.queue,next:null},vn===null?Me.memoizedState=vn=e:vn=vn.next=e}return vn}function ef(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function So(e){var n=_o;return _o+=1,ar===null&&(ar=[]),e=sm(ar,e,n),n=Me,(vn===null?n.memoizedState:vn.next)===null&&(n=n.alternate,F.H=n===null||n.memoizedState===null?jm:Ym),e}function Pl(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return So(e);if(e.$$typeof===D)return In(e)}throw Error(a(438,String(e)))}function nf(e){var n=null,s=Me.updateQueue;if(s!==null&&(n=s.memoCache),n==null){var o=Me.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(n={data:o.data.map(function(u){return u.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),s===null&&(s=ef(),Me.updateQueue=s),s.memoCache=n,s=n.data[n.index],s===void 0)for(s=n.data[n.index]=Array(e),o=0;o<e;o++)s[o]=k;return n.index++,s}function la(e,n){return typeof n=="function"?n(e):n}function Ol(e){var n=xn();return af(n,Ye,e)}function af(e,n,s){var o=e.queue;if(o===null)throw Error(a(311));o.lastRenderedReducer=s;var u=e.baseQueue,h=o.pending;if(h!==null){if(u!==null){var M=u.next;u.next=h.next,h.next=M}n.baseQueue=u=h,o.pending=null}if(h=e.baseState,u===null)e.memoizedState=h;else{n=u.next;var R=M=null,H=null,it=n,vt=!1;do{var yt=it.lane&-536870913;if(yt!==it.lane?(Le&yt)===yt:(Ia&yt)===yt){var st=it.revertLane;if(st===0)H!==null&&(H=H.next={lane:0,revertLane:0,action:it.action,hasEagerState:it.hasEagerState,eagerState:it.eagerState,next:null}),yt===tr&&(vt=!0);else if((Ia&st)===st){it=it.next,st===tr&&(vt=!0);continue}else yt={lane:0,revertLane:it.revertLane,action:it.action,hasEagerState:it.hasEagerState,eagerState:it.eagerState,next:null},H===null?(R=H=yt,M=h):H=H.next=yt,Me.lanes|=st,ka|=st;yt=it.action,Es&&s(h,yt),h=it.hasEagerState?it.eagerState:s(h,yt)}else st={lane:yt,revertLane:it.revertLane,action:it.action,hasEagerState:it.hasEagerState,eagerState:it.eagerState,next:null},H===null?(R=H=st,M=h):H=H.next=st,Me.lanes|=yt,ka|=yt;it=it.next}while(it!==null&&it!==n);if(H===null?M=h:H.next=R,!ni(h,e.memoizedState)&&(Tn=!0,vt&&(s=er,s!==null)))throw s;e.memoizedState=h,e.baseState=M,e.baseQueue=H,o.lastRenderedState=h}return u===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function sf(e){var n=xn(),s=n.queue;if(s===null)throw Error(a(311));s.lastRenderedReducer=e;var o=s.dispatch,u=s.pending,h=n.memoizedState;if(u!==null){s.pending=null;var M=u=u.next;do h=e(h,M.action),M=M.next;while(M!==u);ni(h,n.memoizedState)||(Tn=!0),n.memoizedState=h,n.baseQueue===null&&(n.baseState=h),s.lastRenderedState=h}return[h,o]}function dm(e,n,s){var o=Me,u=xn(),h=Fe;if(h){if(s===void 0)throw Error(a(407));s=s()}else s=n();var M=!ni((Ye||u).memoizedState,s);M&&(u.memoizedState=s,Tn=!0),u=u.queue;var R=gm.bind(null,o,u,e);if(yo(2048,8,R,[e]),u.getSnapshot!==n||M||vn!==null&&vn.memoizedState.tag&1){if(o.flags|=2048,sr(9,Il(),mm.bind(null,o,u,s,n),null),$e===null)throw Error(a(349));h||(Ia&124)!==0||pm(o,n,s)}return s}function pm(e,n,s){e.flags|=16384,e={getSnapshot:n,value:s},n=Me.updateQueue,n===null?(n=ef(),Me.updateQueue=n,n.stores=[e]):(s=n.stores,s===null?n.stores=[e]:s.push(e))}function mm(e,n,s,o){n.value=s,n.getSnapshot=o,vm(n)&&xm(e)}function gm(e,n,s){return s(function(){vm(n)&&xm(e)})}function vm(e){var n=e.getSnapshot;e=e.value;try{var s=n();return!ni(e,s)}catch{return!0}}function xm(e){var n=Ks(e,2);n!==null&&li(n,e,2)}function rf(e){var n=Kn();if(typeof e=="function"){var s=e;if(e=s(),Es){$(!0);try{s()}finally{$(!1)}}}return n.memoizedState=n.baseState=e,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:la,lastRenderedState:e},n}function _m(e,n,s,o){return e.baseState=s,af(e,Ye,typeof o=="function"?o:la)}function N_(e,n,s,o,u){if(Fl(e))throw Error(a(485));if(e=n.action,e!==null){var h={payload:u,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(M){h.listeners.push(M)}};F.T!==null?s(!0):h.isTransition=!1,o(h),s=n.pending,s===null?(h.next=n.pending=h,Sm(n,h)):(h.next=s.next,n.pending=s.next=h)}}function Sm(e,n){var s=n.action,o=n.payload,u=e.state;if(n.isTransition){var h=F.T,M={};F.T=M;try{var R=s(u,o),H=F.S;H!==null&&H(M,R),ym(e,n,R)}catch(it){of(e,n,it)}finally{F.T=h}}else try{h=s(u,o),ym(e,n,h)}catch(it){of(e,n,it)}}function ym(e,n,s){s!==null&&typeof s=="object"&&typeof s.then=="function"?s.then(function(o){Mm(e,n,o)},function(o){return of(e,n,o)}):Mm(e,n,s)}function Mm(e,n,s){n.status="fulfilled",n.value=s,bm(n),e.state=s,n=e.pending,n!==null&&(s=n.next,s===n?e.pending=null:(s=s.next,n.next=s,Sm(e,s)))}function of(e,n,s){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do n.status="rejected",n.reason=s,bm(n),n=n.next;while(n!==o)}e.action=null}function bm(e){e=e.listeners;for(var n=0;n<e.length;n++)(0,e[n])()}function Em(e,n){return n}function Tm(e,n){if(Fe){var s=$e.formState;if(s!==null){t:{var o=Me;if(Fe){if(ln){e:{for(var u=ln,h=Bi;u.nodeType!==8;){if(!h){u=null;break e}if(u=Ai(u.nextSibling),u===null){u=null;break e}}h=u.data,u=h==="F!"||h==="F"?u:null}if(u){ln=Ai(u.nextSibling),o=u.data==="F!";break t}}Ss(o)}o=!1}o&&(n=s[0])}}return s=Kn(),s.memoizedState=s.baseState=n,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Em,lastRenderedState:n},s.queue=o,s=Xm.bind(null,Me,o),o.dispatch=s,o=rf(!1),h=hf.bind(null,Me,!1,o.queue),o=Kn(),u={state:n,dispatch:null,action:e,pending:null},o.queue=u,s=N_.bind(null,Me,u,h,s),u.dispatch=s,o.memoizedState=e,[n,s,!1]}function Am(e){var n=xn();return wm(n,Ye,e)}function wm(e,n,s){if(n=af(e,n,Em)[0],e=Ol(la)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var o=So(n)}catch(M){throw M===po?Cl:M}else o=n;n=xn();var u=n.queue,h=u.dispatch;return s!==n.memoizedState&&(Me.flags|=2048,sr(9,Il(),U_.bind(null,u,s),null)),[o,h,e]}function U_(e,n){e.action=n}function Rm(e){var n=xn(),s=Ye;if(s!==null)return wm(n,s,e);xn(),n=n.memoizedState,s=xn();var o=s.queue.dispatch;return s.memoizedState=e,[n,o,!1]}function sr(e,n,s,o){return e={tag:e,create:s,deps:o,inst:n,next:null},n=Me.updateQueue,n===null&&(n=ef(),Me.updateQueue=n),s=n.lastEffect,s===null?n.lastEffect=e.next=e:(o=s.next,s.next=e,e.next=o,n.lastEffect=e),e}function Il(){return{destroy:void 0,resource:void 0}}function Cm(){return xn().memoizedState}function Bl(e,n,s,o){var u=Kn();o=o===void 0?null:o,Me.flags|=e,u.memoizedState=sr(1|n,Il(),s,o)}function yo(e,n,s,o){var u=xn();o=o===void 0?null:o;var h=u.memoizedState.inst;Ye!==null&&o!==null&&Ku(o,Ye.memoizedState.deps)?u.memoizedState=sr(n,h,s,o):(Me.flags|=e,u.memoizedState=sr(1|n,h,s,o))}function Dm(e,n){Bl(8390656,8,e,n)}function Nm(e,n){yo(2048,8,e,n)}function Um(e,n){return yo(4,2,e,n)}function Lm(e,n){return yo(4,4,e,n)}function Pm(e,n){if(typeof n=="function"){e=e();var s=n(e);return function(){typeof s=="function"?s():n(null)}}if(n!=null)return e=e(),n.current=e,function(){n.current=null}}function Om(e,n,s){s=s!=null?s.concat([e]):null,yo(4,4,Pm.bind(null,n,e),s)}function lf(){}function Im(e,n){var s=xn();n=n===void 0?null:n;var o=s.memoizedState;return n!==null&&Ku(n,o[1])?o[0]:(s.memoizedState=[e,n],e)}function Bm(e,n){var s=xn();n=n===void 0?null:n;var o=s.memoizedState;if(n!==null&&Ku(n,o[1]))return o[0];if(o=e(),Es){$(!0);try{e()}finally{$(!1)}}return s.memoizedState=[o,n],o}function cf(e,n,s){return s===void 0||(Ia&1073741824)!==0?e.memoizedState=n:(e.memoizedState=s,e=G0(),Me.lanes|=e,ka|=e,s)}function Fm(e,n,s,o){return ni(s,n)?s:nr.current!==null?(e=cf(e,s,o),ni(e,n)||(Tn=!0),e):(Ia&42)===0?(Tn=!0,e.memoizedState=s):(e=G0(),Me.lanes|=e,ka|=e,n)}function zm(e,n,s,o,u){var h=V.p;V.p=h!==0&&8>h?h:8;var M=F.T,R={};F.T=R,hf(e,!1,n,s);try{var H=u(),it=F.S;if(it!==null&&it(R,H),H!==null&&typeof H=="object"&&typeof H.then=="function"){var vt=R_(H,o);Mo(e,n,vt,oi(e))}else Mo(e,n,o,oi(e))}catch(yt){Mo(e,n,{then:function(){},status:"rejected",reason:yt},oi())}finally{V.p=h,F.T=M}}function L_(){}function uf(e,n,s,o){if(e.tag!==5)throw Error(a(476));var u=Gm(e).queue;zm(e,u,n,rt,s===null?L_:function(){return Hm(e),s(o)})}function Gm(e){var n=e.memoizedState;if(n!==null)return n;n={memoizedState:rt,baseState:rt,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:la,lastRenderedState:rt},next:null};var s={};return n.next={memoizedState:s,baseState:s,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:la,lastRenderedState:s},next:null},e.memoizedState=n,e=e.alternate,e!==null&&(e.memoizedState=n),n}function Hm(e){var n=Gm(e).next.queue;Mo(e,n,{},oi())}function ff(){return In(Go)}function Vm(){return xn().memoizedState}function km(){return xn().memoizedState}function P_(e){for(var n=e.return;n!==null;){switch(n.tag){case 24:case 3:var s=oi();e=Pa(s);var o=Oa(n,e,s);o!==null&&(li(o,n,s),go(o,n,s)),n={cache:Gu()},e.payload=n;return}n=n.return}}function O_(e,n,s){var o=oi();s={lane:o,revertLane:0,action:s,hasEagerState:!1,eagerState:null,next:null},Fl(e)?Wm(n,s):(s=Du(e,n,s,o),s!==null&&(li(s,e,o),qm(s,n,o)))}function Xm(e,n,s){var o=oi();Mo(e,n,s,o)}function Mo(e,n,s,o){var u={lane:o,revertLane:0,action:s,hasEagerState:!1,eagerState:null,next:null};if(Fl(e))Wm(n,u);else{var h=e.alternate;if(e.lanes===0&&(h===null||h.lanes===0)&&(h=n.lastRenderedReducer,h!==null))try{var M=n.lastRenderedState,R=h(M,s);if(u.hasEagerState=!0,u.eagerState=R,ni(R,M))return yl(e,n,u,0),$e===null&&Sl(),!1}catch{}if(s=Du(e,n,u,o),s!==null)return li(s,e,o),qm(s,n,o),!0}return!1}function hf(e,n,s,o){if(o={lane:2,revertLane:Xf(),action:o,hasEagerState:!1,eagerState:null,next:null},Fl(e)){if(n)throw Error(a(479))}else n=Du(e,s,o,2),n!==null&&li(n,e,2)}function Fl(e){var n=e.alternate;return e===Me||n!==null&&n===Me}function Wm(e,n){ir=Ul=!0;var s=e.pending;s===null?n.next=n:(n.next=s.next,s.next=n),e.pending=n}function qm(e,n,s){if((s&4194048)!==0){var o=n.lanes;o&=e.pendingLanes,s|=o,n.lanes=s,zt(e,s)}}var zl={readContext:In,use:Pl,useCallback:dn,useContext:dn,useEffect:dn,useImperativeHandle:dn,useLayoutEffect:dn,useInsertionEffect:dn,useMemo:dn,useReducer:dn,useRef:dn,useState:dn,useDebugValue:dn,useDeferredValue:dn,useTransition:dn,useSyncExternalStore:dn,useId:dn,useHostTransitionStatus:dn,useFormState:dn,useActionState:dn,useOptimistic:dn,useMemoCache:dn,useCacheRefresh:dn},jm={readContext:In,use:Pl,useCallback:function(e,n){return Kn().memoizedState=[e,n===void 0?null:n],e},useContext:In,useEffect:Dm,useImperativeHandle:function(e,n,s){s=s!=null?s.concat([e]):null,Bl(4194308,4,Pm.bind(null,n,e),s)},useLayoutEffect:function(e,n){return Bl(4194308,4,e,n)},useInsertionEffect:function(e,n){Bl(4,2,e,n)},useMemo:function(e,n){var s=Kn();n=n===void 0?null:n;var o=e();if(Es){$(!0);try{e()}finally{$(!1)}}return s.memoizedState=[o,n],o},useReducer:function(e,n,s){var o=Kn();if(s!==void 0){var u=s(n);if(Es){$(!0);try{s(n)}finally{$(!1)}}}else u=n;return o.memoizedState=o.baseState=u,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:u},o.queue=e,e=e.dispatch=O_.bind(null,Me,e),[o.memoizedState,e]},useRef:function(e){var n=Kn();return e={current:e},n.memoizedState=e},useState:function(e){e=rf(e);var n=e.queue,s=Xm.bind(null,Me,n);return n.dispatch=s,[e.memoizedState,s]},useDebugValue:lf,useDeferredValue:function(e,n){var s=Kn();return cf(s,e,n)},useTransition:function(){var e=rf(!1);return e=zm.bind(null,Me,e.queue,!0,!1),Kn().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,n,s){var o=Me,u=Kn();if(Fe){if(s===void 0)throw Error(a(407));s=s()}else{if(s=n(),$e===null)throw Error(a(349));(Le&124)!==0||pm(o,n,s)}u.memoizedState=s;var h={value:s,getSnapshot:n};return u.queue=h,Dm(gm.bind(null,o,h,e),[e]),o.flags|=2048,sr(9,Il(),mm.bind(null,o,h,s,n),null),s},useId:function(){var e=Kn(),n=$e.identifierPrefix;if(Fe){var s=sa,o=aa;s=(o&~(1<<32-ht(o)-1)).toString(32)+s,n="«"+n+"R"+s,s=Ll++,0<s&&(n+="H"+s.toString(32)),n+="»"}else s=C_++,n="«"+n+"r"+s.toString(32)+"»";return e.memoizedState=n},useHostTransitionStatus:ff,useFormState:Tm,useActionState:Tm,useOptimistic:function(e){var n=Kn();n.memoizedState=n.baseState=e;var s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=s,n=hf.bind(null,Me,!0,s),s.dispatch=n,[e,n]},useMemoCache:nf,useCacheRefresh:function(){return Kn().memoizedState=P_.bind(null,Me)}},Ym={readContext:In,use:Pl,useCallback:Im,useContext:In,useEffect:Nm,useImperativeHandle:Om,useInsertionEffect:Um,useLayoutEffect:Lm,useMemo:Bm,useReducer:Ol,useRef:Cm,useState:function(){return Ol(la)},useDebugValue:lf,useDeferredValue:function(e,n){var s=xn();return Fm(s,Ye.memoizedState,e,n)},useTransition:function(){var e=Ol(la)[0],n=xn().memoizedState;return[typeof e=="boolean"?e:So(e),n]},useSyncExternalStore:dm,useId:Vm,useHostTransitionStatus:ff,useFormState:Am,useActionState:Am,useOptimistic:function(e,n){var s=xn();return _m(s,Ye,e,n)},useMemoCache:nf,useCacheRefresh:km},I_={readContext:In,use:Pl,useCallback:Im,useContext:In,useEffect:Nm,useImperativeHandle:Om,useInsertionEffect:Um,useLayoutEffect:Lm,useMemo:Bm,useReducer:sf,useRef:Cm,useState:function(){return sf(la)},useDebugValue:lf,useDeferredValue:function(e,n){var s=xn();return Ye===null?cf(s,e,n):Fm(s,Ye.memoizedState,e,n)},useTransition:function(){var e=sf(la)[0],n=xn().memoizedState;return[typeof e=="boolean"?e:So(e),n]},useSyncExternalStore:dm,useId:Vm,useHostTransitionStatus:ff,useFormState:Rm,useActionState:Rm,useOptimistic:function(e,n){var s=xn();return Ye!==null?_m(s,Ye,e,n):(s.baseState=e,[e,s.queue.dispatch])},useMemoCache:nf,useCacheRefresh:km},rr=null,bo=0;function Gl(e){var n=bo;return bo+=1,rr===null&&(rr=[]),sm(rr,e,n)}function Eo(e,n){n=n.props.ref,e.ref=n!==void 0?n:null}function Hl(e,n){throw n.$$typeof===x?Error(a(525)):(e=Object.prototype.toString.call(n),Error(a(31,e==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":e)))}function Zm(e){var n=e._init;return n(e._payload)}function Km(e){function n(Q,q){if(e){var et=Q.deletions;et===null?(Q.deletions=[q],Q.flags|=16):et.push(q)}}function s(Q,q){if(!e)return null;for(;q!==null;)n(Q,q),q=q.sibling;return null}function o(Q){for(var q=new Map;Q!==null;)Q.key!==null?q.set(Q.key,Q):q.set(Q.index,Q),Q=Q.sibling;return q}function u(Q,q){return Q=ia(Q,q),Q.index=0,Q.sibling=null,Q}function h(Q,q,et){return Q.index=et,e?(et=Q.alternate,et!==null?(et=et.index,et<q?(Q.flags|=67108866,q):et):(Q.flags|=67108866,q)):(Q.flags|=1048576,q)}function M(Q){return e&&Q.alternate===null&&(Q.flags|=67108866),Q}function R(Q,q,et,_t){return q===null||q.tag!==6?(q=Uu(et,Q.mode,_t),q.return=Q,q):(q=u(q,et),q.return=Q,q)}function H(Q,q,et,_t){var Wt=et.type;return Wt===b?vt(Q,q,et.props.children,_t,et.key):q!==null&&(q.elementType===Wt||typeof Wt=="object"&&Wt!==null&&Wt.$$typeof===A&&Zm(Wt)===q.type)?(q=u(q,et.props),Eo(q,et),q.return=Q,q):(q=bl(et.type,et.key,et.props,null,Q.mode,_t),Eo(q,et),q.return=Q,q)}function it(Q,q,et,_t){return q===null||q.tag!==4||q.stateNode.containerInfo!==et.containerInfo||q.stateNode.implementation!==et.implementation?(q=Lu(et,Q.mode,_t),q.return=Q,q):(q=u(q,et.children||[]),q.return=Q,q)}function vt(Q,q,et,_t,Wt){return q===null||q.tag!==7?(q=gs(et,Q.mode,_t,Wt),q.return=Q,q):(q=u(q,et),q.return=Q,q)}function yt(Q,q,et){if(typeof q=="string"&&q!==""||typeof q=="number"||typeof q=="bigint")return q=Uu(""+q,Q.mode,et),q.return=Q,q;if(typeof q=="object"&&q!==null){switch(q.$$typeof){case g:return et=bl(q.type,q.key,q.props,null,Q.mode,et),Eo(et,q),et.return=Q,et;case y:return q=Lu(q,Q.mode,et),q.return=Q,q;case A:var _t=q._init;return q=_t(q._payload),yt(Q,q,et)}if(W(q)||Y(q))return q=gs(q,Q.mode,et,null),q.return=Q,q;if(typeof q.then=="function")return yt(Q,Gl(q),et);if(q.$$typeof===D)return yt(Q,wl(Q,q),et);Hl(Q,q)}return null}function st(Q,q,et,_t){var Wt=q!==null?q.key:null;if(typeof et=="string"&&et!==""||typeof et=="number"||typeof et=="bigint")return Wt!==null?null:R(Q,q,""+et,_t);if(typeof et=="object"&&et!==null){switch(et.$$typeof){case g:return et.key===Wt?H(Q,q,et,_t):null;case y:return et.key===Wt?it(Q,q,et,_t):null;case A:return Wt=et._init,et=Wt(et._payload),st(Q,q,et,_t)}if(W(et)||Y(et))return Wt!==null?null:vt(Q,q,et,_t,null);if(typeof et.then=="function")return st(Q,q,Gl(et),_t);if(et.$$typeof===D)return st(Q,q,wl(Q,et),_t);Hl(Q,et)}return null}function lt(Q,q,et,_t,Wt){if(typeof _t=="string"&&_t!==""||typeof _t=="number"||typeof _t=="bigint")return Q=Q.get(et)||null,R(q,Q,""+_t,Wt);if(typeof _t=="object"&&_t!==null){switch(_t.$$typeof){case g:return Q=Q.get(_t.key===null?et:_t.key)||null,H(q,Q,_t,Wt);case y:return Q=Q.get(_t.key===null?et:_t.key)||null,it(q,Q,_t,Wt);case A:var Ee=_t._init;return _t=Ee(_t._payload),lt(Q,q,et,_t,Wt)}if(W(_t)||Y(_t))return Q=Q.get(et)||null,vt(q,Q,_t,Wt,null);if(typeof _t.then=="function")return lt(Q,q,et,Gl(_t),Wt);if(_t.$$typeof===D)return lt(Q,q,et,wl(q,_t),Wt);Hl(q,_t)}return null}function se(Q,q,et,_t){for(var Wt=null,Ee=null,Jt=q,ie=q=0,wn=null;Jt!==null&&ie<et.length;ie++){Jt.index>ie?(wn=Jt,Jt=null):wn=Jt.sibling;var Ie=st(Q,Jt,et[ie],_t);if(Ie===null){Jt===null&&(Jt=wn);break}e&&Jt&&Ie.alternate===null&&n(Q,Jt),q=h(Ie,q,ie),Ee===null?Wt=Ie:Ee.sibling=Ie,Ee=Ie,Jt=wn}if(ie===et.length)return s(Q,Jt),Fe&&xs(Q,ie),Wt;if(Jt===null){for(;ie<et.length;ie++)Jt=yt(Q,et[ie],_t),Jt!==null&&(q=h(Jt,q,ie),Ee===null?Wt=Jt:Ee.sibling=Jt,Ee=Jt);return Fe&&xs(Q,ie),Wt}for(Jt=o(Jt);ie<et.length;ie++)wn=lt(Jt,Q,ie,et[ie],_t),wn!==null&&(e&&wn.alternate!==null&&Jt.delete(wn.key===null?ie:wn.key),q=h(wn,q,ie),Ee===null?Wt=wn:Ee.sibling=wn,Ee=wn);return e&&Jt.forEach(function(Ja){return n(Q,Ja)}),Fe&&xs(Q,ie),Wt}function ne(Q,q,et,_t){if(et==null)throw Error(a(151));for(var Wt=null,Ee=null,Jt=q,ie=q=0,wn=null,Ie=et.next();Jt!==null&&!Ie.done;ie++,Ie=et.next()){Jt.index>ie?(wn=Jt,Jt=null):wn=Jt.sibling;var Ja=st(Q,Jt,Ie.value,_t);if(Ja===null){Jt===null&&(Jt=wn);break}e&&Jt&&Ja.alternate===null&&n(Q,Jt),q=h(Ja,q,ie),Ee===null?Wt=Ja:Ee.sibling=Ja,Ee=Ja,Jt=wn}if(Ie.done)return s(Q,Jt),Fe&&xs(Q,ie),Wt;if(Jt===null){for(;!Ie.done;ie++,Ie=et.next())Ie=yt(Q,Ie.value,_t),Ie!==null&&(q=h(Ie,q,ie),Ee===null?Wt=Ie:Ee.sibling=Ie,Ee=Ie);return Fe&&xs(Q,ie),Wt}for(Jt=o(Jt);!Ie.done;ie++,Ie=et.next())Ie=lt(Jt,Q,ie,Ie.value,_t),Ie!==null&&(e&&Ie.alternate!==null&&Jt.delete(Ie.key===null?ie:Ie.key),q=h(Ie,q,ie),Ee===null?Wt=Ie:Ee.sibling=Ie,Ee=Ie);return e&&Jt.forEach(function(BS){return n(Q,BS)}),Fe&&xs(Q,ie),Wt}function Ke(Q,q,et,_t){if(typeof et=="object"&&et!==null&&et.type===b&&et.key===null&&(et=et.props.children),typeof et=="object"&&et!==null){switch(et.$$typeof){case g:t:{for(var Wt=et.key;q!==null;){if(q.key===Wt){if(Wt=et.type,Wt===b){if(q.tag===7){s(Q,q.sibling),_t=u(q,et.props.children),_t.return=Q,Q=_t;break t}}else if(q.elementType===Wt||typeof Wt=="object"&&Wt!==null&&Wt.$$typeof===A&&Zm(Wt)===q.type){s(Q,q.sibling),_t=u(q,et.props),Eo(_t,et),_t.return=Q,Q=_t;break t}s(Q,q);break}else n(Q,q);q=q.sibling}et.type===b?(_t=gs(et.props.children,Q.mode,_t,et.key),_t.return=Q,Q=_t):(_t=bl(et.type,et.key,et.props,null,Q.mode,_t),Eo(_t,et),_t.return=Q,Q=_t)}return M(Q);case y:t:{for(Wt=et.key;q!==null;){if(q.key===Wt)if(q.tag===4&&q.stateNode.containerInfo===et.containerInfo&&q.stateNode.implementation===et.implementation){s(Q,q.sibling),_t=u(q,et.children||[]),_t.return=Q,Q=_t;break t}else{s(Q,q);break}else n(Q,q);q=q.sibling}_t=Lu(et,Q.mode,_t),_t.return=Q,Q=_t}return M(Q);case A:return Wt=et._init,et=Wt(et._payload),Ke(Q,q,et,_t)}if(W(et))return se(Q,q,et,_t);if(Y(et)){if(Wt=Y(et),typeof Wt!="function")throw Error(a(150));return et=Wt.call(et),ne(Q,q,et,_t)}if(typeof et.then=="function")return Ke(Q,q,Gl(et),_t);if(et.$$typeof===D)return Ke(Q,q,wl(Q,et),_t);Hl(Q,et)}return typeof et=="string"&&et!==""||typeof et=="number"||typeof et=="bigint"?(et=""+et,q!==null&&q.tag===6?(s(Q,q.sibling),_t=u(q,et),_t.return=Q,Q=_t):(s(Q,q),_t=Uu(et,Q.mode,_t),_t.return=Q,Q=_t),M(Q)):s(Q,q)}return function(Q,q,et,_t){try{bo=0;var Wt=Ke(Q,q,et,_t);return rr=null,Wt}catch(Jt){if(Jt===po||Jt===Cl)throw Jt;var Ee=ii(29,Jt,null,Q.mode);return Ee.lanes=_t,Ee.return=Q,Ee}}}var or=Km(!0),Qm=Km(!1),xi=tt(null),Fi=null;function Ba(e){var n=e.alternate;St(Mn,Mn.current&1),St(xi,e),Fi===null&&(n===null||nr.current!==null||n.memoizedState!==null)&&(Fi=e)}function Jm(e){if(e.tag===22){if(St(Mn,Mn.current),St(xi,e),Fi===null){var n=e.alternate;n!==null&&n.memoizedState!==null&&(Fi=e)}}else Fa()}function Fa(){St(Mn,Mn.current),St(xi,xi.current)}function ca(e){dt(xi),Fi===e&&(Fi=null),dt(Mn)}var Mn=tt(0);function Vl(e){for(var n=e;n!==null;){if(n.tag===13){var s=n.memoizedState;if(s!==null&&(s=s.dehydrated,s===null||s.data==="$?"||nh(s)))return n}else if(n.tag===19&&n.memoizedProps.revealOrder!==void 0){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}function df(e,n,s,o){n=e.memoizedState,s=s(o,n),s=s==null?n:v({},n,s),e.memoizedState=s,e.lanes===0&&(e.updateQueue.baseState=s)}var pf={enqueueSetState:function(e,n,s){e=e._reactInternals;var o=oi(),u=Pa(o);u.payload=n,s!=null&&(u.callback=s),n=Oa(e,u,o),n!==null&&(li(n,e,o),go(n,e,o))},enqueueReplaceState:function(e,n,s){e=e._reactInternals;var o=oi(),u=Pa(o);u.tag=1,u.payload=n,s!=null&&(u.callback=s),n=Oa(e,u,o),n!==null&&(li(n,e,o),go(n,e,o))},enqueueForceUpdate:function(e,n){e=e._reactInternals;var s=oi(),o=Pa(s);o.tag=2,n!=null&&(o.callback=n),n=Oa(e,o,s),n!==null&&(li(n,e,s),go(n,e,s))}};function $m(e,n,s,o,u,h,M){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,h,M):n.prototype&&n.prototype.isPureReactComponent?!so(s,o)||!so(u,h):!0}function t0(e,n,s,o){e=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(s,o),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(s,o),n.state!==e&&pf.enqueueReplaceState(n,n.state,null)}function Ts(e,n){var s=n;if("ref"in n){s={};for(var o in n)o!=="ref"&&(s[o]=n[o])}if(e=e.defaultProps){s===n&&(s=v({},s));for(var u in e)s[u]===void 0&&(s[u]=e[u])}return s}var kl=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function e0(e){kl(e)}function n0(e){console.error(e)}function i0(e){kl(e)}function Xl(e,n){try{var s=e.onUncaughtError;s(n.value,{componentStack:n.stack})}catch(o){setTimeout(function(){throw o})}}function a0(e,n,s){try{var o=e.onCaughtError;o(s.value,{componentStack:s.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function mf(e,n,s){return s=Pa(s),s.tag=3,s.payload={element:null},s.callback=function(){Xl(e,n)},s}function s0(e){return e=Pa(e),e.tag=3,e}function r0(e,n,s,o){var u=s.type.getDerivedStateFromError;if(typeof u=="function"){var h=o.value;e.payload=function(){return u(h)},e.callback=function(){a0(n,s,o)}}var M=s.stateNode;M!==null&&typeof M.componentDidCatch=="function"&&(e.callback=function(){a0(n,s,o),typeof u!="function"&&(Xa===null?Xa=new Set([this]):Xa.add(this));var R=o.stack;this.componentDidCatch(o.value,{componentStack:R!==null?R:""})})}function B_(e,n,s,o,u){if(s.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(n=s.alternate,n!==null&&uo(n,s,u,!0),s=xi.current,s!==null){switch(s.tag){case 13:return Fi===null?zf():s.alternate===null&&cn===0&&(cn=3),s.flags&=-257,s.flags|=65536,s.lanes=u,o===ku?s.flags|=16384:(n=s.updateQueue,n===null?s.updateQueue=new Set([o]):n.add(o),Hf(e,o,u)),!1;case 22:return s.flags|=65536,o===ku?s.flags|=16384:(n=s.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([o])},s.updateQueue=n):(s=n.retryQueue,s===null?n.retryQueue=new Set([o]):s.add(o)),Hf(e,o,u)),!1}throw Error(a(435,s.tag))}return Hf(e,o,u),zf(),!1}if(Fe)return n=xi.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=u,o!==Iu&&(e=Error(a(422),{cause:o}),co(pi(e,s)))):(o!==Iu&&(n=Error(a(423),{cause:o}),co(pi(n,s))),e=e.current.alternate,e.flags|=65536,u&=-u,e.lanes|=u,o=pi(o,s),u=mf(e.stateNode,o,u),qu(e,u),cn!==4&&(cn=2)),!1;var h=Error(a(520),{cause:o});if(h=pi(h,s),No===null?No=[h]:No.push(h),cn!==4&&(cn=2),n===null)return!0;o=pi(o,s),s=n;do{switch(s.tag){case 3:return s.flags|=65536,e=u&-u,s.lanes|=e,e=mf(s.stateNode,o,e),qu(s,e),!1;case 1:if(n=s.type,h=s.stateNode,(s.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||h!==null&&typeof h.componentDidCatch=="function"&&(Xa===null||!Xa.has(h))))return s.flags|=65536,u&=-u,s.lanes|=u,u=s0(u),r0(u,e,s,o),qu(s,u),!1}s=s.return}while(s!==null);return!1}var o0=Error(a(461)),Tn=!1;function Un(e,n,s,o){n.child=e===null?Qm(n,null,s,o):or(n,e.child,s,o)}function l0(e,n,s,o,u){s=s.render;var h=n.ref;if("ref"in o){var M={};for(var R in o)R!=="ref"&&(M[R]=o[R])}else M=o;return Ms(n),o=Qu(e,n,s,M,h,u),R=Ju(),e!==null&&!Tn?($u(e,n,u),ua(e,n,u)):(Fe&&R&&Pu(n),n.flags|=1,Un(e,n,o,u),n.child)}function c0(e,n,s,o,u){if(e===null){var h=s.type;return typeof h=="function"&&!Nu(h)&&h.defaultProps===void 0&&s.compare===null?(n.tag=15,n.type=h,u0(e,n,h,o,u)):(e=bl(s.type,null,o,n,n.mode,u),e.ref=n.ref,e.return=n,n.child=e)}if(h=e.child,!bf(e,u)){var M=h.memoizedProps;if(s=s.compare,s=s!==null?s:so,s(M,o)&&e.ref===n.ref)return ua(e,n,u)}return n.flags|=1,e=ia(h,o),e.ref=n.ref,e.return=n,n.child=e}function u0(e,n,s,o,u){if(e!==null){var h=e.memoizedProps;if(so(h,o)&&e.ref===n.ref)if(Tn=!1,n.pendingProps=o=h,bf(e,u))(e.flags&131072)!==0&&(Tn=!0);else return n.lanes=e.lanes,ua(e,n,u)}return gf(e,n,s,o,u)}function f0(e,n,s){var o=n.pendingProps,u=o.children,h=e!==null?e.memoizedState:null;if(o.mode==="hidden"){if((n.flags&128)!==0){if(o=h!==null?h.baseLanes|s:s,e!==null){for(u=n.child=e.child,h=0;u!==null;)h=h|u.lanes|u.childLanes,u=u.sibling;n.childLanes=h&~o}else n.childLanes=0,n.child=null;return h0(e,n,o,s)}if((s&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},e!==null&&Rl(n,h!==null?h.cachePool:null),h!==null?um(n,h):Yu(),Jm(n);else return n.lanes=n.childLanes=536870912,h0(e,n,h!==null?h.baseLanes|s:s,s)}else h!==null?(Rl(n,h.cachePool),um(n,h),Fa(),n.memoizedState=null):(e!==null&&Rl(n,null),Yu(),Fa());return Un(e,n,u,s),n.child}function h0(e,n,s,o){var u=Vu();return u=u===null?null:{parent:yn._currentValue,pool:u},n.memoizedState={baseLanes:s,cachePool:u},e!==null&&Rl(n,null),Yu(),Jm(n),e!==null&&uo(e,n,o,!0),null}function Wl(e,n){var s=n.ref;if(s===null)e!==null&&e.ref!==null&&(n.flags|=4194816);else{if(typeof s!="function"&&typeof s!="object")throw Error(a(284));(e===null||e.ref!==s)&&(n.flags|=4194816)}}function gf(e,n,s,o,u){return Ms(n),s=Qu(e,n,s,o,void 0,u),o=Ju(),e!==null&&!Tn?($u(e,n,u),ua(e,n,u)):(Fe&&o&&Pu(n),n.flags|=1,Un(e,n,s,u),n.child)}function d0(e,n,s,o,u,h){return Ms(n),n.updateQueue=null,s=hm(n,o,s,u),fm(e),o=Ju(),e!==null&&!Tn?($u(e,n,h),ua(e,n,h)):(Fe&&o&&Pu(n),n.flags|=1,Un(e,n,s,h),n.child)}function p0(e,n,s,o,u){if(Ms(n),n.stateNode===null){var h=Qs,M=s.contextType;typeof M=="object"&&M!==null&&(h=In(M)),h=new s(o,h),n.memoizedState=h.state!==null&&h.state!==void 0?h.state:null,h.updater=pf,n.stateNode=h,h._reactInternals=n,h=n.stateNode,h.props=o,h.state=n.memoizedState,h.refs={},Xu(n),M=s.contextType,h.context=typeof M=="object"&&M!==null?In(M):Qs,h.state=n.memoizedState,M=s.getDerivedStateFromProps,typeof M=="function"&&(df(n,s,M,o),h.state=n.memoizedState),typeof s.getDerivedStateFromProps=="function"||typeof h.getSnapshotBeforeUpdate=="function"||typeof h.UNSAFE_componentWillMount!="function"&&typeof h.componentWillMount!="function"||(M=h.state,typeof h.componentWillMount=="function"&&h.componentWillMount(),typeof h.UNSAFE_componentWillMount=="function"&&h.UNSAFE_componentWillMount(),M!==h.state&&pf.enqueueReplaceState(h,h.state,null),xo(n,o,h,u),vo(),h.state=n.memoizedState),typeof h.componentDidMount=="function"&&(n.flags|=4194308),o=!0}else if(e===null){h=n.stateNode;var R=n.memoizedProps,H=Ts(s,R);h.props=H;var it=h.context,vt=s.contextType;M=Qs,typeof vt=="object"&&vt!==null&&(M=In(vt));var yt=s.getDerivedStateFromProps;vt=typeof yt=="function"||typeof h.getSnapshotBeforeUpdate=="function",R=n.pendingProps!==R,vt||typeof h.UNSAFE_componentWillReceiveProps!="function"&&typeof h.componentWillReceiveProps!="function"||(R||it!==M)&&t0(n,h,o,M),La=!1;var st=n.memoizedState;h.state=st,xo(n,o,h,u),vo(),it=n.memoizedState,R||st!==it||La?(typeof yt=="function"&&(df(n,s,yt,o),it=n.memoizedState),(H=La||$m(n,s,H,o,st,it,M))?(vt||typeof h.UNSAFE_componentWillMount!="function"&&typeof h.componentWillMount!="function"||(typeof h.componentWillMount=="function"&&h.componentWillMount(),typeof h.UNSAFE_componentWillMount=="function"&&h.UNSAFE_componentWillMount()),typeof h.componentDidMount=="function"&&(n.flags|=4194308)):(typeof h.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=o,n.memoizedState=it),h.props=o,h.state=it,h.context=M,o=H):(typeof h.componentDidMount=="function"&&(n.flags|=4194308),o=!1)}else{h=n.stateNode,Wu(e,n),M=n.memoizedProps,vt=Ts(s,M),h.props=vt,yt=n.pendingProps,st=h.context,it=s.contextType,H=Qs,typeof it=="object"&&it!==null&&(H=In(it)),R=s.getDerivedStateFromProps,(it=typeof R=="function"||typeof h.getSnapshotBeforeUpdate=="function")||typeof h.UNSAFE_componentWillReceiveProps!="function"&&typeof h.componentWillReceiveProps!="function"||(M!==yt||st!==H)&&t0(n,h,o,H),La=!1,st=n.memoizedState,h.state=st,xo(n,o,h,u),vo();var lt=n.memoizedState;M!==yt||st!==lt||La||e!==null&&e.dependencies!==null&&Al(e.dependencies)?(typeof R=="function"&&(df(n,s,R,o),lt=n.memoizedState),(vt=La||$m(n,s,vt,o,st,lt,H)||e!==null&&e.dependencies!==null&&Al(e.dependencies))?(it||typeof h.UNSAFE_componentWillUpdate!="function"&&typeof h.componentWillUpdate!="function"||(typeof h.componentWillUpdate=="function"&&h.componentWillUpdate(o,lt,H),typeof h.UNSAFE_componentWillUpdate=="function"&&h.UNSAFE_componentWillUpdate(o,lt,H)),typeof h.componentDidUpdate=="function"&&(n.flags|=4),typeof h.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof h.componentDidUpdate!="function"||M===e.memoizedProps&&st===e.memoizedState||(n.flags|=4),typeof h.getSnapshotBeforeUpdate!="function"||M===e.memoizedProps&&st===e.memoizedState||(n.flags|=1024),n.memoizedProps=o,n.memoizedState=lt),h.props=o,h.state=lt,h.context=H,o=vt):(typeof h.componentDidUpdate!="function"||M===e.memoizedProps&&st===e.memoizedState||(n.flags|=4),typeof h.getSnapshotBeforeUpdate!="function"||M===e.memoizedProps&&st===e.memoizedState||(n.flags|=1024),o=!1)}return h=o,Wl(e,n),o=(n.flags&128)!==0,h||o?(h=n.stateNode,s=o&&typeof s.getDerivedStateFromError!="function"?null:h.render(),n.flags|=1,e!==null&&o?(n.child=or(n,e.child,null,u),n.child=or(n,null,s,u)):Un(e,n,s,u),n.memoizedState=h.state,e=n.child):e=ua(e,n,u),e}function m0(e,n,s,o){return lo(),n.flags|=256,Un(e,n,s,o),n.child}var vf={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function xf(e){return{baseLanes:e,cachePool:nm()}}function _f(e,n,s){return e=e!==null?e.childLanes&~s:0,n&&(e|=_i),e}function g0(e,n,s){var o=n.pendingProps,u=!1,h=(n.flags&128)!==0,M;if((M=h)||(M=e!==null&&e.memoizedState===null?!1:(Mn.current&2)!==0),M&&(u=!0,n.flags&=-129),M=(n.flags&32)!==0,n.flags&=-33,e===null){if(Fe){if(u?Ba(n):Fa(),Fe){var R=ln,H;if(H=R){t:{for(H=R,R=Bi;H.nodeType!==8;){if(!R){R=null;break t}if(H=Ai(H.nextSibling),H===null){R=null;break t}}R=H}R!==null?(n.memoizedState={dehydrated:R,treeContext:vs!==null?{id:aa,overflow:sa}:null,retryLane:536870912,hydrationErrors:null},H=ii(18,null,null,0),H.stateNode=R,H.return=n,n.child=H,kn=n,ln=null,H=!0):H=!1}H||Ss(n)}if(R=n.memoizedState,R!==null&&(R=R.dehydrated,R!==null))return nh(R)?n.lanes=32:n.lanes=536870912,null;ca(n)}return R=o.children,o=o.fallback,u?(Fa(),u=n.mode,R=ql({mode:"hidden",children:R},u),o=gs(o,u,s,null),R.return=n,o.return=n,R.sibling=o,n.child=R,u=n.child,u.memoizedState=xf(s),u.childLanes=_f(e,M,s),n.memoizedState=vf,o):(Ba(n),Sf(n,R))}if(H=e.memoizedState,H!==null&&(R=H.dehydrated,R!==null)){if(h)n.flags&256?(Ba(n),n.flags&=-257,n=yf(e,n,s)):n.memoizedState!==null?(Fa(),n.child=e.child,n.flags|=128,n=null):(Fa(),u=o.fallback,R=n.mode,o=ql({mode:"visible",children:o.children},R),u=gs(u,R,s,null),u.flags|=2,o.return=n,u.return=n,o.sibling=u,n.child=o,or(n,e.child,null,s),o=n.child,o.memoizedState=xf(s),o.childLanes=_f(e,M,s),n.memoizedState=vf,n=u);else if(Ba(n),nh(R)){if(M=R.nextSibling&&R.nextSibling.dataset,M)var it=M.dgst;M=it,o=Error(a(419)),o.stack="",o.digest=M,co({value:o,source:null,stack:null}),n=yf(e,n,s)}else if(Tn||uo(e,n,s,!1),M=(s&e.childLanes)!==0,Tn||M){if(M=$e,M!==null&&(o=s&-s,o=(o&42)!==0?1:Dt(o),o=(o&(M.suspendedLanes|s))!==0?0:o,o!==0&&o!==H.retryLane))throw H.retryLane=o,Ks(e,o),li(M,e,o),o0;R.data==="$?"||zf(),n=yf(e,n,s)}else R.data==="$?"?(n.flags|=192,n.child=e.child,n=null):(e=H.treeContext,ln=Ai(R.nextSibling),kn=n,Fe=!0,_s=null,Bi=!1,e!==null&&(gi[vi++]=aa,gi[vi++]=sa,gi[vi++]=vs,aa=e.id,sa=e.overflow,vs=n),n=Sf(n,o.children),n.flags|=4096);return n}return u?(Fa(),u=o.fallback,R=n.mode,H=e.child,it=H.sibling,o=ia(H,{mode:"hidden",children:o.children}),o.subtreeFlags=H.subtreeFlags&65011712,it!==null?u=ia(it,u):(u=gs(u,R,s,null),u.flags|=2),u.return=n,o.return=n,o.sibling=u,n.child=o,o=u,u=n.child,R=e.child.memoizedState,R===null?R=xf(s):(H=R.cachePool,H!==null?(it=yn._currentValue,H=H.parent!==it?{parent:it,pool:it}:H):H=nm(),R={baseLanes:R.baseLanes|s,cachePool:H}),u.memoizedState=R,u.childLanes=_f(e,M,s),n.memoizedState=vf,o):(Ba(n),s=e.child,e=s.sibling,s=ia(s,{mode:"visible",children:o.children}),s.return=n,s.sibling=null,e!==null&&(M=n.deletions,M===null?(n.deletions=[e],n.flags|=16):M.push(e)),n.child=s,n.memoizedState=null,s)}function Sf(e,n){return n=ql({mode:"visible",children:n},e.mode),n.return=e,e.child=n}function ql(e,n){return e=ii(22,e,null,n),e.lanes=0,e.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null},e}function yf(e,n,s){return or(n,e.child,null,s),e=Sf(n,n.pendingProps.children),e.flags|=2,n.memoizedState=null,e}function v0(e,n,s){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n),Fu(e.return,n,s)}function Mf(e,n,s,o,u){var h=e.memoizedState;h===null?e.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:o,tail:s,tailMode:u}:(h.isBackwards=n,h.rendering=null,h.renderingStartTime=0,h.last=o,h.tail=s,h.tailMode=u)}function x0(e,n,s){var o=n.pendingProps,u=o.revealOrder,h=o.tail;if(Un(e,n,o.children,s),o=Mn.current,(o&2)!==0)o=o&1|2,n.flags|=128;else{if(e!==null&&(e.flags&128)!==0)t:for(e=n.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&v0(e,s,n);else if(e.tag===19)v0(e,s,n);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===n)break t;for(;e.sibling===null;){if(e.return===null||e.return===n)break t;e=e.return}e.sibling.return=e.return,e=e.sibling}o&=1}switch(St(Mn,o),u){case"forwards":for(s=n.child,u=null;s!==null;)e=s.alternate,e!==null&&Vl(e)===null&&(u=s),s=s.sibling;s=u,s===null?(u=n.child,n.child=null):(u=s.sibling,s.sibling=null),Mf(n,!1,u,s,h);break;case"backwards":for(s=null,u=n.child,n.child=null;u!==null;){if(e=u.alternate,e!==null&&Vl(e)===null){n.child=u;break}e=u.sibling,u.sibling=s,s=u,u=e}Mf(n,!0,s,null,h);break;case"together":Mf(n,!1,null,null,void 0);break;default:n.memoizedState=null}return n.child}function ua(e,n,s){if(e!==null&&(n.dependencies=e.dependencies),ka|=n.lanes,(s&n.childLanes)===0)if(e!==null){if(uo(e,n,s,!1),(s&n.childLanes)===0)return null}else return null;if(e!==null&&n.child!==e.child)throw Error(a(153));if(n.child!==null){for(e=n.child,s=ia(e,e.pendingProps),n.child=s,s.return=n;e.sibling!==null;)e=e.sibling,s=s.sibling=ia(e,e.pendingProps),s.return=n;s.sibling=null}return n.child}function bf(e,n){return(e.lanes&n)!==0?!0:(e=e.dependencies,!!(e!==null&&Al(e)))}function F_(e,n,s){switch(n.tag){case 3:pt(n,n.stateNode.containerInfo),Ua(n,yn,e.memoizedState.cache),lo();break;case 27:case 5:$t(n);break;case 4:pt(n,n.stateNode.containerInfo);break;case 10:Ua(n,n.type,n.memoizedProps.value);break;case 13:var o=n.memoizedState;if(o!==null)return o.dehydrated!==null?(Ba(n),n.flags|=128,null):(s&n.child.childLanes)!==0?g0(e,n,s):(Ba(n),e=ua(e,n,s),e!==null?e.sibling:null);Ba(n);break;case 19:var u=(e.flags&128)!==0;if(o=(s&n.childLanes)!==0,o||(uo(e,n,s,!1),o=(s&n.childLanes)!==0),u){if(o)return x0(e,n,s);n.flags|=128}if(u=n.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),St(Mn,Mn.current),o)break;return null;case 22:case 23:return n.lanes=0,f0(e,n,s);case 24:Ua(n,yn,e.memoizedState.cache)}return ua(e,n,s)}function _0(e,n,s){if(e!==null)if(e.memoizedProps!==n.pendingProps)Tn=!0;else{if(!bf(e,s)&&(n.flags&128)===0)return Tn=!1,F_(e,n,s);Tn=(e.flags&131072)!==0}else Tn=!1,Fe&&(n.flags&1048576)!==0&&Zp(n,Tl,n.index);switch(n.lanes=0,n.tag){case 16:t:{e=n.pendingProps;var o=n.elementType,u=o._init;if(o=u(o._payload),n.type=o,typeof o=="function")Nu(o)?(e=Ts(o,e),n.tag=1,n=p0(null,n,o,e,s)):(n.tag=0,n=gf(null,n,o,e,s));else{if(o!=null){if(u=o.$$typeof,u===U){n.tag=11,n=l0(null,n,o,e,s);break t}else if(u===z){n.tag=14,n=c0(null,n,o,e,s);break t}}throw n=ut(o)||o,Error(a(306,n,""))}}return n;case 0:return gf(e,n,n.type,n.pendingProps,s);case 1:return o=n.type,u=Ts(o,n.pendingProps),p0(e,n,o,u,s);case 3:t:{if(pt(n,n.stateNode.containerInfo),e===null)throw Error(a(387));o=n.pendingProps;var h=n.memoizedState;u=h.element,Wu(e,n),xo(n,o,null,s);var M=n.memoizedState;if(o=M.cache,Ua(n,yn,o),o!==h.cache&&zu(n,[yn],s,!0),vo(),o=M.element,h.isDehydrated)if(h={element:o,isDehydrated:!1,cache:M.cache},n.updateQueue.baseState=h,n.memoizedState=h,n.flags&256){n=m0(e,n,o,s);break t}else if(o!==u){u=pi(Error(a(424)),n),co(u),n=m0(e,n,o,s);break t}else for(e=n.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,ln=Ai(e.firstChild),kn=n,Fe=!0,_s=null,Bi=!0,s=Qm(n,null,o,s),n.child=s;s;)s.flags=s.flags&-3|4096,s=s.sibling;else{if(lo(),o===u){n=ua(e,n,s);break t}Un(e,n,o,s)}n=n.child}return n;case 26:return Wl(e,n),e===null?(s=bg(n.type,null,n.pendingProps,null))?n.memoizedState=s:Fe||(s=n.type,e=n.pendingProps,o=rc(J.current).createElement(s),o[ce]=n,o[en]=e,Pn(o,s,e),rn(o),n.stateNode=o):n.memoizedState=bg(n.type,e.memoizedProps,n.pendingProps,e.memoizedState),null;case 27:return $t(n),e===null&&Fe&&(o=n.stateNode=Sg(n.type,n.pendingProps,J.current),kn=n,Bi=!0,u=ln,ja(n.type)?(ih=u,ln=Ai(o.firstChild)):ln=u),Un(e,n,n.pendingProps.children,s),Wl(e,n),e===null&&(n.flags|=4194304),n.child;case 5:return e===null&&Fe&&((u=o=ln)&&(o=hS(o,n.type,n.pendingProps,Bi),o!==null?(n.stateNode=o,kn=n,ln=Ai(o.firstChild),Bi=!1,u=!0):u=!1),u||Ss(n)),$t(n),u=n.type,h=n.pendingProps,M=e!==null?e.memoizedProps:null,o=h.children,$f(u,h)?o=null:M!==null&&$f(u,M)&&(n.flags|=32),n.memoizedState!==null&&(u=Qu(e,n,D_,null,null,s),Go._currentValue=u),Wl(e,n),Un(e,n,o,s),n.child;case 6:return e===null&&Fe&&((e=s=ln)&&(s=dS(s,n.pendingProps,Bi),s!==null?(n.stateNode=s,kn=n,ln=null,e=!0):e=!1),e||Ss(n)),null;case 13:return g0(e,n,s);case 4:return pt(n,n.stateNode.containerInfo),o=n.pendingProps,e===null?n.child=or(n,null,o,s):Un(e,n,o,s),n.child;case 11:return l0(e,n,n.type,n.pendingProps,s);case 7:return Un(e,n,n.pendingProps,s),n.child;case 8:return Un(e,n,n.pendingProps.children,s),n.child;case 12:return Un(e,n,n.pendingProps.children,s),n.child;case 10:return o=n.pendingProps,Ua(n,n.type,o.value),Un(e,n,o.children,s),n.child;case 9:return u=n.type._context,o=n.pendingProps.children,Ms(n),u=In(u),o=o(u),n.flags|=1,Un(e,n,o,s),n.child;case 14:return c0(e,n,n.type,n.pendingProps,s);case 15:return u0(e,n,n.type,n.pendingProps,s);case 19:return x0(e,n,s);case 31:return o=n.pendingProps,s=n.mode,o={mode:o.mode,children:o.children},e===null?(s=ql(o,s),s.ref=n.ref,n.child=s,s.return=n,n=s):(s=ia(e.child,o),s.ref=n.ref,n.child=s,s.return=n,n=s),n;case 22:return f0(e,n,s);case 24:return Ms(n),o=In(yn),e===null?(u=Vu(),u===null&&(u=$e,h=Gu(),u.pooledCache=h,h.refCount++,h!==null&&(u.pooledCacheLanes|=s),u=h),n.memoizedState={parent:o,cache:u},Xu(n),Ua(n,yn,u)):((e.lanes&s)!==0&&(Wu(e,n),xo(n,null,null,s),vo()),u=e.memoizedState,h=n.memoizedState,u.parent!==o?(u={parent:o,cache:o},n.memoizedState=u,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=u),Ua(n,yn,o)):(o=h.cache,Ua(n,yn,o),o!==u.cache&&zu(n,[yn],s,!0))),Un(e,n,n.pendingProps.children,s),n.child;case 29:throw n.pendingProps}throw Error(a(156,n.tag))}function fa(e){e.flags|=4}function S0(e,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!Rg(n)){if(n=xi.current,n!==null&&((Le&4194048)===Le?Fi!==null:(Le&62914560)!==Le&&(Le&536870912)===0||n!==Fi))throw mo=ku,im;e.flags|=8192}}function jl(e,n){n!==null&&(e.flags|=4),e.flags&16384&&(n=e.tag!==22?fe():536870912,e.lanes|=n,fr|=n)}function To(e,n){if(!Fe)switch(e.tailMode){case"hidden":n=e.tail;for(var s=null;n!==null;)n.alternate!==null&&(s=n),n=n.sibling;s===null?e.tail=null:s.sibling=null;break;case"collapsed":s=e.tail;for(var o=null;s!==null;)s.alternate!==null&&(o=s),s=s.sibling;o===null?n||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null}}function on(e){var n=e.alternate!==null&&e.alternate.child===e.child,s=0,o=0;if(n)for(var u=e.child;u!==null;)s|=u.lanes|u.childLanes,o|=u.subtreeFlags&65011712,o|=u.flags&65011712,u.return=e,u=u.sibling;else for(u=e.child;u!==null;)s|=u.lanes|u.childLanes,o|=u.subtreeFlags,o|=u.flags,u.return=e,u=u.sibling;return e.subtreeFlags|=o,e.childLanes=s,n}function z_(e,n,s){var o=n.pendingProps;switch(Ou(n),n.tag){case 31:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return on(n),null;case 1:return on(n),null;case 3:return s=n.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),n.memoizedState.cache!==o&&(n.flags|=2048),oa(yn),Ft(),s.pendingContext&&(s.context=s.pendingContext,s.pendingContext=null),(e===null||e.child===null)&&(oo(n)?fa(n):e===null||e.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Jp())),on(n),null;case 26:return s=n.memoizedState,e===null?(fa(n),s!==null?(on(n),S0(n,s)):(on(n),n.flags&=-16777217)):s?s!==e.memoizedState?(fa(n),on(n),S0(n,s)):(on(n),n.flags&=-16777217):(e.memoizedProps!==o&&fa(n),on(n),n.flags&=-16777217),null;case 27:Zt(n),s=J.current;var u=n.type;if(e!==null&&n.stateNode!=null)e.memoizedProps!==o&&fa(n);else{if(!o){if(n.stateNode===null)throw Error(a(166));return on(n),null}e=Nt.current,oo(n)?Kp(n):(e=Sg(u,o,s),n.stateNode=e,fa(n))}return on(n),null;case 5:if(Zt(n),s=n.type,e!==null&&n.stateNode!=null)e.memoizedProps!==o&&fa(n);else{if(!o){if(n.stateNode===null)throw Error(a(166));return on(n),null}if(e=Nt.current,oo(n))Kp(n);else{switch(u=rc(J.current),e){case 1:e=u.createElementNS("http://www.w3.org/2000/svg",s);break;case 2:e=u.createElementNS("http://www.w3.org/1998/Math/MathML",s);break;default:switch(s){case"svg":e=u.createElementNS("http://www.w3.org/2000/svg",s);break;case"math":e=u.createElementNS("http://www.w3.org/1998/Math/MathML",s);break;case"script":e=u.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild);break;case"select":e=typeof o.is=="string"?u.createElement("select",{is:o.is}):u.createElement("select"),o.multiple?e.multiple=!0:o.size&&(e.size=o.size);break;default:e=typeof o.is=="string"?u.createElement(s,{is:o.is}):u.createElement(s)}}e[ce]=n,e[en]=o;t:for(u=n.child;u!==null;){if(u.tag===5||u.tag===6)e.appendChild(u.stateNode);else if(u.tag!==4&&u.tag!==27&&u.child!==null){u.child.return=u,u=u.child;continue}if(u===n)break t;for(;u.sibling===null;){if(u.return===null||u.return===n)break t;u=u.return}u.sibling.return=u.return,u=u.sibling}n.stateNode=e;t:switch(Pn(e,s,o),s){case"button":case"input":case"select":case"textarea":e=!!o.autoFocus;break t;case"img":e=!0;break t;default:e=!1}e&&fa(n)}}return on(n),n.flags&=-16777217,null;case 6:if(e&&n.stateNode!=null)e.memoizedProps!==o&&fa(n);else{if(typeof o!="string"&&n.stateNode===null)throw Error(a(166));if(e=J.current,oo(n)){if(e=n.stateNode,s=n.memoizedProps,o=null,u=kn,u!==null)switch(u.tag){case 27:case 5:o=u.memoizedProps}e[ce]=n,e=!!(e.nodeValue===s||o!==null&&o.suppressHydrationWarning===!0||dg(e.nodeValue,s)),e||Ss(n)}else e=rc(e).createTextNode(o),e[ce]=n,n.stateNode=e}return on(n),null;case 13:if(o=n.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(u=oo(n),o!==null&&o.dehydrated!==null){if(e===null){if(!u)throw Error(a(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(a(317));u[ce]=n}else lo(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;on(n),u=!1}else u=Jp(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=u),u=!0;if(!u)return n.flags&256?(ca(n),n):(ca(n),null)}if(ca(n),(n.flags&128)!==0)return n.lanes=s,n;if(s=o!==null,e=e!==null&&e.memoizedState!==null,s){o=n.child,u=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(u=o.alternate.memoizedState.cachePool.pool);var h=null;o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(h=o.memoizedState.cachePool.pool),h!==u&&(o.flags|=2048)}return s!==e&&s&&(n.child.flags|=8192),jl(n,n.updateQueue),on(n),null;case 4:return Ft(),e===null&&Yf(n.stateNode.containerInfo),on(n),null;case 10:return oa(n.type),on(n),null;case 19:if(dt(Mn),u=n.memoizedState,u===null)return on(n),null;if(o=(n.flags&128)!==0,h=u.rendering,h===null)if(o)To(u,!1);else{if(cn!==0||e!==null&&(e.flags&128)!==0)for(e=n.child;e!==null;){if(h=Vl(e),h!==null){for(n.flags|=128,To(u,!1),e=h.updateQueue,n.updateQueue=e,jl(n,e),n.subtreeFlags=0,e=s,s=n.child;s!==null;)Yp(s,e),s=s.sibling;return St(Mn,Mn.current&1|2),n.child}e=e.sibling}u.tail!==null&&ee()>Kl&&(n.flags|=128,o=!0,To(u,!1),n.lanes=4194304)}else{if(!o)if(e=Vl(h),e!==null){if(n.flags|=128,o=!0,e=e.updateQueue,n.updateQueue=e,jl(n,e),To(u,!0),u.tail===null&&u.tailMode==="hidden"&&!h.alternate&&!Fe)return on(n),null}else 2*ee()-u.renderingStartTime>Kl&&s!==536870912&&(n.flags|=128,o=!0,To(u,!1),n.lanes=4194304);u.isBackwards?(h.sibling=n.child,n.child=h):(e=u.last,e!==null?e.sibling=h:n.child=h,u.last=h)}return u.tail!==null?(n=u.tail,u.rendering=n,u.tail=n.sibling,u.renderingStartTime=ee(),n.sibling=null,e=Mn.current,St(Mn,o?e&1|2:e&1),n):(on(n),null);case 22:case 23:return ca(n),Zu(),o=n.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(n.flags|=8192):o&&(n.flags|=8192),o?(s&536870912)!==0&&(n.flags&128)===0&&(on(n),n.subtreeFlags&6&&(n.flags|=8192)):on(n),s=n.updateQueue,s!==null&&jl(n,s.retryQueue),s=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==s&&(n.flags|=2048),e!==null&&dt(bs),null;case 24:return s=null,e!==null&&(s=e.memoizedState.cache),n.memoizedState.cache!==s&&(n.flags|=2048),oa(yn),on(n),null;case 25:return null;case 30:return null}throw Error(a(156,n.tag))}function G_(e,n){switch(Ou(n),n.tag){case 1:return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 3:return oa(yn),Ft(),e=n.flags,(e&65536)!==0&&(e&128)===0?(n.flags=e&-65537|128,n):null;case 26:case 27:case 5:return Zt(n),null;case 13:if(ca(n),e=n.memoizedState,e!==null&&e.dehydrated!==null){if(n.alternate===null)throw Error(a(340));lo()}return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 19:return dt(Mn),null;case 4:return Ft(),null;case 10:return oa(n.type),null;case 22:case 23:return ca(n),Zu(),e!==null&&dt(bs),e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 24:return oa(yn),null;case 25:return null;default:return null}}function y0(e,n){switch(Ou(n),n.tag){case 3:oa(yn),Ft();break;case 26:case 27:case 5:Zt(n);break;case 4:Ft();break;case 13:ca(n);break;case 19:dt(Mn);break;case 10:oa(n.type);break;case 22:case 23:ca(n),Zu(),e!==null&&dt(bs);break;case 24:oa(yn)}}function Ao(e,n){try{var s=n.updateQueue,o=s!==null?s.lastEffect:null;if(o!==null){var u=o.next;s=u;do{if((s.tag&e)===e){o=void 0;var h=s.create,M=s.inst;o=h(),M.destroy=o}s=s.next}while(s!==u)}}catch(R){Qe(n,n.return,R)}}function za(e,n,s){try{var o=n.updateQueue,u=o!==null?o.lastEffect:null;if(u!==null){var h=u.next;o=h;do{if((o.tag&e)===e){var M=o.inst,R=M.destroy;if(R!==void 0){M.destroy=void 0,u=n;var H=s,it=R;try{it()}catch(vt){Qe(u,H,vt)}}}o=o.next}while(o!==h)}}catch(vt){Qe(n,n.return,vt)}}function M0(e){var n=e.updateQueue;if(n!==null){var s=e.stateNode;try{cm(n,s)}catch(o){Qe(e,e.return,o)}}}function b0(e,n,s){s.props=Ts(e.type,e.memoizedProps),s.state=e.memoizedState;try{s.componentWillUnmount()}catch(o){Qe(e,n,o)}}function wo(e,n){try{var s=e.ref;if(s!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:o=e.stateNode;break;default:o=e.stateNode}typeof s=="function"?e.refCleanup=s(o):s.current=o}}catch(u){Qe(e,n,u)}}function zi(e,n){var s=e.ref,o=e.refCleanup;if(s!==null)if(typeof o=="function")try{o()}catch(u){Qe(e,n,u)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof s=="function")try{s(null)}catch(u){Qe(e,n,u)}else s.current=null}function E0(e){var n=e.type,s=e.memoizedProps,o=e.stateNode;try{t:switch(n){case"button":case"input":case"select":case"textarea":s.autoFocus&&o.focus();break t;case"img":s.src?o.src=s.src:s.srcSet&&(o.srcset=s.srcSet)}}catch(u){Qe(e,e.return,u)}}function Ef(e,n,s){try{var o=e.stateNode;oS(o,e.type,s,n),o[en]=n}catch(u){Qe(e,e.return,u)}}function T0(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&ja(e.type)||e.tag===4}function Tf(e){t:for(;;){for(;e.sibling===null;){if(e.return===null||T0(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&ja(e.type)||e.flags&2||e.child===null||e.tag===4)continue t;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Af(e,n,s){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s).insertBefore(e,n):(n=s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,n.appendChild(e),s=s._reactRootContainer,s!=null||n.onclick!==null||(n.onclick=sc));else if(o!==4&&(o===27&&ja(e.type)&&(s=e.stateNode,n=null),e=e.child,e!==null))for(Af(e,n,s),e=e.sibling;e!==null;)Af(e,n,s),e=e.sibling}function Yl(e,n,s){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?s.insertBefore(e,n):s.appendChild(e);else if(o!==4&&(o===27&&ja(e.type)&&(s=e.stateNode),e=e.child,e!==null))for(Yl(e,n,s),e=e.sibling;e!==null;)Yl(e,n,s),e=e.sibling}function A0(e){var n=e.stateNode,s=e.memoizedProps;try{for(var o=e.type,u=n.attributes;u.length;)n.removeAttributeNode(u[0]);Pn(n,o,s),n[ce]=e,n[en]=s}catch(h){Qe(e,e.return,h)}}var ha=!1,pn=!1,wf=!1,w0=typeof WeakSet=="function"?WeakSet:Set,An=null;function H_(e,n){if(e=e.containerInfo,Qf=hc,e=Fp(e),Eu(e)){if("selectionStart"in e)var s={start:e.selectionStart,end:e.selectionEnd};else t:{s=(s=e.ownerDocument)&&s.defaultView||window;var o=s.getSelection&&s.getSelection();if(o&&o.rangeCount!==0){s=o.anchorNode;var u=o.anchorOffset,h=o.focusNode;o=o.focusOffset;try{s.nodeType,h.nodeType}catch{s=null;break t}var M=0,R=-1,H=-1,it=0,vt=0,yt=e,st=null;e:for(;;){for(var lt;yt!==s||u!==0&&yt.nodeType!==3||(R=M+u),yt!==h||o!==0&&yt.nodeType!==3||(H=M+o),yt.nodeType===3&&(M+=yt.nodeValue.length),(lt=yt.firstChild)!==null;)st=yt,yt=lt;for(;;){if(yt===e)break e;if(st===s&&++it===u&&(R=M),st===h&&++vt===o&&(H=M),(lt=yt.nextSibling)!==null)break;yt=st,st=yt.parentNode}yt=lt}s=R===-1||H===-1?null:{start:R,end:H}}else s=null}s=s||{start:0,end:0}}else s=null;for(Jf={focusedElem:e,selectionRange:s},hc=!1,An=n;An!==null;)if(n=An,e=n.child,(n.subtreeFlags&1024)!==0&&e!==null)e.return=n,An=e;else for(;An!==null;){switch(n=An,h=n.alternate,e=n.flags,n.tag){case 0:break;case 11:case 15:break;case 1:if((e&1024)!==0&&h!==null){e=void 0,s=n,u=h.memoizedProps,h=h.memoizedState,o=s.stateNode;try{var se=Ts(s.type,u,s.elementType===s.type);e=o.getSnapshotBeforeUpdate(se,h),o.__reactInternalSnapshotBeforeUpdate=e}catch(ne){Qe(s,s.return,ne)}}break;case 3:if((e&1024)!==0){if(e=n.stateNode.containerInfo,s=e.nodeType,s===9)eh(e);else if(s===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":eh(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(a(163))}if(e=n.sibling,e!==null){e.return=n.return,An=e;break}An=n.return}}function R0(e,n,s){var o=s.flags;switch(s.tag){case 0:case 11:case 15:Ga(e,s),o&4&&Ao(5,s);break;case 1:if(Ga(e,s),o&4)if(e=s.stateNode,n===null)try{e.componentDidMount()}catch(M){Qe(s,s.return,M)}else{var u=Ts(s.type,n.memoizedProps);n=n.memoizedState;try{e.componentDidUpdate(u,n,e.__reactInternalSnapshotBeforeUpdate)}catch(M){Qe(s,s.return,M)}}o&64&&M0(s),o&512&&wo(s,s.return);break;case 3:if(Ga(e,s),o&64&&(e=s.updateQueue,e!==null)){if(n=null,s.child!==null)switch(s.child.tag){case 27:case 5:n=s.child.stateNode;break;case 1:n=s.child.stateNode}try{cm(e,n)}catch(M){Qe(s,s.return,M)}}break;case 27:n===null&&o&4&&A0(s);case 26:case 5:Ga(e,s),n===null&&o&4&&E0(s),o&512&&wo(s,s.return);break;case 12:Ga(e,s);break;case 13:Ga(e,s),o&4&&N0(e,s),o&64&&(e=s.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(s=K_.bind(null,s),pS(e,s))));break;case 22:if(o=s.memoizedState!==null||ha,!o){n=n!==null&&n.memoizedState!==null||pn,u=ha;var h=pn;ha=o,(pn=n)&&!h?Ha(e,s,(s.subtreeFlags&8772)!==0):Ga(e,s),ha=u,pn=h}break;case 30:break;default:Ga(e,s)}}function C0(e){var n=e.alternate;n!==null&&(e.alternate=null,C0(n)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(n=e.stateNode,n!==null&&hs(n)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var sn=null,Qn=!1;function da(e,n,s){for(s=s.child;s!==null;)D0(e,n,s),s=s.sibling}function D0(e,n,s){if(E&&typeof E.onCommitFiberUnmount=="function")try{E.onCommitFiberUnmount(L,s)}catch{}switch(s.tag){case 26:pn||zi(s,n),da(e,n,s),s.memoizedState?s.memoizedState.count--:s.stateNode&&(s=s.stateNode,s.parentNode.removeChild(s));break;case 27:pn||zi(s,n);var o=sn,u=Qn;ja(s.type)&&(sn=s.stateNode,Qn=!1),da(e,n,s),Io(s.stateNode),sn=o,Qn=u;break;case 5:pn||zi(s,n);case 6:if(o=sn,u=Qn,sn=null,da(e,n,s),sn=o,Qn=u,sn!==null)if(Qn)try{(sn.nodeType===9?sn.body:sn.nodeName==="HTML"?sn.ownerDocument.body:sn).removeChild(s.stateNode)}catch(h){Qe(s,n,h)}else try{sn.removeChild(s.stateNode)}catch(h){Qe(s,n,h)}break;case 18:sn!==null&&(Qn?(e=sn,xg(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,s.stateNode),Xo(e)):xg(sn,s.stateNode));break;case 4:o=sn,u=Qn,sn=s.stateNode.containerInfo,Qn=!0,da(e,n,s),sn=o,Qn=u;break;case 0:case 11:case 14:case 15:pn||za(2,s,n),pn||za(4,s,n),da(e,n,s);break;case 1:pn||(zi(s,n),o=s.stateNode,typeof o.componentWillUnmount=="function"&&b0(s,n,o)),da(e,n,s);break;case 21:da(e,n,s);break;case 22:pn=(o=pn)||s.memoizedState!==null,da(e,n,s),pn=o;break;default:da(e,n,s)}}function N0(e,n){if(n.memoizedState===null&&(e=n.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Xo(e)}catch(s){Qe(n,n.return,s)}}function V_(e){switch(e.tag){case 13:case 19:var n=e.stateNode;return n===null&&(n=e.stateNode=new w0),n;case 22:return e=e.stateNode,n=e._retryCache,n===null&&(n=e._retryCache=new w0),n;default:throw Error(a(435,e.tag))}}function Rf(e,n){var s=V_(e);n.forEach(function(o){var u=Q_.bind(null,e,o);s.has(o)||(s.add(o),o.then(u,u))})}function ai(e,n){var s=n.deletions;if(s!==null)for(var o=0;o<s.length;o++){var u=s[o],h=e,M=n,R=M;t:for(;R!==null;){switch(R.tag){case 27:if(ja(R.type)){sn=R.stateNode,Qn=!1;break t}break;case 5:sn=R.stateNode,Qn=!1;break t;case 3:case 4:sn=R.stateNode.containerInfo,Qn=!0;break t}R=R.return}if(sn===null)throw Error(a(160));D0(h,M,u),sn=null,Qn=!1,h=u.alternate,h!==null&&(h.return=null),u.return=null}if(n.subtreeFlags&13878)for(n=n.child;n!==null;)U0(n,e),n=n.sibling}var Ti=null;function U0(e,n){var s=e.alternate,o=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:ai(n,e),si(e),o&4&&(za(3,e,e.return),Ao(3,e),za(5,e,e.return));break;case 1:ai(n,e),si(e),o&512&&(pn||s===null||zi(s,s.return)),o&64&&ha&&(e=e.updateQueue,e!==null&&(o=e.callbacks,o!==null&&(s=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=s===null?o:s.concat(o))));break;case 26:var u=Ti;if(ai(n,e),si(e),o&512&&(pn||s===null||zi(s,s.return)),o&4){var h=s!==null?s.memoizedState:null;if(o=e.memoizedState,s===null)if(o===null)if(e.stateNode===null){t:{o=e.type,s=e.memoizedProps,u=u.ownerDocument||u;e:switch(o){case"title":h=u.getElementsByTagName("title")[0],(!h||h[ti]||h[ce]||h.namespaceURI==="http://www.w3.org/2000/svg"||h.hasAttribute("itemprop"))&&(h=u.createElement(o),u.head.insertBefore(h,u.querySelector("head > title"))),Pn(h,o,s),h[ce]=e,rn(h),o=h;break t;case"link":var M=Ag("link","href",u).get(o+(s.href||""));if(M){for(var R=0;R<M.length;R++)if(h=M[R],h.getAttribute("href")===(s.href==null||s.href===""?null:s.href)&&h.getAttribute("rel")===(s.rel==null?null:s.rel)&&h.getAttribute("title")===(s.title==null?null:s.title)&&h.getAttribute("crossorigin")===(s.crossOrigin==null?null:s.crossOrigin)){M.splice(R,1);break e}}h=u.createElement(o),Pn(h,o,s),u.head.appendChild(h);break;case"meta":if(M=Ag("meta","content",u).get(o+(s.content||""))){for(R=0;R<M.length;R++)if(h=M[R],h.getAttribute("content")===(s.content==null?null:""+s.content)&&h.getAttribute("name")===(s.name==null?null:s.name)&&h.getAttribute("property")===(s.property==null?null:s.property)&&h.getAttribute("http-equiv")===(s.httpEquiv==null?null:s.httpEquiv)&&h.getAttribute("charset")===(s.charSet==null?null:s.charSet)){M.splice(R,1);break e}}h=u.createElement(o),Pn(h,o,s),u.head.appendChild(h);break;default:throw Error(a(468,o))}h[ce]=e,rn(h),o=h}e.stateNode=o}else wg(u,e.type,e.stateNode);else e.stateNode=Tg(u,o,e.memoizedProps);else h!==o?(h===null?s.stateNode!==null&&(s=s.stateNode,s.parentNode.removeChild(s)):h.count--,o===null?wg(u,e.type,e.stateNode):Tg(u,o,e.memoizedProps)):o===null&&e.stateNode!==null&&Ef(e,e.memoizedProps,s.memoizedProps)}break;case 27:ai(n,e),si(e),o&512&&(pn||s===null||zi(s,s.return)),s!==null&&o&4&&Ef(e,e.memoizedProps,s.memoizedProps);break;case 5:if(ai(n,e),si(e),o&512&&(pn||s===null||zi(s,s.return)),e.flags&32){u=e.stateNode;try{Vn(u,"")}catch(lt){Qe(e,e.return,lt)}}o&4&&e.stateNode!=null&&(u=e.memoizedProps,Ef(e,u,s!==null?s.memoizedProps:u)),o&1024&&(wf=!0);break;case 6:if(ai(n,e),si(e),o&4){if(e.stateNode===null)throw Error(a(162));o=e.memoizedProps,s=e.stateNode;try{s.nodeValue=o}catch(lt){Qe(e,e.return,lt)}}break;case 3:if(cc=null,u=Ti,Ti=oc(n.containerInfo),ai(n,e),Ti=u,si(e),o&4&&s!==null&&s.memoizedState.isDehydrated)try{Xo(n.containerInfo)}catch(lt){Qe(e,e.return,lt)}wf&&(wf=!1,L0(e));break;case 4:o=Ti,Ti=oc(e.stateNode.containerInfo),ai(n,e),si(e),Ti=o;break;case 12:ai(n,e),si(e);break;case 13:ai(n,e),si(e),e.child.flags&8192&&e.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Pf=ee()),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,Rf(e,o)));break;case 22:u=e.memoizedState!==null;var H=s!==null&&s.memoizedState!==null,it=ha,vt=pn;if(ha=it||u,pn=vt||H,ai(n,e),pn=vt,ha=it,si(e),o&8192)t:for(n=e.stateNode,n._visibility=u?n._visibility&-2:n._visibility|1,u&&(s===null||H||ha||pn||As(e)),s=null,n=e;;){if(n.tag===5||n.tag===26){if(s===null){H=s=n;try{if(h=H.stateNode,u)M=h.style,typeof M.setProperty=="function"?M.setProperty("display","none","important"):M.display="none";else{R=H.stateNode;var yt=H.memoizedProps.style,st=yt!=null&&yt.hasOwnProperty("display")?yt.display:null;R.style.display=st==null||typeof st=="boolean"?"":(""+st).trim()}}catch(lt){Qe(H,H.return,lt)}}}else if(n.tag===6){if(s===null){H=n;try{H.stateNode.nodeValue=u?"":H.memoizedProps}catch(lt){Qe(H,H.return,lt)}}}else if((n.tag!==22&&n.tag!==23||n.memoizedState===null||n===e)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break t;for(;n.sibling===null;){if(n.return===null||n.return===e)break t;s===n&&(s=null),n=n.return}s===n&&(s=null),n.sibling.return=n.return,n=n.sibling}o&4&&(o=e.updateQueue,o!==null&&(s=o.retryQueue,s!==null&&(o.retryQueue=null,Rf(e,s))));break;case 19:ai(n,e),si(e),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,Rf(e,o)));break;case 30:break;case 21:break;default:ai(n,e),si(e)}}function si(e){var n=e.flags;if(n&2){try{for(var s,o=e.return;o!==null;){if(T0(o)){s=o;break}o=o.return}if(s==null)throw Error(a(160));switch(s.tag){case 27:var u=s.stateNode,h=Tf(e);Yl(e,h,u);break;case 5:var M=s.stateNode;s.flags&32&&(Vn(M,""),s.flags&=-33);var R=Tf(e);Yl(e,R,M);break;case 3:case 4:var H=s.stateNode.containerInfo,it=Tf(e);Af(e,it,H);break;default:throw Error(a(161))}}catch(vt){Qe(e,e.return,vt)}e.flags&=-3}n&4096&&(e.flags&=-4097)}function L0(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var n=e;L0(n),n.tag===5&&n.flags&1024&&n.stateNode.reset(),e=e.sibling}}function Ga(e,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)R0(e,n.alternate,n),n=n.sibling}function As(e){for(e=e.child;e!==null;){var n=e;switch(n.tag){case 0:case 11:case 14:case 15:za(4,n,n.return),As(n);break;case 1:zi(n,n.return);var s=n.stateNode;typeof s.componentWillUnmount=="function"&&b0(n,n.return,s),As(n);break;case 27:Io(n.stateNode);case 26:case 5:zi(n,n.return),As(n);break;case 22:n.memoizedState===null&&As(n);break;case 30:As(n);break;default:As(n)}e=e.sibling}}function Ha(e,n,s){for(s=s&&(n.subtreeFlags&8772)!==0,n=n.child;n!==null;){var o=n.alternate,u=e,h=n,M=h.flags;switch(h.tag){case 0:case 11:case 15:Ha(u,h,s),Ao(4,h);break;case 1:if(Ha(u,h,s),o=h,u=o.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(it){Qe(o,o.return,it)}if(o=h,u=o.updateQueue,u!==null){var R=o.stateNode;try{var H=u.shared.hiddenCallbacks;if(H!==null)for(u.shared.hiddenCallbacks=null,u=0;u<H.length;u++)lm(H[u],R)}catch(it){Qe(o,o.return,it)}}s&&M&64&&M0(h),wo(h,h.return);break;case 27:A0(h);case 26:case 5:Ha(u,h,s),s&&o===null&&M&4&&E0(h),wo(h,h.return);break;case 12:Ha(u,h,s);break;case 13:Ha(u,h,s),s&&M&4&&N0(u,h);break;case 22:h.memoizedState===null&&Ha(u,h,s),wo(h,h.return);break;case 30:break;default:Ha(u,h,s)}n=n.sibling}}function Cf(e,n){var s=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),e=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(e=n.memoizedState.cachePool.pool),e!==s&&(e!=null&&e.refCount++,s!=null&&fo(s))}function Df(e,n){e=null,n.alternate!==null&&(e=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==e&&(n.refCount++,e!=null&&fo(e))}function Gi(e,n,s,o){if(n.subtreeFlags&10256)for(n=n.child;n!==null;)P0(e,n,s,o),n=n.sibling}function P0(e,n,s,o){var u=n.flags;switch(n.tag){case 0:case 11:case 15:Gi(e,n,s,o),u&2048&&Ao(9,n);break;case 1:Gi(e,n,s,o);break;case 3:Gi(e,n,s,o),u&2048&&(e=null,n.alternate!==null&&(e=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==e&&(n.refCount++,e!=null&&fo(e)));break;case 12:if(u&2048){Gi(e,n,s,o),e=n.stateNode;try{var h=n.memoizedProps,M=h.id,R=h.onPostCommit;typeof R=="function"&&R(M,n.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(H){Qe(n,n.return,H)}}else Gi(e,n,s,o);break;case 13:Gi(e,n,s,o);break;case 23:break;case 22:h=n.stateNode,M=n.alternate,n.memoizedState!==null?h._visibility&2?Gi(e,n,s,o):Ro(e,n):h._visibility&2?Gi(e,n,s,o):(h._visibility|=2,lr(e,n,s,o,(n.subtreeFlags&10256)!==0)),u&2048&&Cf(M,n);break;case 24:Gi(e,n,s,o),u&2048&&Df(n.alternate,n);break;default:Gi(e,n,s,o)}}function lr(e,n,s,o,u){for(u=u&&(n.subtreeFlags&10256)!==0,n=n.child;n!==null;){var h=e,M=n,R=s,H=o,it=M.flags;switch(M.tag){case 0:case 11:case 15:lr(h,M,R,H,u),Ao(8,M);break;case 23:break;case 22:var vt=M.stateNode;M.memoizedState!==null?vt._visibility&2?lr(h,M,R,H,u):Ro(h,M):(vt._visibility|=2,lr(h,M,R,H,u)),u&&it&2048&&Cf(M.alternate,M);break;case 24:lr(h,M,R,H,u),u&&it&2048&&Df(M.alternate,M);break;default:lr(h,M,R,H,u)}n=n.sibling}}function Ro(e,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var s=e,o=n,u=o.flags;switch(o.tag){case 22:Ro(s,o),u&2048&&Cf(o.alternate,o);break;case 24:Ro(s,o),u&2048&&Df(o.alternate,o);break;default:Ro(s,o)}n=n.sibling}}var Co=8192;function cr(e){if(e.subtreeFlags&Co)for(e=e.child;e!==null;)O0(e),e=e.sibling}function O0(e){switch(e.tag){case 26:cr(e),e.flags&Co&&e.memoizedState!==null&&wS(Ti,e.memoizedState,e.memoizedProps);break;case 5:cr(e);break;case 3:case 4:var n=Ti;Ti=oc(e.stateNode.containerInfo),cr(e),Ti=n;break;case 22:e.memoizedState===null&&(n=e.alternate,n!==null&&n.memoizedState!==null?(n=Co,Co=16777216,cr(e),Co=n):cr(e));break;default:cr(e)}}function I0(e){var n=e.alternate;if(n!==null&&(e=n.child,e!==null)){n.child=null;do n=e.sibling,e.sibling=null,e=n;while(e!==null)}}function Do(e){var n=e.deletions;if((e.flags&16)!==0){if(n!==null)for(var s=0;s<n.length;s++){var o=n[s];An=o,F0(o,e)}I0(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)B0(e),e=e.sibling}function B0(e){switch(e.tag){case 0:case 11:case 15:Do(e),e.flags&2048&&za(9,e,e.return);break;case 3:Do(e);break;case 12:Do(e);break;case 22:var n=e.stateNode;e.memoizedState!==null&&n._visibility&2&&(e.return===null||e.return.tag!==13)?(n._visibility&=-3,Zl(e)):Do(e);break;default:Do(e)}}function Zl(e){var n=e.deletions;if((e.flags&16)!==0){if(n!==null)for(var s=0;s<n.length;s++){var o=n[s];An=o,F0(o,e)}I0(e)}for(e=e.child;e!==null;){switch(n=e,n.tag){case 0:case 11:case 15:za(8,n,n.return),Zl(n);break;case 22:s=n.stateNode,s._visibility&2&&(s._visibility&=-3,Zl(n));break;default:Zl(n)}e=e.sibling}}function F0(e,n){for(;An!==null;){var s=An;switch(s.tag){case 0:case 11:case 15:za(8,s,n);break;case 23:case 22:if(s.memoizedState!==null&&s.memoizedState.cachePool!==null){var o=s.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:fo(s.memoizedState.cache)}if(o=s.child,o!==null)o.return=s,An=o;else t:for(s=e;An!==null;){o=An;var u=o.sibling,h=o.return;if(C0(o),o===s){An=null;break t}if(u!==null){u.return=h,An=u;break t}An=h}}}var k_={getCacheForType:function(e){var n=In(yn),s=n.data.get(e);return s===void 0&&(s=e(),n.data.set(e,s)),s}},X_=typeof WeakMap=="function"?WeakMap:Map,Xe=0,$e=null,Te=null,Le=0,We=0,ri=null,Va=!1,ur=!1,Nf=!1,pa=0,cn=0,ka=0,ws=0,Uf=0,_i=0,fr=0,No=null,Jn=null,Lf=!1,Pf=0,Kl=1/0,Ql=null,Xa=null,Ln=0,Wa=null,hr=null,dr=0,Of=0,If=null,z0=null,Uo=0,Bf=null;function oi(){if((Xe&2)!==0&&Le!==0)return Le&-Le;if(F.T!==null){var e=tr;return e!==0?e:Xf()}return Kt()}function G0(){_i===0&&(_i=(Le&536870912)===0||Fe?re():536870912);var e=xi.current;return e!==null&&(e.flags|=32),_i}function li(e,n,s){(e===$e&&(We===2||We===9)||e.cancelPendingCommit!==null)&&(pr(e,0),qa(e,Le,_i,!1)),X(e,s),((Xe&2)===0||e!==$e)&&(e===$e&&((Xe&2)===0&&(ws|=s),cn===4&&qa(e,Le,_i,!1)),Hi(e))}function H0(e,n,s){if((Xe&6)!==0)throw Error(a(327));var o=!s&&(n&124)===0&&(n&e.expiredLanes)===0||At(e,n),u=o?j_(e,n):Gf(e,n,!0),h=o;do{if(u===0){ur&&!o&&qa(e,n,0,!1);break}else{if(s=e.current.alternate,h&&!W_(s)){u=Gf(e,n,!1),h=!1;continue}if(u===2){if(h=n,e.errorRecoveryDisabledLanes&h)var M=0;else M=e.pendingLanes&-536870913,M=M!==0?M:M&536870912?536870912:0;if(M!==0){n=M;t:{var R=e;u=No;var H=R.current.memoizedState.isDehydrated;if(H&&(pr(R,M).flags|=256),M=Gf(R,M,!1),M!==2){if(Nf&&!H){R.errorRecoveryDisabledLanes|=h,ws|=h,u=4;break t}h=Jn,Jn=u,h!==null&&(Jn===null?Jn=h:Jn.push.apply(Jn,h))}u=M}if(h=!1,u!==2)continue}}if(u===1){pr(e,0),qa(e,n,0,!0);break}t:{switch(o=e,h=u,h){case 0:case 1:throw Error(a(345));case 4:if((n&4194048)!==n)break;case 6:qa(o,n,_i,!Va);break t;case 2:Jn=null;break;case 3:case 5:break;default:throw Error(a(329))}if((n&62914560)===n&&(u=Pf+300-ee(),10<u)){if(qa(o,n,_i,!Va),Gt(o,0,!0)!==0)break t;o.timeoutHandle=gg(V0.bind(null,o,s,Jn,Ql,Lf,n,_i,ws,fr,Va,h,2,-0,0),u);break t}V0(o,s,Jn,Ql,Lf,n,_i,ws,fr,Va,h,0,-0,0)}}break}while(!0);Hi(e)}function V0(e,n,s,o,u,h,M,R,H,it,vt,yt,st,lt){if(e.timeoutHandle=-1,yt=n.subtreeFlags,(yt&8192||(yt&16785408)===16785408)&&(zo={stylesheets:null,count:0,unsuspend:AS},O0(n),yt=RS(),yt!==null)){e.cancelPendingCommit=yt(Z0.bind(null,e,n,h,s,o,u,M,R,H,vt,1,st,lt)),qa(e,h,M,!it);return}Z0(e,n,h,s,o,u,M,R,H)}function W_(e){for(var n=e;;){var s=n.tag;if((s===0||s===11||s===15)&&n.flags&16384&&(s=n.updateQueue,s!==null&&(s=s.stores,s!==null)))for(var o=0;o<s.length;o++){var u=s[o],h=u.getSnapshot;u=u.value;try{if(!ni(h(),u))return!1}catch{return!1}}if(s=n.child,n.subtreeFlags&16384&&s!==null)s.return=n,n=s;else{if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function qa(e,n,s,o){n&=~Uf,n&=~ws,e.suspendedLanes|=n,e.pingedLanes&=~n,o&&(e.warmLanes|=n),o=e.expirationTimes;for(var u=n;0<u;){var h=31-ht(u),M=1<<h;o[h]=-1,u&=~M}s!==0&&mt(e,s,n)}function Jl(){return(Xe&6)===0?(Lo(0),!1):!0}function Ff(){if(Te!==null){if(We===0)var e=Te.return;else e=Te,ra=ys=null,tf(e),rr=null,bo=0,e=Te;for(;e!==null;)y0(e.alternate,e),e=e.return;Te=null}}function pr(e,n){var s=e.timeoutHandle;s!==-1&&(e.timeoutHandle=-1,cS(s)),s=e.cancelPendingCommit,s!==null&&(e.cancelPendingCommit=null,s()),Ff(),$e=e,Te=s=ia(e.current,null),Le=n,We=0,ri=null,Va=!1,ur=At(e,n),Nf=!1,fr=_i=Uf=ws=ka=cn=0,Jn=No=null,Lf=!1,(n&8)!==0&&(n|=n&32);var o=e.entangledLanes;if(o!==0)for(e=e.entanglements,o&=n;0<o;){var u=31-ht(o),h=1<<u;n|=e[u],o&=~h}return pa=n,Sl(),s}function k0(e,n){Me=null,F.H=zl,n===po||n===Cl?(n=rm(),We=3):n===im?(n=rm(),We=4):We=n===o0?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,ri=n,Te===null&&(cn=1,Xl(e,pi(n,e.current)))}function X0(){var e=F.H;return F.H=zl,e===null?zl:e}function W0(){var e=F.A;return F.A=k_,e}function zf(){cn=4,Va||(Le&4194048)!==Le&&xi.current!==null||(ur=!0),(ka&134217727)===0&&(ws&134217727)===0||$e===null||qa($e,Le,_i,!1)}function Gf(e,n,s){var o=Xe;Xe|=2;var u=X0(),h=W0();($e!==e||Le!==n)&&(Ql=null,pr(e,n)),n=!1;var M=cn;t:do try{if(We!==0&&Te!==null){var R=Te,H=ri;switch(We){case 8:Ff(),M=6;break t;case 3:case 2:case 9:case 6:xi.current===null&&(n=!0);var it=We;if(We=0,ri=null,mr(e,R,H,it),s&&ur){M=0;break t}break;default:it=We,We=0,ri=null,mr(e,R,H,it)}}q_(),M=cn;break}catch(vt){k0(e,vt)}while(!0);return n&&e.shellSuspendCounter++,ra=ys=null,Xe=o,F.H=u,F.A=h,Te===null&&($e=null,Le=0,Sl()),M}function q_(){for(;Te!==null;)q0(Te)}function j_(e,n){var s=Xe;Xe|=2;var o=X0(),u=W0();$e!==e||Le!==n?(Ql=null,Kl=ee()+500,pr(e,n)):ur=At(e,n);t:do try{if(We!==0&&Te!==null){n=Te;var h=ri;e:switch(We){case 1:We=0,ri=null,mr(e,n,h,1);break;case 2:case 9:if(am(h)){We=0,ri=null,j0(n);break}n=function(){We!==2&&We!==9||$e!==e||(We=7),Hi(e)},h.then(n,n);break t;case 3:We=7;break t;case 4:We=5;break t;case 7:am(h)?(We=0,ri=null,j0(n)):(We=0,ri=null,mr(e,n,h,7));break;case 5:var M=null;switch(Te.tag){case 26:M=Te.memoizedState;case 5:case 27:var R=Te;if(!M||Rg(M)){We=0,ri=null;var H=R.sibling;if(H!==null)Te=H;else{var it=R.return;it!==null?(Te=it,$l(it)):Te=null}break e}}We=0,ri=null,mr(e,n,h,5);break;case 6:We=0,ri=null,mr(e,n,h,6);break;case 8:Ff(),cn=6;break t;default:throw Error(a(462))}}Y_();break}catch(vt){k0(e,vt)}while(!0);return ra=ys=null,F.H=o,F.A=u,Xe=s,Te!==null?0:($e=null,Le=0,Sl(),cn)}function Y_(){for(;Te!==null&&!jt();)q0(Te)}function q0(e){var n=_0(e.alternate,e,pa);e.memoizedProps=e.pendingProps,n===null?$l(e):Te=n}function j0(e){var n=e,s=n.alternate;switch(n.tag){case 15:case 0:n=d0(s,n,n.pendingProps,n.type,void 0,Le);break;case 11:n=d0(s,n,n.pendingProps,n.type.render,n.ref,Le);break;case 5:tf(n);default:y0(s,n),n=Te=Yp(n,pa),n=_0(s,n,pa)}e.memoizedProps=e.pendingProps,n===null?$l(e):Te=n}function mr(e,n,s,o){ra=ys=null,tf(n),rr=null,bo=0;var u=n.return;try{if(B_(e,u,n,s,Le)){cn=1,Xl(e,pi(s,e.current)),Te=null;return}}catch(h){if(u!==null)throw Te=u,h;cn=1,Xl(e,pi(s,e.current)),Te=null;return}n.flags&32768?(Fe||o===1?e=!0:ur||(Le&536870912)!==0?e=!1:(Va=e=!0,(o===2||o===9||o===3||o===6)&&(o=xi.current,o!==null&&o.tag===13&&(o.flags|=16384))),Y0(n,e)):$l(n)}function $l(e){var n=e;do{if((n.flags&32768)!==0){Y0(n,Va);return}e=n.return;var s=z_(n.alternate,n,pa);if(s!==null){Te=s;return}if(n=n.sibling,n!==null){Te=n;return}Te=n=e}while(n!==null);cn===0&&(cn=5)}function Y0(e,n){do{var s=G_(e.alternate,e);if(s!==null){s.flags&=32767,Te=s;return}if(s=e.return,s!==null&&(s.flags|=32768,s.subtreeFlags=0,s.deletions=null),!n&&(e=e.sibling,e!==null)){Te=e;return}Te=e=s}while(e!==null);cn=6,Te=null}function Z0(e,n,s,o,u,h,M,R,H){e.cancelPendingCommit=null;do tc();while(Ln!==0);if((Xe&6)!==0)throw Error(a(327));if(n!==null){if(n===e.current)throw Error(a(177));if(h=n.lanes|n.childLanes,h|=Cu,Ct(e,s,h,M,R,H),e===$e&&(Te=$e=null,Le=0),hr=n,Wa=e,dr=s,Of=h,If=u,z0=o,(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,J_(Ue,function(){return tg(),null})):(e.callbackNode=null,e.callbackPriority=0),o=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||o){o=F.T,F.T=null,u=V.p,V.p=2,M=Xe,Xe|=4;try{H_(e,n,s)}finally{Xe=M,V.p=u,F.T=o}}Ln=1,K0(),Q0(),J0()}}function K0(){if(Ln===1){Ln=0;var e=Wa,n=hr,s=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||s){s=F.T,F.T=null;var o=V.p;V.p=2;var u=Xe;Xe|=4;try{U0(n,e);var h=Jf,M=Fp(e.containerInfo),R=h.focusedElem,H=h.selectionRange;if(M!==R&&R&&R.ownerDocument&&Bp(R.ownerDocument.documentElement,R)){if(H!==null&&Eu(R)){var it=H.start,vt=H.end;if(vt===void 0&&(vt=it),"selectionStart"in R)R.selectionStart=it,R.selectionEnd=Math.min(vt,R.value.length);else{var yt=R.ownerDocument||document,st=yt&&yt.defaultView||window;if(st.getSelection){var lt=st.getSelection(),se=R.textContent.length,ne=Math.min(H.start,se),Ke=H.end===void 0?ne:Math.min(H.end,se);!lt.extend&&ne>Ke&&(M=Ke,Ke=ne,ne=M);var Q=Ip(R,ne),q=Ip(R,Ke);if(Q&&q&&(lt.rangeCount!==1||lt.anchorNode!==Q.node||lt.anchorOffset!==Q.offset||lt.focusNode!==q.node||lt.focusOffset!==q.offset)){var et=yt.createRange();et.setStart(Q.node,Q.offset),lt.removeAllRanges(),ne>Ke?(lt.addRange(et),lt.extend(q.node,q.offset)):(et.setEnd(q.node,q.offset),lt.addRange(et))}}}}for(yt=[],lt=R;lt=lt.parentNode;)lt.nodeType===1&&yt.push({element:lt,left:lt.scrollLeft,top:lt.scrollTop});for(typeof R.focus=="function"&&R.focus(),R=0;R<yt.length;R++){var _t=yt[R];_t.element.scrollLeft=_t.left,_t.element.scrollTop=_t.top}}hc=!!Qf,Jf=Qf=null}finally{Xe=u,V.p=o,F.T=s}}e.current=n,Ln=2}}function Q0(){if(Ln===2){Ln=0;var e=Wa,n=hr,s=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||s){s=F.T,F.T=null;var o=V.p;V.p=2;var u=Xe;Xe|=4;try{R0(e,n.alternate,n)}finally{Xe=u,V.p=o,F.T=s}}Ln=3}}function J0(){if(Ln===4||Ln===3){Ln=0,te();var e=Wa,n=hr,s=dr,o=z0;(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?Ln=5:(Ln=0,hr=Wa=null,$0(e,e.pendingLanes));var u=e.pendingLanes;if(u===0&&(Xa=null),bt(s),n=n.stateNode,E&&typeof E.onCommitFiberRoot=="function")try{E.onCommitFiberRoot(L,n,void 0,(n.current.flags&128)===128)}catch{}if(o!==null){n=F.T,u=V.p,V.p=2,F.T=null;try{for(var h=e.onRecoverableError,M=0;M<o.length;M++){var R=o[M];h(R.value,{componentStack:R.stack})}}finally{F.T=n,V.p=u}}(dr&3)!==0&&tc(),Hi(e),u=e.pendingLanes,(s&4194090)!==0&&(u&42)!==0?e===Bf?Uo++:(Uo=0,Bf=e):Uo=0,Lo(0)}}function $0(e,n){(e.pooledCacheLanes&=n)===0&&(n=e.pooledCache,n!=null&&(e.pooledCache=null,fo(n)))}function tc(e){return K0(),Q0(),J0(),tg()}function tg(){if(Ln!==5)return!1;var e=Wa,n=Of;Of=0;var s=bt(dr),o=F.T,u=V.p;try{V.p=32>s?32:s,F.T=null,s=If,If=null;var h=Wa,M=dr;if(Ln=0,hr=Wa=null,dr=0,(Xe&6)!==0)throw Error(a(331));var R=Xe;if(Xe|=4,B0(h.current),P0(h,h.current,M,s),Xe=R,Lo(0,!1),E&&typeof E.onPostCommitFiberRoot=="function")try{E.onPostCommitFiberRoot(L,h)}catch{}return!0}finally{V.p=u,F.T=o,$0(e,n)}}function eg(e,n,s){n=pi(s,n),n=mf(e.stateNode,n,2),e=Oa(e,n,2),e!==null&&(X(e,2),Hi(e))}function Qe(e,n,s){if(e.tag===3)eg(e,e,s);else for(;n!==null;){if(n.tag===3){eg(n,e,s);break}else if(n.tag===1){var o=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Xa===null||!Xa.has(o))){e=pi(s,e),s=s0(2),o=Oa(n,s,2),o!==null&&(r0(s,o,n,e),X(o,2),Hi(o));break}}n=n.return}}function Hf(e,n,s){var o=e.pingCache;if(o===null){o=e.pingCache=new X_;var u=new Set;o.set(n,u)}else u=o.get(n),u===void 0&&(u=new Set,o.set(n,u));u.has(s)||(Nf=!0,u.add(s),e=Z_.bind(null,e,n,s),n.then(e,e))}function Z_(e,n,s){var o=e.pingCache;o!==null&&o.delete(n),e.pingedLanes|=e.suspendedLanes&s,e.warmLanes&=~s,$e===e&&(Le&s)===s&&(cn===4||cn===3&&(Le&62914560)===Le&&300>ee()-Pf?(Xe&2)===0&&pr(e,0):Uf|=s,fr===Le&&(fr=0)),Hi(e)}function ng(e,n){n===0&&(n=fe()),e=Ks(e,n),e!==null&&(X(e,n),Hi(e))}function K_(e){var n=e.memoizedState,s=0;n!==null&&(s=n.retryLane),ng(e,s)}function Q_(e,n){var s=0;switch(e.tag){case 13:var o=e.stateNode,u=e.memoizedState;u!==null&&(s=u.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(a(314))}o!==null&&o.delete(n),ng(e,s)}function J_(e,n){return le(e,n)}var ec=null,gr=null,Vf=!1,nc=!1,kf=!1,Rs=0;function Hi(e){e!==gr&&e.next===null&&(gr===null?ec=gr=e:gr=gr.next=e),nc=!0,Vf||(Vf=!0,tS())}function Lo(e,n){if(!kf&&nc){kf=!0;do for(var s=!1,o=ec;o!==null;){if(e!==0){var u=o.pendingLanes;if(u===0)var h=0;else{var M=o.suspendedLanes,R=o.pingedLanes;h=(1<<31-ht(42|e)+1)-1,h&=u&~(M&~R),h=h&201326741?h&201326741|1:h?h|2:0}h!==0&&(s=!0,rg(o,h))}else h=Le,h=Gt(o,o===$e?h:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(h&3)===0||At(o,h)||(s=!0,rg(o,h));o=o.next}while(s);kf=!1}}function $_(){ig()}function ig(){nc=Vf=!1;var e=0;Rs!==0&&(lS()&&(e=Rs),Rs=0);for(var n=ee(),s=null,o=ec;o!==null;){var u=o.next,h=ag(o,n);h===0?(o.next=null,s===null?ec=u:s.next=u,u===null&&(gr=s)):(s=o,(e!==0||(h&3)!==0)&&(nc=!0)),o=u}Lo(e)}function ag(e,n){for(var s=e.suspendedLanes,o=e.pingedLanes,u=e.expirationTimes,h=e.pendingLanes&-62914561;0<h;){var M=31-ht(h),R=1<<M,H=u[M];H===-1?((R&s)===0||(R&o)!==0)&&(u[M]=Rt(R,n)):H<=n&&(e.expiredLanes|=R),h&=~R}if(n=$e,s=Le,s=Gt(e,e===n?s:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,s===0||e===n&&(We===2||We===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&Ne(o),e.callbackNode=null,e.callbackPriority=0;if((s&3)===0||At(e,s)){if(n=s&-s,n===e.callbackPriority)return n;switch(o!==null&&Ne(o),bt(s)){case 2:case 8:s=j;break;case 32:s=Ue;break;case 268435456:s=ke;break;default:s=Ue}return o=sg.bind(null,e),s=le(s,o),e.callbackPriority=n,e.callbackNode=s,n}return o!==null&&o!==null&&Ne(o),e.callbackPriority=2,e.callbackNode=null,2}function sg(e,n){if(Ln!==0&&Ln!==5)return e.callbackNode=null,e.callbackPriority=0,null;var s=e.callbackNode;if(tc()&&e.callbackNode!==s)return null;var o=Le;return o=Gt(e,e===$e?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(H0(e,o,n),ag(e,ee()),e.callbackNode!=null&&e.callbackNode===s?sg.bind(null,e):null)}function rg(e,n){if(tc())return null;H0(e,n,!0)}function tS(){uS(function(){(Xe&6)!==0?le(Ve,$_):ig()})}function Xf(){return Rs===0&&(Rs=re()),Rs}function og(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:bi(""+e)}function lg(e,n){var s=n.ownerDocument.createElement("input");return s.name=n.name,s.value=n.value,e.id&&s.setAttribute("form",e.id),n.parentNode.insertBefore(s,n),e=new FormData(e),s.parentNode.removeChild(s),e}function eS(e,n,s,o,u){if(n==="submit"&&s&&s.stateNode===u){var h=og((u[en]||null).action),M=o.submitter;M&&(n=(n=M[en]||null)?og(n.formAction):M.getAttribute("formAction"),n!==null&&(h=n,M=null));var R=new vl("action","action",null,o,u);e.push({event:R,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(Rs!==0){var H=M?lg(u,M):new FormData(u);uf(s,{pending:!0,data:H,method:u.method,action:h},null,H)}}else typeof h=="function"&&(R.preventDefault(),H=M?lg(u,M):new FormData(u),uf(s,{pending:!0,data:H,method:u.method,action:h},h,H))},currentTarget:u}]})}}for(var Wf=0;Wf<Ru.length;Wf++){var qf=Ru[Wf],nS=qf.toLowerCase(),iS=qf[0].toUpperCase()+qf.slice(1);Ei(nS,"on"+iS)}Ei(Hp,"onAnimationEnd"),Ei(Vp,"onAnimationIteration"),Ei(kp,"onAnimationStart"),Ei("dblclick","onDoubleClick"),Ei("focusin","onFocus"),Ei("focusout","onBlur"),Ei(S_,"onTransitionRun"),Ei(y_,"onTransitionStart"),Ei(M_,"onTransitionCancel"),Ei(Xp,"onTransitionEnd"),Ca("onMouseEnter",["mouseout","mouseover"]),Ca("onMouseLeave",["mouseout","mouseover"]),Ca("onPointerEnter",["pointerout","pointerover"]),Ca("onPointerLeave",["pointerout","pointerover"]),ea("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),ea("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),ea("onBeforeInput",["compositionend","keypress","textInput","paste"]),ea("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),ea("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),ea("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Po="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),aS=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Po));function cg(e,n){n=(n&4)!==0;for(var s=0;s<e.length;s++){var o=e[s],u=o.event;o=o.listeners;t:{var h=void 0;if(n)for(var M=o.length-1;0<=M;M--){var R=o[M],H=R.instance,it=R.currentTarget;if(R=R.listener,H!==h&&u.isPropagationStopped())break t;h=R,u.currentTarget=it;try{h(u)}catch(vt){kl(vt)}u.currentTarget=null,h=H}else for(M=0;M<o.length;M++){if(R=o[M],H=R.instance,it=R.currentTarget,R=R.listener,H!==h&&u.isPropagationStopped())break t;h=R,u.currentTarget=it;try{h(u)}catch(vt){kl(vt)}u.currentTarget=null,h=H}}}}function Ae(e,n){var s=n[fs];s===void 0&&(s=n[fs]=new Set);var o=e+"__bubble";s.has(o)||(ug(n,e,2,!1),s.add(o))}function jf(e,n,s){var o=0;n&&(o|=4),ug(s,e,o,n)}var ic="_reactListening"+Math.random().toString(36).slice(2);function Yf(e){if(!e[ic]){e[ic]=!0,Kr.forEach(function(s){s!=="selectionchange"&&(aS.has(s)||jf(s,!1,e),jf(s,!0,e))});var n=e.nodeType===9?e:e.ownerDocument;n===null||n[ic]||(n[ic]=!0,jf("selectionchange",!1,n))}}function ug(e,n,s,o){switch(Pg(n)){case 2:var u=NS;break;case 8:u=US;break;default:u=lh}s=u.bind(null,n,s,e),u=void 0,!mu||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(u=!0),o?u!==void 0?e.addEventListener(n,s,{capture:!0,passive:u}):e.addEventListener(n,s,!0):u!==void 0?e.addEventListener(n,s,{passive:u}):e.addEventListener(n,s,!1)}function Zf(e,n,s,o,u){var h=o;if((n&1)===0&&(n&2)===0&&o!==null)t:for(;;){if(o===null)return;var M=o.tag;if(M===3||M===4){var R=o.stateNode.containerInfo;if(R===u)break;if(M===4)for(M=o.return;M!==null;){var H=M.tag;if((H===3||H===4)&&M.stateNode.containerInfo===u)return;M=M.return}for(;R!==null;){if(M=Ji(R),M===null)return;if(H=M.tag,H===5||H===6||H===26||H===27){o=h=M;continue t}R=R.parentNode}}o=o.return}vp(function(){var it=h,vt=du(s),yt=[];t:{var st=Wp.get(e);if(st!==void 0){var lt=vl,se=e;switch(e){case"keypress":if(ml(s)===0)break t;case"keydown":case"keyup":lt=Jx;break;case"focusin":se="focus",lt=_u;break;case"focusout":se="blur",lt=_u;break;case"beforeblur":case"afterblur":lt=_u;break;case"click":if(s.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":lt=Sp;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":lt=Gx;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":lt=e_;break;case Hp:case Vp:case kp:lt=kx;break;case Xp:lt=i_;break;case"scroll":case"scrollend":lt=Fx;break;case"wheel":lt=s_;break;case"copy":case"cut":case"paste":lt=Wx;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":lt=Mp;break;case"toggle":case"beforetoggle":lt=o_}var ne=(n&4)!==0,Ke=!ne&&(e==="scroll"||e==="scrollend"),Q=ne?st!==null?st+"Capture":null:st;ne=[];for(var q=it,et;q!==null;){var _t=q;if(et=_t.stateNode,_t=_t.tag,_t!==5&&_t!==26&&_t!==27||et===null||Q===null||(_t=Jr(q,Q),_t!=null&&ne.push(Oo(q,_t,et))),Ke)break;q=q.return}0<ne.length&&(st=new lt(st,se,null,s,vt),yt.push({event:st,listeners:ne}))}}if((n&7)===0){t:{if(st=e==="mouseover"||e==="pointerover",lt=e==="mouseout"||e==="pointerout",st&&s!==ks&&(se=s.relatedTarget||s.fromElement)&&(Ji(se)||se[Dn]))break t;if((lt||st)&&(st=vt.window===vt?vt:(st=vt.ownerDocument)?st.defaultView||st.parentWindow:window,lt?(se=s.relatedTarget||s.toElement,lt=it,se=se?Ji(se):null,se!==null&&(Ke=c(se),ne=se.tag,se!==Ke||ne!==5&&ne!==27&&ne!==6)&&(se=null)):(lt=null,se=it),lt!==se)){if(ne=Sp,_t="onMouseLeave",Q="onMouseEnter",q="mouse",(e==="pointerout"||e==="pointerover")&&(ne=Mp,_t="onPointerLeave",Q="onPointerEnter",q="pointer"),Ke=lt==null?st:Oi(lt),et=se==null?st:Oi(se),st=new ne(_t,q+"leave",lt,s,vt),st.target=Ke,st.relatedTarget=et,_t=null,Ji(vt)===it&&(ne=new ne(Q,q+"enter",se,s,vt),ne.target=et,ne.relatedTarget=Ke,_t=ne),Ke=_t,lt&&se)e:{for(ne=lt,Q=se,q=0,et=ne;et;et=vr(et))q++;for(et=0,_t=Q;_t;_t=vr(_t))et++;for(;0<q-et;)ne=vr(ne),q--;for(;0<et-q;)Q=vr(Q),et--;for(;q--;){if(ne===Q||Q!==null&&ne===Q.alternate)break e;ne=vr(ne),Q=vr(Q)}ne=null}else ne=null;lt!==null&&fg(yt,st,lt,ne,!1),se!==null&&Ke!==null&&fg(yt,Ke,se,ne,!0)}}t:{if(st=it?Oi(it):window,lt=st.nodeName&&st.nodeName.toLowerCase(),lt==="select"||lt==="input"&&st.type==="file")var Wt=Dp;else if(Rp(st))if(Np)Wt=v_;else{Wt=m_;var Ee=p_}else lt=st.nodeName,!lt||lt.toLowerCase()!=="input"||st.type!=="checkbox"&&st.type!=="radio"?it&&di(it.elementType)&&(Wt=Dp):Wt=g_;if(Wt&&(Wt=Wt(e,it))){Cp(yt,Wt,s,vt);break t}Ee&&Ee(e,st,it),e==="focusout"&&it&&st.type==="number"&&it.memoizedProps.value!=null&&Nn(st,"number",st.value)}switch(Ee=it?Oi(it):window,e){case"focusin":(Rp(Ee)||Ee.contentEditable==="true")&&(js=Ee,Tu=it,ro=null);break;case"focusout":ro=Tu=js=null;break;case"mousedown":Au=!0;break;case"contextmenu":case"mouseup":case"dragend":Au=!1,zp(yt,s,vt);break;case"selectionchange":if(__)break;case"keydown":case"keyup":zp(yt,s,vt)}var Jt;if(yu)t:{switch(e){case"compositionstart":var ie="onCompositionStart";break t;case"compositionend":ie="onCompositionEnd";break t;case"compositionupdate":ie="onCompositionUpdate";break t}ie=void 0}else qs?Ap(e,s)&&(ie="onCompositionEnd"):e==="keydown"&&s.keyCode===229&&(ie="onCompositionStart");ie&&(bp&&s.locale!=="ko"&&(qs||ie!=="onCompositionStart"?ie==="onCompositionEnd"&&qs&&(Jt=xp()):(Na=vt,gu="value"in Na?Na.value:Na.textContent,qs=!0)),Ee=ac(it,ie),0<Ee.length&&(ie=new yp(ie,e,null,s,vt),yt.push({event:ie,listeners:Ee}),Jt?ie.data=Jt:(Jt=wp(s),Jt!==null&&(ie.data=Jt)))),(Jt=c_?u_(e,s):f_(e,s))&&(ie=ac(it,"onBeforeInput"),0<ie.length&&(Ee=new yp("onBeforeInput","beforeinput",null,s,vt),yt.push({event:Ee,listeners:ie}),Ee.data=Jt)),eS(yt,e,it,s,vt)}cg(yt,n)})}function Oo(e,n,s){return{instance:e,listener:n,currentTarget:s}}function ac(e,n){for(var s=n+"Capture",o=[];e!==null;){var u=e,h=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||h===null||(u=Jr(e,s),u!=null&&o.unshift(Oo(e,u,h)),u=Jr(e,n),u!=null&&o.push(Oo(e,u,h))),e.tag===3)return o;e=e.return}return[]}function vr(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function fg(e,n,s,o,u){for(var h=n._reactName,M=[];s!==null&&s!==o;){var R=s,H=R.alternate,it=R.stateNode;if(R=R.tag,H!==null&&H===o)break;R!==5&&R!==26&&R!==27||it===null||(H=it,u?(it=Jr(s,h),it!=null&&M.unshift(Oo(s,it,H))):u||(it=Jr(s,h),it!=null&&M.push(Oo(s,it,H)))),s=s.return}M.length!==0&&e.push({event:n,listeners:M})}var sS=/\r\n?/g,rS=/\u0000|\uFFFD/g;function hg(e){return(typeof e=="string"?e:""+e).replace(sS,`
`).replace(rS,"")}function dg(e,n){return n=hg(n),hg(e)===n}function sc(){}function Ze(e,n,s,o,u,h){switch(s){case"children":typeof o=="string"?n==="body"||n==="textarea"&&o===""||Vn(e,o):(typeof o=="number"||typeof o=="bigint")&&n!=="body"&&Vn(e,""+o);break;case"className":w(e,"class",o);break;case"tabIndex":w(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":w(e,s,o);break;case"style":an(e,o,h);break;case"data":if(n!=="object"){w(e,"data",o);break}case"src":case"href":if(o===""&&(n!=="a"||s!=="href")){e.removeAttribute(s);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(s);break}o=bi(""+o),e.setAttribute(s,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(s,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof h=="function"&&(s==="formAction"?(n!=="input"&&Ze(e,n,"name",u.name,u,null),Ze(e,n,"formEncType",u.formEncType,u,null),Ze(e,n,"formMethod",u.formMethod,u,null),Ze(e,n,"formTarget",u.formTarget,u,null)):(Ze(e,n,"encType",u.encType,u,null),Ze(e,n,"method",u.method,u,null),Ze(e,n,"target",u.target,u,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(s);break}o=bi(""+o),e.setAttribute(s,o);break;case"onClick":o!=null&&(e.onclick=sc);break;case"onScroll":o!=null&&Ae("scroll",e);break;case"onScrollEnd":o!=null&&Ae("scrollend",e);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(a(61));if(s=o.__html,s!=null){if(u.children!=null)throw Error(a(60));e.innerHTML=s}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}s=bi(""+o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",s);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(s,""+o):e.removeAttribute(s);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(s,""):e.removeAttribute(s);break;case"capture":case"download":o===!0?e.setAttribute(s,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(s,o):e.removeAttribute(s);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(s,o):e.removeAttribute(s);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(s):e.setAttribute(s,o);break;case"popover":Ae("beforetoggle",e),Ae("toggle",e),Vs(e,"popover",o);break;case"xlinkActuate":Z(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Z(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Z(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Z(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Z(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Z(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Z(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Z(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Z(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Vs(e,"is",o);break;case"innerText":case"textContent":break;default:(!(2<s.length)||s[0]!=="o"&&s[0]!=="O"||s[1]!=="n"&&s[1]!=="N")&&(s=je.get(s)||s,Vs(e,s,o))}}function Kf(e,n,s,o,u,h){switch(s){case"style":an(e,o,h);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(a(61));if(s=o.__html,s!=null){if(u.children!=null)throw Error(a(60));e.innerHTML=s}}break;case"children":typeof o=="string"?Vn(e,o):(typeof o=="number"||typeof o=="bigint")&&Vn(e,""+o);break;case"onScroll":o!=null&&Ae("scroll",e);break;case"onScrollEnd":o!=null&&Ae("scrollend",e);break;case"onClick":o!=null&&(e.onclick=sc);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!Qr.hasOwnProperty(s))t:{if(s[0]==="o"&&s[1]==="n"&&(u=s.endsWith("Capture"),n=s.slice(2,u?s.length-7:void 0),h=e[en]||null,h=h!=null?h[s]:null,typeof h=="function"&&e.removeEventListener(n,h,u),typeof o=="function")){typeof h!="function"&&h!==null&&(s in e?e[s]=null:e.hasAttribute(s)&&e.removeAttribute(s)),e.addEventListener(n,o,u);break t}s in e?e[s]=o:o===!0?e.setAttribute(s,""):Vs(e,s,o)}}}function Pn(e,n,s){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Ae("error",e),Ae("load",e);var o=!1,u=!1,h;for(h in s)if(s.hasOwnProperty(h)){var M=s[h];if(M!=null)switch(h){case"src":o=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,n));default:Ze(e,n,h,M,s,null)}}u&&Ze(e,n,"srcSet",s.srcSet,s,null),o&&Ze(e,n,"src",s.src,s,null);return;case"input":Ae("invalid",e);var R=h=M=u=null,H=null,it=null;for(o in s)if(s.hasOwnProperty(o)){var vt=s[o];if(vt!=null)switch(o){case"name":u=vt;break;case"type":M=vt;break;case"checked":H=vt;break;case"defaultChecked":it=vt;break;case"value":h=vt;break;case"defaultValue":R=vt;break;case"children":case"dangerouslySetInnerHTML":if(vt!=null)throw Error(a(137,n));break;default:Ze(e,n,o,vt,s,null)}}kt(e,h,R,H,it,M,u,!1),Qt(e);return;case"select":Ae("invalid",e),o=M=h=null;for(u in s)if(s.hasOwnProperty(u)&&(R=s[u],R!=null))switch(u){case"value":h=R;break;case"defaultValue":M=R;break;case"multiple":o=R;default:Ze(e,n,u,R,s,null)}n=h,s=M,e.multiple=!!o,n!=null?Se(e,!!o,n,!1):s!=null&&Se(e,!!o,s,!0);return;case"textarea":Ae("invalid",e),h=u=o=null;for(M in s)if(s.hasOwnProperty(M)&&(R=s[M],R!=null))switch(M){case"value":o=R;break;case"defaultValue":u=R;break;case"children":h=R;break;case"dangerouslySetInnerHTML":if(R!=null)throw Error(a(91));break;default:Ze(e,n,M,R,s,null)}ei(e,o,u,h),Qt(e);return;case"option":for(H in s)s.hasOwnProperty(H)&&(o=s[H],o!=null)&&(H==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":Ze(e,n,H,o,s,null));return;case"dialog":Ae("beforetoggle",e),Ae("toggle",e),Ae("cancel",e),Ae("close",e);break;case"iframe":case"object":Ae("load",e);break;case"video":case"audio":for(o=0;o<Po.length;o++)Ae(Po[o],e);break;case"image":Ae("error",e),Ae("load",e);break;case"details":Ae("toggle",e);break;case"embed":case"source":case"link":Ae("error",e),Ae("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(it in s)if(s.hasOwnProperty(it)&&(o=s[it],o!=null))switch(it){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,n));default:Ze(e,n,it,o,s,null)}return;default:if(di(n)){for(vt in s)s.hasOwnProperty(vt)&&(o=s[vt],o!==void 0&&Kf(e,n,vt,o,s,void 0));return}}for(R in s)s.hasOwnProperty(R)&&(o=s[R],o!=null&&Ze(e,n,R,o,s,null))}function oS(e,n,s,o){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,h=null,M=null,R=null,H=null,it=null,vt=null;for(lt in s){var yt=s[lt];if(s.hasOwnProperty(lt)&&yt!=null)switch(lt){case"checked":break;case"value":break;case"defaultValue":H=yt;default:o.hasOwnProperty(lt)||Ze(e,n,lt,null,o,yt)}}for(var st in o){var lt=o[st];if(yt=s[st],o.hasOwnProperty(st)&&(lt!=null||yt!=null))switch(st){case"type":h=lt;break;case"name":u=lt;break;case"checked":it=lt;break;case"defaultChecked":vt=lt;break;case"value":M=lt;break;case"defaultValue":R=lt;break;case"children":case"dangerouslySetInnerHTML":if(lt!=null)throw Error(a(137,n));break;default:lt!==yt&&Ze(e,n,st,lt,o,yt)}}gn(e,M,R,H,it,vt,h,u);return;case"select":lt=M=R=st=null;for(h in s)if(H=s[h],s.hasOwnProperty(h)&&H!=null)switch(h){case"value":break;case"multiple":lt=H;default:o.hasOwnProperty(h)||Ze(e,n,h,null,o,H)}for(u in o)if(h=o[u],H=s[u],o.hasOwnProperty(u)&&(h!=null||H!=null))switch(u){case"value":st=h;break;case"defaultValue":R=h;break;case"multiple":M=h;default:h!==H&&Ze(e,n,u,h,o,H)}n=R,s=M,o=lt,st!=null?Se(e,!!s,st,!1):!!o!=!!s&&(n!=null?Se(e,!!s,n,!0):Se(e,!!s,s?[]:"",!1));return;case"textarea":lt=st=null;for(R in s)if(u=s[R],s.hasOwnProperty(R)&&u!=null&&!o.hasOwnProperty(R))switch(R){case"value":break;case"children":break;default:Ze(e,n,R,null,o,u)}for(M in o)if(u=o[M],h=s[M],o.hasOwnProperty(M)&&(u!=null||h!=null))switch(M){case"value":st=u;break;case"defaultValue":lt=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(a(91));break;default:u!==h&&Ze(e,n,M,u,o,h)}Hn(e,st,lt);return;case"option":for(var se in s)st=s[se],s.hasOwnProperty(se)&&st!=null&&!o.hasOwnProperty(se)&&(se==="selected"?e.selected=!1:Ze(e,n,se,null,o,st));for(H in o)st=o[H],lt=s[H],o.hasOwnProperty(H)&&st!==lt&&(st!=null||lt!=null)&&(H==="selected"?e.selected=st&&typeof st!="function"&&typeof st!="symbol":Ze(e,n,H,st,o,lt));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var ne in s)st=s[ne],s.hasOwnProperty(ne)&&st!=null&&!o.hasOwnProperty(ne)&&Ze(e,n,ne,null,o,st);for(it in o)if(st=o[it],lt=s[it],o.hasOwnProperty(it)&&st!==lt&&(st!=null||lt!=null))switch(it){case"children":case"dangerouslySetInnerHTML":if(st!=null)throw Error(a(137,n));break;default:Ze(e,n,it,st,o,lt)}return;default:if(di(n)){for(var Ke in s)st=s[Ke],s.hasOwnProperty(Ke)&&st!==void 0&&!o.hasOwnProperty(Ke)&&Kf(e,n,Ke,void 0,o,st);for(vt in o)st=o[vt],lt=s[vt],!o.hasOwnProperty(vt)||st===lt||st===void 0&&lt===void 0||Kf(e,n,vt,st,o,lt);return}}for(var Q in s)st=s[Q],s.hasOwnProperty(Q)&&st!=null&&!o.hasOwnProperty(Q)&&Ze(e,n,Q,null,o,st);for(yt in o)st=o[yt],lt=s[yt],!o.hasOwnProperty(yt)||st===lt||st==null&&lt==null||Ze(e,n,yt,st,o,lt)}var Qf=null,Jf=null;function rc(e){return e.nodeType===9?e:e.ownerDocument}function pg(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function mg(e,n){if(e===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&n==="foreignObject"?0:e}function $f(e,n){return e==="textarea"||e==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var th=null;function lS(){var e=window.event;return e&&e.type==="popstate"?e===th?!1:(th=e,!0):(th=null,!1)}var gg=typeof setTimeout=="function"?setTimeout:void 0,cS=typeof clearTimeout=="function"?clearTimeout:void 0,vg=typeof Promise=="function"?Promise:void 0,uS=typeof queueMicrotask=="function"?queueMicrotask:typeof vg<"u"?function(e){return vg.resolve(null).then(e).catch(fS)}:gg;function fS(e){setTimeout(function(){throw e})}function ja(e){return e==="head"}function xg(e,n){var s=n,o=0,u=0;do{var h=s.nextSibling;if(e.removeChild(s),h&&h.nodeType===8)if(s=h.data,s==="/$"){if(0<o&&8>o){s=o;var M=e.ownerDocument;if(s&1&&Io(M.documentElement),s&2&&Io(M.body),s&4)for(s=M.head,Io(s),M=s.firstChild;M;){var R=M.nextSibling,H=M.nodeName;M[ti]||H==="SCRIPT"||H==="STYLE"||H==="LINK"&&M.rel.toLowerCase()==="stylesheet"||s.removeChild(M),M=R}}if(u===0){e.removeChild(h),Xo(n);return}u--}else s==="$"||s==="$?"||s==="$!"?u++:o=s.charCodeAt(0)-48;else o=0;s=h}while(s);Xo(n)}function eh(e){var n=e.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var s=n;switch(n=n.nextSibling,s.nodeName){case"HTML":case"HEAD":case"BODY":eh(s),hs(s);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(s.rel.toLowerCase()==="stylesheet")continue}e.removeChild(s)}}function hS(e,n,s,o){for(;e.nodeType===1;){var u=s;if(e.nodeName.toLowerCase()!==n.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[ti])switch(n){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(h=e.getAttribute("rel"),h==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(h!==u.rel||e.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||e.getAttribute("title")!==(u.title==null?null:u.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(h=e.getAttribute("src"),(h!==(u.src==null?null:u.src)||e.getAttribute("type")!==(u.type==null?null:u.type)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&h&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(n==="input"&&e.type==="hidden"){var h=u.name==null?null:""+u.name;if(u.type==="hidden"&&e.getAttribute("name")===h)return e}else return e;if(e=Ai(e.nextSibling),e===null)break}return null}function dS(e,n,s){if(n==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!s||(e=Ai(e.nextSibling),e===null))return null;return e}function nh(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState==="complete"}function pS(e,n){var s=e.ownerDocument;if(e.data!=="$?"||s.readyState==="complete")n();else{var o=function(){n(),s.removeEventListener("DOMContentLoaded",o)};s.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function Ai(e){for(;e!=null;e=e.nextSibling){var n=e.nodeType;if(n===1||n===3)break;if(n===8){if(n=e.data,n==="$"||n==="$!"||n==="$?"||n==="F!"||n==="F")break;if(n==="/$")return null}}return e}var ih=null;function _g(e){e=e.previousSibling;for(var n=0;e;){if(e.nodeType===8){var s=e.data;if(s==="$"||s==="$!"||s==="$?"){if(n===0)return e;n--}else s==="/$"&&n++}e=e.previousSibling}return null}function Sg(e,n,s){switch(n=rc(s),e){case"html":if(e=n.documentElement,!e)throw Error(a(452));return e;case"head":if(e=n.head,!e)throw Error(a(453));return e;case"body":if(e=n.body,!e)throw Error(a(454));return e;default:throw Error(a(451))}}function Io(e){for(var n=e.attributes;n.length;)e.removeAttributeNode(n[0]);hs(e)}var Si=new Map,yg=new Set;function oc(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var ma=V.d;V.d={f:mS,r:gS,D:vS,C:xS,L:_S,m:SS,X:MS,S:yS,M:bS};function mS(){var e=ma.f(),n=Jl();return e||n}function gS(e){var n=$i(e);n!==null&&n.tag===5&&n.type==="form"?Hm(n):ma.r(e)}var xr=typeof document>"u"?null:document;function Mg(e,n,s){var o=xr;if(o&&typeof n=="string"&&n){var u=_e(n);u='link[rel="'+e+'"][href="'+u+'"]',typeof s=="string"&&(u+='[crossorigin="'+s+'"]'),yg.has(u)||(yg.add(u),e={rel:e,crossOrigin:s,href:n},o.querySelector(u)===null&&(n=o.createElement("link"),Pn(n,"link",e),rn(n),o.head.appendChild(n)))}}function vS(e){ma.D(e),Mg("dns-prefetch",e,null)}function xS(e,n){ma.C(e,n),Mg("preconnect",e,n)}function _S(e,n,s){ma.L(e,n,s);var o=xr;if(o&&e&&n){var u='link[rel="preload"][as="'+_e(n)+'"]';n==="image"&&s&&s.imageSrcSet?(u+='[imagesrcset="'+_e(s.imageSrcSet)+'"]',typeof s.imageSizes=="string"&&(u+='[imagesizes="'+_e(s.imageSizes)+'"]')):u+='[href="'+_e(e)+'"]';var h=u;switch(n){case"style":h=_r(e);break;case"script":h=Sr(e)}Si.has(h)||(e=v({rel:"preload",href:n==="image"&&s&&s.imageSrcSet?void 0:e,as:n},s),Si.set(h,e),o.querySelector(u)!==null||n==="style"&&o.querySelector(Bo(h))||n==="script"&&o.querySelector(Fo(h))||(n=o.createElement("link"),Pn(n,"link",e),rn(n),o.head.appendChild(n)))}}function SS(e,n){ma.m(e,n);var s=xr;if(s&&e){var o=n&&typeof n.as=="string"?n.as:"script",u='link[rel="modulepreload"][as="'+_e(o)+'"][href="'+_e(e)+'"]',h=u;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":h=Sr(e)}if(!Si.has(h)&&(e=v({rel:"modulepreload",href:e},n),Si.set(h,e),s.querySelector(u)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(s.querySelector(Fo(h)))return}o=s.createElement("link"),Pn(o,"link",e),rn(o),s.head.appendChild(o)}}}function yS(e,n,s){ma.S(e,n,s);var o=xr;if(o&&e){var u=ta(o).hoistableStyles,h=_r(e);n=n||"default";var M=u.get(h);if(!M){var R={loading:0,preload:null};if(M=o.querySelector(Bo(h)))R.loading=5;else{e=v({rel:"stylesheet",href:e,"data-precedence":n},s),(s=Si.get(h))&&ah(e,s);var H=M=o.createElement("link");rn(H),Pn(H,"link",e),H._p=new Promise(function(it,vt){H.onload=it,H.onerror=vt}),H.addEventListener("load",function(){R.loading|=1}),H.addEventListener("error",function(){R.loading|=2}),R.loading|=4,lc(M,n,o)}M={type:"stylesheet",instance:M,count:1,state:R},u.set(h,M)}}}function MS(e,n){ma.X(e,n);var s=xr;if(s&&e){var o=ta(s).hoistableScripts,u=Sr(e),h=o.get(u);h||(h=s.querySelector(Fo(u)),h||(e=v({src:e,async:!0},n),(n=Si.get(u))&&sh(e,n),h=s.createElement("script"),rn(h),Pn(h,"link",e),s.head.appendChild(h)),h={type:"script",instance:h,count:1,state:null},o.set(u,h))}}function bS(e,n){ma.M(e,n);var s=xr;if(s&&e){var o=ta(s).hoistableScripts,u=Sr(e),h=o.get(u);h||(h=s.querySelector(Fo(u)),h||(e=v({src:e,async:!0,type:"module"},n),(n=Si.get(u))&&sh(e,n),h=s.createElement("script"),rn(h),Pn(h,"link",e),s.head.appendChild(h)),h={type:"script",instance:h,count:1,state:null},o.set(u,h))}}function bg(e,n,s,o){var u=(u=J.current)?oc(u):null;if(!u)throw Error(a(446));switch(e){case"meta":case"title":return null;case"style":return typeof s.precedence=="string"&&typeof s.href=="string"?(n=_r(s.href),s=ta(u).hoistableStyles,o=s.get(n),o||(o={type:"style",instance:null,count:0,state:null},s.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(s.rel==="stylesheet"&&typeof s.href=="string"&&typeof s.precedence=="string"){e=_r(s.href);var h=ta(u).hoistableStyles,M=h.get(e);if(M||(u=u.ownerDocument||u,M={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},h.set(e,M),(h=u.querySelector(Bo(e)))&&!h._p&&(M.instance=h,M.state.loading=5),Si.has(e)||(s={rel:"preload",as:"style",href:s.href,crossOrigin:s.crossOrigin,integrity:s.integrity,media:s.media,hrefLang:s.hrefLang,referrerPolicy:s.referrerPolicy},Si.set(e,s),h||ES(u,e,s,M.state))),n&&o===null)throw Error(a(528,""));return M}if(n&&o!==null)throw Error(a(529,""));return null;case"script":return n=s.async,s=s.src,typeof s=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(n=Sr(s),s=ta(u).hoistableScripts,o=s.get(n),o||(o={type:"script",instance:null,count:0,state:null},s.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,e))}}function _r(e){return'href="'+_e(e)+'"'}function Bo(e){return'link[rel="stylesheet"]['+e+"]"}function Eg(e){return v({},e,{"data-precedence":e.precedence,precedence:null})}function ES(e,n,s,o){e.querySelector('link[rel="preload"][as="style"]['+n+"]")?o.loading=1:(n=e.createElement("link"),o.preload=n,n.addEventListener("load",function(){return o.loading|=1}),n.addEventListener("error",function(){return o.loading|=2}),Pn(n,"link",s),rn(n),e.head.appendChild(n))}function Sr(e){return'[src="'+_e(e)+'"]'}function Fo(e){return"script[async]"+e}function Tg(e,n,s){if(n.count++,n.instance===null)switch(n.type){case"style":var o=e.querySelector('style[data-href~="'+_e(s.href)+'"]');if(o)return n.instance=o,rn(o),o;var u=v({},s,{"data-href":s.href,"data-precedence":s.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),rn(o),Pn(o,"style",u),lc(o,s.precedence,e),n.instance=o;case"stylesheet":u=_r(s.href);var h=e.querySelector(Bo(u));if(h)return n.state.loading|=4,n.instance=h,rn(h),h;o=Eg(s),(u=Si.get(u))&&ah(o,u),h=(e.ownerDocument||e).createElement("link"),rn(h);var M=h;return M._p=new Promise(function(R,H){M.onload=R,M.onerror=H}),Pn(h,"link",o),n.state.loading|=4,lc(h,s.precedence,e),n.instance=h;case"script":return h=Sr(s.src),(u=e.querySelector(Fo(h)))?(n.instance=u,rn(u),u):(o=s,(u=Si.get(h))&&(o=v({},s),sh(o,u)),e=e.ownerDocument||e,u=e.createElement("script"),rn(u),Pn(u,"link",o),e.head.appendChild(u),n.instance=u);case"void":return null;default:throw Error(a(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(o=n.instance,n.state.loading|=4,lc(o,s.precedence,e));return n.instance}function lc(e,n,s){for(var o=s.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=o.length?o[o.length-1]:null,h=u,M=0;M<o.length;M++){var R=o[M];if(R.dataset.precedence===n)h=R;else if(h!==u)break}h?h.parentNode.insertBefore(e,h.nextSibling):(n=s.nodeType===9?s.head:s,n.insertBefore(e,n.firstChild))}function ah(e,n){e.crossOrigin==null&&(e.crossOrigin=n.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=n.referrerPolicy),e.title==null&&(e.title=n.title)}function sh(e,n){e.crossOrigin==null&&(e.crossOrigin=n.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=n.referrerPolicy),e.integrity==null&&(e.integrity=n.integrity)}var cc=null;function Ag(e,n,s){if(cc===null){var o=new Map,u=cc=new Map;u.set(s,o)}else u=cc,o=u.get(s),o||(o=new Map,u.set(s,o));if(o.has(e))return o;for(o.set(e,null),s=s.getElementsByTagName(e),u=0;u<s.length;u++){var h=s[u];if(!(h[ti]||h[ce]||e==="link"&&h.getAttribute("rel")==="stylesheet")&&h.namespaceURI!=="http://www.w3.org/2000/svg"){var M=h.getAttribute(n)||"";M=e+M;var R=o.get(M);R?R.push(h):o.set(M,[h])}}return o}function wg(e,n,s){e=e.ownerDocument||e,e.head.insertBefore(s,n==="title"?e.querySelector("head > title"):null)}function TS(e,n,s){if(s===1||n.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;return n.rel==="stylesheet"?(e=n.disabled,typeof n.precedence=="string"&&e==null):!0;case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function Rg(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}var zo=null;function AS(){}function wS(e,n,s){if(zo===null)throw Error(a(475));var o=zo;if(n.type==="stylesheet"&&(typeof s.media!="string"||matchMedia(s.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var u=_r(s.href),h=e.querySelector(Bo(u));if(h){e=h._p,e!==null&&typeof e=="object"&&typeof e.then=="function"&&(o.count++,o=uc.bind(o),e.then(o,o)),n.state.loading|=4,n.instance=h,rn(h);return}h=e.ownerDocument||e,s=Eg(s),(u=Si.get(u))&&ah(s,u),h=h.createElement("link"),rn(h);var M=h;M._p=new Promise(function(R,H){M.onload=R,M.onerror=H}),Pn(h,"link",s),n.instance=h}o.stylesheets===null&&(o.stylesheets=new Map),o.stylesheets.set(n,e),(e=n.state.preload)&&(n.state.loading&3)===0&&(o.count++,n=uc.bind(o),e.addEventListener("load",n),e.addEventListener("error",n))}}function RS(){if(zo===null)throw Error(a(475));var e=zo;return e.stylesheets&&e.count===0&&rh(e,e.stylesheets),0<e.count?function(n){var s=setTimeout(function(){if(e.stylesheets&&rh(e,e.stylesheets),e.unsuspend){var o=e.unsuspend;e.unsuspend=null,o()}},6e4);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(s)}}:null}function uc(){if(this.count--,this.count===0){if(this.stylesheets)rh(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var fc=null;function rh(e,n){e.stylesheets=null,e.unsuspend!==null&&(e.count++,fc=new Map,n.forEach(CS,e),fc=null,uc.call(e))}function CS(e,n){if(!(n.state.loading&4)){var s=fc.get(e);if(s)var o=s.get(null);else{s=new Map,fc.set(e,s);for(var u=e.querySelectorAll("link[data-precedence],style[data-precedence]"),h=0;h<u.length;h++){var M=u[h];(M.nodeName==="LINK"||M.getAttribute("media")!=="not all")&&(s.set(M.dataset.precedence,M),o=M)}o&&s.set(null,o)}u=n.instance,M=u.getAttribute("data-precedence"),h=s.get(M)||o,h===o&&s.set(null,u),s.set(M,u),this.count++,o=uc.bind(this),u.addEventListener("load",o),u.addEventListener("error",o),h?h.parentNode.insertBefore(u,h.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(u,e.firstChild)),n.state.loading|=4}}var Go={$$typeof:D,Provider:null,Consumer:null,_currentValue:rt,_currentValue2:rt,_threadCount:0};function DS(e,n,s,o,u,h,M,R){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=we(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=we(0),this.hiddenUpdates=we(null),this.identifierPrefix=o,this.onUncaughtError=u,this.onCaughtError=h,this.onRecoverableError=M,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=R,this.incompleteTransitions=new Map}function Cg(e,n,s,o,u,h,M,R,H,it,vt,yt){return e=new DS(e,n,s,M,R,H,it,yt),n=1,h===!0&&(n|=24),h=ii(3,null,null,n),e.current=h,h.stateNode=e,n=Gu(),n.refCount++,e.pooledCache=n,n.refCount++,h.memoizedState={element:o,isDehydrated:s,cache:n},Xu(h),e}function Dg(e){return e?(e=Qs,e):Qs}function Ng(e,n,s,o,u,h){u=Dg(u),o.context===null?o.context=u:o.pendingContext=u,o=Pa(n),o.payload={element:s},h=h===void 0?null:h,h!==null&&(o.callback=h),s=Oa(e,o,n),s!==null&&(li(s,e,n),go(s,e,n))}function Ug(e,n){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var s=e.retryLane;e.retryLane=s!==0&&s<n?s:n}}function oh(e,n){Ug(e,n),(e=e.alternate)&&Ug(e,n)}function Lg(e){if(e.tag===13){var n=Ks(e,67108864);n!==null&&li(n,e,67108864),oh(e,67108864)}}var hc=!0;function NS(e,n,s,o){var u=F.T;F.T=null;var h=V.p;try{V.p=2,lh(e,n,s,o)}finally{V.p=h,F.T=u}}function US(e,n,s,o){var u=F.T;F.T=null;var h=V.p;try{V.p=8,lh(e,n,s,o)}finally{V.p=h,F.T=u}}function lh(e,n,s,o){if(hc){var u=ch(o);if(u===null)Zf(e,n,o,dc,s),Og(e,o);else if(PS(u,e,n,s,o))o.stopPropagation();else if(Og(e,o),n&4&&-1<LS.indexOf(e)){for(;u!==null;){var h=$i(u);if(h!==null)switch(h.tag){case 3:if(h=h.stateNode,h.current.memoizedState.isDehydrated){var M=Lt(h.pendingLanes);if(M!==0){var R=h;for(R.pendingLanes|=2,R.entangledLanes|=2;M;){var H=1<<31-ht(M);R.entanglements[1]|=H,M&=~H}Hi(h),(Xe&6)===0&&(Kl=ee()+500,Lo(0))}}break;case 13:R=Ks(h,2),R!==null&&li(R,h,2),Jl(),oh(h,2)}if(h=ch(o),h===null&&Zf(e,n,o,dc,s),h===u)break;u=h}u!==null&&o.stopPropagation()}else Zf(e,n,o,null,s)}}function ch(e){return e=du(e),uh(e)}var dc=null;function uh(e){if(dc=null,e=Ji(e),e!==null){var n=c(e);if(n===null)e=null;else{var s=n.tag;if(s===13){if(e=f(n),e!==null)return e;e=null}else if(s===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;e=null}else n!==e&&(e=null)}}return dc=e,null}function Pg(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(me()){case Ve:return 2;case j:return 8;case Ue:case ge:return 32;case ke:return 268435456;default:return 32}default:return 32}}var fh=!1,Ya=null,Za=null,Ka=null,Ho=new Map,Vo=new Map,Qa=[],LS="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Og(e,n){switch(e){case"focusin":case"focusout":Ya=null;break;case"dragenter":case"dragleave":Za=null;break;case"mouseover":case"mouseout":Ka=null;break;case"pointerover":case"pointerout":Ho.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":Vo.delete(n.pointerId)}}function ko(e,n,s,o,u,h){return e===null||e.nativeEvent!==h?(e={blockedOn:n,domEventName:s,eventSystemFlags:o,nativeEvent:h,targetContainers:[u]},n!==null&&(n=$i(n),n!==null&&Lg(n)),e):(e.eventSystemFlags|=o,n=e.targetContainers,u!==null&&n.indexOf(u)===-1&&n.push(u),e)}function PS(e,n,s,o,u){switch(n){case"focusin":return Ya=ko(Ya,e,n,s,o,u),!0;case"dragenter":return Za=ko(Za,e,n,s,o,u),!0;case"mouseover":return Ka=ko(Ka,e,n,s,o,u),!0;case"pointerover":var h=u.pointerId;return Ho.set(h,ko(Ho.get(h)||null,e,n,s,o,u)),!0;case"gotpointercapture":return h=u.pointerId,Vo.set(h,ko(Vo.get(h)||null,e,n,s,o,u)),!0}return!1}function Ig(e){var n=Ji(e.target);if(n!==null){var s=c(n);if(s!==null){if(n=s.tag,n===13){if(n=f(s),n!==null){e.blockedOn=n,he(e.priority,function(){if(s.tag===13){var o=oi();o=Dt(o);var u=Ks(s,o);u!==null&&li(u,s,o),oh(s,o)}});return}}else if(n===3&&s.stateNode.current.memoizedState.isDehydrated){e.blockedOn=s.tag===3?s.stateNode.containerInfo:null;return}}}e.blockedOn=null}function pc(e){if(e.blockedOn!==null)return!1;for(var n=e.targetContainers;0<n.length;){var s=ch(e.nativeEvent);if(s===null){s=e.nativeEvent;var o=new s.constructor(s.type,s);ks=o,s.target.dispatchEvent(o),ks=null}else return n=$i(s),n!==null&&Lg(n),e.blockedOn=s,!1;n.shift()}return!0}function Bg(e,n,s){pc(e)&&s.delete(n)}function OS(){fh=!1,Ya!==null&&pc(Ya)&&(Ya=null),Za!==null&&pc(Za)&&(Za=null),Ka!==null&&pc(Ka)&&(Ka=null),Ho.forEach(Bg),Vo.forEach(Bg)}function mc(e,n){e.blockedOn===n&&(e.blockedOn=null,fh||(fh=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,OS)))}var gc=null;function Fg(e){gc!==e&&(gc=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){gc===e&&(gc=null);for(var n=0;n<e.length;n+=3){var s=e[n],o=e[n+1],u=e[n+2];if(typeof o!="function"){if(uh(o||s)===null)continue;break}var h=$i(s);h!==null&&(e.splice(n,3),n-=3,uf(h,{pending:!0,data:u,method:s.method,action:o},o,u))}}))}function Xo(e){function n(H){return mc(H,e)}Ya!==null&&mc(Ya,e),Za!==null&&mc(Za,e),Ka!==null&&mc(Ka,e),Ho.forEach(n),Vo.forEach(n);for(var s=0;s<Qa.length;s++){var o=Qa[s];o.blockedOn===e&&(o.blockedOn=null)}for(;0<Qa.length&&(s=Qa[0],s.blockedOn===null);)Ig(s),s.blockedOn===null&&Qa.shift();if(s=(e.ownerDocument||e).$$reactFormReplay,s!=null)for(o=0;o<s.length;o+=3){var u=s[o],h=s[o+1],M=u[en]||null;if(typeof h=="function")M||Fg(s);else if(M){var R=null;if(h&&h.hasAttribute("formAction")){if(u=h,M=h[en]||null)R=M.formAction;else if(uh(u)!==null)continue}else R=M.action;typeof R=="function"?s[o+1]=R:(s.splice(o,3),o-=3),Fg(s)}}}function hh(e){this._internalRoot=e}vc.prototype.render=hh.prototype.render=function(e){var n=this._internalRoot;if(n===null)throw Error(a(409));var s=n.current,o=oi();Ng(s,o,e,n,null,null)},vc.prototype.unmount=hh.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var n=e.containerInfo;Ng(e.current,2,null,e,null,null),Jl(),n[Dn]=null}};function vc(e){this._internalRoot=e}vc.prototype.unstable_scheduleHydration=function(e){if(e){var n=Kt();e={blockedOn:null,target:e,priority:n};for(var s=0;s<Qa.length&&n!==0&&n<Qa[s].priority;s++);Qa.splice(s,0,e),s===0&&Ig(e)}};var zg=t.version;if(zg!=="19.1.0")throw Error(a(527,zg,"19.1.0"));V.findDOMNode=function(e){var n=e._reactInternals;if(n===void 0)throw typeof e.render=="function"?Error(a(188)):(e=Object.keys(e).join(","),Error(a(268,e)));return e=m(n),e=e!==null?d(e):null,e=e===null?null:e.stateNode,e};var IS={bundleType:0,version:"19.1.0",rendererPackageName:"react-dom",currentDispatcherRef:F,reconcilerVersion:"19.1.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var xc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!xc.isDisabled&&xc.supportsFiber)try{L=xc.inject(IS),E=xc}catch{}}return qo.createRoot=function(e,n){if(!l(e))throw Error(a(299));var s=!1,o="",u=e0,h=n0,M=i0,R=null;return n!=null&&(n.unstable_strictMode===!0&&(s=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onUncaughtError!==void 0&&(u=n.onUncaughtError),n.onCaughtError!==void 0&&(h=n.onCaughtError),n.onRecoverableError!==void 0&&(M=n.onRecoverableError),n.unstable_transitionCallbacks!==void 0&&(R=n.unstable_transitionCallbacks)),n=Cg(e,1,!1,null,null,s,o,u,h,M,R,null),e[Dn]=n.current,Yf(e),new hh(n)},qo.hydrateRoot=function(e,n,s){if(!l(e))throw Error(a(299));var o=!1,u="",h=e0,M=n0,R=i0,H=null,it=null;return s!=null&&(s.unstable_strictMode===!0&&(o=!0),s.identifierPrefix!==void 0&&(u=s.identifierPrefix),s.onUncaughtError!==void 0&&(h=s.onUncaughtError),s.onCaughtError!==void 0&&(M=s.onCaughtError),s.onRecoverableError!==void 0&&(R=s.onRecoverableError),s.unstable_transitionCallbacks!==void 0&&(H=s.unstable_transitionCallbacks),s.formState!==void 0&&(it=s.formState)),n=Cg(e,1,!0,n,s??null,o,u,h,M,R,H,it),n.context=Dg(null),s=n.current,o=oi(),o=Dt(o),u=Pa(o),u.callback=null,Oa(s,u,o),s=o,n.current.lanes=s,X(n,s),Hi(n),e[Dn]=n.current,Yf(e),new vc(n)},qo.version="19.1.0",qo}var Zg;function qS(){if(Zg)return mh.exports;Zg=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),mh.exports=WS(),mh.exports}var jS=qS();const jd="184",YS=0,Kg=1,ZS=2,qc=1,KS=2,el=3,cs=0,$n=1,Ma=2,Ta=0,zr=1,Qg=2,Jg=3,$g=4,QS=5,Ps=100,JS=101,$S=102,ty=103,ey=104,ny=200,iy=201,ay=202,sy=203,td=204,ed=205,ry=206,oy=207,ly=208,cy=209,uy=210,fy=211,hy=212,dy=213,py=214,nd=0,id=1,ad=2,Hr=3,sd=4,rd=5,od=6,ld=7,nx=0,my=1,gy=2,Yi=0,ix=1,ax=2,sx=3,Yd=4,rx=5,ox=6,lx=7,cx=300,zs=301,Vr=302,_h=303,Sh=304,su=306,cd=1e3,ba=1001,ud=1002,On=1003,vy=1004,_c=1005,Gn=1006,yh=1007,Is=1008,hi=1009,ux=1010,fx=1011,rl=1012,Zd=1013,Ki=1014,qi=1015,wa=1016,Kd=1017,Qd=1018,ol=1020,hx=35902,dx=35899,px=1021,mx=1022,Li=1023,Ra=1026,Bs=1027,gx=1028,Jd=1029,Gs=1030,$d=1031,tp=1033,jc=33776,Yc=33777,Zc=33778,Kc=33779,fd=35840,hd=35841,dd=35842,pd=35843,md=36196,gd=37492,vd=37496,xd=37488,_d=37489,Jc=37490,Sd=37491,yd=37808,Md=37809,bd=37810,Ed=37811,Td=37812,Ad=37813,wd=37814,Rd=37815,Cd=37816,Dd=37817,Nd=37818,Ud=37819,Ld=37820,Pd=37821,Od=36492,Id=36494,Bd=36495,Fd=36283,zd=36284,$c=36285,Gd=36286,xy=3200,Hd=0,_y=1,rs="",fi="srgb",tu="srgb-linear",eu="linear",qe="srgb",yr=7680,tv=519,Sy=512,yy=513,My=514,ep=515,by=516,Ey=517,np=518,Ty=519,ev=35044,nv="300 es",ji=2e3,ll=2001;function Ay(r){for(let t=r.length-1;t>=0;--t)if(r[t]>=65535)return!0;return!1}function nu(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function wy(){const r=nu("canvas");return r.style.display="block",r}const iv={};function av(...r){const t="THREE."+r.shift();console.log(t,...r)}function vx(r){const t=r[0];if(typeof t=="string"&&t.startsWith("TSL:")){const i=r[1];i&&i.isStackTrace?r[0]+=" "+i.getLocation():r[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return r}function ae(...r){r=vx(r);const t="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.warn(i.getError(t)):console.warn(t,...r)}}function Oe(...r){r=vx(r);const t="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.error(i.getError(t)):console.error(t,...r)}}function Vd(...r){const t=r.join(" ");t in iv||(iv[t]=!0,ae(...r))}function Ry(r,t,i){return new Promise(function(a,l){function c(){switch(r.clientWaitSync(t,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:l();break;case r.TIMEOUT_EXPIRED:setTimeout(c,i);break;default:a()}}setTimeout(c,i)})}const Cy={[nd]:id,[ad]:od,[sd]:ld,[Hr]:rd,[id]:nd,[od]:ad,[ld]:sd,[rd]:Hr};class Hs{addEventListener(t,i){this._listeners===void 0&&(this._listeners={});const a=this._listeners;a[t]===void 0&&(a[t]=[]),a[t].indexOf(i)===-1&&a[t].push(i)}hasEventListener(t,i){const a=this._listeners;return a===void 0?!1:a[t]!==void 0&&a[t].indexOf(i)!==-1}removeEventListener(t,i){const a=this._listeners;if(a===void 0)return;const l=a[t];if(l!==void 0){const c=l.indexOf(i);c!==-1&&l.splice(c,1)}}dispatchEvent(t){const i=this._listeners;if(i===void 0)return;const a=i[t.type];if(a!==void 0){t.target=this;const l=a.slice(0);for(let c=0,f=l.length;c<f;c++)l[c].call(this,t);t.target=null}}}const Fn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let sv=1234567;const al=Math.PI/180,cl=180/Math.PI;function Wr(){const r=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0,a=Math.random()*4294967295|0;return(Fn[r&255]+Fn[r>>8&255]+Fn[r>>16&255]+Fn[r>>24&255]+"-"+Fn[t&255]+Fn[t>>8&255]+"-"+Fn[t>>16&15|64]+Fn[t>>24&255]+"-"+Fn[i&63|128]+Fn[i>>8&255]+"-"+Fn[i>>16&255]+Fn[i>>24&255]+Fn[a&255]+Fn[a>>8&255]+Fn[a>>16&255]+Fn[a>>24&255]).toLowerCase()}function Re(r,t,i){return Math.max(t,Math.min(i,r))}function ip(r,t){return(r%t+t)%t}function Dy(r,t,i,a,l){return a+(r-t)*(l-a)/(i-t)}function Ny(r,t,i){return r!==t?(i-r)/(t-r):0}function sl(r,t,i){return(1-i)*r+i*t}function Uy(r,t,i,a){return sl(r,t,1-Math.exp(-i*a))}function Ly(r,t=1){return t-Math.abs(ip(r,t*2)-t)}function Py(r,t,i){return r<=t?0:r>=i?1:(r=(r-t)/(i-t),r*r*(3-2*r))}function Oy(r,t,i){return r<=t?0:r>=i?1:(r=(r-t)/(i-t),r*r*r*(r*(r*6-15)+10))}function Iy(r,t){return r+Math.floor(Math.random()*(t-r+1))}function By(r,t){return r+Math.random()*(t-r)}function Fy(r){return r*(.5-Math.random())}function zy(r){r!==void 0&&(sv=r);let t=sv+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Gy(r){return r*al}function Hy(r){return r*cl}function Vy(r){return(r&r-1)===0&&r!==0}function ky(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))}function Xy(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function Wy(r,t,i,a,l){const c=Math.cos,f=Math.sin,p=c(i/2),m=f(i/2),d=c((t+a)/2),v=f((t+a)/2),x=c((t-a)/2),g=f((t-a)/2),y=c((a-t)/2),b=f((a-t)/2);switch(l){case"XYX":r.set(p*v,m*x,m*g,p*d);break;case"YZY":r.set(m*g,p*v,m*x,p*d);break;case"ZXZ":r.set(m*x,m*g,p*v,p*d);break;case"XZX":r.set(p*v,m*b,m*y,p*d);break;case"YXY":r.set(m*y,p*v,m*b,p*d);break;case"ZYZ":r.set(m*b,m*y,p*v,p*d);break;default:ae("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+l)}}function Fr(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function Wn(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}const wi={DEG2RAD:al,RAD2DEG:cl,generateUUID:Wr,clamp:Re,euclideanModulo:ip,mapLinear:Dy,inverseLerp:Ny,lerp:sl,damp:Uy,pingpong:Ly,smoothstep:Py,smootherstep:Oy,randInt:Iy,randFloat:By,randFloatSpread:Fy,seededRandom:zy,degToRad:Gy,radToDeg:Hy,isPowerOfTwo:Vy,ceilPowerOfTwo:ky,floorPowerOfTwo:Xy,setQuaternionFromProperEuler:Wy,normalize:Wn,denormalize:Fr},fp=class fp{constructor(t=0,i=0){this.x=t,this.y=i}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,i){return this.x=t,this.y=i,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const i=this.x,a=this.y,l=t.elements;return this.x=l[0]*i+l[3]*a+l[6],this.y=l[1]*i+l[4]*a+l[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,i){return this.x=Re(this.x,t.x,i.x),this.y=Re(this.y,t.y,i.y),this}clampScalar(t,i){return this.x=Re(this.x,t,i),this.y=Re(this.y,t,i),this}clampLength(t,i){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Re(a,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const i=Math.sqrt(this.lengthSq()*t.lengthSq());if(i===0)return Math.PI/2;const a=this.dot(t)/i;return Math.acos(Re(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const i=this.x-t.x,a=this.y-t.y;return i*i+a*a}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this}lerpVectors(t,i,a){return this.x=t.x+(i.x-t.x)*a,this.y=t.y+(i.y-t.y)*a,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this}rotateAround(t,i){const a=Math.cos(i),l=Math.sin(i),c=this.x-t.x,f=this.y-t.y;return this.x=c*a-f*l+t.x,this.y=c*l+f*a+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};fp.prototype.isVector2=!0;let De=fp;class qr{constructor(t=0,i=0,a=0,l=1){this.isQuaternion=!0,this._x=t,this._y=i,this._z=a,this._w=l}static slerpFlat(t,i,a,l,c,f,p){let m=a[l+0],d=a[l+1],v=a[l+2],x=a[l+3],g=c[f+0],y=c[f+1],b=c[f+2],C=c[f+3];if(x!==C||m!==g||d!==y||v!==b){let S=m*g+d*y+v*b+x*C;S<0&&(g=-g,y=-y,b=-b,C=-C,S=-S);let _=1-p;if(S<.9995){const T=Math.acos(S),D=Math.sin(T);_=Math.sin(_*T)/D,p=Math.sin(p*T)/D,m=m*_+g*p,d=d*_+y*p,v=v*_+b*p,x=x*_+C*p}else{m=m*_+g*p,d=d*_+y*p,v=v*_+b*p,x=x*_+C*p;const T=1/Math.sqrt(m*m+d*d+v*v+x*x);m*=T,d*=T,v*=T,x*=T}}t[i]=m,t[i+1]=d,t[i+2]=v,t[i+3]=x}static multiplyQuaternionsFlat(t,i,a,l,c,f){const p=a[l],m=a[l+1],d=a[l+2],v=a[l+3],x=c[f],g=c[f+1],y=c[f+2],b=c[f+3];return t[i]=p*b+v*x+m*y-d*g,t[i+1]=m*b+v*g+d*x-p*y,t[i+2]=d*b+v*y+p*g-m*x,t[i+3]=v*b-p*x-m*g-d*y,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,i,a,l){return this._x=t,this._y=i,this._z=a,this._w=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,i=!0){const a=t._x,l=t._y,c=t._z,f=t._order,p=Math.cos,m=Math.sin,d=p(a/2),v=p(l/2),x=p(c/2),g=m(a/2),y=m(l/2),b=m(c/2);switch(f){case"XYZ":this._x=g*v*x+d*y*b,this._y=d*y*x-g*v*b,this._z=d*v*b+g*y*x,this._w=d*v*x-g*y*b;break;case"YXZ":this._x=g*v*x+d*y*b,this._y=d*y*x-g*v*b,this._z=d*v*b-g*y*x,this._w=d*v*x+g*y*b;break;case"ZXY":this._x=g*v*x-d*y*b,this._y=d*y*x+g*v*b,this._z=d*v*b+g*y*x,this._w=d*v*x-g*y*b;break;case"ZYX":this._x=g*v*x-d*y*b,this._y=d*y*x+g*v*b,this._z=d*v*b-g*y*x,this._w=d*v*x+g*y*b;break;case"YZX":this._x=g*v*x+d*y*b,this._y=d*y*x+g*v*b,this._z=d*v*b-g*y*x,this._w=d*v*x-g*y*b;break;case"XZY":this._x=g*v*x-d*y*b,this._y=d*y*x-g*v*b,this._z=d*v*b+g*y*x,this._w=d*v*x+g*y*b;break;default:ae("Quaternion: .setFromEuler() encountered an unknown order: "+f)}return i===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,i){const a=i/2,l=Math.sin(a);return this._x=t.x*l,this._y=t.y*l,this._z=t.z*l,this._w=Math.cos(a),this._onChangeCallback(),this}setFromRotationMatrix(t){const i=t.elements,a=i[0],l=i[4],c=i[8],f=i[1],p=i[5],m=i[9],d=i[2],v=i[6],x=i[10],g=a+p+x;if(g>0){const y=.5/Math.sqrt(g+1);this._w=.25/y,this._x=(v-m)*y,this._y=(c-d)*y,this._z=(f-l)*y}else if(a>p&&a>x){const y=2*Math.sqrt(1+a-p-x);this._w=(v-m)/y,this._x=.25*y,this._y=(l+f)/y,this._z=(c+d)/y}else if(p>x){const y=2*Math.sqrt(1+p-a-x);this._w=(c-d)/y,this._x=(l+f)/y,this._y=.25*y,this._z=(m+v)/y}else{const y=2*Math.sqrt(1+x-a-p);this._w=(f-l)/y,this._x=(c+d)/y,this._y=(m+v)/y,this._z=.25*y}return this._onChangeCallback(),this}setFromUnitVectors(t,i){let a=t.dot(i)+1;return a<1e-8?(a=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=a):(this._x=0,this._y=-t.z,this._z=t.y,this._w=a)):(this._x=t.y*i.z-t.z*i.y,this._y=t.z*i.x-t.x*i.z,this._z=t.x*i.y-t.y*i.x,this._w=a),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Re(this.dot(t),-1,1)))}rotateTowards(t,i){const a=this.angleTo(t);if(a===0)return this;const l=Math.min(1,i/a);return this.slerp(t,l),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,i){const a=t._x,l=t._y,c=t._z,f=t._w,p=i._x,m=i._y,d=i._z,v=i._w;return this._x=a*v+f*p+l*d-c*m,this._y=l*v+f*m+c*p-a*d,this._z=c*v+f*d+a*m-l*p,this._w=f*v-a*p-l*m-c*d,this._onChangeCallback(),this}slerp(t,i){let a=t._x,l=t._y,c=t._z,f=t._w,p=this.dot(t);p<0&&(a=-a,l=-l,c=-c,f=-f,p=-p);let m=1-i;if(p<.9995){const d=Math.acos(p),v=Math.sin(d);m=Math.sin(m*d)/v,i=Math.sin(i*d)/v,this._x=this._x*m+a*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+f*i,this._onChangeCallback()}else this._x=this._x*m+a*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+f*i,this.normalize();return this}slerpQuaternions(t,i,a){return this.copy(t).slerp(i,a)}random(){const t=2*Math.PI*Math.random(),i=2*Math.PI*Math.random(),a=Math.random(),l=Math.sqrt(1-a),c=Math.sqrt(a);return this.set(l*Math.sin(t),l*Math.cos(t),c*Math.sin(i),c*Math.cos(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,i=0){return this._x=t[i],this._y=t[i+1],this._z=t[i+2],this._w=t[i+3],this._onChangeCallback(),this}toArray(t=[],i=0){return t[i]=this._x,t[i+1]=this._y,t[i+2]=this._z,t[i+3]=this._w,t}fromBufferAttribute(t,i){return this._x=t.getX(i),this._y=t.getY(i),this._z=t.getZ(i),this._w=t.getW(i),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const hp=class hp{constructor(t=0,i=0,a=0){this.x=t,this.y=i,this.z=a}set(t,i,a){return a===void 0&&(a=this.z),this.x=t,this.y=i,this.z=a,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this.z=t.z+i.z,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this.z+=t.z*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this.z=t.z-i.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,i){return this.x=t.x*i.x,this.y=t.y*i.y,this.z=t.z*i.z,this}applyEuler(t){return this.applyQuaternion(rv.setFromEuler(t))}applyAxisAngle(t,i){return this.applyQuaternion(rv.setFromAxisAngle(t,i))}applyMatrix3(t){const i=this.x,a=this.y,l=this.z,c=t.elements;return this.x=c[0]*i+c[3]*a+c[6]*l,this.y=c[1]*i+c[4]*a+c[7]*l,this.z=c[2]*i+c[5]*a+c[8]*l,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const i=this.x,a=this.y,l=this.z,c=t.elements,f=1/(c[3]*i+c[7]*a+c[11]*l+c[15]);return this.x=(c[0]*i+c[4]*a+c[8]*l+c[12])*f,this.y=(c[1]*i+c[5]*a+c[9]*l+c[13])*f,this.z=(c[2]*i+c[6]*a+c[10]*l+c[14])*f,this}applyQuaternion(t){const i=this.x,a=this.y,l=this.z,c=t.x,f=t.y,p=t.z,m=t.w,d=2*(f*l-p*a),v=2*(p*i-c*l),x=2*(c*a-f*i);return this.x=i+m*d+f*x-p*v,this.y=a+m*v+p*d-c*x,this.z=l+m*x+c*v-f*d,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const i=this.x,a=this.y,l=this.z,c=t.elements;return this.x=c[0]*i+c[4]*a+c[8]*l,this.y=c[1]*i+c[5]*a+c[9]*l,this.z=c[2]*i+c[6]*a+c[10]*l,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,i){return this.x=Re(this.x,t.x,i.x),this.y=Re(this.y,t.y,i.y),this.z=Re(this.z,t.z,i.z),this}clampScalar(t,i){return this.x=Re(this.x,t,i),this.y=Re(this.y,t,i),this.z=Re(this.z,t,i),this}clampLength(t,i){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Re(a,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this.z+=(t.z-this.z)*i,this}lerpVectors(t,i,a){return this.x=t.x+(i.x-t.x)*a,this.y=t.y+(i.y-t.y)*a,this.z=t.z+(i.z-t.z)*a,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,i){const a=t.x,l=t.y,c=t.z,f=i.x,p=i.y,m=i.z;return this.x=l*m-c*p,this.y=c*f-a*m,this.z=a*p-l*f,this}projectOnVector(t){const i=t.lengthSq();if(i===0)return this.set(0,0,0);const a=t.dot(this)/i;return this.copy(t).multiplyScalar(a)}projectOnPlane(t){return Mh.copy(this).projectOnVector(t),this.sub(Mh)}reflect(t){return this.sub(Mh.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const i=Math.sqrt(this.lengthSq()*t.lengthSq());if(i===0)return Math.PI/2;const a=this.dot(t)/i;return Math.acos(Re(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const i=this.x-t.x,a=this.y-t.y,l=this.z-t.z;return i*i+a*a+l*l}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,i,a){const l=Math.sin(i)*t;return this.x=l*Math.sin(a),this.y=Math.cos(i)*t,this.z=l*Math.cos(a),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,i,a){return this.x=t*Math.sin(i),this.y=a,this.z=t*Math.cos(i),this}setFromMatrixPosition(t){const i=t.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this}setFromMatrixScale(t){const i=this.setFromMatrixColumn(t,0).length(),a=this.setFromMatrixColumn(t,1).length(),l=this.setFromMatrixColumn(t,2).length();return this.x=i,this.y=a,this.z=l,this}setFromMatrixColumn(t,i){return this.fromArray(t.elements,i*4)}setFromMatrix3Column(t,i){return this.fromArray(t.elements,i*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this.z=t[i+2],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t[i+2]=this.z,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this.z=t.getZ(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,i=Math.random()*2-1,a=Math.sqrt(1-i*i);return this.x=a*Math.cos(t),this.y=i,this.z=a*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};hp.prototype.isVector3=!0;let K=hp;const Mh=new K,rv=new qr,dp=class dp{constructor(t,i,a,l,c,f,p,m,d){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,i,a,l,c,f,p,m,d)}set(t,i,a,l,c,f,p,m,d){const v=this.elements;return v[0]=t,v[1]=l,v[2]=p,v[3]=i,v[4]=c,v[5]=m,v[6]=a,v[7]=f,v[8]=d,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const i=this.elements,a=t.elements;return i[0]=a[0],i[1]=a[1],i[2]=a[2],i[3]=a[3],i[4]=a[4],i[5]=a[5],i[6]=a[6],i[7]=a[7],i[8]=a[8],this}extractBasis(t,i,a){return t.setFromMatrix3Column(this,0),i.setFromMatrix3Column(this,1),a.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const i=t.elements;return this.set(i[0],i[4],i[8],i[1],i[5],i[9],i[2],i[6],i[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,i){const a=t.elements,l=i.elements,c=this.elements,f=a[0],p=a[3],m=a[6],d=a[1],v=a[4],x=a[7],g=a[2],y=a[5],b=a[8],C=l[0],S=l[3],_=l[6],T=l[1],D=l[4],U=l[7],P=l[2],N=l[5],z=l[8];return c[0]=f*C+p*T+m*P,c[3]=f*S+p*D+m*N,c[6]=f*_+p*U+m*z,c[1]=d*C+v*T+x*P,c[4]=d*S+v*D+x*N,c[7]=d*_+v*U+x*z,c[2]=g*C+y*T+b*P,c[5]=g*S+y*D+b*N,c[8]=g*_+y*U+b*z,this}multiplyScalar(t){const i=this.elements;return i[0]*=t,i[3]*=t,i[6]*=t,i[1]*=t,i[4]*=t,i[7]*=t,i[2]*=t,i[5]*=t,i[8]*=t,this}determinant(){const t=this.elements,i=t[0],a=t[1],l=t[2],c=t[3],f=t[4],p=t[5],m=t[6],d=t[7],v=t[8];return i*f*v-i*p*d-a*c*v+a*p*m+l*c*d-l*f*m}invert(){const t=this.elements,i=t[0],a=t[1],l=t[2],c=t[3],f=t[4],p=t[5],m=t[6],d=t[7],v=t[8],x=v*f-p*d,g=p*m-v*c,y=d*c-f*m,b=i*x+a*g+l*y;if(b===0)return this.set(0,0,0,0,0,0,0,0,0);const C=1/b;return t[0]=x*C,t[1]=(l*d-v*a)*C,t[2]=(p*a-l*f)*C,t[3]=g*C,t[4]=(v*i-l*m)*C,t[5]=(l*c-p*i)*C,t[6]=y*C,t[7]=(a*m-d*i)*C,t[8]=(f*i-a*c)*C,this}transpose(){let t;const i=this.elements;return t=i[1],i[1]=i[3],i[3]=t,t=i[2],i[2]=i[6],i[6]=t,t=i[5],i[5]=i[7],i[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const i=this.elements;return t[0]=i[0],t[1]=i[3],t[2]=i[6],t[3]=i[1],t[4]=i[4],t[5]=i[7],t[6]=i[2],t[7]=i[5],t[8]=i[8],this}setUvTransform(t,i,a,l,c,f,p){const m=Math.cos(c),d=Math.sin(c);return this.set(a*m,a*d,-a*(m*f+d*p)+f+t,-l*d,l*m,-l*(-d*f+m*p)+p+i,0,0,1),this}scale(t,i){return this.premultiply(bh.makeScale(t,i)),this}rotate(t){return this.premultiply(bh.makeRotation(-t)),this}translate(t,i){return this.premultiply(bh.makeTranslation(t,i)),this}makeTranslation(t,i){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,i,0,0,1),this}makeRotation(t){const i=Math.cos(t),a=Math.sin(t);return this.set(i,-a,0,a,i,0,0,0,1),this}makeScale(t,i){return this.set(t,0,0,0,i,0,0,0,1),this}equals(t){const i=this.elements,a=t.elements;for(let l=0;l<9;l++)if(i[l]!==a[l])return!1;return!0}fromArray(t,i=0){for(let a=0;a<9;a++)this.elements[a]=t[a+i];return this}toArray(t=[],i=0){const a=this.elements;return t[i]=a[0],t[i+1]=a[1],t[i+2]=a[2],t[i+3]=a[3],t[i+4]=a[4],t[i+5]=a[5],t[i+6]=a[6],t[i+7]=a[7],t[i+8]=a[8],t}clone(){return new this.constructor().fromArray(this.elements)}};dp.prototype.isMatrix3=!0;let pe=dp;const bh=new pe,ov=new pe().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),lv=new pe().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function qy(){const r={enabled:!0,workingColorSpace:tu,spaces:{},convert:function(l,c,f){return this.enabled===!1||c===f||!c||!f||(this.spaces[c].transfer===qe&&(l.r=Aa(l.r),l.g=Aa(l.g),l.b=Aa(l.b)),this.spaces[c].primaries!==this.spaces[f].primaries&&(l.applyMatrix3(this.spaces[c].toXYZ),l.applyMatrix3(this.spaces[f].fromXYZ)),this.spaces[f].transfer===qe&&(l.r=Gr(l.r),l.g=Gr(l.g),l.b=Gr(l.b))),l},workingToColorSpace:function(l,c){return this.convert(l,this.workingColorSpace,c)},colorSpaceToWorking:function(l,c){return this.convert(l,c,this.workingColorSpace)},getPrimaries:function(l){return this.spaces[l].primaries},getTransfer:function(l){return l===rs?eu:this.spaces[l].transfer},getToneMappingMode:function(l){return this.spaces[l].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(l,c=this.workingColorSpace){return l.fromArray(this.spaces[c].luminanceCoefficients)},define:function(l){Object.assign(this.spaces,l)},_getMatrix:function(l,c,f){return l.copy(this.spaces[c].toXYZ).multiply(this.spaces[f].fromXYZ)},_getDrawingBufferColorSpace:function(l){return this.spaces[l].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(l=this.workingColorSpace){return this.spaces[l].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(l,c){return Vd("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),r.workingToColorSpace(l,c)},toWorkingColorSpace:function(l,c){return Vd("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),r.colorSpaceToWorking(l,c)}},t=[.64,.33,.3,.6,.15,.06],i=[.2126,.7152,.0722],a=[.3127,.329];return r.define({[tu]:{primaries:t,whitePoint:a,transfer:eu,toXYZ:ov,fromXYZ:lv,luminanceCoefficients:i,workingColorSpaceConfig:{unpackColorSpace:fi},outputColorSpaceConfig:{drawingBufferColorSpace:fi}},[fi]:{primaries:t,whitePoint:a,transfer:qe,toXYZ:ov,fromXYZ:lv,luminanceCoefficients:i,outputColorSpaceConfig:{drawingBufferColorSpace:fi}}}),r}const Ce=qy();function Aa(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function Gr(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Mr;class jy{static getDataURL(t,i="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let a;if(t instanceof HTMLCanvasElement)a=t;else{Mr===void 0&&(Mr=nu("canvas")),Mr.width=t.width,Mr.height=t.height;const l=Mr.getContext("2d");t instanceof ImageData?l.putImageData(t,0,0):l.drawImage(t,0,0,t.width,t.height),a=Mr}return a.toDataURL(i)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const i=nu("canvas");i.width=t.width,i.height=t.height;const a=i.getContext("2d");a.drawImage(t,0,0,t.width,t.height);const l=a.getImageData(0,0,t.width,t.height),c=l.data;for(let f=0;f<c.length;f++)c[f]=Aa(c[f]/255)*255;return a.putImageData(l,0,0),i}else if(t.data){const i=t.data.slice(0);for(let a=0;a<i.length;a++)i instanceof Uint8Array||i instanceof Uint8ClampedArray?i[a]=Math.floor(Aa(i[a]/255)*255):i[a]=Aa(i[a]);return{data:i,width:t.width,height:t.height}}else return ae("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Yy=0;class ap{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Yy++}),this.uuid=Wr(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const i=this.data;return typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement?t.set(i.videoWidth,i.videoHeight,0):typeof VideoFrame<"u"&&i instanceof VideoFrame?t.set(i.displayWidth,i.displayHeight,0):i!==null?t.set(i.width,i.height,i.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const i=t===void 0||typeof t=="string";if(!i&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const a={uuid:this.uuid,url:""},l=this.data;if(l!==null){let c;if(Array.isArray(l)){c=[];for(let f=0,p=l.length;f<p;f++)l[f].isDataTexture?c.push(Eh(l[f].image)):c.push(Eh(l[f]))}else c=Eh(l);a.url=c}return i||(t.images[this.uuid]=a),a}}function Eh(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?jy.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(ae("Texture: Unable to serialize Texture."),{})}let Zy=0;const Th=new K;class jn extends Hs{constructor(t=jn.DEFAULT_IMAGE,i=jn.DEFAULT_MAPPING,a=ba,l=ba,c=Gn,f=Is,p=Li,m=hi,d=jn.DEFAULT_ANISOTROPY,v=rs){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Zy++}),this.uuid=Wr(),this.name="",this.source=new ap(t),this.mipmaps=[],this.mapping=i,this.channel=0,this.wrapS=a,this.wrapT=l,this.magFilter=c,this.minFilter=f,this.anisotropy=d,this.format=p,this.internalFormat=null,this.type=m,this.offset=new De(0,0),this.repeat=new De(1,1),this.center=new De(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new pe,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=v,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Th).x}get height(){return this.source.getSize(Th).y}get depth(){return this.source.getSize(Th).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,i){this.updateRanges.push({start:t,count:i})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const i in t){const a=t[i];if(a===void 0){ae(`Texture.setValues(): parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){ae(`Texture.setValues(): property '${i}' does not exist.`);continue}l&&a&&l.isVector2&&a.isVector2||l&&a&&l.isVector3&&a.isVector3||l&&a&&l.isMatrix3&&a.isMatrix3?l.copy(a):this[i]=a}}toJSON(t){const i=t===void 0||typeof t=="string";if(!i&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const a={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(a.userData=this.userData),i||(t.textures[this.uuid]=a),a}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==cx)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case cd:t.x=t.x-Math.floor(t.x);break;case ba:t.x=t.x<0?0:1;break;case ud:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case cd:t.y=t.y-Math.floor(t.y);break;case ba:t.y=t.y<0?0:1;break;case ud:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}jn.DEFAULT_IMAGE=null;jn.DEFAULT_MAPPING=cx;jn.DEFAULT_ANISOTROPY=1;const pp=class pp{constructor(t=0,i=0,a=0,l=1){this.x=t,this.y=i,this.z=a,this.w=l}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,i,a,l){return this.x=t,this.y=i,this.z=a,this.w=l,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;case 3:this.w=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this.z=t.z+i.z,this.w=t.w+i.w,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this.z+=t.z*i,this.w+=t.w*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this.z=t.z-i.z,this.w=t.w-i.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const i=this.x,a=this.y,l=this.z,c=this.w,f=t.elements;return this.x=f[0]*i+f[4]*a+f[8]*l+f[12]*c,this.y=f[1]*i+f[5]*a+f[9]*l+f[13]*c,this.z=f[2]*i+f[6]*a+f[10]*l+f[14]*c,this.w=f[3]*i+f[7]*a+f[11]*l+f[15]*c,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const i=Math.sqrt(1-t.w*t.w);return i<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/i,this.y=t.y/i,this.z=t.z/i),this}setAxisAngleFromRotationMatrix(t){let i,a,l,c;const m=t.elements,d=m[0],v=m[4],x=m[8],g=m[1],y=m[5],b=m[9],C=m[2],S=m[6],_=m[10];if(Math.abs(v-g)<.01&&Math.abs(x-C)<.01&&Math.abs(b-S)<.01){if(Math.abs(v+g)<.1&&Math.abs(x+C)<.1&&Math.abs(b+S)<.1&&Math.abs(d+y+_-3)<.1)return this.set(1,0,0,0),this;i=Math.PI;const D=(d+1)/2,U=(y+1)/2,P=(_+1)/2,N=(v+g)/4,z=(x+C)/4,A=(b+S)/4;return D>U&&D>P?D<.01?(a=0,l=.707106781,c=.707106781):(a=Math.sqrt(D),l=N/a,c=z/a):U>P?U<.01?(a=.707106781,l=0,c=.707106781):(l=Math.sqrt(U),a=N/l,c=A/l):P<.01?(a=.707106781,l=.707106781,c=0):(c=Math.sqrt(P),a=z/c,l=A/c),this.set(a,l,c,i),this}let T=Math.sqrt((S-b)*(S-b)+(x-C)*(x-C)+(g-v)*(g-v));return Math.abs(T)<.001&&(T=1),this.x=(S-b)/T,this.y=(x-C)/T,this.z=(g-v)/T,this.w=Math.acos((d+y+_-1)/2),this}setFromMatrixPosition(t){const i=t.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this.w=i[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,i){return this.x=Re(this.x,t.x,i.x),this.y=Re(this.y,t.y,i.y),this.z=Re(this.z,t.z,i.z),this.w=Re(this.w,t.w,i.w),this}clampScalar(t,i){return this.x=Re(this.x,t,i),this.y=Re(this.y,t,i),this.z=Re(this.z,t,i),this.w=Re(this.w,t,i),this}clampLength(t,i){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Re(a,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this.z+=(t.z-this.z)*i,this.w+=(t.w-this.w)*i,this}lerpVectors(t,i,a){return this.x=t.x+(i.x-t.x)*a,this.y=t.y+(i.y-t.y)*a,this.z=t.z+(i.z-t.z)*a,this.w=t.w+(i.w-t.w)*a,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this.z=t[i+2],this.w=t[i+3],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t[i+2]=this.z,t[i+3]=this.w,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this.z=t.getZ(i),this.w=t.getW(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};pp.prototype.isVector4=!0;let fn=pp;class Ky extends Hs{constructor(t=1,i=1,a={}){super(),a=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Gn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},a),this.isRenderTarget=!0,this.width=t,this.height=i,this.depth=a.depth,this.scissor=new fn(0,0,t,i),this.scissorTest=!1,this.viewport=new fn(0,0,t,i),this.textures=[];const l={width:t,height:i,depth:a.depth},c=new jn(l),f=a.count;for(let p=0;p<f;p++)this.textures[p]=c.clone(),this.textures[p].isRenderTargetTexture=!0,this.textures[p].renderTarget=this;this._setTextureOptions(a),this.depthBuffer=a.depthBuffer,this.stencilBuffer=a.stencilBuffer,this.resolveDepthBuffer=a.resolveDepthBuffer,this.resolveStencilBuffer=a.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=a.depthTexture,this.samples=a.samples,this.multiview=a.multiview}_setTextureOptions(t={}){const i={minFilter:Gn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(i.mapping=t.mapping),t.wrapS!==void 0&&(i.wrapS=t.wrapS),t.wrapT!==void 0&&(i.wrapT=t.wrapT),t.wrapR!==void 0&&(i.wrapR=t.wrapR),t.magFilter!==void 0&&(i.magFilter=t.magFilter),t.minFilter!==void 0&&(i.minFilter=t.minFilter),t.format!==void 0&&(i.format=t.format),t.type!==void 0&&(i.type=t.type),t.anisotropy!==void 0&&(i.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(i.colorSpace=t.colorSpace),t.flipY!==void 0&&(i.flipY=t.flipY),t.generateMipmaps!==void 0&&(i.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(i.internalFormat=t.internalFormat);for(let a=0;a<this.textures.length;a++)this.textures[a].setValues(i)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,i,a=1){if(this.width!==t||this.height!==i||this.depth!==a){this.width=t,this.height=i,this.depth=a;for(let l=0,c=this.textures.length;l<c;l++)this.textures[l].image.width=t,this.textures[l].image.height=i,this.textures[l].image.depth=a,this.textures[l].isData3DTexture!==!0&&(this.textures[l].isArrayTexture=this.textures[l].image.depth>1);this.dispose()}this.viewport.set(0,0,t,i),this.scissor.set(0,0,t,i)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let i=0,a=t.textures.length;i<a;i++){this.textures[i]=t.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;const l=Object.assign({},t.textures[i].image);this.textures[i].source=new ap(l)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this.multiview=t.multiview,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Zi extends Ky{constructor(t=1,i=1,a={}){super(t,i,a),this.isWebGLRenderTarget=!0}}class xx extends jn{constructor(t=null,i=1,a=1,l=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:i,height:a,depth:l},this.magFilter=On,this.minFilter=On,this.wrapR=ba,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Qy extends jn{constructor(t=null,i=1,a=1,l=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:i,height:a,depth:l},this.magFilter=On,this.minFilter=On,this.wrapR=ba,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const au=class au{constructor(t,i,a,l,c,f,p,m,d,v,x,g,y,b,C,S){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,i,a,l,c,f,p,m,d,v,x,g,y,b,C,S)}set(t,i,a,l,c,f,p,m,d,v,x,g,y,b,C,S){const _=this.elements;return _[0]=t,_[4]=i,_[8]=a,_[12]=l,_[1]=c,_[5]=f,_[9]=p,_[13]=m,_[2]=d,_[6]=v,_[10]=x,_[14]=g,_[3]=y,_[7]=b,_[11]=C,_[15]=S,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new au().fromArray(this.elements)}copy(t){const i=this.elements,a=t.elements;return i[0]=a[0],i[1]=a[1],i[2]=a[2],i[3]=a[3],i[4]=a[4],i[5]=a[5],i[6]=a[6],i[7]=a[7],i[8]=a[8],i[9]=a[9],i[10]=a[10],i[11]=a[11],i[12]=a[12],i[13]=a[13],i[14]=a[14],i[15]=a[15],this}copyPosition(t){const i=this.elements,a=t.elements;return i[12]=a[12],i[13]=a[13],i[14]=a[14],this}setFromMatrix3(t){const i=t.elements;return this.set(i[0],i[3],i[6],0,i[1],i[4],i[7],0,i[2],i[5],i[8],0,0,0,0,1),this}extractBasis(t,i,a){return this.determinant()===0?(t.set(1,0,0),i.set(0,1,0),a.set(0,0,1),this):(t.setFromMatrixColumn(this,0),i.setFromMatrixColumn(this,1),a.setFromMatrixColumn(this,2),this)}makeBasis(t,i,a){return this.set(t.x,i.x,a.x,0,t.y,i.y,a.y,0,t.z,i.z,a.z,0,0,0,0,1),this}extractRotation(t){if(t.determinant()===0)return this.identity();const i=this.elements,a=t.elements,l=1/br.setFromMatrixColumn(t,0).length(),c=1/br.setFromMatrixColumn(t,1).length(),f=1/br.setFromMatrixColumn(t,2).length();return i[0]=a[0]*l,i[1]=a[1]*l,i[2]=a[2]*l,i[3]=0,i[4]=a[4]*c,i[5]=a[5]*c,i[6]=a[6]*c,i[7]=0,i[8]=a[8]*f,i[9]=a[9]*f,i[10]=a[10]*f,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromEuler(t){const i=this.elements,a=t.x,l=t.y,c=t.z,f=Math.cos(a),p=Math.sin(a),m=Math.cos(l),d=Math.sin(l),v=Math.cos(c),x=Math.sin(c);if(t.order==="XYZ"){const g=f*v,y=f*x,b=p*v,C=p*x;i[0]=m*v,i[4]=-m*x,i[8]=d,i[1]=y+b*d,i[5]=g-C*d,i[9]=-p*m,i[2]=C-g*d,i[6]=b+y*d,i[10]=f*m}else if(t.order==="YXZ"){const g=m*v,y=m*x,b=d*v,C=d*x;i[0]=g+C*p,i[4]=b*p-y,i[8]=f*d,i[1]=f*x,i[5]=f*v,i[9]=-p,i[2]=y*p-b,i[6]=C+g*p,i[10]=f*m}else if(t.order==="ZXY"){const g=m*v,y=m*x,b=d*v,C=d*x;i[0]=g-C*p,i[4]=-f*x,i[8]=b+y*p,i[1]=y+b*p,i[5]=f*v,i[9]=C-g*p,i[2]=-f*d,i[6]=p,i[10]=f*m}else if(t.order==="ZYX"){const g=f*v,y=f*x,b=p*v,C=p*x;i[0]=m*v,i[4]=b*d-y,i[8]=g*d+C,i[1]=m*x,i[5]=C*d+g,i[9]=y*d-b,i[2]=-d,i[6]=p*m,i[10]=f*m}else if(t.order==="YZX"){const g=f*m,y=f*d,b=p*m,C=p*d;i[0]=m*v,i[4]=C-g*x,i[8]=b*x+y,i[1]=x,i[5]=f*v,i[9]=-p*v,i[2]=-d*v,i[6]=y*x+b,i[10]=g-C*x}else if(t.order==="XZY"){const g=f*m,y=f*d,b=p*m,C=p*d;i[0]=m*v,i[4]=-x,i[8]=d*v,i[1]=g*x+C,i[5]=f*v,i[9]=y*x-b,i[2]=b*x-y,i[6]=p*v,i[10]=C*x+g}return i[3]=0,i[7]=0,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Jy,t,$y)}lookAt(t,i,a){const l=this.elements;return ci.subVectors(t,i),ci.lengthSq()===0&&(ci.z=1),ci.normalize(),$a.crossVectors(a,ci),$a.lengthSq()===0&&(Math.abs(a.z)===1?ci.x+=1e-4:ci.z+=1e-4,ci.normalize(),$a.crossVectors(a,ci)),$a.normalize(),Sc.crossVectors(ci,$a),l[0]=$a.x,l[4]=Sc.x,l[8]=ci.x,l[1]=$a.y,l[5]=Sc.y,l[9]=ci.y,l[2]=$a.z,l[6]=Sc.z,l[10]=ci.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,i){const a=t.elements,l=i.elements,c=this.elements,f=a[0],p=a[4],m=a[8],d=a[12],v=a[1],x=a[5],g=a[9],y=a[13],b=a[2],C=a[6],S=a[10],_=a[14],T=a[3],D=a[7],U=a[11],P=a[15],N=l[0],z=l[4],A=l[8],O=l[12],k=l[1],G=l[5],Y=l[9],ct=l[13],ut=l[2],W=l[6],F=l[10],V=l[14],rt=l[3],gt=l[7],I=l[11],tt=l[15];return c[0]=f*N+p*k+m*ut+d*rt,c[4]=f*z+p*G+m*W+d*gt,c[8]=f*A+p*Y+m*F+d*I,c[12]=f*O+p*ct+m*V+d*tt,c[1]=v*N+x*k+g*ut+y*rt,c[5]=v*z+x*G+g*W+y*gt,c[9]=v*A+x*Y+g*F+y*I,c[13]=v*O+x*ct+g*V+y*tt,c[2]=b*N+C*k+S*ut+_*rt,c[6]=b*z+C*G+S*W+_*gt,c[10]=b*A+C*Y+S*F+_*I,c[14]=b*O+C*ct+S*V+_*tt,c[3]=T*N+D*k+U*ut+P*rt,c[7]=T*z+D*G+U*W+P*gt,c[11]=T*A+D*Y+U*F+P*I,c[15]=T*O+D*ct+U*V+P*tt,this}multiplyScalar(t){const i=this.elements;return i[0]*=t,i[4]*=t,i[8]*=t,i[12]*=t,i[1]*=t,i[5]*=t,i[9]*=t,i[13]*=t,i[2]*=t,i[6]*=t,i[10]*=t,i[14]*=t,i[3]*=t,i[7]*=t,i[11]*=t,i[15]*=t,this}determinant(){const t=this.elements,i=t[0],a=t[4],l=t[8],c=t[12],f=t[1],p=t[5],m=t[9],d=t[13],v=t[2],x=t[6],g=t[10],y=t[14],b=t[3],C=t[7],S=t[11],_=t[15],T=m*y-d*g,D=p*y-d*x,U=p*g-m*x,P=f*y-d*v,N=f*g-m*v,z=f*x-p*v;return i*(C*T-S*D+_*U)-a*(b*T-S*P+_*N)+l*(b*D-C*P+_*z)-c*(b*U-C*N+S*z)}transpose(){const t=this.elements;let i;return i=t[1],t[1]=t[4],t[4]=i,i=t[2],t[2]=t[8],t[8]=i,i=t[6],t[6]=t[9],t[9]=i,i=t[3],t[3]=t[12],t[12]=i,i=t[7],t[7]=t[13],t[13]=i,i=t[11],t[11]=t[14],t[14]=i,this}setPosition(t,i,a){const l=this.elements;return t.isVector3?(l[12]=t.x,l[13]=t.y,l[14]=t.z):(l[12]=t,l[13]=i,l[14]=a),this}invert(){const t=this.elements,i=t[0],a=t[1],l=t[2],c=t[3],f=t[4],p=t[5],m=t[6],d=t[7],v=t[8],x=t[9],g=t[10],y=t[11],b=t[12],C=t[13],S=t[14],_=t[15],T=i*p-a*f,D=i*m-l*f,U=i*d-c*f,P=a*m-l*p,N=a*d-c*p,z=l*d-c*m,A=v*C-x*b,O=v*S-g*b,k=v*_-y*b,G=x*S-g*C,Y=x*_-y*C,ct=g*_-y*S,ut=T*ct-D*Y+U*G+P*k-N*O+z*A;if(ut===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const W=1/ut;return t[0]=(p*ct-m*Y+d*G)*W,t[1]=(l*Y-a*ct-c*G)*W,t[2]=(C*z-S*N+_*P)*W,t[3]=(g*N-x*z-y*P)*W,t[4]=(m*k-f*ct-d*O)*W,t[5]=(i*ct-l*k+c*O)*W,t[6]=(S*U-b*z-_*D)*W,t[7]=(v*z-g*U+y*D)*W,t[8]=(f*Y-p*k+d*A)*W,t[9]=(a*k-i*Y-c*A)*W,t[10]=(b*N-C*U+_*T)*W,t[11]=(x*U-v*N-y*T)*W,t[12]=(p*O-f*G-m*A)*W,t[13]=(i*G-a*O+l*A)*W,t[14]=(C*D-b*P-S*T)*W,t[15]=(v*P-x*D+g*T)*W,this}scale(t){const i=this.elements,a=t.x,l=t.y,c=t.z;return i[0]*=a,i[4]*=l,i[8]*=c,i[1]*=a,i[5]*=l,i[9]*=c,i[2]*=a,i[6]*=l,i[10]*=c,i[3]*=a,i[7]*=l,i[11]*=c,this}getMaxScaleOnAxis(){const t=this.elements,i=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],a=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],l=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(i,a,l))}makeTranslation(t,i,a){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,i,0,0,1,a,0,0,0,1),this}makeRotationX(t){const i=Math.cos(t),a=Math.sin(t);return this.set(1,0,0,0,0,i,-a,0,0,a,i,0,0,0,0,1),this}makeRotationY(t){const i=Math.cos(t),a=Math.sin(t);return this.set(i,0,a,0,0,1,0,0,-a,0,i,0,0,0,0,1),this}makeRotationZ(t){const i=Math.cos(t),a=Math.sin(t);return this.set(i,-a,0,0,a,i,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,i){const a=Math.cos(i),l=Math.sin(i),c=1-a,f=t.x,p=t.y,m=t.z,d=c*f,v=c*p;return this.set(d*f+a,d*p-l*m,d*m+l*p,0,d*p+l*m,v*p+a,v*m-l*f,0,d*m-l*p,v*m+l*f,c*m*m+a,0,0,0,0,1),this}makeScale(t,i,a){return this.set(t,0,0,0,0,i,0,0,0,0,a,0,0,0,0,1),this}makeShear(t,i,a,l,c,f){return this.set(1,a,c,0,t,1,f,0,i,l,1,0,0,0,0,1),this}compose(t,i,a){const l=this.elements,c=i._x,f=i._y,p=i._z,m=i._w,d=c+c,v=f+f,x=p+p,g=c*d,y=c*v,b=c*x,C=f*v,S=f*x,_=p*x,T=m*d,D=m*v,U=m*x,P=a.x,N=a.y,z=a.z;return l[0]=(1-(C+_))*P,l[1]=(y+U)*P,l[2]=(b-D)*P,l[3]=0,l[4]=(y-U)*N,l[5]=(1-(g+_))*N,l[6]=(S+T)*N,l[7]=0,l[8]=(b+D)*z,l[9]=(S-T)*z,l[10]=(1-(g+C))*z,l[11]=0,l[12]=t.x,l[13]=t.y,l[14]=t.z,l[15]=1,this}decompose(t,i,a){const l=this.elements;t.x=l[12],t.y=l[13],t.z=l[14];const c=this.determinant();if(c===0)return a.set(1,1,1),i.identity(),this;let f=br.set(l[0],l[1],l[2]).length();const p=br.set(l[4],l[5],l[6]).length(),m=br.set(l[8],l[9],l[10]).length();c<0&&(f=-f),Ri.copy(this);const d=1/f,v=1/p,x=1/m;return Ri.elements[0]*=d,Ri.elements[1]*=d,Ri.elements[2]*=d,Ri.elements[4]*=v,Ri.elements[5]*=v,Ri.elements[6]*=v,Ri.elements[8]*=x,Ri.elements[9]*=x,Ri.elements[10]*=x,i.setFromRotationMatrix(Ri),a.x=f,a.y=p,a.z=m,this}makePerspective(t,i,a,l,c,f,p=ji,m=!1){const d=this.elements,v=2*c/(i-t),x=2*c/(a-l),g=(i+t)/(i-t),y=(a+l)/(a-l);let b,C;if(m)b=c/(f-c),C=f*c/(f-c);else if(p===ji)b=-(f+c)/(f-c),C=-2*f*c/(f-c);else if(p===ll)b=-f/(f-c),C=-f*c/(f-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+p);return d[0]=v,d[4]=0,d[8]=g,d[12]=0,d[1]=0,d[5]=x,d[9]=y,d[13]=0,d[2]=0,d[6]=0,d[10]=b,d[14]=C,d[3]=0,d[7]=0,d[11]=-1,d[15]=0,this}makeOrthographic(t,i,a,l,c,f,p=ji,m=!1){const d=this.elements,v=2/(i-t),x=2/(a-l),g=-(i+t)/(i-t),y=-(a+l)/(a-l);let b,C;if(m)b=1/(f-c),C=f/(f-c);else if(p===ji)b=-2/(f-c),C=-(f+c)/(f-c);else if(p===ll)b=-1/(f-c),C=-c/(f-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+p);return d[0]=v,d[4]=0,d[8]=0,d[12]=g,d[1]=0,d[5]=x,d[9]=0,d[13]=y,d[2]=0,d[6]=0,d[10]=b,d[14]=C,d[3]=0,d[7]=0,d[11]=0,d[15]=1,this}equals(t){const i=this.elements,a=t.elements;for(let l=0;l<16;l++)if(i[l]!==a[l])return!1;return!0}fromArray(t,i=0){for(let a=0;a<16;a++)this.elements[a]=t[a+i];return this}toArray(t=[],i=0){const a=this.elements;return t[i]=a[0],t[i+1]=a[1],t[i+2]=a[2],t[i+3]=a[3],t[i+4]=a[4],t[i+5]=a[5],t[i+6]=a[6],t[i+7]=a[7],t[i+8]=a[8],t[i+9]=a[9],t[i+10]=a[10],t[i+11]=a[11],t[i+12]=a[12],t[i+13]=a[13],t[i+14]=a[14],t[i+15]=a[15],t}};au.prototype.isMatrix4=!0;let hn=au;const br=new K,Ri=new hn,Jy=new K(0,0,0),$y=new K(1,1,1),$a=new K,Sc=new K,ci=new K,cv=new hn,uv=new qr;class us{constructor(t=0,i=0,a=0,l=us.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=i,this._z=a,this._order=l}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,i,a,l=this._order){return this._x=t,this._y=i,this._z=a,this._order=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,i=this._order,a=!0){const l=t.elements,c=l[0],f=l[4],p=l[8],m=l[1],d=l[5],v=l[9],x=l[2],g=l[6],y=l[10];switch(i){case"XYZ":this._y=Math.asin(Re(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-v,y),this._z=Math.atan2(-f,c)):(this._x=Math.atan2(g,d),this._z=0);break;case"YXZ":this._x=Math.asin(-Re(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(p,y),this._z=Math.atan2(m,d)):(this._y=Math.atan2(-x,c),this._z=0);break;case"ZXY":this._x=Math.asin(Re(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(-x,y),this._z=Math.atan2(-f,d)):(this._y=0,this._z=Math.atan2(m,c));break;case"ZYX":this._y=Math.asin(-Re(x,-1,1)),Math.abs(x)<.9999999?(this._x=Math.atan2(g,y),this._z=Math.atan2(m,c)):(this._x=0,this._z=Math.atan2(-f,d));break;case"YZX":this._z=Math.asin(Re(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(-v,d),this._y=Math.atan2(-x,c)):(this._x=0,this._y=Math.atan2(p,y));break;case"XZY":this._z=Math.asin(-Re(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(g,d),this._y=Math.atan2(p,c)):(this._x=Math.atan2(-v,y),this._y=0);break;default:ae("Euler: .setFromRotationMatrix() encountered an unknown order: "+i)}return this._order=i,a===!0&&this._onChangeCallback(),this}setFromQuaternion(t,i,a){return cv.makeRotationFromQuaternion(t),this.setFromRotationMatrix(cv,i,a)}setFromVector3(t,i=this._order){return this.set(t.x,t.y,t.z,i)}reorder(t){return uv.setFromEuler(this),this.setFromQuaternion(uv,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],i=0){return t[i]=this._x,t[i+1]=this._y,t[i+2]=this._z,t[i+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}us.DEFAULT_ORDER="XYZ";class _x{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let tM=0;const fv=new K,Er=new qr,ga=new hn,yc=new K,jo=new K,eM=new K,nM=new qr,hv=new K(1,0,0),dv=new K(0,1,0),pv=new K(0,0,1),mv={type:"added"},iM={type:"removed"},Tr={type:"childadded",child:null},Ah={type:"childremoved",child:null};class Cn extends Hs{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:tM++}),this.uuid=Wr(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Cn.DEFAULT_UP.clone();const t=new K,i=new us,a=new qr,l=new K(1,1,1);function c(){a.setFromEuler(i,!1)}function f(){i.setFromQuaternion(a,void 0,!1)}i._onChange(c),a._onChange(f),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:i},quaternion:{configurable:!0,enumerable:!0,value:a},scale:{configurable:!0,enumerable:!0,value:l},modelViewMatrix:{value:new hn},normalMatrix:{value:new pe}}),this.matrix=new hn,this.matrixWorld=new hn,this.matrixAutoUpdate=Cn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Cn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new _x,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,i){this.quaternion.setFromAxisAngle(t,i)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,i){return Er.setFromAxisAngle(t,i),this.quaternion.multiply(Er),this}rotateOnWorldAxis(t,i){return Er.setFromAxisAngle(t,i),this.quaternion.premultiply(Er),this}rotateX(t){return this.rotateOnAxis(hv,t)}rotateY(t){return this.rotateOnAxis(dv,t)}rotateZ(t){return this.rotateOnAxis(pv,t)}translateOnAxis(t,i){return fv.copy(t).applyQuaternion(this.quaternion),this.position.add(fv.multiplyScalar(i)),this}translateX(t){return this.translateOnAxis(hv,t)}translateY(t){return this.translateOnAxis(dv,t)}translateZ(t){return this.translateOnAxis(pv,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(ga.copy(this.matrixWorld).invert())}lookAt(t,i,a){t.isVector3?yc.copy(t):yc.set(t,i,a);const l=this.parent;this.updateWorldMatrix(!0,!1),jo.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ga.lookAt(jo,yc,this.up):ga.lookAt(yc,jo,this.up),this.quaternion.setFromRotationMatrix(ga),l&&(ga.extractRotation(l.matrixWorld),Er.setFromRotationMatrix(ga),this.quaternion.premultiply(Er.invert()))}add(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.add(arguments[i]);return this}return t===this?(Oe("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(mv),Tr.child=t,this.dispatchEvent(Tr),Tr.child=null):Oe("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.remove(arguments[a]);return this}const i=this.children.indexOf(t);return i!==-1&&(t.parent=null,this.children.splice(i,1),t.dispatchEvent(iM),Ah.child=t,this.dispatchEvent(Ah),Ah.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),ga.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),ga.multiply(t.parent.matrixWorld)),t.applyMatrix4(ga),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(mv),Tr.child=t,this.dispatchEvent(Tr),Tr.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,i){if(this[t]===i)return this;for(let a=0,l=this.children.length;a<l;a++){const f=this.children[a].getObjectByProperty(t,i);if(f!==void 0)return f}}getObjectsByProperty(t,i,a=[]){this[t]===i&&a.push(this);const l=this.children;for(let c=0,f=l.length;c<f;c++)l[c].getObjectsByProperty(t,i,a);return a}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(jo,t,eM),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(jo,nM,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const i=this.matrixWorld.elements;return t.set(i[8],i[9],i[10]).normalize()}raycast(){}traverse(t){t(this);const i=this.children;for(let a=0,l=i.length;a<l;a++)i[a].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const i=this.children;for(let a=0,l=i.length;a<l;a++)i[a].traverseVisible(t)}traverseAncestors(t){const i=this.parent;i!==null&&(t(i),i.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const i=t.x,a=t.y,l=t.z,c=this.matrix.elements;c[12]+=i-c[0]*i-c[4]*a-c[8]*l,c[13]+=a-c[1]*i-c[5]*a-c[9]*l,c[14]+=l-c[2]*i-c[6]*a-c[10]*l}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const i=this.children;for(let a=0,l=i.length;a<l;a++)i[a].updateMatrixWorld(t)}updateWorldMatrix(t,i){const a=this.parent;if(t===!0&&a!==null&&a.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),i===!0){const l=this.children;for(let c=0,f=l.length;c<f;c++)l[c].updateWorldMatrix(!1,!0)}}toJSON(t){const i=t===void 0||typeof t=="string",a={};i&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},a.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const l={};l.uuid=this.uuid,l.type=this.type,this.name!==""&&(l.name=this.name),this.castShadow===!0&&(l.castShadow=!0),this.receiveShadow===!0&&(l.receiveShadow=!0),this.visible===!1&&(l.visible=!1),this.frustumCulled===!1&&(l.frustumCulled=!1),this.renderOrder!==0&&(l.renderOrder=this.renderOrder),this.static!==!1&&(l.static=this.static),Object.keys(this.userData).length>0&&(l.userData=this.userData),l.layers=this.layers.mask,l.matrix=this.matrix.toArray(),l.up=this.up.toArray(),this.pivot!==null&&(l.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(l.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(l.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(l.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(l.type="InstancedMesh",l.count=this.count,l.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(l.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(l.type="BatchedMesh",l.perObjectFrustumCulled=this.perObjectFrustumCulled,l.sortObjects=this.sortObjects,l.drawRanges=this._drawRanges,l.reservedRanges=this._reservedRanges,l.geometryInfo=this._geometryInfo.map(p=>({...p,boundingBox:p.boundingBox?p.boundingBox.toJSON():void 0,boundingSphere:p.boundingSphere?p.boundingSphere.toJSON():void 0})),l.instanceInfo=this._instanceInfo.map(p=>({...p})),l.availableInstanceIds=this._availableInstanceIds.slice(),l.availableGeometryIds=this._availableGeometryIds.slice(),l.nextIndexStart=this._nextIndexStart,l.nextVertexStart=this._nextVertexStart,l.geometryCount=this._geometryCount,l.maxInstanceCount=this._maxInstanceCount,l.maxVertexCount=this._maxVertexCount,l.maxIndexCount=this._maxIndexCount,l.geometryInitialized=this._geometryInitialized,l.matricesTexture=this._matricesTexture.toJSON(t),l.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(l.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(l.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(l.boundingBox=this.boundingBox.toJSON()));function c(p,m){return p[m.uuid]===void 0&&(p[m.uuid]=m.toJSON(t)),m.uuid}if(this.isScene)this.background&&(this.background.isColor?l.background=this.background.toJSON():this.background.isTexture&&(l.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(l.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){l.geometry=c(t.geometries,this.geometry);const p=this.geometry.parameters;if(p!==void 0&&p.shapes!==void 0){const m=p.shapes;if(Array.isArray(m))for(let d=0,v=m.length;d<v;d++){const x=m[d];c(t.shapes,x)}else c(t.shapes,m)}}if(this.isSkinnedMesh&&(l.bindMode=this.bindMode,l.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(t.skeletons,this.skeleton),l.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const p=[];for(let m=0,d=this.material.length;m<d;m++)p.push(c(t.materials,this.material[m]));l.material=p}else l.material=c(t.materials,this.material);if(this.children.length>0){l.children=[];for(let p=0;p<this.children.length;p++)l.children.push(this.children[p].toJSON(t).object)}if(this.animations.length>0){l.animations=[];for(let p=0;p<this.animations.length;p++){const m=this.animations[p];l.animations.push(c(t.animations,m))}}if(i){const p=f(t.geometries),m=f(t.materials),d=f(t.textures),v=f(t.images),x=f(t.shapes),g=f(t.skeletons),y=f(t.animations),b=f(t.nodes);p.length>0&&(a.geometries=p),m.length>0&&(a.materials=m),d.length>0&&(a.textures=d),v.length>0&&(a.images=v),x.length>0&&(a.shapes=x),g.length>0&&(a.skeletons=g),y.length>0&&(a.animations=y),b.length>0&&(a.nodes=b)}return a.object=l,a;function f(p){const m=[];for(const d in p){const v=p[d];delete v.metadata,m.push(v)}return m}}clone(t){return new this.constructor().copy(this,t)}copy(t,i=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),i===!0)for(let a=0;a<t.children.length;a++){const l=t.children[a];this.add(l.clone())}return this}}Cn.DEFAULT_UP=new K(0,1,0);Cn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Cn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Fs extends Cn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const aM={type:"move"};class wh{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Fs,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Fs,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new K,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new K),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Fs,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new K,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new K,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const i=this._hand;if(i)for(const a of t.hand.values())this._getHandJoint(i,a)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,i,a){let l=null,c=null,f=null;const p=this._targetRay,m=this._grip,d=this._hand;if(t&&i.session.visibilityState!=="visible-blurred"){if(d&&t.hand){f=!0;for(const C of t.hand.values()){const S=i.getJointPose(C,a),_=this._getHandJoint(d,C);S!==null&&(_.matrix.fromArray(S.transform.matrix),_.matrix.decompose(_.position,_.rotation,_.scale),_.matrixWorldNeedsUpdate=!0,_.jointRadius=S.radius),_.visible=S!==null}const v=d.joints["index-finger-tip"],x=d.joints["thumb-tip"],g=v.position.distanceTo(x.position),y=.02,b=.005;d.inputState.pinching&&g>y+b?(d.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!d.inputState.pinching&&g<=y-b&&(d.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else m!==null&&t.gripSpace&&(c=i.getPose(t.gripSpace,a),c!==null&&(m.matrix.fromArray(c.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,c.linearVelocity?(m.hasLinearVelocity=!0,m.linearVelocity.copy(c.linearVelocity)):m.hasLinearVelocity=!1,c.angularVelocity?(m.hasAngularVelocity=!0,m.angularVelocity.copy(c.angularVelocity)):m.hasAngularVelocity=!1,m.eventsEnabled&&m.dispatchEvent({type:"gripUpdated",data:t,target:this})));p!==null&&(l=i.getPose(t.targetRaySpace,a),l===null&&c!==null&&(l=c),l!==null&&(p.matrix.fromArray(l.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,l.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(l.linearVelocity)):p.hasLinearVelocity=!1,l.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(l.angularVelocity)):p.hasAngularVelocity=!1,this.dispatchEvent(aM)))}return p!==null&&(p.visible=l!==null),m!==null&&(m.visible=c!==null),d!==null&&(d.visible=f!==null),this}_getHandJoint(t,i){if(t.joints[i.jointName]===void 0){const a=new Fs;a.matrixAutoUpdate=!1,a.visible=!1,t.joints[i.jointName]=a,t.add(a)}return t.joints[i.jointName]}}const Sx={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ts={h:0,s:0,l:0},Mc={h:0,s:0,l:0};function Rh(r,t,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?r+(t-r)*6*i:i<1/2?t:i<2/3?r+(t-r)*6*(2/3-i):r}class de{constructor(t,i,a){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,i,a)}set(t,i,a){if(i===void 0&&a===void 0){const l=t;l&&l.isColor?this.copy(l):typeof l=="number"?this.setHex(l):typeof l=="string"&&this.setStyle(l)}else this.setRGB(t,i,a);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,i=fi){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Ce.colorSpaceToWorking(this,i),this}setRGB(t,i,a,l=Ce.workingColorSpace){return this.r=t,this.g=i,this.b=a,Ce.colorSpaceToWorking(this,l),this}setHSL(t,i,a,l=Ce.workingColorSpace){if(t=ip(t,1),i=Re(i,0,1),a=Re(a,0,1),i===0)this.r=this.g=this.b=a;else{const c=a<=.5?a*(1+i):a+i-a*i,f=2*a-c;this.r=Rh(f,c,t+1/3),this.g=Rh(f,c,t),this.b=Rh(f,c,t-1/3)}return Ce.colorSpaceToWorking(this,l),this}setStyle(t,i=fi){function a(c){c!==void 0&&parseFloat(c)<1&&ae("Color: Alpha component of "+t+" will be ignored.")}let l;if(l=/^(\w+)\(([^\)]*)\)/.exec(t)){let c;const f=l[1],p=l[2];switch(f){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return a(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,i);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return a(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,i);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return a(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,i);break;default:ae("Color: Unknown color model "+t)}}else if(l=/^\#([A-Fa-f\d]+)$/.exec(t)){const c=l[1],f=c.length;if(f===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,i);if(f===6)return this.setHex(parseInt(c,16),i);ae("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,i);return this}setColorName(t,i=fi){const a=Sx[t.toLowerCase()];return a!==void 0?this.setHex(a,i):ae("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Aa(t.r),this.g=Aa(t.g),this.b=Aa(t.b),this}copyLinearToSRGB(t){return this.r=Gr(t.r),this.g=Gr(t.g),this.b=Gr(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=fi){return Ce.workingToColorSpace(zn.copy(this),t),Math.round(Re(zn.r*255,0,255))*65536+Math.round(Re(zn.g*255,0,255))*256+Math.round(Re(zn.b*255,0,255))}getHexString(t=fi){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,i=Ce.workingColorSpace){Ce.workingToColorSpace(zn.copy(this),i);const a=zn.r,l=zn.g,c=zn.b,f=Math.max(a,l,c),p=Math.min(a,l,c);let m,d;const v=(p+f)/2;if(p===f)m=0,d=0;else{const x=f-p;switch(d=v<=.5?x/(f+p):x/(2-f-p),f){case a:m=(l-c)/x+(l<c?6:0);break;case l:m=(c-a)/x+2;break;case c:m=(a-l)/x+4;break}m/=6}return t.h=m,t.s=d,t.l=v,t}getRGB(t,i=Ce.workingColorSpace){return Ce.workingToColorSpace(zn.copy(this),i),t.r=zn.r,t.g=zn.g,t.b=zn.b,t}getStyle(t=fi){Ce.workingToColorSpace(zn.copy(this),t);const i=zn.r,a=zn.g,l=zn.b;return t!==fi?`color(${t} ${i.toFixed(3)} ${a.toFixed(3)} ${l.toFixed(3)})`:`rgb(${Math.round(i*255)},${Math.round(a*255)},${Math.round(l*255)})`}offsetHSL(t,i,a){return this.getHSL(ts),this.setHSL(ts.h+t,ts.s+i,ts.l+a)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,i){return this.r=t.r+i.r,this.g=t.g+i.g,this.b=t.b+i.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,i){return this.r+=(t.r-this.r)*i,this.g+=(t.g-this.g)*i,this.b+=(t.b-this.b)*i,this}lerpColors(t,i,a){return this.r=t.r+(i.r-t.r)*a,this.g=t.g+(i.g-t.g)*a,this.b=t.b+(i.b-t.b)*a,this}lerpHSL(t,i){this.getHSL(ts),t.getHSL(Mc);const a=sl(ts.h,Mc.h,i),l=sl(ts.s,Mc.s,i),c=sl(ts.l,Mc.l,i);return this.setHSL(a,l,c),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const i=this.r,a=this.g,l=this.b,c=t.elements;return this.r=c[0]*i+c[3]*a+c[6]*l,this.g=c[1]*i+c[4]*a+c[7]*l,this.b=c[2]*i+c[5]*a+c[8]*l,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,i=0){return this.r=t[i],this.g=t[i+1],this.b=t[i+2],this}toArray(t=[],i=0){return t[i]=this.r,t[i+1]=this.g,t[i+2]=this.b,t}fromBufferAttribute(t,i){return this.r=t.getX(i),this.g=t.getY(i),this.b=t.getZ(i),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const zn=new de;de.NAMES=Sx;class iu{constructor(t,i=1,a=1e3){this.isFog=!0,this.name="",this.color=new de(t),this.near=i,this.far=a}clone(){return new iu(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class sM extends Cn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new us,this.environmentIntensity=1,this.environmentRotation=new us,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,i){return super.copy(t,i),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const i=super.toJSON(t);return this.fog!==null&&(i.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(i.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(i.object.backgroundIntensity=this.backgroundIntensity),i.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(i.object.environmentIntensity=this.environmentIntensity),i.object.environmentRotation=this.environmentRotation.toArray(),i}}const Ci=new K,va=new K,Ch=new K,xa=new K,Ar=new K,wr=new K,gv=new K,Dh=new K,Nh=new K,Uh=new K,Lh=new fn,Ph=new fn,Oh=new fn;class Ui{constructor(t=new K,i=new K,a=new K){this.a=t,this.b=i,this.c=a}static getNormal(t,i,a,l){l.subVectors(a,i),Ci.subVectors(t,i),l.cross(Ci);const c=l.lengthSq();return c>0?l.multiplyScalar(1/Math.sqrt(c)):l.set(0,0,0)}static getBarycoord(t,i,a,l,c){Ci.subVectors(l,i),va.subVectors(a,i),Ch.subVectors(t,i);const f=Ci.dot(Ci),p=Ci.dot(va),m=Ci.dot(Ch),d=va.dot(va),v=va.dot(Ch),x=f*d-p*p;if(x===0)return c.set(0,0,0),null;const g=1/x,y=(d*m-p*v)*g,b=(f*v-p*m)*g;return c.set(1-y-b,b,y)}static containsPoint(t,i,a,l){return this.getBarycoord(t,i,a,l,xa)===null?!1:xa.x>=0&&xa.y>=0&&xa.x+xa.y<=1}static getInterpolation(t,i,a,l,c,f,p,m){return this.getBarycoord(t,i,a,l,xa)===null?(m.x=0,m.y=0,"z"in m&&(m.z=0),"w"in m&&(m.w=0),null):(m.setScalar(0),m.addScaledVector(c,xa.x),m.addScaledVector(f,xa.y),m.addScaledVector(p,xa.z),m)}static getInterpolatedAttribute(t,i,a,l,c,f){return Lh.setScalar(0),Ph.setScalar(0),Oh.setScalar(0),Lh.fromBufferAttribute(t,i),Ph.fromBufferAttribute(t,a),Oh.fromBufferAttribute(t,l),f.setScalar(0),f.addScaledVector(Lh,c.x),f.addScaledVector(Ph,c.y),f.addScaledVector(Oh,c.z),f}static isFrontFacing(t,i,a,l){return Ci.subVectors(a,i),va.subVectors(t,i),Ci.cross(va).dot(l)<0}set(t,i,a){return this.a.copy(t),this.b.copy(i),this.c.copy(a),this}setFromPointsAndIndices(t,i,a,l){return this.a.copy(t[i]),this.b.copy(t[a]),this.c.copy(t[l]),this}setFromAttributeAndIndices(t,i,a,l){return this.a.fromBufferAttribute(t,i),this.b.fromBufferAttribute(t,a),this.c.fromBufferAttribute(t,l),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Ci.subVectors(this.c,this.b),va.subVectors(this.a,this.b),Ci.cross(va).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Ui.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,i){return Ui.getBarycoord(t,this.a,this.b,this.c,i)}getInterpolation(t,i,a,l,c){return Ui.getInterpolation(t,this.a,this.b,this.c,i,a,l,c)}containsPoint(t){return Ui.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Ui.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,i){const a=this.a,l=this.b,c=this.c;let f,p;Ar.subVectors(l,a),wr.subVectors(c,a),Dh.subVectors(t,a);const m=Ar.dot(Dh),d=wr.dot(Dh);if(m<=0&&d<=0)return i.copy(a);Nh.subVectors(t,l);const v=Ar.dot(Nh),x=wr.dot(Nh);if(v>=0&&x<=v)return i.copy(l);const g=m*x-v*d;if(g<=0&&m>=0&&v<=0)return f=m/(m-v),i.copy(a).addScaledVector(Ar,f);Uh.subVectors(t,c);const y=Ar.dot(Uh),b=wr.dot(Uh);if(b>=0&&y<=b)return i.copy(c);const C=y*d-m*b;if(C<=0&&d>=0&&b<=0)return p=d/(d-b),i.copy(a).addScaledVector(wr,p);const S=v*b-y*x;if(S<=0&&x-v>=0&&y-b>=0)return gv.subVectors(c,l),p=(x-v)/(x-v+(y-b)),i.copy(l).addScaledVector(gv,p);const _=1/(S+C+g);return f=C*_,p=g*_,i.copy(a).addScaledVector(Ar,f).addScaledVector(wr,p)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class ul{constructor(t=new K(1/0,1/0,1/0),i=new K(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=i}set(t,i){return this.min.copy(t),this.max.copy(i),this}setFromArray(t){this.makeEmpty();for(let i=0,a=t.length;i<a;i+=3)this.expandByPoint(Di.fromArray(t,i));return this}setFromBufferAttribute(t){this.makeEmpty();for(let i=0,a=t.count;i<a;i++)this.expandByPoint(Di.fromBufferAttribute(t,i));return this}setFromPoints(t){this.makeEmpty();for(let i=0,a=t.length;i<a;i++)this.expandByPoint(t[i]);return this}setFromCenterAndSize(t,i){const a=Di.copy(i).multiplyScalar(.5);return this.min.copy(t).sub(a),this.max.copy(t).add(a),this}setFromObject(t,i=!1){return this.makeEmpty(),this.expandByObject(t,i)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,i=!1){t.updateWorldMatrix(!1,!1);const a=t.geometry;if(a!==void 0){const c=a.getAttribute("position");if(i===!0&&c!==void 0&&t.isInstancedMesh!==!0)for(let f=0,p=c.count;f<p;f++)t.isMesh===!0?t.getVertexPosition(f,Di):Di.fromBufferAttribute(c,f),Di.applyMatrix4(t.matrixWorld),this.expandByPoint(Di);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),bc.copy(t.boundingBox)):(a.boundingBox===null&&a.computeBoundingBox(),bc.copy(a.boundingBox)),bc.applyMatrix4(t.matrixWorld),this.union(bc)}const l=t.children;for(let c=0,f=l.length;c<f;c++)this.expandByObject(l[c],i);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,i){return i.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Di),Di.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let i,a;return t.normal.x>0?(i=t.normal.x*this.min.x,a=t.normal.x*this.max.x):(i=t.normal.x*this.max.x,a=t.normal.x*this.min.x),t.normal.y>0?(i+=t.normal.y*this.min.y,a+=t.normal.y*this.max.y):(i+=t.normal.y*this.max.y,a+=t.normal.y*this.min.y),t.normal.z>0?(i+=t.normal.z*this.min.z,a+=t.normal.z*this.max.z):(i+=t.normal.z*this.max.z,a+=t.normal.z*this.min.z),i<=-t.constant&&a>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Yo),Ec.subVectors(this.max,Yo),Rr.subVectors(t.a,Yo),Cr.subVectors(t.b,Yo),Dr.subVectors(t.c,Yo),es.subVectors(Cr,Rr),ns.subVectors(Dr,Cr),Cs.subVectors(Rr,Dr);let i=[0,-es.z,es.y,0,-ns.z,ns.y,0,-Cs.z,Cs.y,es.z,0,-es.x,ns.z,0,-ns.x,Cs.z,0,-Cs.x,-es.y,es.x,0,-ns.y,ns.x,0,-Cs.y,Cs.x,0];return!Ih(i,Rr,Cr,Dr,Ec)||(i=[1,0,0,0,1,0,0,0,1],!Ih(i,Rr,Cr,Dr,Ec))?!1:(Tc.crossVectors(es,ns),i=[Tc.x,Tc.y,Tc.z],Ih(i,Rr,Cr,Dr,Ec))}clampPoint(t,i){return i.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Di).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Di).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(_a[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),_a[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),_a[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),_a[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),_a[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),_a[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),_a[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),_a[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(_a),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const _a=[new K,new K,new K,new K,new K,new K,new K,new K],Di=new K,bc=new ul,Rr=new K,Cr=new K,Dr=new K,es=new K,ns=new K,Cs=new K,Yo=new K,Ec=new K,Tc=new K,Ds=new K;function Ih(r,t,i,a,l){for(let c=0,f=r.length-3;c<=f;c+=3){Ds.fromArray(r,c);const p=l.x*Math.abs(Ds.x)+l.y*Math.abs(Ds.y)+l.z*Math.abs(Ds.z),m=t.dot(Ds),d=i.dot(Ds),v=a.dot(Ds);if(Math.max(-Math.max(m,d,v),Math.min(m,d,v))>p)return!1}return!0}const _n=new K,Ac=new De;let rM=0;class Pi extends Hs{constructor(t,i,a=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:rM++}),this.name="",this.array=t,this.itemSize=i,this.count=t!==void 0?t.length/i:0,this.normalized=a,this.usage=ev,this.updateRanges=[],this.gpuType=qi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,i){this.updateRanges.push({start:t,count:i})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,i,a){t*=this.itemSize,a*=i.itemSize;for(let l=0,c=this.itemSize;l<c;l++)this.array[t+l]=i.array[a+l];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let i=0,a=this.count;i<a;i++)Ac.fromBufferAttribute(this,i),Ac.applyMatrix3(t),this.setXY(i,Ac.x,Ac.y);else if(this.itemSize===3)for(let i=0,a=this.count;i<a;i++)_n.fromBufferAttribute(this,i),_n.applyMatrix3(t),this.setXYZ(i,_n.x,_n.y,_n.z);return this}applyMatrix4(t){for(let i=0,a=this.count;i<a;i++)_n.fromBufferAttribute(this,i),_n.applyMatrix4(t),this.setXYZ(i,_n.x,_n.y,_n.z);return this}applyNormalMatrix(t){for(let i=0,a=this.count;i<a;i++)_n.fromBufferAttribute(this,i),_n.applyNormalMatrix(t),this.setXYZ(i,_n.x,_n.y,_n.z);return this}transformDirection(t){for(let i=0,a=this.count;i<a;i++)_n.fromBufferAttribute(this,i),_n.transformDirection(t),this.setXYZ(i,_n.x,_n.y,_n.z);return this}set(t,i=0){return this.array.set(t,i),this}getComponent(t,i){let a=this.array[t*this.itemSize+i];return this.normalized&&(a=Fr(a,this.array)),a}setComponent(t,i,a){return this.normalized&&(a=Wn(a,this.array)),this.array[t*this.itemSize+i]=a,this}getX(t){let i=this.array[t*this.itemSize];return this.normalized&&(i=Fr(i,this.array)),i}setX(t,i){return this.normalized&&(i=Wn(i,this.array)),this.array[t*this.itemSize]=i,this}getY(t){let i=this.array[t*this.itemSize+1];return this.normalized&&(i=Fr(i,this.array)),i}setY(t,i){return this.normalized&&(i=Wn(i,this.array)),this.array[t*this.itemSize+1]=i,this}getZ(t){let i=this.array[t*this.itemSize+2];return this.normalized&&(i=Fr(i,this.array)),i}setZ(t,i){return this.normalized&&(i=Wn(i,this.array)),this.array[t*this.itemSize+2]=i,this}getW(t){let i=this.array[t*this.itemSize+3];return this.normalized&&(i=Fr(i,this.array)),i}setW(t,i){return this.normalized&&(i=Wn(i,this.array)),this.array[t*this.itemSize+3]=i,this}setXY(t,i,a){return t*=this.itemSize,this.normalized&&(i=Wn(i,this.array),a=Wn(a,this.array)),this.array[t+0]=i,this.array[t+1]=a,this}setXYZ(t,i,a,l){return t*=this.itemSize,this.normalized&&(i=Wn(i,this.array),a=Wn(a,this.array),l=Wn(l,this.array)),this.array[t+0]=i,this.array[t+1]=a,this.array[t+2]=l,this}setXYZW(t,i,a,l,c){return t*=this.itemSize,this.normalized&&(i=Wn(i,this.array),a=Wn(a,this.array),l=Wn(l,this.array),c=Wn(c,this.array)),this.array[t+0]=i,this.array[t+1]=a,this.array[t+2]=l,this.array[t+3]=c,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==ev&&(t.usage=this.usage),t}dispose(){this.dispatchEvent({type:"dispose"})}}class yx extends Pi{constructor(t,i,a){super(new Uint16Array(t),i,a)}}class Mx extends Pi{constructor(t,i,a){super(new Uint32Array(t),i,a)}}class mn extends Pi{constructor(t,i,a){super(new Float32Array(t),i,a)}}const oM=new ul,Zo=new K,Bh=new K;class ru{constructor(t=new K,i=-1){this.isSphere=!0,this.center=t,this.radius=i}set(t,i){return this.center.copy(t),this.radius=i,this}setFromPoints(t,i){const a=this.center;i!==void 0?a.copy(i):oM.setFromPoints(t).getCenter(a);let l=0;for(let c=0,f=t.length;c<f;c++)l=Math.max(l,a.distanceToSquared(t[c]));return this.radius=Math.sqrt(l),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const i=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=i*i}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,i){const a=this.center.distanceToSquared(t);return i.copy(t),a>this.radius*this.radius&&(i.sub(this.center).normalize(),i.multiplyScalar(this.radius).add(this.center)),i}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Zo.subVectors(t,this.center);const i=Zo.lengthSq();if(i>this.radius*this.radius){const a=Math.sqrt(i),l=(a-this.radius)*.5;this.center.addScaledVector(Zo,l/a),this.radius+=l}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Bh.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Zo.copy(t.center).add(Bh)),this.expandByPoint(Zo.copy(t.center).sub(Bh))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let lM=0;const yi=new hn,Fh=new Cn,Nr=new K,ui=new ul,Ko=new ul,Rn=new K;class Yn extends Hs{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:lM++}),this.uuid=Wr(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Ay(t)?Mx:yx)(t,1):this.index=t,this}setIndirect(t,i=0){return this.indirect=t,this.indirectOffset=i,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,i){return this.attributes[t]=i,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,i,a=0){this.groups.push({start:t,count:i,materialIndex:a})}clearGroups(){this.groups=[]}setDrawRange(t,i){this.drawRange.start=t,this.drawRange.count=i}applyMatrix4(t){const i=this.attributes.position;i!==void 0&&(i.applyMatrix4(t),i.needsUpdate=!0);const a=this.attributes.normal;if(a!==void 0){const c=new pe().getNormalMatrix(t);a.applyNormalMatrix(c),a.needsUpdate=!0}const l=this.attributes.tangent;return l!==void 0&&(l.transformDirection(t),l.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return yi.makeRotationFromQuaternion(t),this.applyMatrix4(yi),this}rotateX(t){return yi.makeRotationX(t),this.applyMatrix4(yi),this}rotateY(t){return yi.makeRotationY(t),this.applyMatrix4(yi),this}rotateZ(t){return yi.makeRotationZ(t),this.applyMatrix4(yi),this}translate(t,i,a){return yi.makeTranslation(t,i,a),this.applyMatrix4(yi),this}scale(t,i,a){return yi.makeScale(t,i,a),this.applyMatrix4(yi),this}lookAt(t){return Fh.lookAt(t),Fh.updateMatrix(),this.applyMatrix4(Fh.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Nr).negate(),this.translate(Nr.x,Nr.y,Nr.z),this}setFromPoints(t){const i=this.getAttribute("position");if(i===void 0){const a=[];for(let l=0,c=t.length;l<c;l++){const f=t[l];a.push(f.x,f.y,f.z||0)}this.setAttribute("position",new mn(a,3))}else{const a=Math.min(t.length,i.count);for(let l=0;l<a;l++){const c=t[l];i.setXYZ(l,c.x,c.y,c.z||0)}t.length>i.count&&ae("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),i.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ul);const t=this.attributes.position,i=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Oe("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new K(-1/0,-1/0,-1/0),new K(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),i)for(let a=0,l=i.length;a<l;a++){const c=i[a];ui.setFromBufferAttribute(c),this.morphTargetsRelative?(Rn.addVectors(this.boundingBox.min,ui.min),this.boundingBox.expandByPoint(Rn),Rn.addVectors(this.boundingBox.max,ui.max),this.boundingBox.expandByPoint(Rn)):(this.boundingBox.expandByPoint(ui.min),this.boundingBox.expandByPoint(ui.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Oe('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ru);const t=this.attributes.position,i=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Oe("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new K,1/0);return}if(t){const a=this.boundingSphere.center;if(ui.setFromBufferAttribute(t),i)for(let c=0,f=i.length;c<f;c++){const p=i[c];Ko.setFromBufferAttribute(p),this.morphTargetsRelative?(Rn.addVectors(ui.min,Ko.min),ui.expandByPoint(Rn),Rn.addVectors(ui.max,Ko.max),ui.expandByPoint(Rn)):(ui.expandByPoint(Ko.min),ui.expandByPoint(Ko.max))}ui.getCenter(a);let l=0;for(let c=0,f=t.count;c<f;c++)Rn.fromBufferAttribute(t,c),l=Math.max(l,a.distanceToSquared(Rn));if(i)for(let c=0,f=i.length;c<f;c++){const p=i[c],m=this.morphTargetsRelative;for(let d=0,v=p.count;d<v;d++)Rn.fromBufferAttribute(p,d),m&&(Nr.fromBufferAttribute(t,d),Rn.add(Nr)),l=Math.max(l,a.distanceToSquared(Rn))}this.boundingSphere.radius=Math.sqrt(l),isNaN(this.boundingSphere.radius)&&Oe('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,i=this.attributes;if(t===null||i.position===void 0||i.normal===void 0||i.uv===void 0){Oe("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const a=i.position,l=i.normal,c=i.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Pi(new Float32Array(4*a.count),4));const f=this.getAttribute("tangent"),p=[],m=[];for(let A=0;A<a.count;A++)p[A]=new K,m[A]=new K;const d=new K,v=new K,x=new K,g=new De,y=new De,b=new De,C=new K,S=new K;function _(A,O,k){d.fromBufferAttribute(a,A),v.fromBufferAttribute(a,O),x.fromBufferAttribute(a,k),g.fromBufferAttribute(c,A),y.fromBufferAttribute(c,O),b.fromBufferAttribute(c,k),v.sub(d),x.sub(d),y.sub(g),b.sub(g);const G=1/(y.x*b.y-b.x*y.y);isFinite(G)&&(C.copy(v).multiplyScalar(b.y).addScaledVector(x,-y.y).multiplyScalar(G),S.copy(x).multiplyScalar(y.x).addScaledVector(v,-b.x).multiplyScalar(G),p[A].add(C),p[O].add(C),p[k].add(C),m[A].add(S),m[O].add(S),m[k].add(S))}let T=this.groups;T.length===0&&(T=[{start:0,count:t.count}]);for(let A=0,O=T.length;A<O;++A){const k=T[A],G=k.start,Y=k.count;for(let ct=G,ut=G+Y;ct<ut;ct+=3)_(t.getX(ct+0),t.getX(ct+1),t.getX(ct+2))}const D=new K,U=new K,P=new K,N=new K;function z(A){P.fromBufferAttribute(l,A),N.copy(P);const O=p[A];D.copy(O),D.sub(P.multiplyScalar(P.dot(O))).normalize(),U.crossVectors(N,O);const G=U.dot(m[A])<0?-1:1;f.setXYZW(A,D.x,D.y,D.z,G)}for(let A=0,O=T.length;A<O;++A){const k=T[A],G=k.start,Y=k.count;for(let ct=G,ut=G+Y;ct<ut;ct+=3)z(t.getX(ct+0)),z(t.getX(ct+1)),z(t.getX(ct+2))}}computeVertexNormals(){const t=this.index,i=this.getAttribute("position");if(i!==void 0){let a=this.getAttribute("normal");if(a===void 0)a=new Pi(new Float32Array(i.count*3),3),this.setAttribute("normal",a);else for(let g=0,y=a.count;g<y;g++)a.setXYZ(g,0,0,0);const l=new K,c=new K,f=new K,p=new K,m=new K,d=new K,v=new K,x=new K;if(t)for(let g=0,y=t.count;g<y;g+=3){const b=t.getX(g+0),C=t.getX(g+1),S=t.getX(g+2);l.fromBufferAttribute(i,b),c.fromBufferAttribute(i,C),f.fromBufferAttribute(i,S),v.subVectors(f,c),x.subVectors(l,c),v.cross(x),p.fromBufferAttribute(a,b),m.fromBufferAttribute(a,C),d.fromBufferAttribute(a,S),p.add(v),m.add(v),d.add(v),a.setXYZ(b,p.x,p.y,p.z),a.setXYZ(C,m.x,m.y,m.z),a.setXYZ(S,d.x,d.y,d.z)}else for(let g=0,y=i.count;g<y;g+=3)l.fromBufferAttribute(i,g+0),c.fromBufferAttribute(i,g+1),f.fromBufferAttribute(i,g+2),v.subVectors(f,c),x.subVectors(l,c),v.cross(x),a.setXYZ(g+0,v.x,v.y,v.z),a.setXYZ(g+1,v.x,v.y,v.z),a.setXYZ(g+2,v.x,v.y,v.z);this.normalizeNormals(),a.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let i=0,a=t.count;i<a;i++)Rn.fromBufferAttribute(t,i),Rn.normalize(),t.setXYZ(i,Rn.x,Rn.y,Rn.z)}toNonIndexed(){function t(p,m){const d=p.array,v=p.itemSize,x=p.normalized,g=new d.constructor(m.length*v);let y=0,b=0;for(let C=0,S=m.length;C<S;C++){p.isInterleavedBufferAttribute?y=m[C]*p.data.stride+p.offset:y=m[C]*v;for(let _=0;_<v;_++)g[b++]=d[y++]}return new Pi(g,v,x)}if(this.index===null)return ae("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const i=new Yn,a=this.index.array,l=this.attributes;for(const p in l){const m=l[p],d=t(m,a);i.setAttribute(p,d)}const c=this.morphAttributes;for(const p in c){const m=[],d=c[p];for(let v=0,x=d.length;v<x;v++){const g=d[v],y=t(g,a);m.push(y)}i.morphAttributes[p]=m}i.morphTargetsRelative=this.morphTargetsRelative;const f=this.groups;for(let p=0,m=f.length;p<m;p++){const d=f[p];i.addGroup(d.start,d.count,d.materialIndex)}return i}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const m=this.parameters;for(const d in m)m[d]!==void 0&&(t[d]=m[d]);return t}t.data={attributes:{}};const i=this.index;i!==null&&(t.data.index={type:i.array.constructor.name,array:Array.prototype.slice.call(i.array)});const a=this.attributes;for(const m in a){const d=a[m];t.data.attributes[m]=d.toJSON(t.data)}const l={};let c=!1;for(const m in this.morphAttributes){const d=this.morphAttributes[m],v=[];for(let x=0,g=d.length;x<g;x++){const y=d[x];v.push(y.toJSON(t.data))}v.length>0&&(l[m]=v,c=!0)}c&&(t.data.morphAttributes=l,t.data.morphTargetsRelative=this.morphTargetsRelative);const f=this.groups;f.length>0&&(t.data.groups=JSON.parse(JSON.stringify(f)));const p=this.boundingSphere;return p!==null&&(t.data.boundingSphere=p.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const i={};this.name=t.name;const a=t.index;a!==null&&this.setIndex(a.clone());const l=t.attributes;for(const d in l){const v=l[d];this.setAttribute(d,v.clone(i))}const c=t.morphAttributes;for(const d in c){const v=[],x=c[d];for(let g=0,y=x.length;g<y;g++)v.push(x[g].clone(i));this.morphAttributes[d]=v}this.morphTargetsRelative=t.morphTargetsRelative;const f=t.groups;for(let d=0,v=f.length;d<v;d++){const x=f[d];this.addGroup(x.start,x.count,x.materialIndex)}const p=t.boundingBox;p!==null&&(this.boundingBox=p.clone());const m=t.boundingSphere;return m!==null&&(this.boundingSphere=m.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}let cM=0;class jr extends Hs{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:cM++}),this.uuid=Wr(),this.name="",this.type="Material",this.blending=zr,this.side=cs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=td,this.blendDst=ed,this.blendEquation=Ps,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new de(0,0,0),this.blendAlpha=0,this.depthFunc=Hr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=tv,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=yr,this.stencilZFail=yr,this.stencilZPass=yr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const i in t){const a=t[i];if(a===void 0){ae(`Material: parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){ae(`Material: '${i}' is not a property of THREE.${this.type}.`);continue}l&&l.isColor?l.set(a):l&&l.isVector3&&a&&a.isVector3?l.copy(a):this[i]=a}}toJSON(t){const i=t===void 0||typeof t=="string";i&&(t={textures:{},images:{}});const a={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.color&&this.color.isColor&&(a.color=this.color.getHex()),this.roughness!==void 0&&(a.roughness=this.roughness),this.metalness!==void 0&&(a.metalness=this.metalness),this.sheen!==void 0&&(a.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(a.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(a.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(a.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(a.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(a.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(a.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(a.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(a.shininess=this.shininess),this.clearcoat!==void 0&&(a.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(a.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(a.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(a.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(a.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,a.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(a.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(a.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(a.dispersion=this.dispersion),this.iridescence!==void 0&&(a.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(a.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(a.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(a.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(a.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(a.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(a.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(a.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(a.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(a.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(a.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(a.lightMap=this.lightMap.toJSON(t).uuid,a.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(a.aoMap=this.aoMap.toJSON(t).uuid,a.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(a.bumpMap=this.bumpMap.toJSON(t).uuid,a.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(a.normalMap=this.normalMap.toJSON(t).uuid,a.normalMapType=this.normalMapType,a.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(a.displacementMap=this.displacementMap.toJSON(t).uuid,a.displacementScale=this.displacementScale,a.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(a.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(a.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(a.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(a.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(a.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(a.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(a.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(a.combine=this.combine)),this.envMapRotation!==void 0&&(a.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(a.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(a.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(a.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(a.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(a.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(a.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(a.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(a.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(a.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(a.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(a.size=this.size),this.shadowSide!==null&&(a.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(a.sizeAttenuation=this.sizeAttenuation),this.blending!==zr&&(a.blending=this.blending),this.side!==cs&&(a.side=this.side),this.vertexColors===!0&&(a.vertexColors=!0),this.opacity<1&&(a.opacity=this.opacity),this.transparent===!0&&(a.transparent=!0),this.blendSrc!==td&&(a.blendSrc=this.blendSrc),this.blendDst!==ed&&(a.blendDst=this.blendDst),this.blendEquation!==Ps&&(a.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(a.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(a.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(a.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(a.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(a.blendAlpha=this.blendAlpha),this.depthFunc!==Hr&&(a.depthFunc=this.depthFunc),this.depthTest===!1&&(a.depthTest=this.depthTest),this.depthWrite===!1&&(a.depthWrite=this.depthWrite),this.colorWrite===!1&&(a.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(a.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==tv&&(a.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(a.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(a.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==yr&&(a.stencilFail=this.stencilFail),this.stencilZFail!==yr&&(a.stencilZFail=this.stencilZFail),this.stencilZPass!==yr&&(a.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(a.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(a.rotation=this.rotation),this.polygonOffset===!0&&(a.polygonOffset=!0),this.polygonOffsetFactor!==0&&(a.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(a.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(a.linewidth=this.linewidth),this.dashSize!==void 0&&(a.dashSize=this.dashSize),this.gapSize!==void 0&&(a.gapSize=this.gapSize),this.scale!==void 0&&(a.scale=this.scale),this.dithering===!0&&(a.dithering=!0),this.alphaTest>0&&(a.alphaTest=this.alphaTest),this.alphaHash===!0&&(a.alphaHash=!0),this.alphaToCoverage===!0&&(a.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(a.premultipliedAlpha=!0),this.forceSinglePass===!0&&(a.forceSinglePass=!0),this.allowOverride===!1&&(a.allowOverride=!1),this.wireframe===!0&&(a.wireframe=!0),this.wireframeLinewidth>1&&(a.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(a.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(a.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(a.flatShading=!0),this.visible===!1&&(a.visible=!1),this.toneMapped===!1&&(a.toneMapped=!1),this.fog===!1&&(a.fog=!1),Object.keys(this.userData).length>0&&(a.userData=this.userData);function l(c){const f=[];for(const p in c){const m=c[p];delete m.metadata,f.push(m)}return f}if(i){const c=l(t.textures),f=l(t.images);c.length>0&&(a.textures=c),f.length>0&&(a.images=f)}return a}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const i=t.clippingPlanes;let a=null;if(i!==null){const l=i.length;a=new Array(l);for(let c=0;c!==l;++c)a[c]=i[c].clone()}return this.clippingPlanes=a,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}const Sa=new K,zh=new K,wc=new K,is=new K,Gh=new K,Rc=new K,Hh=new K;class bx{constructor(t=new K,i=new K(0,0,-1)){this.origin=t,this.direction=i}set(t,i){return this.origin.copy(t),this.direction.copy(i),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,i){return i.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Sa)),this}closestPointToPoint(t,i){i.subVectors(t,this.origin);const a=i.dot(this.direction);return a<0?i.copy(this.origin):i.copy(this.origin).addScaledVector(this.direction,a)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const i=Sa.subVectors(t,this.origin).dot(this.direction);return i<0?this.origin.distanceToSquared(t):(Sa.copy(this.origin).addScaledVector(this.direction,i),Sa.distanceToSquared(t))}distanceSqToSegment(t,i,a,l){zh.copy(t).add(i).multiplyScalar(.5),wc.copy(i).sub(t).normalize(),is.copy(this.origin).sub(zh);const c=t.distanceTo(i)*.5,f=-this.direction.dot(wc),p=is.dot(this.direction),m=-is.dot(wc),d=is.lengthSq(),v=Math.abs(1-f*f);let x,g,y,b;if(v>0)if(x=f*m-p,g=f*p-m,b=c*v,x>=0)if(g>=-b)if(g<=b){const C=1/v;x*=C,g*=C,y=x*(x+f*g+2*p)+g*(f*x+g+2*m)+d}else g=c,x=Math.max(0,-(f*g+p)),y=-x*x+g*(g+2*m)+d;else g=-c,x=Math.max(0,-(f*g+p)),y=-x*x+g*(g+2*m)+d;else g<=-b?(x=Math.max(0,-(-f*c+p)),g=x>0?-c:Math.min(Math.max(-c,-m),c),y=-x*x+g*(g+2*m)+d):g<=b?(x=0,g=Math.min(Math.max(-c,-m),c),y=g*(g+2*m)+d):(x=Math.max(0,-(f*c+p)),g=x>0?c:Math.min(Math.max(-c,-m),c),y=-x*x+g*(g+2*m)+d);else g=f>0?-c:c,x=Math.max(0,-(f*g+p)),y=-x*x+g*(g+2*m)+d;return a&&a.copy(this.origin).addScaledVector(this.direction,x),l&&l.copy(zh).addScaledVector(wc,g),y}intersectSphere(t,i){Sa.subVectors(t.center,this.origin);const a=Sa.dot(this.direction),l=Sa.dot(Sa)-a*a,c=t.radius*t.radius;if(l>c)return null;const f=Math.sqrt(c-l),p=a-f,m=a+f;return m<0?null:p<0?this.at(m,i):this.at(p,i)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const i=t.normal.dot(this.direction);if(i===0)return t.distanceToPoint(this.origin)===0?0:null;const a=-(this.origin.dot(t.normal)+t.constant)/i;return a>=0?a:null}intersectPlane(t,i){const a=this.distanceToPlane(t);return a===null?null:this.at(a,i)}intersectsPlane(t){const i=t.distanceToPoint(this.origin);return i===0||t.normal.dot(this.direction)*i<0}intersectBox(t,i){let a,l,c,f,p,m;const d=1/this.direction.x,v=1/this.direction.y,x=1/this.direction.z,g=this.origin;return d>=0?(a=(t.min.x-g.x)*d,l=(t.max.x-g.x)*d):(a=(t.max.x-g.x)*d,l=(t.min.x-g.x)*d),v>=0?(c=(t.min.y-g.y)*v,f=(t.max.y-g.y)*v):(c=(t.max.y-g.y)*v,f=(t.min.y-g.y)*v),a>f||c>l||((c>a||isNaN(a))&&(a=c),(f<l||isNaN(l))&&(l=f),x>=0?(p=(t.min.z-g.z)*x,m=(t.max.z-g.z)*x):(p=(t.max.z-g.z)*x,m=(t.min.z-g.z)*x),a>m||p>l)||((p>a||a!==a)&&(a=p),(m<l||l!==l)&&(l=m),l<0)?null:this.at(a>=0?a:l,i)}intersectsBox(t){return this.intersectBox(t,Sa)!==null}intersectTriangle(t,i,a,l,c){Gh.subVectors(i,t),Rc.subVectors(a,t),Hh.crossVectors(Gh,Rc);let f=this.direction.dot(Hh),p;if(f>0){if(l)return null;p=1}else if(f<0)p=-1,f=-f;else return null;is.subVectors(this.origin,t);const m=p*this.direction.dot(Rc.crossVectors(is,Rc));if(m<0)return null;const d=p*this.direction.dot(Gh.cross(is));if(d<0||m+d>f)return null;const v=-p*is.dot(Hh);return v<0?null:this.at(v/f,c)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class os extends jr{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new de(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new us,this.combine=nx,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const vv=new hn,Ns=new bx,Cc=new ru,xv=new K,Dc=new K,Nc=new K,Uc=new K,Vh=new K,Lc=new K,_v=new K,Pc=new K;class qt extends Cn{constructor(t=new Yn,i=new os){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,i){return super.copy(t,i),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const i=this.geometry.morphAttributes,a=Object.keys(i);if(a.length>0){const l=i[a[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,f=l.length;c<f;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}getVertexPosition(t,i){const a=this.geometry,l=a.attributes.position,c=a.morphAttributes.position,f=a.morphTargetsRelative;i.fromBufferAttribute(l,t);const p=this.morphTargetInfluences;if(c&&p){Lc.set(0,0,0);for(let m=0,d=c.length;m<d;m++){const v=p[m],x=c[m];v!==0&&(Vh.fromBufferAttribute(x,t),f?Lc.addScaledVector(Vh,v):Lc.addScaledVector(Vh.sub(i),v))}i.add(Lc)}return i}raycast(t,i){const a=this.geometry,l=this.material,c=this.matrixWorld;l!==void 0&&(a.boundingSphere===null&&a.computeBoundingSphere(),Cc.copy(a.boundingSphere),Cc.applyMatrix4(c),Ns.copy(t.ray).recast(t.near),!(Cc.containsPoint(Ns.origin)===!1&&(Ns.intersectSphere(Cc,xv)===null||Ns.origin.distanceToSquared(xv)>(t.far-t.near)**2))&&(vv.copy(c).invert(),Ns.copy(t.ray).applyMatrix4(vv),!(a.boundingBox!==null&&Ns.intersectsBox(a.boundingBox)===!1)&&this._computeIntersections(t,i,Ns)))}_computeIntersections(t,i,a){let l;const c=this.geometry,f=this.material,p=c.index,m=c.attributes.position,d=c.attributes.uv,v=c.attributes.uv1,x=c.attributes.normal,g=c.groups,y=c.drawRange;if(p!==null)if(Array.isArray(f))for(let b=0,C=g.length;b<C;b++){const S=g[b],_=f[S.materialIndex],T=Math.max(S.start,y.start),D=Math.min(p.count,Math.min(S.start+S.count,y.start+y.count));for(let U=T,P=D;U<P;U+=3){const N=p.getX(U),z=p.getX(U+1),A=p.getX(U+2);l=Oc(this,_,t,a,d,v,x,N,z,A),l&&(l.faceIndex=Math.floor(U/3),l.face.materialIndex=S.materialIndex,i.push(l))}}else{const b=Math.max(0,y.start),C=Math.min(p.count,y.start+y.count);for(let S=b,_=C;S<_;S+=3){const T=p.getX(S),D=p.getX(S+1),U=p.getX(S+2);l=Oc(this,f,t,a,d,v,x,T,D,U),l&&(l.faceIndex=Math.floor(S/3),i.push(l))}}else if(m!==void 0)if(Array.isArray(f))for(let b=0,C=g.length;b<C;b++){const S=g[b],_=f[S.materialIndex],T=Math.max(S.start,y.start),D=Math.min(m.count,Math.min(S.start+S.count,y.start+y.count));for(let U=T,P=D;U<P;U+=3){const N=U,z=U+1,A=U+2;l=Oc(this,_,t,a,d,v,x,N,z,A),l&&(l.faceIndex=Math.floor(U/3),l.face.materialIndex=S.materialIndex,i.push(l))}}else{const b=Math.max(0,y.start),C=Math.min(m.count,y.start+y.count);for(let S=b,_=C;S<_;S+=3){const T=S,D=S+1,U=S+2;l=Oc(this,f,t,a,d,v,x,T,D,U),l&&(l.faceIndex=Math.floor(S/3),i.push(l))}}}}function uM(r,t,i,a,l,c,f,p){let m;if(t.side===$n?m=a.intersectTriangle(f,c,l,!0,p):m=a.intersectTriangle(l,c,f,t.side===cs,p),m===null)return null;Pc.copy(p),Pc.applyMatrix4(r.matrixWorld);const d=i.ray.origin.distanceTo(Pc);return d<i.near||d>i.far?null:{distance:d,point:Pc.clone(),object:r}}function Oc(r,t,i,a,l,c,f,p,m,d){r.getVertexPosition(p,Dc),r.getVertexPosition(m,Nc),r.getVertexPosition(d,Uc);const v=uM(r,t,i,a,Dc,Nc,Uc,_v);if(v){const x=new K;Ui.getBarycoord(_v,Dc,Nc,Uc,x),l&&(v.uv=Ui.getInterpolatedAttribute(l,p,m,d,x,new De)),c&&(v.uv1=Ui.getInterpolatedAttribute(c,p,m,d,x,new De)),f&&(v.normal=Ui.getInterpolatedAttribute(f,p,m,d,x,new K),v.normal.dot(a.direction)>0&&v.normal.multiplyScalar(-1));const g={a:p,b:m,c:d,normal:new K,materialIndex:0};Ui.getNormal(Dc,Nc,Uc,g.normal),v.face=g,v.barycoord=x}return v}class fM extends jn{constructor(t=null,i=1,a=1,l,c,f,p,m,d=On,v=On,x,g){super(null,f,p,m,d,v,l,c,x,g),this.isDataTexture=!0,this.image={data:t,width:i,height:a},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const kh=new K,hM=new K,dM=new pe;class Ls{constructor(t=new K(1,0,0),i=0){this.isPlane=!0,this.normal=t,this.constant=i}set(t,i){return this.normal.copy(t),this.constant=i,this}setComponents(t,i,a,l){return this.normal.set(t,i,a),this.constant=l,this}setFromNormalAndCoplanarPoint(t,i){return this.normal.copy(t),this.constant=-i.dot(this.normal),this}setFromCoplanarPoints(t,i,a){const l=kh.subVectors(a,i).cross(hM.subVectors(t,i)).normalize();return this.setFromNormalAndCoplanarPoint(l,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,i){return i.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,i,a=!0){const l=t.delta(kh),c=this.normal.dot(l);if(c===0)return this.distanceToPoint(t.start)===0?i.copy(t.start):null;const f=-(t.start.dot(this.normal)+this.constant)/c;return a===!0&&(f<0||f>1)?null:i.copy(t.start).addScaledVector(l,f)}intersectsLine(t){const i=this.distanceToPoint(t.start),a=this.distanceToPoint(t.end);return i<0&&a>0||a<0&&i>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,i){const a=i||dM.getNormalMatrix(t),l=this.coplanarPoint(kh).applyMatrix4(t),c=this.normal.applyMatrix3(a).normalize();return this.constant=-l.dot(c),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Us=new ru,pM=new De(.5,.5),Ic=new K;class sp{constructor(t=new Ls,i=new Ls,a=new Ls,l=new Ls,c=new Ls,f=new Ls){this.planes=[t,i,a,l,c,f]}set(t,i,a,l,c,f){const p=this.planes;return p[0].copy(t),p[1].copy(i),p[2].copy(a),p[3].copy(l),p[4].copy(c),p[5].copy(f),this}copy(t){const i=this.planes;for(let a=0;a<6;a++)i[a].copy(t.planes[a]);return this}setFromProjectionMatrix(t,i=ji,a=!1){const l=this.planes,c=t.elements,f=c[0],p=c[1],m=c[2],d=c[3],v=c[4],x=c[5],g=c[6],y=c[7],b=c[8],C=c[9],S=c[10],_=c[11],T=c[12],D=c[13],U=c[14],P=c[15];if(l[0].setComponents(d-f,y-v,_-b,P-T).normalize(),l[1].setComponents(d+f,y+v,_+b,P+T).normalize(),l[2].setComponents(d+p,y+x,_+C,P+D).normalize(),l[3].setComponents(d-p,y-x,_-C,P-D).normalize(),a)l[4].setComponents(m,g,S,U).normalize(),l[5].setComponents(d-m,y-g,_-S,P-U).normalize();else if(l[4].setComponents(d-m,y-g,_-S,P-U).normalize(),i===ji)l[5].setComponents(d+m,y+g,_+S,P+U).normalize();else if(i===ll)l[5].setComponents(m,g,S,U).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+i);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Us.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const i=t.geometry;i.boundingSphere===null&&i.computeBoundingSphere(),Us.copy(i.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Us)}intersectsSprite(t){Us.center.set(0,0,0);const i=pM.distanceTo(t.center);return Us.radius=.7071067811865476+i,Us.applyMatrix4(t.matrixWorld),this.intersectsSphere(Us)}intersectsSphere(t){const i=this.planes,a=t.center,l=-t.radius;for(let c=0;c<6;c++)if(i[c].distanceToPoint(a)<l)return!1;return!0}intersectsBox(t){const i=this.planes;for(let a=0;a<6;a++){const l=i[a];if(Ic.x=l.normal.x>0?t.max.x:t.min.x,Ic.y=l.normal.y>0?t.max.y:t.min.y,Ic.z=l.normal.z>0?t.max.z:t.min.z,l.distanceToPoint(Ic)<0)return!1}return!0}containsPoint(t){const i=this.planes;for(let a=0;a<6;a++)if(i[a].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Ex extends jr{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new de(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const Sv=new hn,kd=new bx,Bc=new ru,Fc=new K;class mM extends Cn{constructor(t=new Yn,i=new Ex){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,i){return super.copy(t,i),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,i){const a=this.geometry,l=this.matrixWorld,c=t.params.Points.threshold,f=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),Bc.copy(a.boundingSphere),Bc.applyMatrix4(l),Bc.radius+=c,t.ray.intersectsSphere(Bc)===!1)return;Sv.copy(l).invert(),kd.copy(t.ray).applyMatrix4(Sv);const p=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=p*p,d=a.index,x=a.attributes.position;if(d!==null){const g=Math.max(0,f.start),y=Math.min(d.count,f.start+f.count);for(let b=g,C=y;b<C;b++){const S=d.getX(b);Fc.fromBufferAttribute(x,S),yv(Fc,S,m,l,t,i,this)}}else{const g=Math.max(0,f.start),y=Math.min(x.count,f.start+f.count);for(let b=g,C=y;b<C;b++)Fc.fromBufferAttribute(x,b),yv(Fc,b,m,l,t,i,this)}}updateMorphTargets(){const i=this.geometry.morphAttributes,a=Object.keys(i);if(a.length>0){const l=i[a[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,f=l.length;c<f;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}}function yv(r,t,i,a,l,c,f){const p=kd.distanceSqToPoint(r);if(p<i){const m=new K;kd.closestPointToPoint(r,m),m.applyMatrix4(a);const d=l.ray.origin.distanceTo(m);if(d<l.near||d>l.far)return;c.push({distance:d,distanceToRay:Math.sqrt(p),point:m,index:t,face:null,faceIndex:null,barycoord:null,object:f})}}class Tx extends jn{constructor(t=[],i=zs,a,l,c,f,p,m,d,v){super(t,i,a,l,c,f,p,m,d,v),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class kr extends jn{constructor(t,i,a=Ki,l,c,f,p=On,m=On,d,v=Ra,x=1){if(v!==Ra&&v!==Bs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const g={width:t,height:i,depth:x};super(g,l,c,f,p,m,v,a,d),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new ap(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const i=super.toJSON(t);return this.compareFunction!==null&&(i.compareFunction=this.compareFunction),i}}class gM extends kr{constructor(t,i=Ki,a=zs,l,c,f=On,p=On,m,d=Ra){const v={width:t,height:t,depth:1},x=[v,v,v,v,v,v];super(t,t,i,a,l,c,f,p,m,d),this.image=x,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class Ax extends jn{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class ze extends Yn{constructor(t=1,i=1,a=1,l=1,c=1,f=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:i,depth:a,widthSegments:l,heightSegments:c,depthSegments:f};const p=this;l=Math.floor(l),c=Math.floor(c),f=Math.floor(f);const m=[],d=[],v=[],x=[];let g=0,y=0;b("z","y","x",-1,-1,a,i,t,f,c,0),b("z","y","x",1,-1,a,i,-t,f,c,1),b("x","z","y",1,1,t,a,i,l,f,2),b("x","z","y",1,-1,t,a,-i,l,f,3),b("x","y","z",1,-1,t,i,a,l,c,4),b("x","y","z",-1,-1,t,i,-a,l,c,5),this.setIndex(m),this.setAttribute("position",new mn(d,3)),this.setAttribute("normal",new mn(v,3)),this.setAttribute("uv",new mn(x,2));function b(C,S,_,T,D,U,P,N,z,A,O){const k=U/z,G=P/A,Y=U/2,ct=P/2,ut=N/2,W=z+1,F=A+1;let V=0,rt=0;const gt=new K;for(let I=0;I<F;I++){const tt=I*G-ct;for(let dt=0;dt<W;dt++){const St=dt*k-Y;gt[C]=St*T,gt[S]=tt*D,gt[_]=ut,d.push(gt.x,gt.y,gt.z),gt[C]=0,gt[S]=0,gt[_]=N>0?1:-1,v.push(gt.x,gt.y,gt.z),x.push(dt/z),x.push(1-I/A),V+=1}}for(let I=0;I<A;I++)for(let tt=0;tt<z;tt++){const dt=g+tt+W*I,St=g+tt+W*(I+1),Nt=g+(tt+1)+W*(I+1),Tt=g+(tt+1)+W*I;m.push(dt,St,Tt),m.push(St,Nt,Tt),rt+=6}p.addGroup(y,rt,O),y+=rt,g+=V}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ze(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class Xi extends Yn{constructor(t=1,i=1,a=1,l=32,c=1,f=!1,p=0,m=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:i,height:a,radialSegments:l,heightSegments:c,openEnded:f,thetaStart:p,thetaLength:m};const d=this;l=Math.floor(l),c=Math.floor(c);const v=[],x=[],g=[],y=[];let b=0;const C=[],S=a/2;let _=0;T(),f===!1&&(t>0&&D(!0),i>0&&D(!1)),this.setIndex(v),this.setAttribute("position",new mn(x,3)),this.setAttribute("normal",new mn(g,3)),this.setAttribute("uv",new mn(y,2));function T(){const U=new K,P=new K;let N=0;const z=(i-t)/a;for(let A=0;A<=c;A++){const O=[],k=A/c,G=k*(i-t)+t;for(let Y=0;Y<=l;Y++){const ct=Y/l,ut=ct*m+p,W=Math.sin(ut),F=Math.cos(ut);P.x=G*W,P.y=-k*a+S,P.z=G*F,x.push(P.x,P.y,P.z),U.set(W,z,F).normalize(),g.push(U.x,U.y,U.z),y.push(ct,1-k),O.push(b++)}C.push(O)}for(let A=0;A<l;A++)for(let O=0;O<c;O++){const k=C[O][A],G=C[O+1][A],Y=C[O+1][A+1],ct=C[O][A+1];(t>0||O!==0)&&(v.push(k,G,ct),N+=3),(i>0||O!==c-1)&&(v.push(G,Y,ct),N+=3)}d.addGroup(_,N,0),_+=N}function D(U){const P=b,N=new De,z=new K;let A=0;const O=U===!0?t:i,k=U===!0?1:-1;for(let Y=1;Y<=l;Y++)x.push(0,S*k,0),g.push(0,k,0),y.push(.5,.5),b++;const G=b;for(let Y=0;Y<=l;Y++){const ut=Y/l*m+p,W=Math.cos(ut),F=Math.sin(ut);z.x=O*F,z.y=S*k,z.z=O*W,x.push(z.x,z.y,z.z),g.push(0,k,0),N.x=W*.5+.5,N.y=F*.5*k+.5,y.push(N.x,N.y),b++}for(let Y=0;Y<l;Y++){const ct=P+Y,ut=G+Y;U===!0?v.push(ut,ut+1,ct):v.push(ut+1,ut,ct),A+=3}d.addGroup(_,A,U===!0?1:2),_+=A}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Xi(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class ou extends Yn{constructor(t=[],i=[],a=1,l=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:i,radius:a,detail:l};const c=[],f=[];p(l),d(a),v(),this.setAttribute("position",new mn(c,3)),this.setAttribute("normal",new mn(c.slice(),3)),this.setAttribute("uv",new mn(f,2)),l===0?this.computeVertexNormals():this.normalizeNormals();function p(T){const D=new K,U=new K,P=new K;for(let N=0;N<i.length;N+=3)y(i[N+0],D),y(i[N+1],U),y(i[N+2],P),m(D,U,P,T)}function m(T,D,U,P){const N=P+1,z=[];for(let A=0;A<=N;A++){z[A]=[];const O=T.clone().lerp(U,A/N),k=D.clone().lerp(U,A/N),G=N-A;for(let Y=0;Y<=G;Y++)Y===0&&A===N?z[A][Y]=O:z[A][Y]=O.clone().lerp(k,Y/G)}for(let A=0;A<N;A++)for(let O=0;O<2*(N-A)-1;O++){const k=Math.floor(O/2);O%2===0?(g(z[A][k+1]),g(z[A+1][k]),g(z[A][k])):(g(z[A][k+1]),g(z[A+1][k+1]),g(z[A+1][k]))}}function d(T){const D=new K;for(let U=0;U<c.length;U+=3)D.x=c[U+0],D.y=c[U+1],D.z=c[U+2],D.normalize().multiplyScalar(T),c[U+0]=D.x,c[U+1]=D.y,c[U+2]=D.z}function v(){const T=new K;for(let D=0;D<c.length;D+=3){T.x=c[D+0],T.y=c[D+1],T.z=c[D+2];const U=S(T)/2/Math.PI+.5,P=_(T)/Math.PI+.5;f.push(U,1-P)}b(),x()}function x(){for(let T=0;T<f.length;T+=6){const D=f[T+0],U=f[T+2],P=f[T+4],N=Math.max(D,U,P),z=Math.min(D,U,P);N>.9&&z<.1&&(D<.2&&(f[T+0]+=1),U<.2&&(f[T+2]+=1),P<.2&&(f[T+4]+=1))}}function g(T){c.push(T.x,T.y,T.z)}function y(T,D){const U=T*3;D.x=t[U+0],D.y=t[U+1],D.z=t[U+2]}function b(){const T=new K,D=new K,U=new K,P=new K,N=new De,z=new De,A=new De;for(let O=0,k=0;O<c.length;O+=9,k+=6){T.set(c[O+0],c[O+1],c[O+2]),D.set(c[O+3],c[O+4],c[O+5]),U.set(c[O+6],c[O+7],c[O+8]),N.set(f[k+0],f[k+1]),z.set(f[k+2],f[k+3]),A.set(f[k+4],f[k+5]),P.copy(T).add(D).add(U).divideScalar(3);const G=S(P);C(N,k+0,T,G),C(z,k+2,D,G),C(A,k+4,U,G)}}function C(T,D,U,P){P<0&&T.x===1&&(f[D]=T.x-1),U.x===0&&U.z===0&&(f[D]=P/2/Math.PI+.5)}function S(T){return Math.atan2(T.z,-T.x)}function _(T){return Math.atan2(-T.y,Math.sqrt(T.x*T.x+T.z*T.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ou(t.vertices,t.indices,t.radius,t.detail)}}class rp extends ou{constructor(t=1,i=0){const a=(1+Math.sqrt(5))/2,l=[-1,a,0,1,a,0,-1,-a,0,1,-a,0,0,-1,a,0,1,a,0,-1,-a,0,1,-a,a,0,-1,a,0,1,-a,0,-1,-a,0,1],c=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(l,c,t,i),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:i}}static fromJSON(t){return new rp(t.radius,t.detail)}}class op extends ou{constructor(t=1,i=0){const a=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],l=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(a,l,t,i),this.type="OctahedronGeometry",this.parameters={radius:t,detail:i}}static fromJSON(t){return new op(t.radius,t.detail)}}class Ea extends Yn{constructor(t=1,i=1,a=1,l=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:i,widthSegments:a,heightSegments:l};const c=t/2,f=i/2,p=Math.floor(a),m=Math.floor(l),d=p+1,v=m+1,x=t/p,g=i/m,y=[],b=[],C=[],S=[];for(let _=0;_<v;_++){const T=_*g-f;for(let D=0;D<d;D++){const U=D*x-c;b.push(U,-T,0),C.push(0,0,1),S.push(D/p),S.push(1-_/m)}}for(let _=0;_<m;_++)for(let T=0;T<p;T++){const D=T+d*_,U=T+d*(_+1),P=T+1+d*(_+1),N=T+1+d*_;y.push(D,U,N),y.push(U,P,N)}this.setIndex(y),this.setAttribute("position",new mn(b,3)),this.setAttribute("normal",new mn(C,3)),this.setAttribute("uv",new mn(S,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ea(t.width,t.height,t.widthSegments,t.heightSegments)}}class ss extends Yn{constructor(t=1,i=32,a=16,l=0,c=Math.PI*2,f=0,p=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:i,heightSegments:a,phiStart:l,phiLength:c,thetaStart:f,thetaLength:p},i=Math.max(3,Math.floor(i)),a=Math.max(2,Math.floor(a));const m=Math.min(f+p,Math.PI);let d=0;const v=[],x=new K,g=new K,y=[],b=[],C=[],S=[];for(let _=0;_<=a;_++){const T=[],D=_/a;let U=0;_===0&&f===0?U=.5/i:_===a&&m===Math.PI&&(U=-.5/i);for(let P=0;P<=i;P++){const N=P/i;x.x=-t*Math.cos(l+N*c)*Math.sin(f+D*p),x.y=t*Math.cos(f+D*p),x.z=t*Math.sin(l+N*c)*Math.sin(f+D*p),b.push(x.x,x.y,x.z),g.copy(x).normalize(),C.push(g.x,g.y,g.z),S.push(N+U,1-D),T.push(d++)}v.push(T)}for(let _=0;_<a;_++)for(let T=0;T<i;T++){const D=v[_][T+1],U=v[_][T],P=v[_+1][T],N=v[_+1][T+1];(_!==0||f>0)&&y.push(D,U,N),(_!==a-1||m<Math.PI)&&y.push(U,P,N)}this.setIndex(y),this.setAttribute("position",new mn(b,3)),this.setAttribute("normal",new mn(C,3)),this.setAttribute("uv",new mn(S,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ss(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class lp extends Yn{constructor(t=1,i=.4,a=12,l=48,c=Math.PI*2,f=0,p=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:i,radialSegments:a,tubularSegments:l,arc:c,thetaStart:f,thetaLength:p},a=Math.floor(a),l=Math.floor(l);const m=[],d=[],v=[],x=[],g=new K,y=new K,b=new K;for(let C=0;C<=a;C++){const S=f+C/a*p;for(let _=0;_<=l;_++){const T=_/l*c;y.x=(t+i*Math.cos(S))*Math.cos(T),y.y=(t+i*Math.cos(S))*Math.sin(T),y.z=i*Math.sin(S),d.push(y.x,y.y,y.z),g.x=t*Math.cos(T),g.y=t*Math.sin(T),b.subVectors(y,g).normalize(),v.push(b.x,b.y,b.z),x.push(_/l),x.push(C/a)}}for(let C=1;C<=a;C++)for(let S=1;S<=l;S++){const _=(l+1)*C+S-1,T=(l+1)*(C-1)+S-1,D=(l+1)*(C-1)+S,U=(l+1)*C+S;m.push(_,T,U),m.push(T,D,U)}this.setIndex(m),this.setAttribute("position",new mn(d,3)),this.setAttribute("normal",new mn(v,3)),this.setAttribute("uv",new mn(x,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new lp(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}function Xr(r){const t={};for(const i in r){t[i]={};for(const a in r[i]){const l=r[i][a];if(Mv(l))l.isRenderTargetTexture?(ae("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[i][a]=null):t[i][a]=l.clone();else if(Array.isArray(l))if(Mv(l[0])){const c=[];for(let f=0,p=l.length;f<p;f++)c[f]=l[f].clone();t[i][a]=c}else t[i][a]=l.slice();else t[i][a]=l}}return t}function qn(r){const t={};for(let i=0;i<r.length;i++){const a=Xr(r[i]);for(const l in a)t[l]=a[l]}return t}function Mv(r){return r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)}function vM(r){const t=[];for(let i=0;i<r.length;i++)t.push(r[i].clone());return t}function wx(r){const t=r.getRenderTarget();return t===null?r.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Ce.workingColorSpace}const xM={clone:Xr,merge:qn};var _M=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,SM=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Qi extends jr{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=_M,this.fragmentShader=SM,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Xr(t.uniforms),this.uniformsGroups=vM(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const i=super.toJSON(t);i.glslVersion=this.glslVersion,i.uniforms={};for(const l in this.uniforms){const f=this.uniforms[l].value;f&&f.isTexture?i.uniforms[l]={type:"t",value:f.toJSON(t).uuid}:f&&f.isColor?i.uniforms[l]={type:"c",value:f.getHex()}:f&&f.isVector2?i.uniforms[l]={type:"v2",value:f.toArray()}:f&&f.isVector3?i.uniforms[l]={type:"v3",value:f.toArray()}:f&&f.isVector4?i.uniforms[l]={type:"v4",value:f.toArray()}:f&&f.isMatrix3?i.uniforms[l]={type:"m3",value:f.toArray()}:f&&f.isMatrix4?i.uniforms[l]={type:"m4",value:f.toArray()}:i.uniforms[l]={value:f}}Object.keys(this.defines).length>0&&(i.defines=this.defines),i.vertexShader=this.vertexShader,i.fragmentShader=this.fragmentShader,i.lights=this.lights,i.clipping=this.clipping;const a={};for(const l in this.extensions)this.extensions[l]===!0&&(a[l]=!0);return Object.keys(a).length>0&&(i.extensions=a),i}}class yM extends Qi{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class be extends jr{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new de(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new de(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Hd,this.normalScale=new De(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new us,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class MM extends jr{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=xy,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class bM extends jr{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class cp extends Cn{constructor(t,i=1){super(),this.isLight=!0,this.type="Light",this.color=new de(t),this.intensity=i}dispose(){this.dispatchEvent({type:"dispose"})}copy(t,i){return super.copy(t,i),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const i=super.toJSON(t);return i.object.color=this.color.getHex(),i.object.intensity=this.intensity,i}}class EM extends cp{constructor(t,i,a){super(t,a),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Cn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new de(i)}copy(t,i){return super.copy(t,i),this.groundColor.copy(t.groundColor),this}toJSON(t){const i=super.toJSON(t);return i.object.groundColor=this.groundColor.getHex(),i}}const Xh=new hn,bv=new K,Ev=new K;class TM{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new De(512,512),this.mapType=hi,this.map=null,this.mapPass=null,this.matrix=new hn,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new sp,this._frameExtents=new De(1,1),this._viewportCount=1,this._viewports=[new fn(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const i=this.camera,a=this.matrix;bv.setFromMatrixPosition(t.matrixWorld),i.position.copy(bv),Ev.setFromMatrixPosition(t.target.matrixWorld),i.lookAt(Ev),i.updateMatrixWorld(),Xh.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Xh,i.coordinateSystem,i.reversedDepth),i.coordinateSystem===ll||i.reversedDepth?a.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):a.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),a.multiply(Xh)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const zc=new K,Gc=new qr,Vi=new K;class Rx extends Cn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new hn,this.projectionMatrix=new hn,this.projectionMatrixInverse=new hn,this.coordinateSystem=ji,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,i){return super.copy(t,i),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(zc,Gc,Vi),Vi.x===1&&Vi.y===1&&Vi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(zc,Gc,Vi.set(1,1,1)).invert()}updateWorldMatrix(t,i){super.updateWorldMatrix(t,i),this.matrixWorld.decompose(zc,Gc,Vi),Vi.x===1&&Vi.y===1&&Vi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(zc,Gc,Vi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const as=new K,Tv=new De,Av=new De;class Mi extends Rx{constructor(t=50,i=1,a=.1,l=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=a,this.far=l,this.focus=10,this.aspect=i,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,i){return super.copy(t,i),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const i=.5*this.getFilmHeight()/t;this.fov=cl*2*Math.atan(i),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(al*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return cl*2*Math.atan(Math.tan(al*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,i,a){as.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(as.x,as.y).multiplyScalar(-t/as.z),as.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(as.x,as.y).multiplyScalar(-t/as.z)}getViewSize(t,i){return this.getViewBounds(t,Tv,Av),i.subVectors(Av,Tv)}setViewOffset(t,i,a,l,c,f){this.aspect=t/i,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=i,this.view.offsetX=a,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let i=t*Math.tan(al*.5*this.fov)/this.zoom,a=2*i,l=this.aspect*a,c=-.5*l;const f=this.view;if(this.view!==null&&this.view.enabled){const m=f.fullWidth,d=f.fullHeight;c+=f.offsetX*l/m,i-=f.offsetY*a/d,l*=f.width/m,a*=f.height/d}const p=this.filmOffset;p!==0&&(c+=t*p/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+l,i,i-a,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const i=super.toJSON(t);return i.object.fov=this.fov,i.object.zoom=this.zoom,i.object.near=this.near,i.object.far=this.far,i.object.focus=this.focus,i.object.aspect=this.aspect,this.view!==null&&(i.object.view=Object.assign({},this.view)),i.object.filmGauge=this.filmGauge,i.object.filmOffset=this.filmOffset,i}}class up extends Rx{constructor(t=-1,i=1,a=1,l=-1,c=.1,f=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=i,this.top=a,this.bottom=l,this.near=c,this.far=f,this.updateProjectionMatrix()}copy(t,i){return super.copy(t,i),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,i,a,l,c,f){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=i,this.view.offsetX=a,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),i=(this.top-this.bottom)/(2*this.zoom),a=(this.right+this.left)/2,l=(this.top+this.bottom)/2;let c=a-t,f=a+t,p=l+i,m=l-i;if(this.view!==null&&this.view.enabled){const d=(this.right-this.left)/this.view.fullWidth/this.zoom,v=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=d*this.view.offsetX,f=c+d*this.view.width,p-=v*this.view.offsetY,m=p-v*this.view.height}this.projectionMatrix.makeOrthographic(c,f,p,m,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const i=super.toJSON(t);return i.object.zoom=this.zoom,i.object.left=this.left,i.object.right=this.right,i.object.top=this.top,i.object.bottom=this.bottom,i.object.near=this.near,i.object.far=this.far,this.view!==null&&(i.object.view=Object.assign({},this.view)),i}}class AM extends TM{constructor(){super(new up(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class wM extends cp{constructor(t,i){super(t,i),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Cn.DEFAULT_UP),this.updateMatrix(),this.target=new Cn,this.shadow=new AM}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const i=super.toJSON(t);return i.object.shadow=this.shadow.toJSON(),i.object.target=this.target.uuid,i}}class RM extends cp{constructor(t,i){super(t,i),this.isAmbientLight=!0,this.type="AmbientLight"}}const Ur=-90,Lr=1;class CM extends Cn{constructor(t,i,a){super(),this.type="CubeCamera",this.renderTarget=a,this.coordinateSystem=null,this.activeMipmapLevel=0;const l=new Mi(Ur,Lr,t,i);l.layers=this.layers,this.add(l);const c=new Mi(Ur,Lr,t,i);c.layers=this.layers,this.add(c);const f=new Mi(Ur,Lr,t,i);f.layers=this.layers,this.add(f);const p=new Mi(Ur,Lr,t,i);p.layers=this.layers,this.add(p);const m=new Mi(Ur,Lr,t,i);m.layers=this.layers,this.add(m);const d=new Mi(Ur,Lr,t,i);d.layers=this.layers,this.add(d)}updateCoordinateSystem(){const t=this.coordinateSystem,i=this.children.concat(),[a,l,c,f,p,m]=i;for(const d of i)this.remove(d);if(t===ji)a.up.set(0,1,0),a.lookAt(1,0,0),l.up.set(0,1,0),l.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),f.up.set(0,0,1),f.lookAt(0,-1,0),p.up.set(0,1,0),p.lookAt(0,0,1),m.up.set(0,1,0),m.lookAt(0,0,-1);else if(t===ll)a.up.set(0,-1,0),a.lookAt(-1,0,0),l.up.set(0,-1,0),l.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),f.up.set(0,0,-1),f.lookAt(0,-1,0),p.up.set(0,-1,0),p.lookAt(0,0,1),m.up.set(0,-1,0),m.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const d of i)this.add(d),d.updateMatrixWorld()}update(t,i){this.parent===null&&this.updateMatrixWorld();const{renderTarget:a,activeMipmapLevel:l}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[c,f,p,m,d,v]=this.children,x=t.getRenderTarget(),g=t.getActiveCubeFace(),y=t.getActiveMipmapLevel(),b=t.xr.enabled;t.xr.enabled=!1;const C=a.texture.generateMipmaps;a.texture.generateMipmaps=!1;let S=!1;t.isWebGLRenderer===!0?S=t.state.buffers.depth.getReversed():S=t.reversedDepthBuffer,t.setRenderTarget(a,0,l),S&&t.autoClear===!1&&t.clearDepth(),t.render(i,c),t.setRenderTarget(a,1,l),S&&t.autoClear===!1&&t.clearDepth(),t.render(i,f),t.setRenderTarget(a,2,l),S&&t.autoClear===!1&&t.clearDepth(),t.render(i,p),t.setRenderTarget(a,3,l),S&&t.autoClear===!1&&t.clearDepth(),t.render(i,m),t.setRenderTarget(a,4,l),S&&t.autoClear===!1&&t.clearDepth(),t.render(i,d),a.texture.generateMipmaps=C,t.setRenderTarget(a,5,l),S&&t.autoClear===!1&&t.clearDepth(),t.render(i,v),t.setRenderTarget(x,g,y),t.xr.enabled=b,a.texture.needsPMREMUpdate=!0}}class DM extends Mi{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}class NM{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1,ae("Clock: This module has been deprecated. Please use THREE.Timer instead.")}start(){this.startTime=performance.now(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const i=performance.now();t=(i-this.oldTime)/1e3,this.oldTime=i,this.elapsedTime+=t}return t}}const mp=class mp{constructor(t,i,a,l){this.elements=[1,0,0,1],t!==void 0&&this.set(t,i,a,l)}identity(){return this.set(1,0,0,1),this}fromArray(t,i=0){for(let a=0;a<4;a++)this.elements[a]=t[a+i];return this}set(t,i,a,l){const c=this.elements;return c[0]=t,c[2]=i,c[1]=a,c[3]=l,this}};mp.prototype.isMatrix2=!0;let wv=mp;function Rv(r,t,i,a){const l=UM(a);switch(i){case px:return r*t;case gx:return r*t/l.components*l.byteLength;case Jd:return r*t/l.components*l.byteLength;case Gs:return r*t*2/l.components*l.byteLength;case $d:return r*t*2/l.components*l.byteLength;case mx:return r*t*3/l.components*l.byteLength;case Li:return r*t*4/l.components*l.byteLength;case tp:return r*t*4/l.components*l.byteLength;case jc:case Yc:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case Zc:case Kc:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case hd:case pd:return Math.max(r,16)*Math.max(t,8)/4;case fd:case dd:return Math.max(r,8)*Math.max(t,8)/2;case md:case gd:case xd:case _d:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case vd:case Jc:case Sd:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case yd:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case Md:return Math.floor((r+4)/5)*Math.floor((t+3)/4)*16;case bd:return Math.floor((r+4)/5)*Math.floor((t+4)/5)*16;case Ed:return Math.floor((r+5)/6)*Math.floor((t+4)/5)*16;case Td:return Math.floor((r+5)/6)*Math.floor((t+5)/6)*16;case Ad:return Math.floor((r+7)/8)*Math.floor((t+4)/5)*16;case wd:return Math.floor((r+7)/8)*Math.floor((t+5)/6)*16;case Rd:return Math.floor((r+7)/8)*Math.floor((t+7)/8)*16;case Cd:return Math.floor((r+9)/10)*Math.floor((t+4)/5)*16;case Dd:return Math.floor((r+9)/10)*Math.floor((t+5)/6)*16;case Nd:return Math.floor((r+9)/10)*Math.floor((t+7)/8)*16;case Ud:return Math.floor((r+9)/10)*Math.floor((t+9)/10)*16;case Ld:return Math.floor((r+11)/12)*Math.floor((t+9)/10)*16;case Pd:return Math.floor((r+11)/12)*Math.floor((t+11)/12)*16;case Od:case Id:case Bd:return Math.ceil(r/4)*Math.ceil(t/4)*16;case Fd:case zd:return Math.ceil(r/4)*Math.ceil(t/4)*8;case $c:case Gd:return Math.ceil(r/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${i} format.`)}function UM(r){switch(r){case hi:case ux:return{byteLength:1,components:1};case rl:case fx:case wa:return{byteLength:2,components:1};case Kd:case Qd:return{byteLength:2,components:4};case Ki:case Zd:case qi:return{byteLength:4,components:1};case hx:case dx:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:jd}}));typeof window<"u"&&(window.__THREE__?ae("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=jd);function Cx(){let r=null,t=!1,i=null,a=null;function l(c,f){i(c,f),a=r.requestAnimationFrame(l)}return{start:function(){t!==!0&&i!==null&&r!==null&&(a=r.requestAnimationFrame(l),t=!0)},stop:function(){r!==null&&r.cancelAnimationFrame(a),t=!1},setAnimationLoop:function(c){i=c},setContext:function(c){r=c}}}function LM(r){const t=new WeakMap;function i(p,m){const d=p.array,v=p.usage,x=d.byteLength,g=r.createBuffer();r.bindBuffer(m,g),r.bufferData(m,d,v),p.onUploadCallback();let y;if(d instanceof Float32Array)y=r.FLOAT;else if(typeof Float16Array<"u"&&d instanceof Float16Array)y=r.HALF_FLOAT;else if(d instanceof Uint16Array)p.isFloat16BufferAttribute?y=r.HALF_FLOAT:y=r.UNSIGNED_SHORT;else if(d instanceof Int16Array)y=r.SHORT;else if(d instanceof Uint32Array)y=r.UNSIGNED_INT;else if(d instanceof Int32Array)y=r.INT;else if(d instanceof Int8Array)y=r.BYTE;else if(d instanceof Uint8Array)y=r.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)y=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:g,type:y,bytesPerElement:d.BYTES_PER_ELEMENT,version:p.version,size:x}}function a(p,m,d){const v=m.array,x=m.updateRanges;if(r.bindBuffer(d,p),x.length===0)r.bufferSubData(d,0,v);else{x.sort((y,b)=>y.start-b.start);let g=0;for(let y=1;y<x.length;y++){const b=x[g],C=x[y];C.start<=b.start+b.count+1?b.count=Math.max(b.count,C.start+C.count-b.start):(++g,x[g]=C)}x.length=g+1;for(let y=0,b=x.length;y<b;y++){const C=x[y];r.bufferSubData(d,C.start*v.BYTES_PER_ELEMENT,v,C.start,C.count)}m.clearUpdateRanges()}m.onUploadCallback()}function l(p){return p.isInterleavedBufferAttribute&&(p=p.data),t.get(p)}function c(p){p.isInterleavedBufferAttribute&&(p=p.data);const m=t.get(p);m&&(r.deleteBuffer(m.buffer),t.delete(p))}function f(p,m){if(p.isInterleavedBufferAttribute&&(p=p.data),p.isGLBufferAttribute){const v=t.get(p);(!v||v.version<p.version)&&t.set(p,{buffer:p.buffer,type:p.type,bytesPerElement:p.elementSize,version:p.version});return}const d=t.get(p);if(d===void 0)t.set(p,i(p,m));else if(d.version<p.version){if(d.size!==p.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");a(d.buffer,p,m),d.version=p.version}}return{get:l,remove:c,update:f}}var PM=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,OM=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,IM=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,BM=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,FM=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,zM=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,GM=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,HM=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,VM=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,kM=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,XM=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,WM=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,qM=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,jM=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,YM=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,ZM=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,KM=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,QM=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,JM=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,$M=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,tb=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,eb=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,nb=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,ib=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,ab=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,sb=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,rb=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,ob=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,lb=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,cb=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,ub="gl_FragColor = linearToOutputTexel( gl_FragColor );",fb=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,hb=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,db=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,pb=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,mb=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,gb=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,vb=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,xb=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,_b=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Sb=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,yb=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Mb=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,bb=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Eb=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Tb=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Ab=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,wb=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Rb=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Cb=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Db=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Nb=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Ub=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Lb=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = inverseTransformDirection( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Pb=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Ob=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Ib=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Bb=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Fb=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,zb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Gb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Hb=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Vb=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,kb=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Xb=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Wb=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,qb=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,jb=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Yb=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Zb=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Kb=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Qb=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Jb=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,$b=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,t1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,e1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,n1=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,i1=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,a1=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,s1=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,r1=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,o1=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,l1=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,c1=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,u1=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,f1=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,h1=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,d1=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,p1=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,m1=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,g1=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,v1=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,x1=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,_1=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,S1=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,y1=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,M1=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,b1=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,E1=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,T1=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,A1=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,w1=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,R1=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,C1=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,D1=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,N1=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,U1=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,L1=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const P1=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,O1=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,I1=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,B1=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,F1=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,z1=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,G1=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,H1=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,V1=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,k1=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,X1=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,W1=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,q1=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,j1=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Y1=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Z1=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,K1=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Q1=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,J1=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,$1=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tE=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,eE=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,nE=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,iE=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,aE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,sE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,rE=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,oE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,lE=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,cE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,uE=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,hE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,dE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ye={alphahash_fragment:PM,alphahash_pars_fragment:OM,alphamap_fragment:IM,alphamap_pars_fragment:BM,alphatest_fragment:FM,alphatest_pars_fragment:zM,aomap_fragment:GM,aomap_pars_fragment:HM,batching_pars_vertex:VM,batching_vertex:kM,begin_vertex:XM,beginnormal_vertex:WM,bsdfs:qM,iridescence_fragment:jM,bumpmap_pars_fragment:YM,clipping_planes_fragment:ZM,clipping_planes_pars_fragment:KM,clipping_planes_pars_vertex:QM,clipping_planes_vertex:JM,color_fragment:$M,color_pars_fragment:tb,color_pars_vertex:eb,color_vertex:nb,common:ib,cube_uv_reflection_fragment:ab,defaultnormal_vertex:sb,displacementmap_pars_vertex:rb,displacementmap_vertex:ob,emissivemap_fragment:lb,emissivemap_pars_fragment:cb,colorspace_fragment:ub,colorspace_pars_fragment:fb,envmap_fragment:hb,envmap_common_pars_fragment:db,envmap_pars_fragment:pb,envmap_pars_vertex:mb,envmap_physical_pars_fragment:Ab,envmap_vertex:gb,fog_vertex:vb,fog_pars_vertex:xb,fog_fragment:_b,fog_pars_fragment:Sb,gradientmap_pars_fragment:yb,lightmap_pars_fragment:Mb,lights_lambert_fragment:bb,lights_lambert_pars_fragment:Eb,lights_pars_begin:Tb,lights_toon_fragment:wb,lights_toon_pars_fragment:Rb,lights_phong_fragment:Cb,lights_phong_pars_fragment:Db,lights_physical_fragment:Nb,lights_physical_pars_fragment:Ub,lights_fragment_begin:Lb,lights_fragment_maps:Pb,lights_fragment_end:Ob,lightprobes_pars_fragment:Ib,logdepthbuf_fragment:Bb,logdepthbuf_pars_fragment:Fb,logdepthbuf_pars_vertex:zb,logdepthbuf_vertex:Gb,map_fragment:Hb,map_pars_fragment:Vb,map_particle_fragment:kb,map_particle_pars_fragment:Xb,metalnessmap_fragment:Wb,metalnessmap_pars_fragment:qb,morphinstance_vertex:jb,morphcolor_vertex:Yb,morphnormal_vertex:Zb,morphtarget_pars_vertex:Kb,morphtarget_vertex:Qb,normal_fragment_begin:Jb,normal_fragment_maps:$b,normal_pars_fragment:t1,normal_pars_vertex:e1,normal_vertex:n1,normalmap_pars_fragment:i1,clearcoat_normal_fragment_begin:a1,clearcoat_normal_fragment_maps:s1,clearcoat_pars_fragment:r1,iridescence_pars_fragment:o1,opaque_fragment:l1,packing:c1,premultiplied_alpha_fragment:u1,project_vertex:f1,dithering_fragment:h1,dithering_pars_fragment:d1,roughnessmap_fragment:p1,roughnessmap_pars_fragment:m1,shadowmap_pars_fragment:g1,shadowmap_pars_vertex:v1,shadowmap_vertex:x1,shadowmask_pars_fragment:_1,skinbase_vertex:S1,skinning_pars_vertex:y1,skinning_vertex:M1,skinnormal_vertex:b1,specularmap_fragment:E1,specularmap_pars_fragment:T1,tonemapping_fragment:A1,tonemapping_pars_fragment:w1,transmission_fragment:R1,transmission_pars_fragment:C1,uv_pars_fragment:D1,uv_pars_vertex:N1,uv_vertex:U1,worldpos_vertex:L1,background_vert:P1,background_frag:O1,backgroundCube_vert:I1,backgroundCube_frag:B1,cube_vert:F1,cube_frag:z1,depth_vert:G1,depth_frag:H1,distance_vert:V1,distance_frag:k1,equirect_vert:X1,equirect_frag:W1,linedashed_vert:q1,linedashed_frag:j1,meshbasic_vert:Y1,meshbasic_frag:Z1,meshlambert_vert:K1,meshlambert_frag:Q1,meshmatcap_vert:J1,meshmatcap_frag:$1,meshnormal_vert:tE,meshnormal_frag:eE,meshphong_vert:nE,meshphong_frag:iE,meshphysical_vert:aE,meshphysical_frag:sE,meshtoon_vert:rE,meshtoon_frag:oE,points_vert:lE,points_frag:cE,shadow_vert:uE,shadow_frag:fE,sprite_vert:hE,sprite_frag:dE},Bt={common:{diffuse:{value:new de(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new pe},alphaMap:{value:null},alphaMapTransform:{value:new pe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new pe}},envmap:{envMap:{value:null},envMapRotation:{value:new pe},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new pe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new pe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new pe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new pe},normalScale:{value:new De(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new pe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new pe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new pe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new pe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new de(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new K},probesMax:{value:new K},probesResolution:{value:new K}},points:{diffuse:{value:new de(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new pe},alphaTest:{value:0},uvTransform:{value:new pe}},sprite:{diffuse:{value:new de(16777215)},opacity:{value:1},center:{value:new De(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new pe},alphaMap:{value:null},alphaMapTransform:{value:new pe},alphaTest:{value:0}}},Wi={basic:{uniforms:qn([Bt.common,Bt.specularmap,Bt.envmap,Bt.aomap,Bt.lightmap,Bt.fog]),vertexShader:ye.meshbasic_vert,fragmentShader:ye.meshbasic_frag},lambert:{uniforms:qn([Bt.common,Bt.specularmap,Bt.envmap,Bt.aomap,Bt.lightmap,Bt.emissivemap,Bt.bumpmap,Bt.normalmap,Bt.displacementmap,Bt.fog,Bt.lights,{emissive:{value:new de(0)},envMapIntensity:{value:1}}]),vertexShader:ye.meshlambert_vert,fragmentShader:ye.meshlambert_frag},phong:{uniforms:qn([Bt.common,Bt.specularmap,Bt.envmap,Bt.aomap,Bt.lightmap,Bt.emissivemap,Bt.bumpmap,Bt.normalmap,Bt.displacementmap,Bt.fog,Bt.lights,{emissive:{value:new de(0)},specular:{value:new de(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ye.meshphong_vert,fragmentShader:ye.meshphong_frag},standard:{uniforms:qn([Bt.common,Bt.envmap,Bt.aomap,Bt.lightmap,Bt.emissivemap,Bt.bumpmap,Bt.normalmap,Bt.displacementmap,Bt.roughnessmap,Bt.metalnessmap,Bt.fog,Bt.lights,{emissive:{value:new de(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ye.meshphysical_vert,fragmentShader:ye.meshphysical_frag},toon:{uniforms:qn([Bt.common,Bt.aomap,Bt.lightmap,Bt.emissivemap,Bt.bumpmap,Bt.normalmap,Bt.displacementmap,Bt.gradientmap,Bt.fog,Bt.lights,{emissive:{value:new de(0)}}]),vertexShader:ye.meshtoon_vert,fragmentShader:ye.meshtoon_frag},matcap:{uniforms:qn([Bt.common,Bt.bumpmap,Bt.normalmap,Bt.displacementmap,Bt.fog,{matcap:{value:null}}]),vertexShader:ye.meshmatcap_vert,fragmentShader:ye.meshmatcap_frag},points:{uniforms:qn([Bt.points,Bt.fog]),vertexShader:ye.points_vert,fragmentShader:ye.points_frag},dashed:{uniforms:qn([Bt.common,Bt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ye.linedashed_vert,fragmentShader:ye.linedashed_frag},depth:{uniforms:qn([Bt.common,Bt.displacementmap]),vertexShader:ye.depth_vert,fragmentShader:ye.depth_frag},normal:{uniforms:qn([Bt.common,Bt.bumpmap,Bt.normalmap,Bt.displacementmap,{opacity:{value:1}}]),vertexShader:ye.meshnormal_vert,fragmentShader:ye.meshnormal_frag},sprite:{uniforms:qn([Bt.sprite,Bt.fog]),vertexShader:ye.sprite_vert,fragmentShader:ye.sprite_frag},background:{uniforms:{uvTransform:{value:new pe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ye.background_vert,fragmentShader:ye.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new pe}},vertexShader:ye.backgroundCube_vert,fragmentShader:ye.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ye.cube_vert,fragmentShader:ye.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ye.equirect_vert,fragmentShader:ye.equirect_frag},distance:{uniforms:qn([Bt.common,Bt.displacementmap,{referencePosition:{value:new K},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ye.distance_vert,fragmentShader:ye.distance_frag},shadow:{uniforms:qn([Bt.lights,Bt.fog,{color:{value:new de(0)},opacity:{value:1}}]),vertexShader:ye.shadow_vert,fragmentShader:ye.shadow_frag}};Wi.physical={uniforms:qn([Wi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new pe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new pe},clearcoatNormalScale:{value:new De(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new pe},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new pe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new pe},sheen:{value:0},sheenColor:{value:new de(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new pe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new pe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new pe},transmissionSamplerSize:{value:new De},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new pe},attenuationDistance:{value:0},attenuationColor:{value:new de(0)},specularColor:{value:new de(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new pe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new pe},anisotropyVector:{value:new De},anisotropyMap:{value:null},anisotropyMapTransform:{value:new pe}}]),vertexShader:ye.meshphysical_vert,fragmentShader:ye.meshphysical_frag};const Hc={r:0,b:0,g:0},pE=new hn,Dx=new pe;Dx.set(-1,0,0,0,1,0,0,0,1);function mE(r,t,i,a,l,c){const f=new de(0);let p=l===!0?0:1,m,d,v=null,x=0,g=null;function y(T){let D=T.isScene===!0?T.background:null;if(D&&D.isTexture){const U=T.backgroundBlurriness>0;D=t.get(D,U)}return D}function b(T){let D=!1;const U=y(T);U===null?S(f,p):U&&U.isColor&&(S(U,1),D=!0);const P=r.xr.getEnvironmentBlendMode();P==="additive"?i.buffers.color.setClear(0,0,0,1,c):P==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,c),(r.autoClear||D)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function C(T,D){const U=y(D);U&&(U.isCubeTexture||U.mapping===su)?(d===void 0&&(d=new qt(new ze(1,1,1),new Qi({name:"BackgroundCubeMaterial",uniforms:Xr(Wi.backgroundCube.uniforms),vertexShader:Wi.backgroundCube.vertexShader,fragmentShader:Wi.backgroundCube.fragmentShader,side:$n,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(P,N,z){this.matrixWorld.copyPosition(z.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(d)),d.material.uniforms.envMap.value=U,d.material.uniforms.backgroundBlurriness.value=D.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=D.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(pE.makeRotationFromEuler(D.backgroundRotation)).transpose(),U.isCubeTexture&&U.isRenderTargetTexture===!1&&d.material.uniforms.backgroundRotation.value.premultiply(Dx),d.material.toneMapped=Ce.getTransfer(U.colorSpace)!==qe,(v!==U||x!==U.version||g!==r.toneMapping)&&(d.material.needsUpdate=!0,v=U,x=U.version,g=r.toneMapping),d.layers.enableAll(),T.unshift(d,d.geometry,d.material,0,0,null)):U&&U.isTexture&&(m===void 0&&(m=new qt(new Ea(2,2),new Qi({name:"BackgroundMaterial",uniforms:Xr(Wi.background.uniforms),vertexShader:Wi.background.vertexShader,fragmentShader:Wi.background.fragmentShader,side:cs,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),m.geometry.deleteAttribute("normal"),Object.defineProperty(m.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(m)),m.material.uniforms.t2D.value=U,m.material.uniforms.backgroundIntensity.value=D.backgroundIntensity,m.material.toneMapped=Ce.getTransfer(U.colorSpace)!==qe,U.matrixAutoUpdate===!0&&U.updateMatrix(),m.material.uniforms.uvTransform.value.copy(U.matrix),(v!==U||x!==U.version||g!==r.toneMapping)&&(m.material.needsUpdate=!0,v=U,x=U.version,g=r.toneMapping),m.layers.enableAll(),T.unshift(m,m.geometry,m.material,0,0,null))}function S(T,D){T.getRGB(Hc,wx(r)),i.buffers.color.setClear(Hc.r,Hc.g,Hc.b,D,c)}function _(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),m!==void 0&&(m.geometry.dispose(),m.material.dispose(),m=void 0)}return{getClearColor:function(){return f},setClearColor:function(T,D=1){f.set(T),p=D,S(f,p)},getClearAlpha:function(){return p},setClearAlpha:function(T){p=T,S(f,p)},render:b,addToRenderList:C,dispose:_}}function gE(r,t){const i=r.getParameter(r.MAX_VERTEX_ATTRIBS),a={},l=g(null);let c=l,f=!1;function p(G,Y,ct,ut,W){let F=!1;const V=x(G,ut,ct,Y);c!==V&&(c=V,d(c.object)),F=y(G,ut,ct,W),F&&b(G,ut,ct,W),W!==null&&t.update(W,r.ELEMENT_ARRAY_BUFFER),(F||f)&&(f=!1,U(G,Y,ct,ut),W!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(W).buffer))}function m(){return r.createVertexArray()}function d(G){return r.bindVertexArray(G)}function v(G){return r.deleteVertexArray(G)}function x(G,Y,ct,ut){const W=ut.wireframe===!0;let F=a[Y.id];F===void 0&&(F={},a[Y.id]=F);const V=G.isInstancedMesh===!0?G.id:0;let rt=F[V];rt===void 0&&(rt={},F[V]=rt);let gt=rt[ct.id];gt===void 0&&(gt={},rt[ct.id]=gt);let I=gt[W];return I===void 0&&(I=g(m()),gt[W]=I),I}function g(G){const Y=[],ct=[],ut=[];for(let W=0;W<i;W++)Y[W]=0,ct[W]=0,ut[W]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:Y,enabledAttributes:ct,attributeDivisors:ut,object:G,attributes:{},index:null}}function y(G,Y,ct,ut){const W=c.attributes,F=Y.attributes;let V=0;const rt=ct.getAttributes();for(const gt in rt)if(rt[gt].location>=0){const tt=W[gt];let dt=F[gt];if(dt===void 0&&(gt==="instanceMatrix"&&G.instanceMatrix&&(dt=G.instanceMatrix),gt==="instanceColor"&&G.instanceColor&&(dt=G.instanceColor)),tt===void 0||tt.attribute!==dt||dt&&tt.data!==dt.data)return!0;V++}return c.attributesNum!==V||c.index!==ut}function b(G,Y,ct,ut){const W={},F=Y.attributes;let V=0;const rt=ct.getAttributes();for(const gt in rt)if(rt[gt].location>=0){let tt=F[gt];tt===void 0&&(gt==="instanceMatrix"&&G.instanceMatrix&&(tt=G.instanceMatrix),gt==="instanceColor"&&G.instanceColor&&(tt=G.instanceColor));const dt={};dt.attribute=tt,tt&&tt.data&&(dt.data=tt.data),W[gt]=dt,V++}c.attributes=W,c.attributesNum=V,c.index=ut}function C(){const G=c.newAttributes;for(let Y=0,ct=G.length;Y<ct;Y++)G[Y]=0}function S(G){_(G,0)}function _(G,Y){const ct=c.newAttributes,ut=c.enabledAttributes,W=c.attributeDivisors;ct[G]=1,ut[G]===0&&(r.enableVertexAttribArray(G),ut[G]=1),W[G]!==Y&&(r.vertexAttribDivisor(G,Y),W[G]=Y)}function T(){const G=c.newAttributes,Y=c.enabledAttributes;for(let ct=0,ut=Y.length;ct<ut;ct++)Y[ct]!==G[ct]&&(r.disableVertexAttribArray(ct),Y[ct]=0)}function D(G,Y,ct,ut,W,F,V){V===!0?r.vertexAttribIPointer(G,Y,ct,W,F):r.vertexAttribPointer(G,Y,ct,ut,W,F)}function U(G,Y,ct,ut){C();const W=ut.attributes,F=ct.getAttributes(),V=Y.defaultAttributeValues;for(const rt in F){const gt=F[rt];if(gt.location>=0){let I=W[rt];if(I===void 0&&(rt==="instanceMatrix"&&G.instanceMatrix&&(I=G.instanceMatrix),rt==="instanceColor"&&G.instanceColor&&(I=G.instanceColor)),I!==void 0){const tt=I.normalized,dt=I.itemSize,St=t.get(I);if(St===void 0)continue;const Nt=St.buffer,Tt=St.type,J=St.bytesPerElement,Mt=Tt===r.INT||Tt===r.UNSIGNED_INT||I.gpuType===Zd;if(I.isInterleavedBufferAttribute){const pt=I.data,Ft=pt.stride,$t=I.offset;if(pt.isInstancedInterleavedBuffer){for(let Zt=0;Zt<gt.locationSize;Zt++)_(gt.location+Zt,pt.meshPerAttribute);G.isInstancedMesh!==!0&&ut._maxInstanceCount===void 0&&(ut._maxInstanceCount=pt.meshPerAttribute*pt.count)}else for(let Zt=0;Zt<gt.locationSize;Zt++)S(gt.location+Zt);r.bindBuffer(r.ARRAY_BUFFER,Nt);for(let Zt=0;Zt<gt.locationSize;Zt++)D(gt.location+Zt,dt/gt.locationSize,Tt,tt,Ft*J,($t+dt/gt.locationSize*Zt)*J,Mt)}else{if(I.isInstancedBufferAttribute){for(let pt=0;pt<gt.locationSize;pt++)_(gt.location+pt,I.meshPerAttribute);G.isInstancedMesh!==!0&&ut._maxInstanceCount===void 0&&(ut._maxInstanceCount=I.meshPerAttribute*I.count)}else for(let pt=0;pt<gt.locationSize;pt++)S(gt.location+pt);r.bindBuffer(r.ARRAY_BUFFER,Nt);for(let pt=0;pt<gt.locationSize;pt++)D(gt.location+pt,dt/gt.locationSize,Tt,tt,dt*J,dt/gt.locationSize*pt*J,Mt)}}else if(V!==void 0){const tt=V[rt];if(tt!==void 0)switch(tt.length){case 2:r.vertexAttrib2fv(gt.location,tt);break;case 3:r.vertexAttrib3fv(gt.location,tt);break;case 4:r.vertexAttrib4fv(gt.location,tt);break;default:r.vertexAttrib1fv(gt.location,tt)}}}}T()}function P(){O();for(const G in a){const Y=a[G];for(const ct in Y){const ut=Y[ct];for(const W in ut){const F=ut[W];for(const V in F)v(F[V].object),delete F[V];delete ut[W]}}delete a[G]}}function N(G){if(a[G.id]===void 0)return;const Y=a[G.id];for(const ct in Y){const ut=Y[ct];for(const W in ut){const F=ut[W];for(const V in F)v(F[V].object),delete F[V];delete ut[W]}}delete a[G.id]}function z(G){for(const Y in a){const ct=a[Y];for(const ut in ct){const W=ct[ut];if(W[G.id]===void 0)continue;const F=W[G.id];for(const V in F)v(F[V].object),delete F[V];delete W[G.id]}}}function A(G){for(const Y in a){const ct=a[Y],ut=G.isInstancedMesh===!0?G.id:0,W=ct[ut];if(W!==void 0){for(const F in W){const V=W[F];for(const rt in V)v(V[rt].object),delete V[rt];delete W[F]}delete ct[ut],Object.keys(ct).length===0&&delete a[Y]}}}function O(){k(),f=!0,c!==l&&(c=l,d(c.object))}function k(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:p,reset:O,resetDefaultState:k,dispose:P,releaseStatesOfGeometry:N,releaseStatesOfObject:A,releaseStatesOfProgram:z,initAttributes:C,enableAttribute:S,disableUnusedAttributes:T}}function vE(r,t,i){let a;function l(m){a=m}function c(m,d){r.drawArrays(a,m,d),i.update(d,a,1)}function f(m,d,v){v!==0&&(r.drawArraysInstanced(a,m,d,v),i.update(d,a,v))}function p(m,d,v){if(v===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(a,m,0,d,0,v);let g=0;for(let y=0;y<v;y++)g+=d[y];i.update(g,a,1)}this.setMode=l,this.render=c,this.renderInstances=f,this.renderMultiDraw=p}function xE(r,t,i,a){let l;function c(){if(l!==void 0)return l;if(t.has("EXT_texture_filter_anisotropic")===!0){const z=t.get("EXT_texture_filter_anisotropic");l=r.getParameter(z.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function f(z){return!(z!==Li&&a.convert(z)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function p(z){const A=z===wa&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(z!==hi&&a.convert(z)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&z!==qi&&!A)}function m(z){if(z==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";z="mediump"}return z==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let d=i.precision!==void 0?i.precision:"highp";const v=m(d);v!==d&&(ae("WebGLRenderer:",d,"not supported, using",v,"instead."),d=v);const x=i.logarithmicDepthBuffer===!0,g=i.reversedDepthBuffer===!0&&t.has("EXT_clip_control");i.reversedDepthBuffer===!0&&g===!1&&ae("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const y=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),b=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),C=r.getParameter(r.MAX_TEXTURE_SIZE),S=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),_=r.getParameter(r.MAX_VERTEX_ATTRIBS),T=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),D=r.getParameter(r.MAX_VARYING_VECTORS),U=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),P=r.getParameter(r.MAX_SAMPLES),N=r.getParameter(r.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:m,textureFormatReadable:f,textureTypeReadable:p,precision:d,logarithmicDepthBuffer:x,reversedDepthBuffer:g,maxTextures:y,maxVertexTextures:b,maxTextureSize:C,maxCubemapSize:S,maxAttributes:_,maxVertexUniforms:T,maxVaryings:D,maxFragmentUniforms:U,maxSamples:P,samples:N}}function _E(r){const t=this;let i=null,a=0,l=!1,c=!1;const f=new Ls,p=new pe,m={value:null,needsUpdate:!1};this.uniform=m,this.numPlanes=0,this.numIntersection=0,this.init=function(x,g){const y=x.length!==0||g||a!==0||l;return l=g,a=x.length,y},this.beginShadows=function(){c=!0,v(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(x,g){i=v(x,g,0)},this.setState=function(x,g,y){const b=x.clippingPlanes,C=x.clipIntersection,S=x.clipShadows,_=r.get(x);if(!l||b===null||b.length===0||c&&!S)c?v(null):d();else{const T=c?0:a,D=T*4;let U=_.clippingState||null;m.value=U,U=v(b,g,D,y);for(let P=0;P!==D;++P)U[P]=i[P];_.clippingState=U,this.numIntersection=C?this.numPlanes:0,this.numPlanes+=T}};function d(){m.value!==i&&(m.value=i,m.needsUpdate=a>0),t.numPlanes=a,t.numIntersection=0}function v(x,g,y,b){const C=x!==null?x.length:0;let S=null;if(C!==0){if(S=m.value,b!==!0||S===null){const _=y+C*4,T=g.matrixWorldInverse;p.getNormalMatrix(T),(S===null||S.length<_)&&(S=new Float32Array(_));for(let D=0,U=y;D!==C;++D,U+=4)f.copy(x[D]).applyMatrix4(T,p),f.normal.toArray(S,U),S[U+3]=f.constant}m.value=S,m.needsUpdate=!0}return t.numPlanes=C,t.numIntersection=0,S}}const ls=4,Cv=[.125,.215,.35,.446,.526,.582],Os=20,SE=256,Qo=new up,Dv=new de;let Wh=null,qh=0,jh=0,Yh=!1;const yE=new K;class Nv{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,i=0,a=.1,l=100,c={}){const{size:f=256,position:p=yE}=c;Wh=this._renderer.getRenderTarget(),qh=this._renderer.getActiveCubeFace(),jh=this._renderer.getActiveMipmapLevel(),Yh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(f);const m=this._allocateTargets();return m.depthBuffer=!0,this._sceneToCubeUV(t,a,l,m,p),i>0&&this._blur(m,0,0,i),this._applyPMREM(m),this._cleanup(m),m}fromEquirectangular(t,i=null){return this._fromTexture(t,i)}fromCubemap(t,i=null){return this._fromTexture(t,i)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Pv(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Lv(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(Wh,qh,jh),this._renderer.xr.enabled=Yh,t.scissorTest=!1,Pr(t,0,0,t.width,t.height)}_fromTexture(t,i){t.mapping===zs||t.mapping===Vr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Wh=this._renderer.getRenderTarget(),qh=this._renderer.getActiveCubeFace(),jh=this._renderer.getActiveMipmapLevel(),Yh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const a=i||this._allocateTargets();return this._textureToCubeUV(t,a),this._applyPMREM(a),this._cleanup(a),a}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),i=4*this._cubeSize,a={magFilter:Gn,minFilter:Gn,generateMipmaps:!1,type:wa,format:Li,colorSpace:tu,depthBuffer:!1},l=Uv(t,i,a);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==i){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Uv(t,i,a);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=ME(c)),this._blurMaterial=EE(c,t,i),this._ggxMaterial=bE(c,t,i)}return l}_compileMaterial(t){const i=new qt(new Yn,t);this._renderer.compile(i,Qo)}_sceneToCubeUV(t,i,a,l,c){const m=new Mi(90,1,i,a),d=[1,-1,1,1,1,1],v=[1,1,1,-1,-1,-1],x=this._renderer,g=x.autoClear,y=x.toneMapping;x.getClearColor(Dv),x.toneMapping=Yi,x.autoClear=!1,x.state.buffers.depth.getReversed()&&(x.setRenderTarget(l),x.clearDepth(),x.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new qt(new ze,new os({name:"PMREM.Background",side:$n,depthWrite:!1,depthTest:!1})));const C=this._backgroundBox,S=C.material;let _=!1;const T=t.background;T?T.isColor&&(S.color.copy(T),t.background=null,_=!0):(S.color.copy(Dv),_=!0);for(let D=0;D<6;D++){const U=D%3;U===0?(m.up.set(0,d[D],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x+v[D],c.y,c.z)):U===1?(m.up.set(0,0,d[D]),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y+v[D],c.z)):(m.up.set(0,d[D],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y,c.z+v[D]));const P=this._cubeSize;Pr(l,U*P,D>2?P:0,P,P),x.setRenderTarget(l),_&&x.render(C,m),x.render(t,m)}x.toneMapping=y,x.autoClear=g,t.background=T}_textureToCubeUV(t,i){const a=this._renderer,l=t.mapping===zs||t.mapping===Vr;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=Pv()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Lv());const c=l?this._cubemapMaterial:this._equirectMaterial,f=this._lodMeshes[0];f.material=c;const p=c.uniforms;p.envMap.value=t;const m=this._cubeSize;Pr(i,0,0,3*m,2*m),a.setRenderTarget(i),a.render(f,Qo)}_applyPMREM(t){const i=this._renderer,a=i.autoClear;i.autoClear=!1;const l=this._lodMeshes.length;for(let c=1;c<l;c++)this._applyGGXFilter(t,c-1,c);i.autoClear=a}_applyGGXFilter(t,i,a){const l=this._renderer,c=this._pingPongRenderTarget,f=this._ggxMaterial,p=this._lodMeshes[a];p.material=f;const m=f.uniforms,d=a/(this._lodMeshes.length-1),v=i/(this._lodMeshes.length-1),x=Math.sqrt(d*d-v*v),g=0+d*1.25,y=x*g,{_lodMax:b}=this,C=this._sizeLods[a],S=3*C*(a>b-ls?a-b+ls:0),_=4*(this._cubeSize-C);m.envMap.value=t.texture,m.roughness.value=y,m.mipInt.value=b-i,Pr(c,S,_,3*C,2*C),l.setRenderTarget(c),l.render(p,Qo),m.envMap.value=c.texture,m.roughness.value=0,m.mipInt.value=b-a,Pr(t,S,_,3*C,2*C),l.setRenderTarget(t),l.render(p,Qo)}_blur(t,i,a,l,c){const f=this._pingPongRenderTarget;this._halfBlur(t,f,i,a,l,"latitudinal",c),this._halfBlur(f,t,a,a,l,"longitudinal",c)}_halfBlur(t,i,a,l,c,f,p){const m=this._renderer,d=this._blurMaterial;f!=="latitudinal"&&f!=="longitudinal"&&Oe("blur direction must be either latitudinal or longitudinal!");const v=3,x=this._lodMeshes[l];x.material=d;const g=d.uniforms,y=this._sizeLods[a]-1,b=isFinite(c)?Math.PI/(2*y):2*Math.PI/(2*Os-1),C=c/b,S=isFinite(c)?1+Math.floor(v*C):Os;S>Os&&ae(`sigmaRadians, ${c}, is too large and will clip, as it requested ${S} samples when the maximum is set to ${Os}`);const _=[];let T=0;for(let z=0;z<Os;++z){const A=z/C,O=Math.exp(-A*A/2);_.push(O),z===0?T+=O:z<S&&(T+=2*O)}for(let z=0;z<_.length;z++)_[z]=_[z]/T;g.envMap.value=t.texture,g.samples.value=S,g.weights.value=_,g.latitudinal.value=f==="latitudinal",p&&(g.poleAxis.value=p);const{_lodMax:D}=this;g.dTheta.value=b,g.mipInt.value=D-a;const U=this._sizeLods[l],P=3*U*(l>D-ls?l-D+ls:0),N=4*(this._cubeSize-U);Pr(i,P,N,3*U,2*U),m.setRenderTarget(i),m.render(x,Qo)}}function ME(r){const t=[],i=[],a=[];let l=r;const c=r-ls+1+Cv.length;for(let f=0;f<c;f++){const p=Math.pow(2,l);t.push(p);let m=1/p;f>r-ls?m=Cv[f-r+ls-1]:f===0&&(m=0),i.push(m);const d=1/(p-2),v=-d,x=1+d,g=[v,v,x,v,x,x,v,v,x,x,v,x],y=6,b=6,C=3,S=2,_=1,T=new Float32Array(C*b*y),D=new Float32Array(S*b*y),U=new Float32Array(_*b*y);for(let N=0;N<y;N++){const z=N%3*2/3-1,A=N>2?0:-1,O=[z,A,0,z+2/3,A,0,z+2/3,A+1,0,z,A,0,z+2/3,A+1,0,z,A+1,0];T.set(O,C*b*N),D.set(g,S*b*N);const k=[N,N,N,N,N,N];U.set(k,_*b*N)}const P=new Yn;P.setAttribute("position",new Pi(T,C)),P.setAttribute("uv",new Pi(D,S)),P.setAttribute("faceIndex",new Pi(U,_)),a.push(new qt(P,null)),l>ls&&l--}return{lodMeshes:a,sizeLods:t,sigmas:i}}function Uv(r,t,i){const a=new Zi(r,t,i);return a.texture.mapping=su,a.texture.name="PMREM.cubeUv",a.scissorTest=!0,a}function Pr(r,t,i,a,l){r.viewport.set(t,i,a,l),r.scissor.set(t,i,a,l)}function bE(r,t,i){return new Qi({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:SE,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:lu(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ta,depthTest:!1,depthWrite:!1})}function EE(r,t,i){const a=new Float32Array(Os),l=new K(0,1,0);return new Qi({name:"SphericalGaussianBlur",defines:{n:Os,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:a},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:lu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ta,depthTest:!1,depthWrite:!1})}function Lv(){return new Qi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:lu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ta,depthTest:!1,depthWrite:!1})}function Pv(){return new Qi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:lu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ta,depthTest:!1,depthWrite:!1})}function lu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class Nx extends Zi{constructor(t=1,i={}){super(t,t,i),this.isWebGLCubeRenderTarget=!0;const a={width:t,height:t,depth:1},l=[a,a,a,a,a,a];this.texture=new Tx(l),this._setTextureOptions(i),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,i){this.texture.type=i.type,this.texture.colorSpace=i.colorSpace,this.texture.generateMipmaps=i.generateMipmaps,this.texture.minFilter=i.minFilter,this.texture.magFilter=i.magFilter;const a={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},l=new ze(5,5,5),c=new Qi({name:"CubemapFromEquirect",uniforms:Xr(a.uniforms),vertexShader:a.vertexShader,fragmentShader:a.fragmentShader,side:$n,blending:Ta});c.uniforms.tEquirect.value=i;const f=new qt(l,c),p=i.minFilter;return i.minFilter===Is&&(i.minFilter=Gn),new CM(1,10,this).update(t,f),i.minFilter=p,f.geometry.dispose(),f.material.dispose(),this}clear(t,i=!0,a=!0,l=!0){const c=t.getRenderTarget();for(let f=0;f<6;f++)t.setRenderTarget(this,f),t.clear(i,a,l);t.setRenderTarget(c)}}function TE(r){let t=new WeakMap,i=new WeakMap,a=null;function l(g,y=!1){return g==null?null:y?f(g):c(g)}function c(g){if(g&&g.isTexture){const y=g.mapping;if(y===_h||y===Sh)if(t.has(g)){const b=t.get(g).texture;return p(b,g.mapping)}else{const b=g.image;if(b&&b.height>0){const C=new Nx(b.height);return C.fromEquirectangularTexture(r,g),t.set(g,C),g.addEventListener("dispose",d),p(C.texture,g.mapping)}else return null}}return g}function f(g){if(g&&g.isTexture){const y=g.mapping,b=y===_h||y===Sh,C=y===zs||y===Vr;if(b||C){let S=i.get(g);const _=S!==void 0?S.texture.pmremVersion:0;if(g.isRenderTargetTexture&&g.pmremVersion!==_)return a===null&&(a=new Nv(r)),S=b?a.fromEquirectangular(g,S):a.fromCubemap(g,S),S.texture.pmremVersion=g.pmremVersion,i.set(g,S),S.texture;if(S!==void 0)return S.texture;{const T=g.image;return b&&T&&T.height>0||C&&T&&m(T)?(a===null&&(a=new Nv(r)),S=b?a.fromEquirectangular(g):a.fromCubemap(g),S.texture.pmremVersion=g.pmremVersion,i.set(g,S),g.addEventListener("dispose",v),S.texture):null}}}return g}function p(g,y){return y===_h?g.mapping=zs:y===Sh&&(g.mapping=Vr),g}function m(g){let y=0;const b=6;for(let C=0;C<b;C++)g[C]!==void 0&&y++;return y===b}function d(g){const y=g.target;y.removeEventListener("dispose",d);const b=t.get(y);b!==void 0&&(t.delete(y),b.dispose())}function v(g){const y=g.target;y.removeEventListener("dispose",v);const b=i.get(y);b!==void 0&&(i.delete(y),b.dispose())}function x(){t=new WeakMap,i=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:l,dispose:x}}function AE(r){const t={};function i(a){if(t[a]!==void 0)return t[a];const l=r.getExtension(a);return t[a]=l,l}return{has:function(a){return i(a)!==null},init:function(){i("EXT_color_buffer_float"),i("WEBGL_clip_cull_distance"),i("OES_texture_float_linear"),i("EXT_color_buffer_half_float"),i("WEBGL_multisampled_render_to_texture"),i("WEBGL_render_shared_exponent")},get:function(a){const l=i(a);return l===null&&Vd("WebGLRenderer: "+a+" extension not supported."),l}}}function wE(r,t,i,a){const l={},c=new WeakMap;function f(x){const g=x.target;g.index!==null&&t.remove(g.index);for(const b in g.attributes)t.remove(g.attributes[b]);g.removeEventListener("dispose",f),delete l[g.id];const y=c.get(g);y&&(t.remove(y),c.delete(g)),a.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,i.memory.geometries--}function p(x,g){return l[g.id]===!0||(g.addEventListener("dispose",f),l[g.id]=!0,i.memory.geometries++),g}function m(x){const g=x.attributes;for(const y in g)t.update(g[y],r.ARRAY_BUFFER)}function d(x){const g=[],y=x.index,b=x.attributes.position;let C=0;if(b===void 0)return;if(y!==null){const T=y.array;C=y.version;for(let D=0,U=T.length;D<U;D+=3){const P=T[D+0],N=T[D+1],z=T[D+2];g.push(P,N,N,z,z,P)}}else{const T=b.array;C=b.version;for(let D=0,U=T.length/3-1;D<U;D+=3){const P=D+0,N=D+1,z=D+2;g.push(P,N,N,z,z,P)}}const S=new(b.count>=65535?Mx:yx)(g,1);S.version=C;const _=c.get(x);_&&t.remove(_),c.set(x,S)}function v(x){const g=c.get(x);if(g){const y=x.index;y!==null&&g.version<y.version&&d(x)}else d(x);return c.get(x)}return{get:p,update:m,getWireframeAttribute:v}}function RE(r,t,i){let a;function l(x){a=x}let c,f;function p(x){c=x.type,f=x.bytesPerElement}function m(x,g){r.drawElements(a,g,c,x*f),i.update(g,a,1)}function d(x,g,y){y!==0&&(r.drawElementsInstanced(a,g,c,x*f,y),i.update(g,a,y))}function v(x,g,y){if(y===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(a,g,0,c,x,0,y);let C=0;for(let S=0;S<y;S++)C+=g[S];i.update(C,a,1)}this.setMode=l,this.setIndex=p,this.render=m,this.renderInstances=d,this.renderMultiDraw=v}function CE(r){const t={geometries:0,textures:0},i={frame:0,calls:0,triangles:0,points:0,lines:0};function a(c,f,p){switch(i.calls++,f){case r.TRIANGLES:i.triangles+=p*(c/3);break;case r.LINES:i.lines+=p*(c/2);break;case r.LINE_STRIP:i.lines+=p*(c-1);break;case r.LINE_LOOP:i.lines+=p*c;break;case r.POINTS:i.points+=p*c;break;default:Oe("WebGLInfo: Unknown draw mode:",f);break}}function l(){i.calls=0,i.triangles=0,i.points=0,i.lines=0}return{memory:t,render:i,programs:null,autoReset:!0,reset:l,update:a}}function DE(r,t,i){const a=new WeakMap,l=new fn;function c(f,p,m){const d=f.morphTargetInfluences,v=p.morphAttributes.position||p.morphAttributes.normal||p.morphAttributes.color,x=v!==void 0?v.length:0;let g=a.get(p);if(g===void 0||g.count!==x){let k=function(){A.dispose(),a.delete(p),p.removeEventListener("dispose",k)};var y=k;g!==void 0&&g.texture.dispose();const b=p.morphAttributes.position!==void 0,C=p.morphAttributes.normal!==void 0,S=p.morphAttributes.color!==void 0,_=p.morphAttributes.position||[],T=p.morphAttributes.normal||[],D=p.morphAttributes.color||[];let U=0;b===!0&&(U=1),C===!0&&(U=2),S===!0&&(U=3);let P=p.attributes.position.count*U,N=1;P>t.maxTextureSize&&(N=Math.ceil(P/t.maxTextureSize),P=t.maxTextureSize);const z=new Float32Array(P*N*4*x),A=new xx(z,P,N,x);A.type=qi,A.needsUpdate=!0;const O=U*4;for(let G=0;G<x;G++){const Y=_[G],ct=T[G],ut=D[G],W=P*N*4*G;for(let F=0;F<Y.count;F++){const V=F*O;b===!0&&(l.fromBufferAttribute(Y,F),z[W+V+0]=l.x,z[W+V+1]=l.y,z[W+V+2]=l.z,z[W+V+3]=0),C===!0&&(l.fromBufferAttribute(ct,F),z[W+V+4]=l.x,z[W+V+5]=l.y,z[W+V+6]=l.z,z[W+V+7]=0),S===!0&&(l.fromBufferAttribute(ut,F),z[W+V+8]=l.x,z[W+V+9]=l.y,z[W+V+10]=l.z,z[W+V+11]=ut.itemSize===4?l.w:1)}}g={count:x,texture:A,size:new De(P,N)},a.set(p,g),p.addEventListener("dispose",k)}if(f.isInstancedMesh===!0&&f.morphTexture!==null)m.getUniforms().setValue(r,"morphTexture",f.morphTexture,i);else{let b=0;for(let S=0;S<d.length;S++)b+=d[S];const C=p.morphTargetsRelative?1:1-b;m.getUniforms().setValue(r,"morphTargetBaseInfluence",C),m.getUniforms().setValue(r,"morphTargetInfluences",d)}m.getUniforms().setValue(r,"morphTargetsTexture",g.texture,i),m.getUniforms().setValue(r,"morphTargetsTextureSize",g.size)}return{update:c}}function NE(r,t,i,a,l){let c=new WeakMap;function f(d){const v=l.render.frame,x=d.geometry,g=t.get(d,x);if(c.get(g)!==v&&(t.update(g),c.set(g,v)),d.isInstancedMesh&&(d.hasEventListener("dispose",m)===!1&&d.addEventListener("dispose",m),c.get(d)!==v&&(i.update(d.instanceMatrix,r.ARRAY_BUFFER),d.instanceColor!==null&&i.update(d.instanceColor,r.ARRAY_BUFFER),c.set(d,v))),d.isSkinnedMesh){const y=d.skeleton;c.get(y)!==v&&(y.update(),c.set(y,v))}return g}function p(){c=new WeakMap}function m(d){const v=d.target;v.removeEventListener("dispose",m),a.releaseStatesOfObject(v),i.remove(v.instanceMatrix),v.instanceColor!==null&&i.remove(v.instanceColor)}return{update:f,dispose:p}}const UE={[ix]:"LINEAR_TONE_MAPPING",[ax]:"REINHARD_TONE_MAPPING",[sx]:"CINEON_TONE_MAPPING",[Yd]:"ACES_FILMIC_TONE_MAPPING",[ox]:"AGX_TONE_MAPPING",[lx]:"NEUTRAL_TONE_MAPPING",[rx]:"CUSTOM_TONE_MAPPING"};function LE(r,t,i,a,l){const c=new Zi(t,i,{type:r,depthBuffer:a,stencilBuffer:l,depthTexture:a?new kr(t,i):void 0}),f=new Zi(t,i,{type:wa,depthBuffer:!1,stencilBuffer:!1}),p=new Yn;p.setAttribute("position",new mn([-1,3,0,-1,-1,0,3,-1,0],3)),p.setAttribute("uv",new mn([0,2,0,0,2,0],2));const m=new yM({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new qt(p,m),v=new up(-1,1,1,-1,0,1);let x=null,g=null,y=!1,b,C=null,S=[],_=!1;this.setSize=function(T,D){c.setSize(T,D),f.setSize(T,D);for(let U=0;U<S.length;U++){const P=S[U];P.setSize&&P.setSize(T,D)}},this.setEffects=function(T){S=T,_=S.length>0&&S[0].isRenderPass===!0;const D=c.width,U=c.height;for(let P=0;P<S.length;P++){const N=S[P];N.setSize&&N.setSize(D,U)}},this.begin=function(T,D){if(y||T.toneMapping===Yi&&S.length===0)return!1;if(C=D,D!==null){const U=D.width,P=D.height;(c.width!==U||c.height!==P)&&this.setSize(U,P)}return _===!1&&T.setRenderTarget(c),b=T.toneMapping,T.toneMapping=Yi,!0},this.hasRenderPass=function(){return _},this.end=function(T,D){T.toneMapping=b,y=!0;let U=c,P=f;for(let N=0;N<S.length;N++){const z=S[N];if(z.enabled!==!1&&(z.render(T,P,U,D),z.needsSwap!==!1)){const A=U;U=P,P=A}}if(x!==T.outputColorSpace||g!==T.toneMapping){x=T.outputColorSpace,g=T.toneMapping,m.defines={},Ce.getTransfer(x)===qe&&(m.defines.SRGB_TRANSFER="");const N=UE[g];N&&(m.defines[N]=""),m.needsUpdate=!0}m.uniforms.tDiffuse.value=U.texture,T.setRenderTarget(C),T.render(d,v),C=null,y=!1},this.isCompositing=function(){return y},this.dispose=function(){c.depthTexture&&c.depthTexture.dispose(),c.dispose(),f.dispose(),p.dispose(),m.dispose()}}const Ux=new jn,Xd=new kr(1,1),Lx=new xx,Px=new Qy,Ox=new Tx,Ov=[],Iv=[],Bv=new Float32Array(16),Fv=new Float32Array(9),zv=new Float32Array(4);function Yr(r,t,i){const a=r[0];if(a<=0||a>0)return r;const l=t*i;let c=Ov[l];if(c===void 0&&(c=new Float32Array(l),Ov[l]=c),t!==0){a.toArray(c,0);for(let f=1,p=0;f!==t;++f)p+=i,r[f].toArray(c,p)}return c}function bn(r,t){if(r.length!==t.length)return!1;for(let i=0,a=r.length;i<a;i++)if(r[i]!==t[i])return!1;return!0}function En(r,t){for(let i=0,a=t.length;i<a;i++)r[i]=t[i]}function cu(r,t){let i=Iv[t];i===void 0&&(i=new Int32Array(t),Iv[t]=i);for(let a=0;a!==t;++a)i[a]=r.allocateTextureUnit();return i}function PE(r,t){const i=this.cache;i[0]!==t&&(r.uniform1f(this.addr,t),i[0]=t)}function OE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2f(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(bn(i,t))return;r.uniform2fv(this.addr,t),En(i,t)}}function IE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3f(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else if(t.r!==void 0)(i[0]!==t.r||i[1]!==t.g||i[2]!==t.b)&&(r.uniform3f(this.addr,t.r,t.g,t.b),i[0]=t.r,i[1]=t.g,i[2]=t.b);else{if(bn(i,t))return;r.uniform3fv(this.addr,t),En(i,t)}}function BE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4f(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(bn(i,t))return;r.uniform4fv(this.addr,t),En(i,t)}}function FE(r,t){const i=this.cache,a=t.elements;if(a===void 0){if(bn(i,t))return;r.uniformMatrix2fv(this.addr,!1,t),En(i,t)}else{if(bn(i,a))return;zv.set(a),r.uniformMatrix2fv(this.addr,!1,zv),En(i,a)}}function zE(r,t){const i=this.cache,a=t.elements;if(a===void 0){if(bn(i,t))return;r.uniformMatrix3fv(this.addr,!1,t),En(i,t)}else{if(bn(i,a))return;Fv.set(a),r.uniformMatrix3fv(this.addr,!1,Fv),En(i,a)}}function GE(r,t){const i=this.cache,a=t.elements;if(a===void 0){if(bn(i,t))return;r.uniformMatrix4fv(this.addr,!1,t),En(i,t)}else{if(bn(i,a))return;Bv.set(a),r.uniformMatrix4fv(this.addr,!1,Bv),En(i,a)}}function HE(r,t){const i=this.cache;i[0]!==t&&(r.uniform1i(this.addr,t),i[0]=t)}function VE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2i(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(bn(i,t))return;r.uniform2iv(this.addr,t),En(i,t)}}function kE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3i(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else{if(bn(i,t))return;r.uniform3iv(this.addr,t),En(i,t)}}function XE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4i(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(bn(i,t))return;r.uniform4iv(this.addr,t),En(i,t)}}function WE(r,t){const i=this.cache;i[0]!==t&&(r.uniform1ui(this.addr,t),i[0]=t)}function qE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2ui(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(bn(i,t))return;r.uniform2uiv(this.addr,t),En(i,t)}}function jE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3ui(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else{if(bn(i,t))return;r.uniform3uiv(this.addr,t),En(i,t)}}function YE(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4ui(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(bn(i,t))return;r.uniform4uiv(this.addr,t),En(i,t)}}function ZE(r,t,i){const a=this.cache,l=i.allocateTextureUnit();a[0]!==l&&(r.uniform1i(this.addr,l),a[0]=l);let c;this.type===r.SAMPLER_2D_SHADOW?(Xd.compareFunction=i.isReversedDepthBuffer()?np:ep,c=Xd):c=Ux,i.setTexture2D(t||c,l)}function KE(r,t,i){const a=this.cache,l=i.allocateTextureUnit();a[0]!==l&&(r.uniform1i(this.addr,l),a[0]=l),i.setTexture3D(t||Px,l)}function QE(r,t,i){const a=this.cache,l=i.allocateTextureUnit();a[0]!==l&&(r.uniform1i(this.addr,l),a[0]=l),i.setTextureCube(t||Ox,l)}function JE(r,t,i){const a=this.cache,l=i.allocateTextureUnit();a[0]!==l&&(r.uniform1i(this.addr,l),a[0]=l),i.setTexture2DArray(t||Lx,l)}function $E(r){switch(r){case 5126:return PE;case 35664:return OE;case 35665:return IE;case 35666:return BE;case 35674:return FE;case 35675:return zE;case 35676:return GE;case 5124:case 35670:return HE;case 35667:case 35671:return VE;case 35668:case 35672:return kE;case 35669:case 35673:return XE;case 5125:return WE;case 36294:return qE;case 36295:return jE;case 36296:return YE;case 35678:case 36198:case 36298:case 36306:case 35682:return ZE;case 35679:case 36299:case 36307:return KE;case 35680:case 36300:case 36308:case 36293:return QE;case 36289:case 36303:case 36311:case 36292:return JE}}function tT(r,t){r.uniform1fv(this.addr,t)}function eT(r,t){const i=Yr(t,this.size,2);r.uniform2fv(this.addr,i)}function nT(r,t){const i=Yr(t,this.size,3);r.uniform3fv(this.addr,i)}function iT(r,t){const i=Yr(t,this.size,4);r.uniform4fv(this.addr,i)}function aT(r,t){const i=Yr(t,this.size,4);r.uniformMatrix2fv(this.addr,!1,i)}function sT(r,t){const i=Yr(t,this.size,9);r.uniformMatrix3fv(this.addr,!1,i)}function rT(r,t){const i=Yr(t,this.size,16);r.uniformMatrix4fv(this.addr,!1,i)}function oT(r,t){r.uniform1iv(this.addr,t)}function lT(r,t){r.uniform2iv(this.addr,t)}function cT(r,t){r.uniform3iv(this.addr,t)}function uT(r,t){r.uniform4iv(this.addr,t)}function fT(r,t){r.uniform1uiv(this.addr,t)}function hT(r,t){r.uniform2uiv(this.addr,t)}function dT(r,t){r.uniform3uiv(this.addr,t)}function pT(r,t){r.uniform4uiv(this.addr,t)}function mT(r,t,i){const a=this.cache,l=t.length,c=cu(i,l);bn(a,c)||(r.uniform1iv(this.addr,c),En(a,c));let f;this.type===r.SAMPLER_2D_SHADOW?f=Xd:f=Ux;for(let p=0;p!==l;++p)i.setTexture2D(t[p]||f,c[p])}function gT(r,t,i){const a=this.cache,l=t.length,c=cu(i,l);bn(a,c)||(r.uniform1iv(this.addr,c),En(a,c));for(let f=0;f!==l;++f)i.setTexture3D(t[f]||Px,c[f])}function vT(r,t,i){const a=this.cache,l=t.length,c=cu(i,l);bn(a,c)||(r.uniform1iv(this.addr,c),En(a,c));for(let f=0;f!==l;++f)i.setTextureCube(t[f]||Ox,c[f])}function xT(r,t,i){const a=this.cache,l=t.length,c=cu(i,l);bn(a,c)||(r.uniform1iv(this.addr,c),En(a,c));for(let f=0;f!==l;++f)i.setTexture2DArray(t[f]||Lx,c[f])}function _T(r){switch(r){case 5126:return tT;case 35664:return eT;case 35665:return nT;case 35666:return iT;case 35674:return aT;case 35675:return sT;case 35676:return rT;case 5124:case 35670:return oT;case 35667:case 35671:return lT;case 35668:case 35672:return cT;case 35669:case 35673:return uT;case 5125:return fT;case 36294:return hT;case 36295:return dT;case 36296:return pT;case 35678:case 36198:case 36298:case 36306:case 35682:return mT;case 35679:case 36299:case 36307:return gT;case 35680:case 36300:case 36308:case 36293:return vT;case 36289:case 36303:case 36311:case 36292:return xT}}class ST{constructor(t,i,a){this.id=t,this.addr=a,this.cache=[],this.type=i.type,this.setValue=$E(i.type)}}class yT{constructor(t,i,a){this.id=t,this.addr=a,this.cache=[],this.type=i.type,this.size=i.size,this.setValue=_T(i.type)}}class MT{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,i,a){const l=this.seq;for(let c=0,f=l.length;c!==f;++c){const p=l[c];p.setValue(t,i[p.id],a)}}}const Zh=/(\w+)(\])?(\[|\.)?/g;function Gv(r,t){r.seq.push(t),r.map[t.id]=t}function bT(r,t,i){const a=r.name,l=a.length;for(Zh.lastIndex=0;;){const c=Zh.exec(a),f=Zh.lastIndex;let p=c[1];const m=c[2]==="]",d=c[3];if(m&&(p=p|0),d===void 0||d==="["&&f+2===l){Gv(i,d===void 0?new ST(p,r,t):new yT(p,r,t));break}else{let x=i.map[p];x===void 0&&(x=new MT(p),Gv(i,x)),i=x}}}class Qc{constructor(t,i){this.seq=[],this.map={};const a=t.getProgramParameter(i,t.ACTIVE_UNIFORMS);for(let f=0;f<a;++f){const p=t.getActiveUniform(i,f),m=t.getUniformLocation(i,p.name);bT(p,m,this)}const l=[],c=[];for(const f of this.seq)f.type===t.SAMPLER_2D_SHADOW||f.type===t.SAMPLER_CUBE_SHADOW||f.type===t.SAMPLER_2D_ARRAY_SHADOW?l.push(f):c.push(f);l.length>0&&(this.seq=l.concat(c))}setValue(t,i,a,l){const c=this.map[i];c!==void 0&&c.setValue(t,a,l)}setOptional(t,i,a){const l=i[a];l!==void 0&&this.setValue(t,a,l)}static upload(t,i,a,l){for(let c=0,f=i.length;c!==f;++c){const p=i[c],m=a[p.id];m.needsUpdate!==!1&&p.setValue(t,m.value,l)}}static seqWithValue(t,i){const a=[];for(let l=0,c=t.length;l!==c;++l){const f=t[l];f.id in i&&a.push(f)}return a}}function Hv(r,t,i){const a=r.createShader(t);return r.shaderSource(a,i),r.compileShader(a),a}const ET=37297;let TT=0;function AT(r,t){const i=r.split(`
`),a=[],l=Math.max(t-6,0),c=Math.min(t+6,i.length);for(let f=l;f<c;f++){const p=f+1;a.push(`${p===t?">":" "} ${p}: ${i[f]}`)}return a.join(`
`)}const Vv=new pe;function wT(r){Ce._getMatrix(Vv,Ce.workingColorSpace,r);const t=`mat3( ${Vv.elements.map(i=>i.toFixed(4))} )`;switch(Ce.getTransfer(r)){case eu:return[t,"LinearTransferOETF"];case qe:return[t,"sRGBTransferOETF"];default:return ae("WebGLProgram: Unsupported color space: ",r),[t,"LinearTransferOETF"]}}function kv(r,t,i){const a=r.getShaderParameter(t,r.COMPILE_STATUS),c=(r.getShaderInfoLog(t)||"").trim();if(a&&c==="")return"";const f=/ERROR: 0:(\d+)/.exec(c);if(f){const p=parseInt(f[1]);return i.toUpperCase()+`

`+c+`

`+AT(r.getShaderSource(t),p)}else return c}function RT(r,t){const i=wT(t);return[`vec4 ${r}( vec4 value ) {`,`	return ${i[1]}( vec4( value.rgb * ${i[0]}, value.a ) );`,"}"].join(`
`)}const CT={[ix]:"Linear",[ax]:"Reinhard",[sx]:"Cineon",[Yd]:"ACESFilmic",[ox]:"AgX",[lx]:"Neutral",[rx]:"Custom"};function DT(r,t){const i=CT[t];return i===void 0?(ae("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+r+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+r+"( vec3 color ) { return "+i+"ToneMapping( color ); }"}const Vc=new K;function NT(){Ce.getLuminanceCoefficients(Vc);const r=Vc.x.toFixed(4),t=Vc.y.toFixed(4),i=Vc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${t}, ${i} );`,"	return dot( weights, rgb );","}"].join(`
`)}function UT(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(nl).join(`
`)}function LT(r){const t=[];for(const i in r){const a=r[i];a!==!1&&t.push("#define "+i+" "+a)}return t.join(`
`)}function PT(r,t){const i={},a=r.getProgramParameter(t,r.ACTIVE_ATTRIBUTES);for(let l=0;l<a;l++){const c=r.getActiveAttrib(t,l),f=c.name;let p=1;c.type===r.FLOAT_MAT2&&(p=2),c.type===r.FLOAT_MAT3&&(p=3),c.type===r.FLOAT_MAT4&&(p=4),i[f]={type:c.type,location:r.getAttribLocation(t,f),locationSize:p}}return i}function nl(r){return r!==""}function Xv(r,t){const i=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,i).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Wv(r,t){return r.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const OT=/^[ \t]*#include +<([\w\d./]+)>/gm;function Wd(r){return r.replace(OT,BT)}const IT=new Map;function BT(r,t){let i=ye[t];if(i===void 0){const a=IT.get(t);if(a!==void 0)i=ye[a],ae('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,a);else throw new Error("Can not resolve #include <"+t+">")}return Wd(i)}const FT=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function qv(r){return r.replace(FT,zT)}function zT(r,t,i,a){let l="";for(let c=parseInt(t);c<parseInt(i);c++)l+=a.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return l}function jv(r){let t=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?t+=`
#define HIGH_PRECISION`:r.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const GT={[qc]:"SHADOWMAP_TYPE_PCF",[el]:"SHADOWMAP_TYPE_VSM"};function HT(r){return GT[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const VT={[zs]:"ENVMAP_TYPE_CUBE",[Vr]:"ENVMAP_TYPE_CUBE",[su]:"ENVMAP_TYPE_CUBE_UV"};function kT(r){return r.envMap===!1?"ENVMAP_TYPE_CUBE":VT[r.envMapMode]||"ENVMAP_TYPE_CUBE"}const XT={[Vr]:"ENVMAP_MODE_REFRACTION"};function WT(r){return r.envMap===!1?"ENVMAP_MODE_REFLECTION":XT[r.envMapMode]||"ENVMAP_MODE_REFLECTION"}const qT={[nx]:"ENVMAP_BLENDING_MULTIPLY",[my]:"ENVMAP_BLENDING_MIX",[gy]:"ENVMAP_BLENDING_ADD"};function jT(r){return r.envMap===!1?"ENVMAP_BLENDING_NONE":qT[r.combine]||"ENVMAP_BLENDING_NONE"}function YT(r){const t=r.envMapCubeUVHeight;if(t===null)return null;const i=Math.log2(t)-2,a=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,i),112)),texelHeight:a,maxMip:i}}function ZT(r,t,i,a){const l=r.getContext(),c=i.defines;let f=i.vertexShader,p=i.fragmentShader;const m=HT(i),d=kT(i),v=WT(i),x=jT(i),g=YT(i),y=UT(i),b=LT(c),C=l.createProgram();let S,_,T=i.glslVersion?"#version "+i.glslVersion+`
`:"";i.isRawShaderMaterial?(S=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b].filter(nl).join(`
`),S.length>0&&(S+=`
`),_=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b].filter(nl).join(`
`),_.length>0&&(_+=`
`)):(S=[jv(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b,i.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",i.batching?"#define USE_BATCHING":"",i.batchingColor?"#define USE_BATCHING_COLOR":"",i.instancing?"#define USE_INSTANCING":"",i.instancingColor?"#define USE_INSTANCING_COLOR":"",i.instancingMorph?"#define USE_INSTANCING_MORPH":"",i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.map?"#define USE_MAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+v:"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.displacementMap?"#define USE_DISPLACEMENTMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.mapUv?"#define MAP_UV "+i.mapUv:"",i.alphaMapUv?"#define ALPHAMAP_UV "+i.alphaMapUv:"",i.lightMapUv?"#define LIGHTMAP_UV "+i.lightMapUv:"",i.aoMapUv?"#define AOMAP_UV "+i.aoMapUv:"",i.emissiveMapUv?"#define EMISSIVEMAP_UV "+i.emissiveMapUv:"",i.bumpMapUv?"#define BUMPMAP_UV "+i.bumpMapUv:"",i.normalMapUv?"#define NORMALMAP_UV "+i.normalMapUv:"",i.displacementMapUv?"#define DISPLACEMENTMAP_UV "+i.displacementMapUv:"",i.metalnessMapUv?"#define METALNESSMAP_UV "+i.metalnessMapUv:"",i.roughnessMapUv?"#define ROUGHNESSMAP_UV "+i.roughnessMapUv:"",i.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+i.anisotropyMapUv:"",i.clearcoatMapUv?"#define CLEARCOATMAP_UV "+i.clearcoatMapUv:"",i.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+i.clearcoatNormalMapUv:"",i.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+i.clearcoatRoughnessMapUv:"",i.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+i.iridescenceMapUv:"",i.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+i.iridescenceThicknessMapUv:"",i.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+i.sheenColorMapUv:"",i.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+i.sheenRoughnessMapUv:"",i.specularMapUv?"#define SPECULARMAP_UV "+i.specularMapUv:"",i.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+i.specularColorMapUv:"",i.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+i.specularIntensityMapUv:"",i.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+i.transmissionMapUv:"",i.thicknessMapUv?"#define THICKNESSMAP_UV "+i.thicknessMapUv:"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexNormals?"#define HAS_NORMAL":"",i.vertexColors?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.flatShading?"#define FLAT_SHADED":"",i.skinning?"#define USE_SKINNING":"",i.morphTargets?"#define USE_MORPHTARGETS":"",i.morphNormals&&i.flatShading===!1?"#define USE_MORPHNORMALS":"",i.morphColors?"#define USE_MORPHCOLORS":"",i.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+i.morphTextureStride:"",i.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+i.morphTargetsCount:"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.sizeAttenuation?"#define USE_SIZEATTENUATION":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(nl).join(`
`),_=[jv(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b,i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",i.map?"#define USE_MAP":"",i.matcap?"#define USE_MATCAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+d:"",i.envMap?"#define "+v:"",i.envMap?"#define "+x:"",g?"#define CUBEUV_TEXEL_WIDTH "+g.texelWidth:"",g?"#define CUBEUV_TEXEL_HEIGHT "+g.texelHeight:"",g?"#define CUBEUV_MAX_MIP "+g.maxMip+".0":"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoat?"#define USE_CLEARCOAT":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.dispersion?"#define USE_DISPERSION":"",i.iridescence?"#define USE_IRIDESCENCE":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaTest?"#define USE_ALPHATEST":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.sheen?"#define USE_SHEEN":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors||i.instancingColor?"#define USE_COLOR":"",i.vertexAlphas||i.batchingColor?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.gradientMap?"#define USE_GRADIENTMAP":"",i.flatShading?"#define FLAT_SHADED":"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",i.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",i.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",i.toneMapping!==Yi?"#define TONE_MAPPING":"",i.toneMapping!==Yi?ye.tonemapping_pars_fragment:"",i.toneMapping!==Yi?DT("toneMapping",i.toneMapping):"",i.dithering?"#define DITHERING":"",i.opaque?"#define OPAQUE":"",ye.colorspace_pars_fragment,RT("linearToOutputTexel",i.outputColorSpace),NT(),i.useDepthPacking?"#define DEPTH_PACKING "+i.depthPacking:"",`
`].filter(nl).join(`
`)),f=Wd(f),f=Xv(f,i),f=Wv(f,i),p=Wd(p),p=Xv(p,i),p=Wv(p,i),f=qv(f),p=qv(p),i.isRawShaderMaterial!==!0&&(T=`#version 300 es
`,S=[y,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+S,_=["#define varying in",i.glslVersion===nv?"":"layout(location = 0) out highp vec4 pc_fragColor;",i.glslVersion===nv?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+_);const D=T+S+f,U=T+_+p,P=Hv(l,l.VERTEX_SHADER,D),N=Hv(l,l.FRAGMENT_SHADER,U);l.attachShader(C,P),l.attachShader(C,N),i.index0AttributeName!==void 0?l.bindAttribLocation(C,0,i.index0AttributeName):i.morphTargets===!0&&l.bindAttribLocation(C,0,"position"),l.linkProgram(C);function z(G){if(r.debug.checkShaderErrors){const Y=l.getProgramInfoLog(C)||"",ct=l.getShaderInfoLog(P)||"",ut=l.getShaderInfoLog(N)||"",W=Y.trim(),F=ct.trim(),V=ut.trim();let rt=!0,gt=!0;if(l.getProgramParameter(C,l.LINK_STATUS)===!1)if(rt=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(l,C,P,N);else{const I=kv(l,P,"vertex"),tt=kv(l,N,"fragment");Oe("THREE.WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(C,l.VALIDATE_STATUS)+`

Material Name: `+G.name+`
Material Type: `+G.type+`

Program Info Log: `+W+`
`+I+`
`+tt)}else W!==""?ae("WebGLProgram: Program Info Log:",W):(F===""||V==="")&&(gt=!1);gt&&(G.diagnostics={runnable:rt,programLog:W,vertexShader:{log:F,prefix:S},fragmentShader:{log:V,prefix:_}})}l.deleteShader(P),l.deleteShader(N),A=new Qc(l,C),O=PT(l,C)}let A;this.getUniforms=function(){return A===void 0&&z(this),A};let O;this.getAttributes=function(){return O===void 0&&z(this),O};let k=i.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return k===!1&&(k=l.getProgramParameter(C,ET)),k},this.destroy=function(){a.releaseStatesOfProgram(this),l.deleteProgram(C),this.program=void 0},this.type=i.shaderType,this.name=i.shaderName,this.id=TT++,this.cacheKey=t,this.usedTimes=1,this.program=C,this.vertexShader=P,this.fragmentShader=N,this}let KT=0;class QT{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const i=t.vertexShader,a=t.fragmentShader,l=this._getShaderStage(i),c=this._getShaderStage(a),f=this._getShaderCacheForMaterial(t);return f.has(l)===!1&&(f.add(l),l.usedTimes++),f.has(c)===!1&&(f.add(c),c.usedTimes++),this}remove(t){const i=this.materialCache.get(t);for(const a of i)a.usedTimes--,a.usedTimes===0&&this.shaderCache.delete(a.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const i=this.materialCache;let a=i.get(t);return a===void 0&&(a=new Set,i.set(t,a)),a}_getShaderStage(t){const i=this.shaderCache;let a=i.get(t);return a===void 0&&(a=new JT(t),i.set(t,a)),a}}class JT{constructor(t){this.id=KT++,this.code=t,this.usedTimes=0}}function $T(r){return r===Gs||r===Jc||r===$c}function tA(r,t,i,a,l,c){const f=new _x,p=new QT,m=new Set,d=[],v=new Map,x=a.logarithmicDepthBuffer;let g=a.precision;const y={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function b(A){return m.add(A),A===0?"uv":`uv${A}`}function C(A,O,k,G,Y,ct){const ut=G.fog,W=Y.geometry,F=A.isMeshStandardMaterial||A.isMeshLambertMaterial||A.isMeshPhongMaterial?G.environment:null,V=A.isMeshStandardMaterial||A.isMeshLambertMaterial&&!A.envMap||A.isMeshPhongMaterial&&!A.envMap,rt=t.get(A.envMap||F,V),gt=rt&&rt.mapping===su?rt.image.height:null,I=y[A.type];A.precision!==null&&(g=a.getMaxPrecision(A.precision),g!==A.precision&&ae("WebGLProgram.getParameters:",A.precision,"not supported, using",g,"instead."));const tt=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,dt=tt!==void 0?tt.length:0;let St=0;W.morphAttributes.position!==void 0&&(St=1),W.morphAttributes.normal!==void 0&&(St=2),W.morphAttributes.color!==void 0&&(St=3);let Nt,Tt,J,Mt;if(I){const he=Wi[I];Nt=he.vertexShader,Tt=he.fragmentShader}else Nt=A.vertexShader,Tt=A.fragmentShader,p.update(A),J=p.getVertexShaderID(A),Mt=p.getFragmentShaderID(A);const pt=r.getRenderTarget(),Ft=r.state.buffers.depth.getReversed(),$t=Y.isInstancedMesh===!0,Zt=Y.isBatchedMesh===!0,Pe=!!A.map,le=!!A.matcap,Ne=!!rt,jt=!!A.aoMap,te=!!A.lightMap,ee=!!A.bumpMap,me=!!A.normalMap,Ve=!!A.displacementMap,j=!!A.emissiveMap,Ue=!!A.metalnessMap,ge=!!A.roughnessMap,ke=A.anisotropy>0,Pt=A.clearcoat>0,tn=A.dispersion>0,L=A.iridescence>0,E=A.sheen>0,$=A.transmission>0,ht=ke&&!!A.anisotropyMap,Et=Pt&&!!A.clearcoatMap,wt=Pt&&!!A.clearcoatNormalMap,Ut=Pt&&!!A.clearcoatRoughnessMap,ft=L&&!!A.iridescenceMap,xt=L&&!!A.iridescenceThicknessMap,Lt=E&&!!A.sheenColorMap,Gt=E&&!!A.sheenRoughnessMap,At=!!A.specularMap,Rt=!!A.specularColorMap,re=!!A.specularIntensityMap,fe=$&&!!A.transmissionMap,we=$&&!!A.thicknessMap,X=!!A.gradientMap,Ct=!!A.alphaMap,mt=A.alphaTest>0,zt=!!A.alphaHash,Dt=!!A.extensions;let bt=Yi;A.toneMapped&&(pt===null||pt.isXRRenderTarget===!0)&&(bt=r.toneMapping);const Kt={shaderID:I,shaderType:A.type,shaderName:A.name,vertexShader:Nt,fragmentShader:Tt,defines:A.defines,customVertexShaderID:J,customFragmentShaderID:Mt,isRawShaderMaterial:A.isRawShaderMaterial===!0,glslVersion:A.glslVersion,precision:g,batching:Zt,batchingColor:Zt&&Y._colorsTexture!==null,instancing:$t,instancingColor:$t&&Y.instanceColor!==null,instancingMorph:$t&&Y.morphTexture!==null,outputColorSpace:pt===null?r.outputColorSpace:pt.isXRRenderTarget===!0?pt.texture.colorSpace:Ce.workingColorSpace,alphaToCoverage:!!A.alphaToCoverage,map:Pe,matcap:le,envMap:Ne,envMapMode:Ne&&rt.mapping,envMapCubeUVHeight:gt,aoMap:jt,lightMap:te,bumpMap:ee,normalMap:me,displacementMap:Ve,emissiveMap:j,normalMapObjectSpace:me&&A.normalMapType===_y,normalMapTangentSpace:me&&A.normalMapType===Hd,packedNormalMap:me&&A.normalMapType===Hd&&$T(A.normalMap.format),metalnessMap:Ue,roughnessMap:ge,anisotropy:ke,anisotropyMap:ht,clearcoat:Pt,clearcoatMap:Et,clearcoatNormalMap:wt,clearcoatRoughnessMap:Ut,dispersion:tn,iridescence:L,iridescenceMap:ft,iridescenceThicknessMap:xt,sheen:E,sheenColorMap:Lt,sheenRoughnessMap:Gt,specularMap:At,specularColorMap:Rt,specularIntensityMap:re,transmission:$,transmissionMap:fe,thicknessMap:we,gradientMap:X,opaque:A.transparent===!1&&A.blending===zr&&A.alphaToCoverage===!1,alphaMap:Ct,alphaTest:mt,alphaHash:zt,combine:A.combine,mapUv:Pe&&b(A.map.channel),aoMapUv:jt&&b(A.aoMap.channel),lightMapUv:te&&b(A.lightMap.channel),bumpMapUv:ee&&b(A.bumpMap.channel),normalMapUv:me&&b(A.normalMap.channel),displacementMapUv:Ve&&b(A.displacementMap.channel),emissiveMapUv:j&&b(A.emissiveMap.channel),metalnessMapUv:Ue&&b(A.metalnessMap.channel),roughnessMapUv:ge&&b(A.roughnessMap.channel),anisotropyMapUv:ht&&b(A.anisotropyMap.channel),clearcoatMapUv:Et&&b(A.clearcoatMap.channel),clearcoatNormalMapUv:wt&&b(A.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ut&&b(A.clearcoatRoughnessMap.channel),iridescenceMapUv:ft&&b(A.iridescenceMap.channel),iridescenceThicknessMapUv:xt&&b(A.iridescenceThicknessMap.channel),sheenColorMapUv:Lt&&b(A.sheenColorMap.channel),sheenRoughnessMapUv:Gt&&b(A.sheenRoughnessMap.channel),specularMapUv:At&&b(A.specularMap.channel),specularColorMapUv:Rt&&b(A.specularColorMap.channel),specularIntensityMapUv:re&&b(A.specularIntensityMap.channel),transmissionMapUv:fe&&b(A.transmissionMap.channel),thicknessMapUv:we&&b(A.thicknessMap.channel),alphaMapUv:Ct&&b(A.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(me||ke),vertexNormals:!!W.attributes.normal,vertexColors:A.vertexColors,vertexAlphas:A.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:Y.isPoints===!0&&!!W.attributes.uv&&(Pe||Ct),fog:!!ut,useFog:A.fog===!0,fogExp2:!!ut&&ut.isFogExp2,flatShading:A.wireframe===!1&&(A.flatShading===!0||W.attributes.normal===void 0&&me===!1&&(A.isMeshLambertMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isMeshPhysicalMaterial)),sizeAttenuation:A.sizeAttenuation===!0,logarithmicDepthBuffer:x,reversedDepthBuffer:Ft,skinning:Y.isSkinnedMesh===!0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:dt,morphTextureStride:St,numDirLights:O.directional.length,numPointLights:O.point.length,numSpotLights:O.spot.length,numSpotLightMaps:O.spotLightMap.length,numRectAreaLights:O.rectArea.length,numHemiLights:O.hemi.length,numDirLightShadows:O.directionalShadowMap.length,numPointLightShadows:O.pointShadowMap.length,numSpotLightShadows:O.spotShadowMap.length,numSpotLightShadowsWithMaps:O.numSpotLightShadowsWithMaps,numLightProbes:O.numLightProbes,numLightProbeGrids:ct.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:A.dithering,shadowMapEnabled:r.shadowMap.enabled&&k.length>0,shadowMapType:r.shadowMap.type,toneMapping:bt,decodeVideoTexture:Pe&&A.map.isVideoTexture===!0&&Ce.getTransfer(A.map.colorSpace)===qe,decodeVideoTextureEmissive:j&&A.emissiveMap.isVideoTexture===!0&&Ce.getTransfer(A.emissiveMap.colorSpace)===qe,premultipliedAlpha:A.premultipliedAlpha,doubleSided:A.side===Ma,flipSided:A.side===$n,useDepthPacking:A.depthPacking>=0,depthPacking:A.depthPacking||0,index0AttributeName:A.index0AttributeName,extensionClipCullDistance:Dt&&A.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Dt&&A.extensions.multiDraw===!0||Zt)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:A.customProgramCacheKey()};return Kt.vertexUv1s=m.has(1),Kt.vertexUv2s=m.has(2),Kt.vertexUv3s=m.has(3),m.clear(),Kt}function S(A){const O=[];if(A.shaderID?O.push(A.shaderID):(O.push(A.customVertexShaderID),O.push(A.customFragmentShaderID)),A.defines!==void 0)for(const k in A.defines)O.push(k),O.push(A.defines[k]);return A.isRawShaderMaterial===!1&&(_(O,A),T(O,A),O.push(r.outputColorSpace)),O.push(A.customProgramCacheKey),O.join()}function _(A,O){A.push(O.precision),A.push(O.outputColorSpace),A.push(O.envMapMode),A.push(O.envMapCubeUVHeight),A.push(O.mapUv),A.push(O.alphaMapUv),A.push(O.lightMapUv),A.push(O.aoMapUv),A.push(O.bumpMapUv),A.push(O.normalMapUv),A.push(O.displacementMapUv),A.push(O.emissiveMapUv),A.push(O.metalnessMapUv),A.push(O.roughnessMapUv),A.push(O.anisotropyMapUv),A.push(O.clearcoatMapUv),A.push(O.clearcoatNormalMapUv),A.push(O.clearcoatRoughnessMapUv),A.push(O.iridescenceMapUv),A.push(O.iridescenceThicknessMapUv),A.push(O.sheenColorMapUv),A.push(O.sheenRoughnessMapUv),A.push(O.specularMapUv),A.push(O.specularColorMapUv),A.push(O.specularIntensityMapUv),A.push(O.transmissionMapUv),A.push(O.thicknessMapUv),A.push(O.combine),A.push(O.fogExp2),A.push(O.sizeAttenuation),A.push(O.morphTargetsCount),A.push(O.morphAttributeCount),A.push(O.numDirLights),A.push(O.numPointLights),A.push(O.numSpotLights),A.push(O.numSpotLightMaps),A.push(O.numHemiLights),A.push(O.numRectAreaLights),A.push(O.numDirLightShadows),A.push(O.numPointLightShadows),A.push(O.numSpotLightShadows),A.push(O.numSpotLightShadowsWithMaps),A.push(O.numLightProbes),A.push(O.shadowMapType),A.push(O.toneMapping),A.push(O.numClippingPlanes),A.push(O.numClipIntersection),A.push(O.depthPacking)}function T(A,O){f.disableAll(),O.instancing&&f.enable(0),O.instancingColor&&f.enable(1),O.instancingMorph&&f.enable(2),O.matcap&&f.enable(3),O.envMap&&f.enable(4),O.normalMapObjectSpace&&f.enable(5),O.normalMapTangentSpace&&f.enable(6),O.clearcoat&&f.enable(7),O.iridescence&&f.enable(8),O.alphaTest&&f.enable(9),O.vertexColors&&f.enable(10),O.vertexAlphas&&f.enable(11),O.vertexUv1s&&f.enable(12),O.vertexUv2s&&f.enable(13),O.vertexUv3s&&f.enable(14),O.vertexTangents&&f.enable(15),O.anisotropy&&f.enable(16),O.alphaHash&&f.enable(17),O.batching&&f.enable(18),O.dispersion&&f.enable(19),O.batchingColor&&f.enable(20),O.gradientMap&&f.enable(21),O.packedNormalMap&&f.enable(22),O.vertexNormals&&f.enable(23),A.push(f.mask),f.disableAll(),O.fog&&f.enable(0),O.useFog&&f.enable(1),O.flatShading&&f.enable(2),O.logarithmicDepthBuffer&&f.enable(3),O.reversedDepthBuffer&&f.enable(4),O.skinning&&f.enable(5),O.morphTargets&&f.enable(6),O.morphNormals&&f.enable(7),O.morphColors&&f.enable(8),O.premultipliedAlpha&&f.enable(9),O.shadowMapEnabled&&f.enable(10),O.doubleSided&&f.enable(11),O.flipSided&&f.enable(12),O.useDepthPacking&&f.enable(13),O.dithering&&f.enable(14),O.transmission&&f.enable(15),O.sheen&&f.enable(16),O.opaque&&f.enable(17),O.pointsUvs&&f.enable(18),O.decodeVideoTexture&&f.enable(19),O.decodeVideoTextureEmissive&&f.enable(20),O.alphaToCoverage&&f.enable(21),O.numLightProbeGrids>0&&f.enable(22),A.push(f.mask)}function D(A){const O=y[A.type];let k;if(O){const G=Wi[O];k=xM.clone(G.uniforms)}else k=A.uniforms;return k}function U(A,O){let k=v.get(O);return k!==void 0?++k.usedTimes:(k=new ZT(r,O,A,l),d.push(k),v.set(O,k)),k}function P(A){if(--A.usedTimes===0){const O=d.indexOf(A);d[O]=d[d.length-1],d.pop(),v.delete(A.cacheKey),A.destroy()}}function N(A){p.remove(A)}function z(){p.dispose()}return{getParameters:C,getProgramCacheKey:S,getUniforms:D,acquireProgram:U,releaseProgram:P,releaseShaderCache:N,programs:d,dispose:z}}function eA(){let r=new WeakMap;function t(f){return r.has(f)}function i(f){let p=r.get(f);return p===void 0&&(p={},r.set(f,p)),p}function a(f){r.delete(f)}function l(f,p,m){r.get(f)[p]=m}function c(){r=new WeakMap}return{has:t,get:i,remove:a,update:l,dispose:c}}function nA(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.material.id!==t.material.id?r.material.id-t.material.id:r.materialVariant!==t.materialVariant?r.materialVariant-t.materialVariant:r.z!==t.z?r.z-t.z:r.id-t.id}function Yv(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.z!==t.z?t.z-r.z:r.id-t.id}function Zv(){const r=[];let t=0;const i=[],a=[],l=[];function c(){t=0,i.length=0,a.length=0,l.length=0}function f(g){let y=0;return g.isInstancedMesh&&(y+=2),g.isSkinnedMesh&&(y+=1),y}function p(g,y,b,C,S,_){let T=r[t];return T===void 0?(T={id:g.id,object:g,geometry:y,material:b,materialVariant:f(g),groupOrder:C,renderOrder:g.renderOrder,z:S,group:_},r[t]=T):(T.id=g.id,T.object=g,T.geometry=y,T.material=b,T.materialVariant=f(g),T.groupOrder=C,T.renderOrder=g.renderOrder,T.z=S,T.group=_),t++,T}function m(g,y,b,C,S,_){const T=p(g,y,b,C,S,_);b.transmission>0?a.push(T):b.transparent===!0?l.push(T):i.push(T)}function d(g,y,b,C,S,_){const T=p(g,y,b,C,S,_);b.transmission>0?a.unshift(T):b.transparent===!0?l.unshift(T):i.unshift(T)}function v(g,y){i.length>1&&i.sort(g||nA),a.length>1&&a.sort(y||Yv),l.length>1&&l.sort(y||Yv)}function x(){for(let g=t,y=r.length;g<y;g++){const b=r[g];if(b.id===null)break;b.id=null,b.object=null,b.geometry=null,b.material=null,b.group=null}}return{opaque:i,transmissive:a,transparent:l,init:c,push:m,unshift:d,finish:x,sort:v}}function iA(){let r=new WeakMap;function t(a,l){const c=r.get(a);let f;return c===void 0?(f=new Zv,r.set(a,[f])):l>=c.length?(f=new Zv,c.push(f)):f=c[l],f}function i(){r=new WeakMap}return{get:t,dispose:i}}function aA(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let i;switch(t.type){case"DirectionalLight":i={direction:new K,color:new de};break;case"SpotLight":i={position:new K,direction:new K,color:new de,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":i={position:new K,color:new de,distance:0,decay:0};break;case"HemisphereLight":i={direction:new K,skyColor:new de,groundColor:new de};break;case"RectAreaLight":i={color:new de,position:new K,halfWidth:new K,halfHeight:new K};break}return r[t.id]=i,i}}}function sA(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let i;switch(t.type){case"DirectionalLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new De};break;case"SpotLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new De};break;case"PointLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new De,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[t.id]=i,i}}}let rA=0;function oA(r,t){return(t.castShadow?2:0)-(r.castShadow?2:0)+(t.map?1:0)-(r.map?1:0)}function lA(r){const t=new aA,i=sA(),a={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)a.probe.push(new K);const l=new K,c=new hn,f=new hn;function p(d){let v=0,x=0,g=0;for(let O=0;O<9;O++)a.probe[O].set(0,0,0);let y=0,b=0,C=0,S=0,_=0,T=0,D=0,U=0,P=0,N=0,z=0;d.sort(oA);for(let O=0,k=d.length;O<k;O++){const G=d[O],Y=G.color,ct=G.intensity,ut=G.distance;let W=null;if(G.shadow&&G.shadow.map&&(G.shadow.map.texture.format===Gs?W=G.shadow.map.texture:W=G.shadow.map.depthTexture||G.shadow.map.texture),G.isAmbientLight)v+=Y.r*ct,x+=Y.g*ct,g+=Y.b*ct;else if(G.isLightProbe){for(let F=0;F<9;F++)a.probe[F].addScaledVector(G.sh.coefficients[F],ct);z++}else if(G.isDirectionalLight){const F=t.get(G);if(F.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){const V=G.shadow,rt=i.get(G);rt.shadowIntensity=V.intensity,rt.shadowBias=V.bias,rt.shadowNormalBias=V.normalBias,rt.shadowRadius=V.radius,rt.shadowMapSize=V.mapSize,a.directionalShadow[y]=rt,a.directionalShadowMap[y]=W,a.directionalShadowMatrix[y]=G.shadow.matrix,T++}a.directional[y]=F,y++}else if(G.isSpotLight){const F=t.get(G);F.position.setFromMatrixPosition(G.matrixWorld),F.color.copy(Y).multiplyScalar(ct),F.distance=ut,F.coneCos=Math.cos(G.angle),F.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),F.decay=G.decay,a.spot[C]=F;const V=G.shadow;if(G.map&&(a.spotLightMap[P]=G.map,P++,V.updateMatrices(G),G.castShadow&&N++),a.spotLightMatrix[C]=V.matrix,G.castShadow){const rt=i.get(G);rt.shadowIntensity=V.intensity,rt.shadowBias=V.bias,rt.shadowNormalBias=V.normalBias,rt.shadowRadius=V.radius,rt.shadowMapSize=V.mapSize,a.spotShadow[C]=rt,a.spotShadowMap[C]=W,U++}C++}else if(G.isRectAreaLight){const F=t.get(G);F.color.copy(Y).multiplyScalar(ct),F.halfWidth.set(G.width*.5,0,0),F.halfHeight.set(0,G.height*.5,0),a.rectArea[S]=F,S++}else if(G.isPointLight){const F=t.get(G);if(F.color.copy(G.color).multiplyScalar(G.intensity),F.distance=G.distance,F.decay=G.decay,G.castShadow){const V=G.shadow,rt=i.get(G);rt.shadowIntensity=V.intensity,rt.shadowBias=V.bias,rt.shadowNormalBias=V.normalBias,rt.shadowRadius=V.radius,rt.shadowMapSize=V.mapSize,rt.shadowCameraNear=V.camera.near,rt.shadowCameraFar=V.camera.far,a.pointShadow[b]=rt,a.pointShadowMap[b]=W,a.pointShadowMatrix[b]=G.shadow.matrix,D++}a.point[b]=F,b++}else if(G.isHemisphereLight){const F=t.get(G);F.skyColor.copy(G.color).multiplyScalar(ct),F.groundColor.copy(G.groundColor).multiplyScalar(ct),a.hemi[_]=F,_++}}S>0&&(r.has("OES_texture_float_linear")===!0?(a.rectAreaLTC1=Bt.LTC_FLOAT_1,a.rectAreaLTC2=Bt.LTC_FLOAT_2):(a.rectAreaLTC1=Bt.LTC_HALF_1,a.rectAreaLTC2=Bt.LTC_HALF_2)),a.ambient[0]=v,a.ambient[1]=x,a.ambient[2]=g;const A=a.hash;(A.directionalLength!==y||A.pointLength!==b||A.spotLength!==C||A.rectAreaLength!==S||A.hemiLength!==_||A.numDirectionalShadows!==T||A.numPointShadows!==D||A.numSpotShadows!==U||A.numSpotMaps!==P||A.numLightProbes!==z)&&(a.directional.length=y,a.spot.length=C,a.rectArea.length=S,a.point.length=b,a.hemi.length=_,a.directionalShadow.length=T,a.directionalShadowMap.length=T,a.pointShadow.length=D,a.pointShadowMap.length=D,a.spotShadow.length=U,a.spotShadowMap.length=U,a.directionalShadowMatrix.length=T,a.pointShadowMatrix.length=D,a.spotLightMatrix.length=U+P-N,a.spotLightMap.length=P,a.numSpotLightShadowsWithMaps=N,a.numLightProbes=z,A.directionalLength=y,A.pointLength=b,A.spotLength=C,A.rectAreaLength=S,A.hemiLength=_,A.numDirectionalShadows=T,A.numPointShadows=D,A.numSpotShadows=U,A.numSpotMaps=P,A.numLightProbes=z,a.version=rA++)}function m(d,v){let x=0,g=0,y=0,b=0,C=0;const S=v.matrixWorldInverse;for(let _=0,T=d.length;_<T;_++){const D=d[_];if(D.isDirectionalLight){const U=a.directional[x];U.direction.setFromMatrixPosition(D.matrixWorld),l.setFromMatrixPosition(D.target.matrixWorld),U.direction.sub(l),U.direction.transformDirection(S),x++}else if(D.isSpotLight){const U=a.spot[y];U.position.setFromMatrixPosition(D.matrixWorld),U.position.applyMatrix4(S),U.direction.setFromMatrixPosition(D.matrixWorld),l.setFromMatrixPosition(D.target.matrixWorld),U.direction.sub(l),U.direction.transformDirection(S),y++}else if(D.isRectAreaLight){const U=a.rectArea[b];U.position.setFromMatrixPosition(D.matrixWorld),U.position.applyMatrix4(S),f.identity(),c.copy(D.matrixWorld),c.premultiply(S),f.extractRotation(c),U.halfWidth.set(D.width*.5,0,0),U.halfHeight.set(0,D.height*.5,0),U.halfWidth.applyMatrix4(f),U.halfHeight.applyMatrix4(f),b++}else if(D.isPointLight){const U=a.point[g];U.position.setFromMatrixPosition(D.matrixWorld),U.position.applyMatrix4(S),g++}else if(D.isHemisphereLight){const U=a.hemi[C];U.direction.setFromMatrixPosition(D.matrixWorld),U.direction.transformDirection(S),C++}}}return{setup:p,setupView:m,state:a}}function Kv(r){const t=new lA(r),i=[],a=[],l=[];function c(g){x.camera=g,i.length=0,a.length=0,l.length=0}function f(g){i.push(g)}function p(g){a.push(g)}function m(g){l.push(g)}function d(){t.setup(i)}function v(g){t.setupView(i,g)}const x={lightsArray:i,shadowsArray:a,lightProbeGridArray:l,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:x,setupLights:d,setupLightsView:v,pushLight:f,pushShadow:p,pushLightProbeGrid:m}}function cA(r){let t=new WeakMap;function i(l,c=0){const f=t.get(l);let p;return f===void 0?(p=new Kv(r),t.set(l,[p])):c>=f.length?(p=new Kv(r),f.push(p)):p=f[c],p}function a(){t=new WeakMap}return{get:i,dispose:a}}const uA=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,fA=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,hA=[new K(1,0,0),new K(-1,0,0),new K(0,1,0),new K(0,-1,0),new K(0,0,1),new K(0,0,-1)],dA=[new K(0,-1,0),new K(0,-1,0),new K(0,0,1),new K(0,0,-1),new K(0,-1,0),new K(0,-1,0)],Qv=new hn,Jo=new K,Kh=new K;function pA(r,t,i){let a=new sp;const l=new De,c=new De,f=new fn,p=new MM,m=new bM,d={},v=i.maxTextureSize,x={[cs]:$n,[$n]:cs,[Ma]:Ma},g=new Qi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new De},radius:{value:4}},vertexShader:uA,fragmentShader:fA}),y=g.clone();y.defines.HORIZONTAL_PASS=1;const b=new Yn;b.setAttribute("position",new Pi(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const C=new qt(b,g),S=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=qc;let _=this.type;this.render=function(N,z,A){if(S.enabled===!1||S.autoUpdate===!1&&S.needsUpdate===!1||N.length===0)return;this.type===KS&&(ae("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=qc);const O=r.getRenderTarget(),k=r.getActiveCubeFace(),G=r.getActiveMipmapLevel(),Y=r.state;Y.setBlending(Ta),Y.buffers.depth.getReversed()===!0?Y.buffers.color.setClear(0,0,0,0):Y.buffers.color.setClear(1,1,1,1),Y.buffers.depth.setTest(!0),Y.setScissorTest(!1);const ct=_!==this.type;ct&&z.traverse(function(ut){ut.material&&(Array.isArray(ut.material)?ut.material.forEach(W=>W.needsUpdate=!0):ut.material.needsUpdate=!0)});for(let ut=0,W=N.length;ut<W;ut++){const F=N[ut],V=F.shadow;if(V===void 0){ae("WebGLShadowMap:",F,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;l.copy(V.mapSize);const rt=V.getFrameExtents();l.multiply(rt),c.copy(V.mapSize),(l.x>v||l.y>v)&&(l.x>v&&(c.x=Math.floor(v/rt.x),l.x=c.x*rt.x,V.mapSize.x=c.x),l.y>v&&(c.y=Math.floor(v/rt.y),l.y=c.y*rt.y,V.mapSize.y=c.y));const gt=r.state.buffers.depth.getReversed();if(V.camera._reversedDepth=gt,V.map===null||ct===!0){if(V.map!==null&&(V.map.depthTexture!==null&&(V.map.depthTexture.dispose(),V.map.depthTexture=null),V.map.dispose()),this.type===el){if(F.isPointLight){ae("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}V.map=new Zi(l.x,l.y,{format:Gs,type:wa,minFilter:Gn,magFilter:Gn,generateMipmaps:!1}),V.map.texture.name=F.name+".shadowMap",V.map.depthTexture=new kr(l.x,l.y,qi),V.map.depthTexture.name=F.name+".shadowMapDepth",V.map.depthTexture.format=Ra,V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=On,V.map.depthTexture.magFilter=On}else F.isPointLight?(V.map=new Nx(l.x),V.map.depthTexture=new gM(l.x,Ki)):(V.map=new Zi(l.x,l.y),V.map.depthTexture=new kr(l.x,l.y,Ki)),V.map.depthTexture.name=F.name+".shadowMap",V.map.depthTexture.format=Ra,this.type===qc?(V.map.depthTexture.compareFunction=gt?np:ep,V.map.depthTexture.minFilter=Gn,V.map.depthTexture.magFilter=Gn):(V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=On,V.map.depthTexture.magFilter=On);V.camera.updateProjectionMatrix()}const I=V.map.isWebGLCubeRenderTarget?6:1;for(let tt=0;tt<I;tt++){if(V.map.isWebGLCubeRenderTarget)r.setRenderTarget(V.map,tt),r.clear();else{tt===0&&(r.setRenderTarget(V.map),r.clear());const dt=V.getViewport(tt);f.set(c.x*dt.x,c.y*dt.y,c.x*dt.z,c.y*dt.w),Y.viewport(f)}if(F.isPointLight){const dt=V.camera,St=V.matrix,Nt=F.distance||dt.far;Nt!==dt.far&&(dt.far=Nt,dt.updateProjectionMatrix()),Jo.setFromMatrixPosition(F.matrixWorld),dt.position.copy(Jo),Kh.copy(dt.position),Kh.add(hA[tt]),dt.up.copy(dA[tt]),dt.lookAt(Kh),dt.updateMatrixWorld(),St.makeTranslation(-Jo.x,-Jo.y,-Jo.z),Qv.multiplyMatrices(dt.projectionMatrix,dt.matrixWorldInverse),V._frustum.setFromProjectionMatrix(Qv,dt.coordinateSystem,dt.reversedDepth)}else V.updateMatrices(F);a=V.getFrustum(),U(z,A,V.camera,F,this.type)}V.isPointLightShadow!==!0&&this.type===el&&T(V,A),V.needsUpdate=!1}_=this.type,S.needsUpdate=!1,r.setRenderTarget(O,k,G)};function T(N,z){const A=t.update(C);g.defines.VSM_SAMPLES!==N.blurSamples&&(g.defines.VSM_SAMPLES=N.blurSamples,y.defines.VSM_SAMPLES=N.blurSamples,g.needsUpdate=!0,y.needsUpdate=!0),N.mapPass===null&&(N.mapPass=new Zi(l.x,l.y,{format:Gs,type:wa})),g.uniforms.shadow_pass.value=N.map.depthTexture,g.uniforms.resolution.value=N.mapSize,g.uniforms.radius.value=N.radius,r.setRenderTarget(N.mapPass),r.clear(),r.renderBufferDirect(z,null,A,g,C,null),y.uniforms.shadow_pass.value=N.mapPass.texture,y.uniforms.resolution.value=N.mapSize,y.uniforms.radius.value=N.radius,r.setRenderTarget(N.map),r.clear(),r.renderBufferDirect(z,null,A,y,C,null)}function D(N,z,A,O){let k=null;const G=A.isPointLight===!0?N.customDistanceMaterial:N.customDepthMaterial;if(G!==void 0)k=G;else if(k=A.isPointLight===!0?m:p,r.localClippingEnabled&&z.clipShadows===!0&&Array.isArray(z.clippingPlanes)&&z.clippingPlanes.length!==0||z.displacementMap&&z.displacementScale!==0||z.alphaMap&&z.alphaTest>0||z.map&&z.alphaTest>0||z.alphaToCoverage===!0){const Y=k.uuid,ct=z.uuid;let ut=d[Y];ut===void 0&&(ut={},d[Y]=ut);let W=ut[ct];W===void 0&&(W=k.clone(),ut[ct]=W,z.addEventListener("dispose",P)),k=W}if(k.visible=z.visible,k.wireframe=z.wireframe,O===el?k.side=z.shadowSide!==null?z.shadowSide:z.side:k.side=z.shadowSide!==null?z.shadowSide:x[z.side],k.alphaMap=z.alphaMap,k.alphaTest=z.alphaToCoverage===!0?.5:z.alphaTest,k.map=z.map,k.clipShadows=z.clipShadows,k.clippingPlanes=z.clippingPlanes,k.clipIntersection=z.clipIntersection,k.displacementMap=z.displacementMap,k.displacementScale=z.displacementScale,k.displacementBias=z.displacementBias,k.wireframeLinewidth=z.wireframeLinewidth,k.linewidth=z.linewidth,A.isPointLight===!0&&k.isMeshDistanceMaterial===!0){const Y=r.properties.get(k);Y.light=A}return k}function U(N,z,A,O,k){if(N.visible===!1)return;if(N.layers.test(z.layers)&&(N.isMesh||N.isLine||N.isPoints)&&(N.castShadow||N.receiveShadow&&k===el)&&(!N.frustumCulled||a.intersectsObject(N))){N.modelViewMatrix.multiplyMatrices(A.matrixWorldInverse,N.matrixWorld);const ct=t.update(N),ut=N.material;if(Array.isArray(ut)){const W=ct.groups;for(let F=0,V=W.length;F<V;F++){const rt=W[F],gt=ut[rt.materialIndex];if(gt&&gt.visible){const I=D(N,gt,O,k);N.onBeforeShadow(r,N,z,A,ct,I,rt),r.renderBufferDirect(A,null,ct,I,N,rt),N.onAfterShadow(r,N,z,A,ct,I,rt)}}}else if(ut.visible){const W=D(N,ut,O,k);N.onBeforeShadow(r,N,z,A,ct,W,null),r.renderBufferDirect(A,null,ct,W,N,null),N.onAfterShadow(r,N,z,A,ct,W,null)}}const Y=N.children;for(let ct=0,ut=Y.length;ct<ut;ct++)U(Y[ct],z,A,O,k)}function P(N){N.target.removeEventListener("dispose",P);for(const A in d){const O=d[A],k=N.target.uuid;k in O&&(O[k].dispose(),delete O[k])}}}function mA(r,t){function i(){let X=!1;const Ct=new fn;let mt=null;const zt=new fn(0,0,0,0);return{setMask:function(Dt){mt!==Dt&&!X&&(r.colorMask(Dt,Dt,Dt,Dt),mt=Dt)},setLocked:function(Dt){X=Dt},setClear:function(Dt,bt,Kt,he,Ge){Ge===!0&&(Dt*=he,bt*=he,Kt*=he),Ct.set(Dt,bt,Kt,he),zt.equals(Ct)===!1&&(r.clearColor(Dt,bt,Kt,he),zt.copy(Ct))},reset:function(){X=!1,mt=null,zt.set(-1,0,0,0)}}}function a(){let X=!1,Ct=!1,mt=null,zt=null,Dt=null;return{setReversed:function(bt){if(Ct!==bt){const Kt=t.get("EXT_clip_control");bt?Kt.clipControlEXT(Kt.LOWER_LEFT_EXT,Kt.ZERO_TO_ONE_EXT):Kt.clipControlEXT(Kt.LOWER_LEFT_EXT,Kt.NEGATIVE_ONE_TO_ONE_EXT),Ct=bt;const he=Dt;Dt=null,this.setClear(he)}},getReversed:function(){return Ct},setTest:function(bt){bt?pt(r.DEPTH_TEST):Ft(r.DEPTH_TEST)},setMask:function(bt){mt!==bt&&!X&&(r.depthMask(bt),mt=bt)},setFunc:function(bt){if(Ct&&(bt=Cy[bt]),zt!==bt){switch(bt){case nd:r.depthFunc(r.NEVER);break;case id:r.depthFunc(r.ALWAYS);break;case ad:r.depthFunc(r.LESS);break;case Hr:r.depthFunc(r.LEQUAL);break;case sd:r.depthFunc(r.EQUAL);break;case rd:r.depthFunc(r.GEQUAL);break;case od:r.depthFunc(r.GREATER);break;case ld:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}zt=bt}},setLocked:function(bt){X=bt},setClear:function(bt){Dt!==bt&&(Dt=bt,Ct&&(bt=1-bt),r.clearDepth(bt))},reset:function(){X=!1,mt=null,zt=null,Dt=null,Ct=!1}}}function l(){let X=!1,Ct=null,mt=null,zt=null,Dt=null,bt=null,Kt=null,he=null,Ge=null;return{setTest:function(ce){X||(ce?pt(r.STENCIL_TEST):Ft(r.STENCIL_TEST))},setMask:function(ce){Ct!==ce&&!X&&(r.stencilMask(ce),Ct=ce)},setFunc:function(ce,en,Dn){(mt!==ce||zt!==en||Dt!==Dn)&&(r.stencilFunc(ce,en,Dn),mt=ce,zt=en,Dt=Dn)},setOp:function(ce,en,Dn){(bt!==ce||Kt!==en||he!==Dn)&&(r.stencilOp(ce,en,Dn),bt=ce,Kt=en,he=Dn)},setLocked:function(ce){X=ce},setClear:function(ce){Ge!==ce&&(r.clearStencil(ce),Ge=ce)},reset:function(){X=!1,Ct=null,mt=null,zt=null,Dt=null,bt=null,Kt=null,he=null,Ge=null}}}const c=new i,f=new a,p=new l,m=new WeakMap,d=new WeakMap;let v={},x={},g={},y=new WeakMap,b=[],C=null,S=!1,_=null,T=null,D=null,U=null,P=null,N=null,z=null,A=new de(0,0,0),O=0,k=!1,G=null,Y=null,ct=null,ut=null,W=null;const F=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let V=!1,rt=0;const gt=r.getParameter(r.VERSION);gt.indexOf("WebGL")!==-1?(rt=parseFloat(/^WebGL (\d)/.exec(gt)[1]),V=rt>=1):gt.indexOf("OpenGL ES")!==-1&&(rt=parseFloat(/^OpenGL ES (\d)/.exec(gt)[1]),V=rt>=2);let I=null,tt={};const dt=r.getParameter(r.SCISSOR_BOX),St=r.getParameter(r.VIEWPORT),Nt=new fn().fromArray(dt),Tt=new fn().fromArray(St);function J(X,Ct,mt,zt){const Dt=new Uint8Array(4),bt=r.createTexture();r.bindTexture(X,bt),r.texParameteri(X,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(X,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let Kt=0;Kt<mt;Kt++)X===r.TEXTURE_3D||X===r.TEXTURE_2D_ARRAY?r.texImage3D(Ct,0,r.RGBA,1,1,zt,0,r.RGBA,r.UNSIGNED_BYTE,Dt):r.texImage2D(Ct+Kt,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,Dt);return bt}const Mt={};Mt[r.TEXTURE_2D]=J(r.TEXTURE_2D,r.TEXTURE_2D,1),Mt[r.TEXTURE_CUBE_MAP]=J(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),Mt[r.TEXTURE_2D_ARRAY]=J(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),Mt[r.TEXTURE_3D]=J(r.TEXTURE_3D,r.TEXTURE_3D,1,1),c.setClear(0,0,0,1),f.setClear(1),p.setClear(0),pt(r.DEPTH_TEST),f.setFunc(Hr),ee(!1),me(Kg),pt(r.CULL_FACE),jt(Ta);function pt(X){v[X]!==!0&&(r.enable(X),v[X]=!0)}function Ft(X){v[X]!==!1&&(r.disable(X),v[X]=!1)}function $t(X,Ct){return g[X]!==Ct?(r.bindFramebuffer(X,Ct),g[X]=Ct,X===r.DRAW_FRAMEBUFFER&&(g[r.FRAMEBUFFER]=Ct),X===r.FRAMEBUFFER&&(g[r.DRAW_FRAMEBUFFER]=Ct),!0):!1}function Zt(X,Ct){let mt=b,zt=!1;if(X){mt=y.get(Ct),mt===void 0&&(mt=[],y.set(Ct,mt));const Dt=X.textures;if(mt.length!==Dt.length||mt[0]!==r.COLOR_ATTACHMENT0){for(let bt=0,Kt=Dt.length;bt<Kt;bt++)mt[bt]=r.COLOR_ATTACHMENT0+bt;mt.length=Dt.length,zt=!0}}else mt[0]!==r.BACK&&(mt[0]=r.BACK,zt=!0);zt&&r.drawBuffers(mt)}function Pe(X){return C!==X?(r.useProgram(X),C=X,!0):!1}const le={[Ps]:r.FUNC_ADD,[JS]:r.FUNC_SUBTRACT,[$S]:r.FUNC_REVERSE_SUBTRACT};le[ty]=r.MIN,le[ey]=r.MAX;const Ne={[ny]:r.ZERO,[iy]:r.ONE,[ay]:r.SRC_COLOR,[td]:r.SRC_ALPHA,[uy]:r.SRC_ALPHA_SATURATE,[ly]:r.DST_COLOR,[ry]:r.DST_ALPHA,[sy]:r.ONE_MINUS_SRC_COLOR,[ed]:r.ONE_MINUS_SRC_ALPHA,[cy]:r.ONE_MINUS_DST_COLOR,[oy]:r.ONE_MINUS_DST_ALPHA,[fy]:r.CONSTANT_COLOR,[hy]:r.ONE_MINUS_CONSTANT_COLOR,[dy]:r.CONSTANT_ALPHA,[py]:r.ONE_MINUS_CONSTANT_ALPHA};function jt(X,Ct,mt,zt,Dt,bt,Kt,he,Ge,ce){if(X===Ta){S===!0&&(Ft(r.BLEND),S=!1);return}if(S===!1&&(pt(r.BLEND),S=!0),X!==QS){if(X!==_||ce!==k){if((T!==Ps||P!==Ps)&&(r.blendEquation(r.FUNC_ADD),T=Ps,P=Ps),ce)switch(X){case zr:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Qg:r.blendFunc(r.ONE,r.ONE);break;case Jg:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case $g:r.blendFuncSeparate(r.DST_COLOR,r.ONE_MINUS_SRC_ALPHA,r.ZERO,r.ONE);break;default:Oe("WebGLState: Invalid blending: ",X);break}else switch(X){case zr:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Qg:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE,r.ONE,r.ONE);break;case Jg:Oe("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case $g:Oe("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Oe("WebGLState: Invalid blending: ",X);break}D=null,U=null,N=null,z=null,A.set(0,0,0),O=0,_=X,k=ce}return}Dt=Dt||Ct,bt=bt||mt,Kt=Kt||zt,(Ct!==T||Dt!==P)&&(r.blendEquationSeparate(le[Ct],le[Dt]),T=Ct,P=Dt),(mt!==D||zt!==U||bt!==N||Kt!==z)&&(r.blendFuncSeparate(Ne[mt],Ne[zt],Ne[bt],Ne[Kt]),D=mt,U=zt,N=bt,z=Kt),(he.equals(A)===!1||Ge!==O)&&(r.blendColor(he.r,he.g,he.b,Ge),A.copy(he),O=Ge),_=X,k=!1}function te(X,Ct){X.side===Ma?Ft(r.CULL_FACE):pt(r.CULL_FACE);let mt=X.side===$n;Ct&&(mt=!mt),ee(mt),X.blending===zr&&X.transparent===!1?jt(Ta):jt(X.blending,X.blendEquation,X.blendSrc,X.blendDst,X.blendEquationAlpha,X.blendSrcAlpha,X.blendDstAlpha,X.blendColor,X.blendAlpha,X.premultipliedAlpha),f.setFunc(X.depthFunc),f.setTest(X.depthTest),f.setMask(X.depthWrite),c.setMask(X.colorWrite);const zt=X.stencilWrite;p.setTest(zt),zt&&(p.setMask(X.stencilWriteMask),p.setFunc(X.stencilFunc,X.stencilRef,X.stencilFuncMask),p.setOp(X.stencilFail,X.stencilZFail,X.stencilZPass)),j(X.polygonOffset,X.polygonOffsetFactor,X.polygonOffsetUnits),X.alphaToCoverage===!0?pt(r.SAMPLE_ALPHA_TO_COVERAGE):Ft(r.SAMPLE_ALPHA_TO_COVERAGE)}function ee(X){G!==X&&(X?r.frontFace(r.CW):r.frontFace(r.CCW),G=X)}function me(X){X!==YS?(pt(r.CULL_FACE),X!==Y&&(X===Kg?r.cullFace(r.BACK):X===ZS?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):Ft(r.CULL_FACE),Y=X}function Ve(X){X!==ct&&(V&&r.lineWidth(X),ct=X)}function j(X,Ct,mt){X?(pt(r.POLYGON_OFFSET_FILL),(ut!==Ct||W!==mt)&&(ut=Ct,W=mt,f.getReversed()&&(Ct=-Ct),r.polygonOffset(Ct,mt))):Ft(r.POLYGON_OFFSET_FILL)}function Ue(X){X?pt(r.SCISSOR_TEST):Ft(r.SCISSOR_TEST)}function ge(X){X===void 0&&(X=r.TEXTURE0+F-1),I!==X&&(r.activeTexture(X),I=X)}function ke(X,Ct,mt){mt===void 0&&(I===null?mt=r.TEXTURE0+F-1:mt=I);let zt=tt[mt];zt===void 0&&(zt={type:void 0,texture:void 0},tt[mt]=zt),(zt.type!==X||zt.texture!==Ct)&&(I!==mt&&(r.activeTexture(mt),I=mt),r.bindTexture(X,Ct||Mt[X]),zt.type=X,zt.texture=Ct)}function Pt(){const X=tt[I];X!==void 0&&X.type!==void 0&&(r.bindTexture(X.type,null),X.type=void 0,X.texture=void 0)}function tn(){try{r.compressedTexImage2D(...arguments)}catch(X){Oe("WebGLState:",X)}}function L(){try{r.compressedTexImage3D(...arguments)}catch(X){Oe("WebGLState:",X)}}function E(){try{r.texSubImage2D(...arguments)}catch(X){Oe("WebGLState:",X)}}function $(){try{r.texSubImage3D(...arguments)}catch(X){Oe("WebGLState:",X)}}function ht(){try{r.compressedTexSubImage2D(...arguments)}catch(X){Oe("WebGLState:",X)}}function Et(){try{r.compressedTexSubImage3D(...arguments)}catch(X){Oe("WebGLState:",X)}}function wt(){try{r.texStorage2D(...arguments)}catch(X){Oe("WebGLState:",X)}}function Ut(){try{r.texStorage3D(...arguments)}catch(X){Oe("WebGLState:",X)}}function ft(){try{r.texImage2D(...arguments)}catch(X){Oe("WebGLState:",X)}}function xt(){try{r.texImage3D(...arguments)}catch(X){Oe("WebGLState:",X)}}function Lt(X){return x[X]!==void 0?x[X]:r.getParameter(X)}function Gt(X,Ct){x[X]!==Ct&&(r.pixelStorei(X,Ct),x[X]=Ct)}function At(X){Nt.equals(X)===!1&&(r.scissor(X.x,X.y,X.z,X.w),Nt.copy(X))}function Rt(X){Tt.equals(X)===!1&&(r.viewport(X.x,X.y,X.z,X.w),Tt.copy(X))}function re(X,Ct){let mt=d.get(Ct);mt===void 0&&(mt=new WeakMap,d.set(Ct,mt));let zt=mt.get(X);zt===void 0&&(zt=r.getUniformBlockIndex(Ct,X.name),mt.set(X,zt))}function fe(X,Ct){const zt=d.get(Ct).get(X);m.get(Ct)!==zt&&(r.uniformBlockBinding(Ct,zt,X.__bindingPointIndex),m.set(Ct,zt))}function we(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),f.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),r.pixelStorei(r.PACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,!1),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,r.BROWSER_DEFAULT_WEBGL),r.pixelStorei(r.PACK_ROW_LENGTH,0),r.pixelStorei(r.PACK_SKIP_PIXELS,0),r.pixelStorei(r.PACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_ROW_LENGTH,0),r.pixelStorei(r.UNPACK_IMAGE_HEIGHT,0),r.pixelStorei(r.UNPACK_SKIP_PIXELS,0),r.pixelStorei(r.UNPACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_SKIP_IMAGES,0),v={},x={},I=null,tt={},g={},y=new WeakMap,b=[],C=null,S=!1,_=null,T=null,D=null,U=null,P=null,N=null,z=null,A=new de(0,0,0),O=0,k=!1,G=null,Y=null,ct=null,ut=null,W=null,Nt.set(0,0,r.canvas.width,r.canvas.height),Tt.set(0,0,r.canvas.width,r.canvas.height),c.reset(),f.reset(),p.reset()}return{buffers:{color:c,depth:f,stencil:p},enable:pt,disable:Ft,bindFramebuffer:$t,drawBuffers:Zt,useProgram:Pe,setBlending:jt,setMaterial:te,setFlipSided:ee,setCullFace:me,setLineWidth:Ve,setPolygonOffset:j,setScissorTest:Ue,activeTexture:ge,bindTexture:ke,unbindTexture:Pt,compressedTexImage2D:tn,compressedTexImage3D:L,texImage2D:ft,texImage3D:xt,pixelStorei:Gt,getParameter:Lt,updateUBOMapping:re,uniformBlockBinding:fe,texStorage2D:wt,texStorage3D:Ut,texSubImage2D:E,texSubImage3D:$,compressedTexSubImage2D:ht,compressedTexSubImage3D:Et,scissor:At,viewport:Rt,reset:we}}function gA(r,t,i,a,l,c,f){const p=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new De,v=new WeakMap,x=new Set;let g;const y=new WeakMap;let b=!1;try{b=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function C(L,E){return b?new OffscreenCanvas(L,E):nu("canvas")}function S(L,E,$){let ht=1;const Et=tn(L);if((Et.width>$||Et.height>$)&&(ht=$/Math.max(Et.width,Et.height)),ht<1)if(typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&L instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&L instanceof ImageBitmap||typeof VideoFrame<"u"&&L instanceof VideoFrame){const wt=Math.floor(ht*Et.width),Ut=Math.floor(ht*Et.height);g===void 0&&(g=C(wt,Ut));const ft=E?C(wt,Ut):g;return ft.width=wt,ft.height=Ut,ft.getContext("2d").drawImage(L,0,0,wt,Ut),ae("WebGLRenderer: Texture has been resized from ("+Et.width+"x"+Et.height+") to ("+wt+"x"+Ut+")."),ft}else return"data"in L&&ae("WebGLRenderer: Image in DataTexture is too big ("+Et.width+"x"+Et.height+")."),L;return L}function _(L){return L.generateMipmaps}function T(L){r.generateMipmap(L)}function D(L){return L.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:L.isWebGL3DRenderTarget?r.TEXTURE_3D:L.isWebGLArrayRenderTarget||L.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function U(L,E,$,ht,Et,wt=!1){if(L!==null){if(r[L]!==void 0)return r[L];ae("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+L+"'")}let Ut;ht&&(Ut=t.get("EXT_texture_norm16"),Ut||ae("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let ft=E;if(E===r.RED&&($===r.FLOAT&&(ft=r.R32F),$===r.HALF_FLOAT&&(ft=r.R16F),$===r.UNSIGNED_BYTE&&(ft=r.R8),$===r.UNSIGNED_SHORT&&Ut&&(ft=Ut.R16_EXT),$===r.SHORT&&Ut&&(ft=Ut.R16_SNORM_EXT)),E===r.RED_INTEGER&&($===r.UNSIGNED_BYTE&&(ft=r.R8UI),$===r.UNSIGNED_SHORT&&(ft=r.R16UI),$===r.UNSIGNED_INT&&(ft=r.R32UI),$===r.BYTE&&(ft=r.R8I),$===r.SHORT&&(ft=r.R16I),$===r.INT&&(ft=r.R32I)),E===r.RG&&($===r.FLOAT&&(ft=r.RG32F),$===r.HALF_FLOAT&&(ft=r.RG16F),$===r.UNSIGNED_BYTE&&(ft=r.RG8),$===r.UNSIGNED_SHORT&&Ut&&(ft=Ut.RG16_EXT),$===r.SHORT&&Ut&&(ft=Ut.RG16_SNORM_EXT)),E===r.RG_INTEGER&&($===r.UNSIGNED_BYTE&&(ft=r.RG8UI),$===r.UNSIGNED_SHORT&&(ft=r.RG16UI),$===r.UNSIGNED_INT&&(ft=r.RG32UI),$===r.BYTE&&(ft=r.RG8I),$===r.SHORT&&(ft=r.RG16I),$===r.INT&&(ft=r.RG32I)),E===r.RGB_INTEGER&&($===r.UNSIGNED_BYTE&&(ft=r.RGB8UI),$===r.UNSIGNED_SHORT&&(ft=r.RGB16UI),$===r.UNSIGNED_INT&&(ft=r.RGB32UI),$===r.BYTE&&(ft=r.RGB8I),$===r.SHORT&&(ft=r.RGB16I),$===r.INT&&(ft=r.RGB32I)),E===r.RGBA_INTEGER&&($===r.UNSIGNED_BYTE&&(ft=r.RGBA8UI),$===r.UNSIGNED_SHORT&&(ft=r.RGBA16UI),$===r.UNSIGNED_INT&&(ft=r.RGBA32UI),$===r.BYTE&&(ft=r.RGBA8I),$===r.SHORT&&(ft=r.RGBA16I),$===r.INT&&(ft=r.RGBA32I)),E===r.RGB&&($===r.UNSIGNED_SHORT&&Ut&&(ft=Ut.RGB16_EXT),$===r.SHORT&&Ut&&(ft=Ut.RGB16_SNORM_EXT),$===r.UNSIGNED_INT_5_9_9_9_REV&&(ft=r.RGB9_E5),$===r.UNSIGNED_INT_10F_11F_11F_REV&&(ft=r.R11F_G11F_B10F)),E===r.RGBA){const xt=wt?eu:Ce.getTransfer(Et);$===r.FLOAT&&(ft=r.RGBA32F),$===r.HALF_FLOAT&&(ft=r.RGBA16F),$===r.UNSIGNED_BYTE&&(ft=xt===qe?r.SRGB8_ALPHA8:r.RGBA8),$===r.UNSIGNED_SHORT&&Ut&&(ft=Ut.RGBA16_EXT),$===r.SHORT&&Ut&&(ft=Ut.RGBA16_SNORM_EXT),$===r.UNSIGNED_SHORT_4_4_4_4&&(ft=r.RGBA4),$===r.UNSIGNED_SHORT_5_5_5_1&&(ft=r.RGB5_A1)}return(ft===r.R16F||ft===r.R32F||ft===r.RG16F||ft===r.RG32F||ft===r.RGBA16F||ft===r.RGBA32F)&&t.get("EXT_color_buffer_float"),ft}function P(L,E){let $;return L?E===null||E===Ki||E===ol?$=r.DEPTH24_STENCIL8:E===qi?$=r.DEPTH32F_STENCIL8:E===rl&&($=r.DEPTH24_STENCIL8,ae("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===Ki||E===ol?$=r.DEPTH_COMPONENT24:E===qi?$=r.DEPTH_COMPONENT32F:E===rl&&($=r.DEPTH_COMPONENT16),$}function N(L,E){return _(L)===!0||L.isFramebufferTexture&&L.minFilter!==On&&L.minFilter!==Gn?Math.log2(Math.max(E.width,E.height))+1:L.mipmaps!==void 0&&L.mipmaps.length>0?L.mipmaps.length:L.isCompressedTexture&&Array.isArray(L.image)?E.mipmaps.length:1}function z(L){const E=L.target;E.removeEventListener("dispose",z),O(E),E.isVideoTexture&&v.delete(E),E.isHTMLTexture&&x.delete(E)}function A(L){const E=L.target;E.removeEventListener("dispose",A),G(E)}function O(L){const E=a.get(L);if(E.__webglInit===void 0)return;const $=L.source,ht=y.get($);if(ht){const Et=ht[E.__cacheKey];Et.usedTimes--,Et.usedTimes===0&&k(L),Object.keys(ht).length===0&&y.delete($)}a.remove(L)}function k(L){const E=a.get(L);r.deleteTexture(E.__webglTexture);const $=L.source,ht=y.get($);delete ht[E.__cacheKey],f.memory.textures--}function G(L){const E=a.get(L);if(L.depthTexture&&(L.depthTexture.dispose(),a.remove(L.depthTexture)),L.isWebGLCubeRenderTarget)for(let ht=0;ht<6;ht++){if(Array.isArray(E.__webglFramebuffer[ht]))for(let Et=0;Et<E.__webglFramebuffer[ht].length;Et++)r.deleteFramebuffer(E.__webglFramebuffer[ht][Et]);else r.deleteFramebuffer(E.__webglFramebuffer[ht]);E.__webglDepthbuffer&&r.deleteRenderbuffer(E.__webglDepthbuffer[ht])}else{if(Array.isArray(E.__webglFramebuffer))for(let ht=0;ht<E.__webglFramebuffer.length;ht++)r.deleteFramebuffer(E.__webglFramebuffer[ht]);else r.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&r.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&r.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let ht=0;ht<E.__webglColorRenderbuffer.length;ht++)E.__webglColorRenderbuffer[ht]&&r.deleteRenderbuffer(E.__webglColorRenderbuffer[ht]);E.__webglDepthRenderbuffer&&r.deleteRenderbuffer(E.__webglDepthRenderbuffer)}const $=L.textures;for(let ht=0,Et=$.length;ht<Et;ht++){const wt=a.get($[ht]);wt.__webglTexture&&(r.deleteTexture(wt.__webglTexture),f.memory.textures--),a.remove($[ht])}a.remove(L)}let Y=0;function ct(){Y=0}function ut(){return Y}function W(L){Y=L}function F(){const L=Y;return L>=l.maxTextures&&ae("WebGLTextures: Trying to use "+L+" texture units while this GPU supports only "+l.maxTextures),Y+=1,L}function V(L){const E=[];return E.push(L.wrapS),E.push(L.wrapT),E.push(L.wrapR||0),E.push(L.magFilter),E.push(L.minFilter),E.push(L.anisotropy),E.push(L.internalFormat),E.push(L.format),E.push(L.type),E.push(L.generateMipmaps),E.push(L.premultiplyAlpha),E.push(L.flipY),E.push(L.unpackAlignment),E.push(L.colorSpace),E.join()}function rt(L,E){const $=a.get(L);if(L.isVideoTexture&&ke(L),L.isRenderTargetTexture===!1&&L.isExternalTexture!==!0&&L.version>0&&$.__version!==L.version){const ht=L.image;if(ht===null)ae("WebGLRenderer: Texture marked for update but no image data found.");else if(ht.complete===!1)ae("WebGLRenderer: Texture marked for update but image is incomplete");else{Ft($,L,E);return}}else L.isExternalTexture&&($.__webglTexture=L.sourceTexture?L.sourceTexture:null);i.bindTexture(r.TEXTURE_2D,$.__webglTexture,r.TEXTURE0+E)}function gt(L,E){const $=a.get(L);if(L.isRenderTargetTexture===!1&&L.version>0&&$.__version!==L.version){Ft($,L,E);return}else L.isExternalTexture&&($.__webglTexture=L.sourceTexture?L.sourceTexture:null);i.bindTexture(r.TEXTURE_2D_ARRAY,$.__webglTexture,r.TEXTURE0+E)}function I(L,E){const $=a.get(L);if(L.isRenderTargetTexture===!1&&L.version>0&&$.__version!==L.version){Ft($,L,E);return}i.bindTexture(r.TEXTURE_3D,$.__webglTexture,r.TEXTURE0+E)}function tt(L,E){const $=a.get(L);if(L.isCubeDepthTexture!==!0&&L.version>0&&$.__version!==L.version){$t($,L,E);return}i.bindTexture(r.TEXTURE_CUBE_MAP,$.__webglTexture,r.TEXTURE0+E)}const dt={[cd]:r.REPEAT,[ba]:r.CLAMP_TO_EDGE,[ud]:r.MIRRORED_REPEAT},St={[On]:r.NEAREST,[vy]:r.NEAREST_MIPMAP_NEAREST,[_c]:r.NEAREST_MIPMAP_LINEAR,[Gn]:r.LINEAR,[yh]:r.LINEAR_MIPMAP_NEAREST,[Is]:r.LINEAR_MIPMAP_LINEAR},Nt={[Sy]:r.NEVER,[Ty]:r.ALWAYS,[yy]:r.LESS,[ep]:r.LEQUAL,[My]:r.EQUAL,[np]:r.GEQUAL,[by]:r.GREATER,[Ey]:r.NOTEQUAL};function Tt(L,E){if(E.type===qi&&t.has("OES_texture_float_linear")===!1&&(E.magFilter===Gn||E.magFilter===yh||E.magFilter===_c||E.magFilter===Is||E.minFilter===Gn||E.minFilter===yh||E.minFilter===_c||E.minFilter===Is)&&ae("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(L,r.TEXTURE_WRAP_S,dt[E.wrapS]),r.texParameteri(L,r.TEXTURE_WRAP_T,dt[E.wrapT]),(L===r.TEXTURE_3D||L===r.TEXTURE_2D_ARRAY)&&r.texParameteri(L,r.TEXTURE_WRAP_R,dt[E.wrapR]),r.texParameteri(L,r.TEXTURE_MAG_FILTER,St[E.magFilter]),r.texParameteri(L,r.TEXTURE_MIN_FILTER,St[E.minFilter]),E.compareFunction&&(r.texParameteri(L,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(L,r.TEXTURE_COMPARE_FUNC,Nt[E.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===On||E.minFilter!==_c&&E.minFilter!==Is||E.type===qi&&t.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||a.get(E).__currentAnisotropy){const $=t.get("EXT_texture_filter_anisotropic");r.texParameterf(L,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,l.getMaxAnisotropy())),a.get(E).__currentAnisotropy=E.anisotropy}}}function J(L,E){let $=!1;L.__webglInit===void 0&&(L.__webglInit=!0,E.addEventListener("dispose",z));const ht=E.source;let Et=y.get(ht);Et===void 0&&(Et={},y.set(ht,Et));const wt=V(E);if(wt!==L.__cacheKey){Et[wt]===void 0&&(Et[wt]={texture:r.createTexture(),usedTimes:0},f.memory.textures++,$=!0),Et[wt].usedTimes++;const Ut=Et[L.__cacheKey];Ut!==void 0&&(Et[L.__cacheKey].usedTimes--,Ut.usedTimes===0&&k(E)),L.__cacheKey=wt,L.__webglTexture=Et[wt].texture}return $}function Mt(L,E,$){return Math.floor(Math.floor(L/$)/E)}function pt(L,E,$,ht){const wt=L.updateRanges;if(wt.length===0)i.texSubImage2D(r.TEXTURE_2D,0,0,0,E.width,E.height,$,ht,E.data);else{wt.sort((Gt,At)=>Gt.start-At.start);let Ut=0;for(let Gt=1;Gt<wt.length;Gt++){const At=wt[Ut],Rt=wt[Gt],re=At.start+At.count,fe=Mt(Rt.start,E.width,4),we=Mt(At.start,E.width,4);Rt.start<=re+1&&fe===we&&Mt(Rt.start+Rt.count-1,E.width,4)===fe?At.count=Math.max(At.count,Rt.start+Rt.count-At.start):(++Ut,wt[Ut]=Rt)}wt.length=Ut+1;const ft=i.getParameter(r.UNPACK_ROW_LENGTH),xt=i.getParameter(r.UNPACK_SKIP_PIXELS),Lt=i.getParameter(r.UNPACK_SKIP_ROWS);i.pixelStorei(r.UNPACK_ROW_LENGTH,E.width);for(let Gt=0,At=wt.length;Gt<At;Gt++){const Rt=wt[Gt],re=Math.floor(Rt.start/4),fe=Math.ceil(Rt.count/4),we=re%E.width,X=Math.floor(re/E.width),Ct=fe,mt=1;i.pixelStorei(r.UNPACK_SKIP_PIXELS,we),i.pixelStorei(r.UNPACK_SKIP_ROWS,X),i.texSubImage2D(r.TEXTURE_2D,0,we,X,Ct,mt,$,ht,E.data)}L.clearUpdateRanges(),i.pixelStorei(r.UNPACK_ROW_LENGTH,ft),i.pixelStorei(r.UNPACK_SKIP_PIXELS,xt),i.pixelStorei(r.UNPACK_SKIP_ROWS,Lt)}}function Ft(L,E,$){let ht=r.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(ht=r.TEXTURE_2D_ARRAY),E.isData3DTexture&&(ht=r.TEXTURE_3D);const Et=J(L,E),wt=E.source;i.bindTexture(ht,L.__webglTexture,r.TEXTURE0+$);const Ut=a.get(wt);if(wt.version!==Ut.__version||Et===!0){if(i.activeTexture(r.TEXTURE0+$),(typeof ImageBitmap<"u"&&E.image instanceof ImageBitmap)===!1){const mt=Ce.getPrimaries(Ce.workingColorSpace),zt=E.colorSpace===rs?null:Ce.getPrimaries(E.colorSpace),Dt=E.colorSpace===rs||mt===zt?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,Dt)}i.pixelStorei(r.UNPACK_ALIGNMENT,E.unpackAlignment);let xt=S(E.image,!1,l.maxTextureSize);xt=Pt(E,xt);const Lt=c.convert(E.format,E.colorSpace),Gt=c.convert(E.type);let At=U(E.internalFormat,Lt,Gt,E.normalized,E.colorSpace,E.isVideoTexture);Tt(ht,E);let Rt;const re=E.mipmaps,fe=E.isVideoTexture!==!0,we=Ut.__version===void 0||Et===!0,X=wt.dataReady,Ct=N(E,xt);if(E.isDepthTexture)At=P(E.format===Bs,E.type),we&&(fe?i.texStorage2D(r.TEXTURE_2D,1,At,xt.width,xt.height):i.texImage2D(r.TEXTURE_2D,0,At,xt.width,xt.height,0,Lt,Gt,null));else if(E.isDataTexture)if(re.length>0){fe&&we&&i.texStorage2D(r.TEXTURE_2D,Ct,At,re[0].width,re[0].height);for(let mt=0,zt=re.length;mt<zt;mt++)Rt=re[mt],fe?X&&i.texSubImage2D(r.TEXTURE_2D,mt,0,0,Rt.width,Rt.height,Lt,Gt,Rt.data):i.texImage2D(r.TEXTURE_2D,mt,At,Rt.width,Rt.height,0,Lt,Gt,Rt.data);E.generateMipmaps=!1}else fe?(we&&i.texStorage2D(r.TEXTURE_2D,Ct,At,xt.width,xt.height),X&&pt(E,xt,Lt,Gt)):i.texImage2D(r.TEXTURE_2D,0,At,xt.width,xt.height,0,Lt,Gt,xt.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){fe&&we&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Ct,At,re[0].width,re[0].height,xt.depth);for(let mt=0,zt=re.length;mt<zt;mt++)if(Rt=re[mt],E.format!==Li)if(Lt!==null)if(fe){if(X)if(E.layerUpdates.size>0){const Dt=Rv(Rt.width,Rt.height,E.format,E.type);for(const bt of E.layerUpdates){const Kt=Rt.data.subarray(bt*Dt/Rt.data.BYTES_PER_ELEMENT,(bt+1)*Dt/Rt.data.BYTES_PER_ELEMENT);i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,mt,0,0,bt,Rt.width,Rt.height,1,Lt,Kt)}E.clearLayerUpdates()}else i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,mt,0,0,0,Rt.width,Rt.height,xt.depth,Lt,Rt.data)}else i.compressedTexImage3D(r.TEXTURE_2D_ARRAY,mt,At,Rt.width,Rt.height,xt.depth,0,Rt.data,0,0);else ae("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else fe?X&&i.texSubImage3D(r.TEXTURE_2D_ARRAY,mt,0,0,0,Rt.width,Rt.height,xt.depth,Lt,Gt,Rt.data):i.texImage3D(r.TEXTURE_2D_ARRAY,mt,At,Rt.width,Rt.height,xt.depth,0,Lt,Gt,Rt.data)}else{fe&&we&&i.texStorage2D(r.TEXTURE_2D,Ct,At,re[0].width,re[0].height);for(let mt=0,zt=re.length;mt<zt;mt++)Rt=re[mt],E.format!==Li?Lt!==null?fe?X&&i.compressedTexSubImage2D(r.TEXTURE_2D,mt,0,0,Rt.width,Rt.height,Lt,Rt.data):i.compressedTexImage2D(r.TEXTURE_2D,mt,At,Rt.width,Rt.height,0,Rt.data):ae("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):fe?X&&i.texSubImage2D(r.TEXTURE_2D,mt,0,0,Rt.width,Rt.height,Lt,Gt,Rt.data):i.texImage2D(r.TEXTURE_2D,mt,At,Rt.width,Rt.height,0,Lt,Gt,Rt.data)}else if(E.isDataArrayTexture)if(fe){if(we&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Ct,At,xt.width,xt.height,xt.depth),X)if(E.layerUpdates.size>0){const mt=Rv(xt.width,xt.height,E.format,E.type);for(const zt of E.layerUpdates){const Dt=xt.data.subarray(zt*mt/xt.data.BYTES_PER_ELEMENT,(zt+1)*mt/xt.data.BYTES_PER_ELEMENT);i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,zt,xt.width,xt.height,1,Lt,Gt,Dt)}E.clearLayerUpdates()}else i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,xt.width,xt.height,xt.depth,Lt,Gt,xt.data)}else i.texImage3D(r.TEXTURE_2D_ARRAY,0,At,xt.width,xt.height,xt.depth,0,Lt,Gt,xt.data);else if(E.isData3DTexture)fe?(we&&i.texStorage3D(r.TEXTURE_3D,Ct,At,xt.width,xt.height,xt.depth),X&&i.texSubImage3D(r.TEXTURE_3D,0,0,0,0,xt.width,xt.height,xt.depth,Lt,Gt,xt.data)):i.texImage3D(r.TEXTURE_3D,0,At,xt.width,xt.height,xt.depth,0,Lt,Gt,xt.data);else if(E.isFramebufferTexture){if(we)if(fe)i.texStorage2D(r.TEXTURE_2D,Ct,At,xt.width,xt.height);else{let mt=xt.width,zt=xt.height;for(let Dt=0;Dt<Ct;Dt++)i.texImage2D(r.TEXTURE_2D,Dt,At,mt,zt,0,Lt,Gt,null),mt>>=1,zt>>=1}}else if(E.isHTMLTexture){if("texElementImage2D"in r){const mt=r.canvas;if(mt.hasAttribute("layoutsubtree")||mt.setAttribute("layoutsubtree","true"),xt.parentNode!==mt){mt.appendChild(xt),x.add(E),mt.onpaint=he=>{const Ge=he.changedElements;for(const ce of x)Ge.includes(ce.image)&&(ce.needsUpdate=!0)},mt.requestPaint();return}const zt=0,Dt=r.RGBA,bt=r.RGBA,Kt=r.UNSIGNED_BYTE;r.texElementImage2D(r.TEXTURE_2D,zt,Dt,bt,Kt,xt),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)}}else if(re.length>0){if(fe&&we){const mt=tn(re[0]);i.texStorage2D(r.TEXTURE_2D,Ct,At,mt.width,mt.height)}for(let mt=0,zt=re.length;mt<zt;mt++)Rt=re[mt],fe?X&&i.texSubImage2D(r.TEXTURE_2D,mt,0,0,Lt,Gt,Rt):i.texImage2D(r.TEXTURE_2D,mt,At,Lt,Gt,Rt);E.generateMipmaps=!1}else if(fe){if(we){const mt=tn(xt);i.texStorage2D(r.TEXTURE_2D,Ct,At,mt.width,mt.height)}X&&i.texSubImage2D(r.TEXTURE_2D,0,0,0,Lt,Gt,xt)}else i.texImage2D(r.TEXTURE_2D,0,At,Lt,Gt,xt);_(E)&&T(ht),Ut.__version=wt.version,E.onUpdate&&E.onUpdate(E)}L.__version=E.version}function $t(L,E,$){if(E.image.length!==6)return;const ht=J(L,E),Et=E.source;i.bindTexture(r.TEXTURE_CUBE_MAP,L.__webglTexture,r.TEXTURE0+$);const wt=a.get(Et);if(Et.version!==wt.__version||ht===!0){i.activeTexture(r.TEXTURE0+$);const Ut=Ce.getPrimaries(Ce.workingColorSpace),ft=E.colorSpace===rs?null:Ce.getPrimaries(E.colorSpace),xt=E.colorSpace===rs||Ut===ft?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(r.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,xt);const Lt=E.isCompressedTexture||E.image[0].isCompressedTexture,Gt=E.image[0]&&E.image[0].isDataTexture,At=[];for(let bt=0;bt<6;bt++)!Lt&&!Gt?At[bt]=S(E.image[bt],!0,l.maxCubemapSize):At[bt]=Gt?E.image[bt].image:E.image[bt],At[bt]=Pt(E,At[bt]);const Rt=At[0],re=c.convert(E.format,E.colorSpace),fe=c.convert(E.type),we=U(E.internalFormat,re,fe,E.normalized,E.colorSpace),X=E.isVideoTexture!==!0,Ct=wt.__version===void 0||ht===!0,mt=Et.dataReady;let zt=N(E,Rt);Tt(r.TEXTURE_CUBE_MAP,E);let Dt;if(Lt){X&&Ct&&i.texStorage2D(r.TEXTURE_CUBE_MAP,zt,we,Rt.width,Rt.height);for(let bt=0;bt<6;bt++){Dt=At[bt].mipmaps;for(let Kt=0;Kt<Dt.length;Kt++){const he=Dt[Kt];E.format!==Li?re!==null?X?mt&&i.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt,0,0,he.width,he.height,re,he.data):i.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt,we,he.width,he.height,0,he.data):ae("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):X?mt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt,0,0,he.width,he.height,re,fe,he.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt,we,he.width,he.height,0,re,fe,he.data)}}}else{if(Dt=E.mipmaps,X&&Ct){Dt.length>0&&zt++;const bt=tn(At[0]);i.texStorage2D(r.TEXTURE_CUBE_MAP,zt,we,bt.width,bt.height)}for(let bt=0;bt<6;bt++)if(Gt){X?mt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,0,0,0,At[bt].width,At[bt].height,re,fe,At[bt].data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,0,we,At[bt].width,At[bt].height,0,re,fe,At[bt].data);for(let Kt=0;Kt<Dt.length;Kt++){const Ge=Dt[Kt].image[bt].image;X?mt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt+1,0,0,Ge.width,Ge.height,re,fe,Ge.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt+1,we,Ge.width,Ge.height,0,re,fe,Ge.data)}}else{X?mt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,0,0,0,re,fe,At[bt]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,0,we,re,fe,At[bt]);for(let Kt=0;Kt<Dt.length;Kt++){const he=Dt[Kt];X?mt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt+1,0,0,re,fe,he.image[bt]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+bt,Kt+1,we,re,fe,he.image[bt])}}}_(E)&&T(r.TEXTURE_CUBE_MAP),wt.__version=Et.version,E.onUpdate&&E.onUpdate(E)}L.__version=E.version}function Zt(L,E,$,ht,Et,wt){const Ut=c.convert($.format,$.colorSpace),ft=c.convert($.type),xt=U($.internalFormat,Ut,ft,$.normalized,$.colorSpace),Lt=a.get(E),Gt=a.get($);if(Gt.__renderTarget=E,!Lt.__hasExternalTextures){const At=Math.max(1,E.width>>wt),Rt=Math.max(1,E.height>>wt);Et===r.TEXTURE_3D||Et===r.TEXTURE_2D_ARRAY?i.texImage3D(Et,wt,xt,At,Rt,E.depth,0,Ut,ft,null):i.texImage2D(Et,wt,xt,At,Rt,0,Ut,ft,null)}i.bindFramebuffer(r.FRAMEBUFFER,L),ge(E)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,ht,Et,Gt.__webglTexture,0,Ue(E)):(Et===r.TEXTURE_2D||Et>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&Et<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,ht,Et,Gt.__webglTexture,wt),i.bindFramebuffer(r.FRAMEBUFFER,null)}function Pe(L,E,$){if(r.bindRenderbuffer(r.RENDERBUFFER,L),E.depthBuffer){const ht=E.depthTexture,Et=ht&&ht.isDepthTexture?ht.type:null,wt=P(E.stencilBuffer,Et),Ut=E.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;ge(E)?p.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Ue(E),wt,E.width,E.height):$?r.renderbufferStorageMultisample(r.RENDERBUFFER,Ue(E),wt,E.width,E.height):r.renderbufferStorage(r.RENDERBUFFER,wt,E.width,E.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Ut,r.RENDERBUFFER,L)}else{const ht=E.textures;for(let Et=0;Et<ht.length;Et++){const wt=ht[Et],Ut=c.convert(wt.format,wt.colorSpace),ft=c.convert(wt.type),xt=U(wt.internalFormat,Ut,ft,wt.normalized,wt.colorSpace);ge(E)?p.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Ue(E),xt,E.width,E.height):$?r.renderbufferStorageMultisample(r.RENDERBUFFER,Ue(E),xt,E.width,E.height):r.renderbufferStorage(r.RENDERBUFFER,xt,E.width,E.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function le(L,E,$){const ht=E.isWebGLCubeRenderTarget===!0;if(i.bindFramebuffer(r.FRAMEBUFFER,L),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Et=a.get(E.depthTexture);if(Et.__renderTarget=E,(!Et.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),ht){if(Et.__webglInit===void 0&&(Et.__webglInit=!0,E.depthTexture.addEventListener("dispose",z)),Et.__webglTexture===void 0){Et.__webglTexture=r.createTexture(),i.bindTexture(r.TEXTURE_CUBE_MAP,Et.__webglTexture),Tt(r.TEXTURE_CUBE_MAP,E.depthTexture);const Lt=c.convert(E.depthTexture.format),Gt=c.convert(E.depthTexture.type);let At;E.depthTexture.format===Ra?At=r.DEPTH_COMPONENT24:E.depthTexture.format===Bs&&(At=r.DEPTH24_STENCIL8);for(let Rt=0;Rt<6;Rt++)r.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Rt,0,At,E.width,E.height,0,Lt,Gt,null)}}else rt(E.depthTexture,0);const wt=Et.__webglTexture,Ut=Ue(E),ft=ht?r.TEXTURE_CUBE_MAP_POSITIVE_X+$:r.TEXTURE_2D,xt=E.depthTexture.format===Bs?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;if(E.depthTexture.format===Ra)ge(E)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,xt,ft,wt,0,Ut):r.framebufferTexture2D(r.FRAMEBUFFER,xt,ft,wt,0);else if(E.depthTexture.format===Bs)ge(E)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,xt,ft,wt,0,Ut):r.framebufferTexture2D(r.FRAMEBUFFER,xt,ft,wt,0);else throw new Error("Unknown depthTexture format")}function Ne(L){const E=a.get(L),$=L.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==L.depthTexture){const ht=L.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),ht){const Et=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,ht.removeEventListener("dispose",Et)};ht.addEventListener("dispose",Et),E.__depthDisposeCallback=Et}E.__boundDepthTexture=ht}if(L.depthTexture&&!E.__autoAllocateDepthBuffer)if($)for(let ht=0;ht<6;ht++)le(E.__webglFramebuffer[ht],L,ht);else{const ht=L.texture.mipmaps;ht&&ht.length>0?le(E.__webglFramebuffer[0],L,0):le(E.__webglFramebuffer,L,0)}else if($){E.__webglDepthbuffer=[];for(let ht=0;ht<6;ht++)if(i.bindFramebuffer(r.FRAMEBUFFER,E.__webglFramebuffer[ht]),E.__webglDepthbuffer[ht]===void 0)E.__webglDepthbuffer[ht]=r.createRenderbuffer(),Pe(E.__webglDepthbuffer[ht],L,!1);else{const Et=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,wt=E.__webglDepthbuffer[ht];r.bindRenderbuffer(r.RENDERBUFFER,wt),r.framebufferRenderbuffer(r.FRAMEBUFFER,Et,r.RENDERBUFFER,wt)}}else{const ht=L.texture.mipmaps;if(ht&&ht.length>0?i.bindFramebuffer(r.FRAMEBUFFER,E.__webglFramebuffer[0]):i.bindFramebuffer(r.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=r.createRenderbuffer(),Pe(E.__webglDepthbuffer,L,!1);else{const Et=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,wt=E.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,wt),r.framebufferRenderbuffer(r.FRAMEBUFFER,Et,r.RENDERBUFFER,wt)}}i.bindFramebuffer(r.FRAMEBUFFER,null)}function jt(L,E,$){const ht=a.get(L);E!==void 0&&Zt(ht.__webglFramebuffer,L,L.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),$!==void 0&&Ne(L)}function te(L){const E=L.texture,$=a.get(L),ht=a.get(E);L.addEventListener("dispose",A);const Et=L.textures,wt=L.isWebGLCubeRenderTarget===!0,Ut=Et.length>1;if(Ut||(ht.__webglTexture===void 0&&(ht.__webglTexture=r.createTexture()),ht.__version=E.version,f.memory.textures++),wt){$.__webglFramebuffer=[];for(let ft=0;ft<6;ft++)if(E.mipmaps&&E.mipmaps.length>0){$.__webglFramebuffer[ft]=[];for(let xt=0;xt<E.mipmaps.length;xt++)$.__webglFramebuffer[ft][xt]=r.createFramebuffer()}else $.__webglFramebuffer[ft]=r.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){$.__webglFramebuffer=[];for(let ft=0;ft<E.mipmaps.length;ft++)$.__webglFramebuffer[ft]=r.createFramebuffer()}else $.__webglFramebuffer=r.createFramebuffer();if(Ut)for(let ft=0,xt=Et.length;ft<xt;ft++){const Lt=a.get(Et[ft]);Lt.__webglTexture===void 0&&(Lt.__webglTexture=r.createTexture(),f.memory.textures++)}if(L.samples>0&&ge(L)===!1){$.__webglMultisampledFramebuffer=r.createFramebuffer(),$.__webglColorRenderbuffer=[],i.bindFramebuffer(r.FRAMEBUFFER,$.__webglMultisampledFramebuffer);for(let ft=0;ft<Et.length;ft++){const xt=Et[ft];$.__webglColorRenderbuffer[ft]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,$.__webglColorRenderbuffer[ft]);const Lt=c.convert(xt.format,xt.colorSpace),Gt=c.convert(xt.type),At=U(xt.internalFormat,Lt,Gt,xt.normalized,xt.colorSpace,L.isXRRenderTarget===!0),Rt=Ue(L);r.renderbufferStorageMultisample(r.RENDERBUFFER,Rt,At,L.width,L.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ft,r.RENDERBUFFER,$.__webglColorRenderbuffer[ft])}r.bindRenderbuffer(r.RENDERBUFFER,null),L.depthBuffer&&($.__webglDepthRenderbuffer=r.createRenderbuffer(),Pe($.__webglDepthRenderbuffer,L,!0)),i.bindFramebuffer(r.FRAMEBUFFER,null)}}if(wt){i.bindTexture(r.TEXTURE_CUBE_MAP,ht.__webglTexture),Tt(r.TEXTURE_CUBE_MAP,E);for(let ft=0;ft<6;ft++)if(E.mipmaps&&E.mipmaps.length>0)for(let xt=0;xt<E.mipmaps.length;xt++)Zt($.__webglFramebuffer[ft][xt],L,E,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ft,xt);else Zt($.__webglFramebuffer[ft],L,E,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0);_(E)&&T(r.TEXTURE_CUBE_MAP),i.unbindTexture()}else if(Ut){for(let ft=0,xt=Et.length;ft<xt;ft++){const Lt=Et[ft],Gt=a.get(Lt);let At=r.TEXTURE_2D;(L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(At=L.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(At,Gt.__webglTexture),Tt(At,Lt),Zt($.__webglFramebuffer,L,Lt,r.COLOR_ATTACHMENT0+ft,At,0),_(Lt)&&T(At)}i.unbindTexture()}else{let ft=r.TEXTURE_2D;if((L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(ft=L.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(ft,ht.__webglTexture),Tt(ft,E),E.mipmaps&&E.mipmaps.length>0)for(let xt=0;xt<E.mipmaps.length;xt++)Zt($.__webglFramebuffer[xt],L,E,r.COLOR_ATTACHMENT0,ft,xt);else Zt($.__webglFramebuffer,L,E,r.COLOR_ATTACHMENT0,ft,0);_(E)&&T(ft),i.unbindTexture()}L.depthBuffer&&Ne(L)}function ee(L){const E=L.textures;for(let $=0,ht=E.length;$<ht;$++){const Et=E[$];if(_(Et)){const wt=D(L),Ut=a.get(Et).__webglTexture;i.bindTexture(wt,Ut),T(wt),i.unbindTexture()}}}const me=[],Ve=[];function j(L){if(L.samples>0){if(ge(L)===!1){const E=L.textures,$=L.width,ht=L.height;let Et=r.COLOR_BUFFER_BIT;const wt=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Ut=a.get(L),ft=E.length>1;if(ft)for(let Lt=0;Lt<E.length;Lt++)i.bindFramebuffer(r.FRAMEBUFFER,Ut.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.RENDERBUFFER,null),i.bindFramebuffer(r.FRAMEBUFFER,Ut.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.TEXTURE_2D,null,0);i.bindFramebuffer(r.READ_FRAMEBUFFER,Ut.__webglMultisampledFramebuffer);const xt=L.texture.mipmaps;xt&&xt.length>0?i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ut.__webglFramebuffer[0]):i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ut.__webglFramebuffer);for(let Lt=0;Lt<E.length;Lt++){if(L.resolveDepthBuffer&&(L.depthBuffer&&(Et|=r.DEPTH_BUFFER_BIT),L.stencilBuffer&&L.resolveStencilBuffer&&(Et|=r.STENCIL_BUFFER_BIT)),ft){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Ut.__webglColorRenderbuffer[Lt]);const Gt=a.get(E[Lt]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,Gt,0)}r.blitFramebuffer(0,0,$,ht,0,0,$,ht,Et,r.NEAREST),m===!0&&(me.length=0,Ve.length=0,me.push(r.COLOR_ATTACHMENT0+Lt),L.depthBuffer&&L.resolveDepthBuffer===!1&&(me.push(wt),Ve.push(wt),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,Ve)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,me))}if(i.bindFramebuffer(r.READ_FRAMEBUFFER,null),i.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),ft)for(let Lt=0;Lt<E.length;Lt++){i.bindFramebuffer(r.FRAMEBUFFER,Ut.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.RENDERBUFFER,Ut.__webglColorRenderbuffer[Lt]);const Gt=a.get(E[Lt]).__webglTexture;i.bindFramebuffer(r.FRAMEBUFFER,Ut.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.TEXTURE_2D,Gt,0)}i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ut.__webglMultisampledFramebuffer)}else if(L.depthBuffer&&L.resolveDepthBuffer===!1&&m){const E=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[E])}}}function Ue(L){return Math.min(l.maxSamples,L.samples)}function ge(L){const E=a.get(L);return L.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function ke(L){const E=f.render.frame;v.get(L)!==E&&(v.set(L,E),L.update())}function Pt(L,E){const $=L.colorSpace,ht=L.format,Et=L.type;return L.isCompressedTexture===!0||L.isVideoTexture===!0||$!==tu&&$!==rs&&(Ce.getTransfer($)===qe?(ht!==Li||Et!==hi)&&ae("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Oe("WebGLTextures: Unsupported texture color space:",$)),E}function tn(L){return typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement?(d.width=L.naturalWidth||L.width,d.height=L.naturalHeight||L.height):typeof VideoFrame<"u"&&L instanceof VideoFrame?(d.width=L.displayWidth,d.height=L.displayHeight):(d.width=L.width,d.height=L.height),d}this.allocateTextureUnit=F,this.resetTextureUnits=ct,this.getTextureUnits=ut,this.setTextureUnits=W,this.setTexture2D=rt,this.setTexture2DArray=gt,this.setTexture3D=I,this.setTextureCube=tt,this.rebindTextures=jt,this.setupRenderTarget=te,this.updateRenderTargetMipmap=ee,this.updateMultisampleRenderTarget=j,this.setupDepthRenderbuffer=Ne,this.setupFrameBufferTexture=Zt,this.useMultisampledRTT=ge,this.isReversedDepthBuffer=function(){return i.buffers.depth.getReversed()}}function vA(r,t){function i(a,l=rs){let c;const f=Ce.getTransfer(l);if(a===hi)return r.UNSIGNED_BYTE;if(a===Kd)return r.UNSIGNED_SHORT_4_4_4_4;if(a===Qd)return r.UNSIGNED_SHORT_5_5_5_1;if(a===hx)return r.UNSIGNED_INT_5_9_9_9_REV;if(a===dx)return r.UNSIGNED_INT_10F_11F_11F_REV;if(a===ux)return r.BYTE;if(a===fx)return r.SHORT;if(a===rl)return r.UNSIGNED_SHORT;if(a===Zd)return r.INT;if(a===Ki)return r.UNSIGNED_INT;if(a===qi)return r.FLOAT;if(a===wa)return r.HALF_FLOAT;if(a===px)return r.ALPHA;if(a===mx)return r.RGB;if(a===Li)return r.RGBA;if(a===Ra)return r.DEPTH_COMPONENT;if(a===Bs)return r.DEPTH_STENCIL;if(a===gx)return r.RED;if(a===Jd)return r.RED_INTEGER;if(a===Gs)return r.RG;if(a===$d)return r.RG_INTEGER;if(a===tp)return r.RGBA_INTEGER;if(a===jc||a===Yc||a===Zc||a===Kc)if(f===qe)if(c=t.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(a===jc)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(a===Yc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(a===Zc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(a===Kc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=t.get("WEBGL_compressed_texture_s3tc"),c!==null){if(a===jc)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(a===Yc)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(a===Zc)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(a===Kc)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(a===fd||a===hd||a===dd||a===pd)if(c=t.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(a===fd)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(a===hd)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(a===dd)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(a===pd)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(a===md||a===gd||a===vd||a===xd||a===_d||a===Jc||a===Sd)if(c=t.get("WEBGL_compressed_texture_etc"),c!==null){if(a===md||a===gd)return f===qe?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(a===vd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(a===xd)return c.COMPRESSED_R11_EAC;if(a===_d)return c.COMPRESSED_SIGNED_R11_EAC;if(a===Jc)return c.COMPRESSED_RG11_EAC;if(a===Sd)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(a===yd||a===Md||a===bd||a===Ed||a===Td||a===Ad||a===wd||a===Rd||a===Cd||a===Dd||a===Nd||a===Ud||a===Ld||a===Pd)if(c=t.get("WEBGL_compressed_texture_astc"),c!==null){if(a===yd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(a===Md)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(a===bd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(a===Ed)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(a===Td)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(a===Ad)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(a===wd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(a===Rd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(a===Cd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(a===Dd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(a===Nd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(a===Ud)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(a===Ld)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(a===Pd)return f===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(a===Od||a===Id||a===Bd)if(c=t.get("EXT_texture_compression_bptc"),c!==null){if(a===Od)return f===qe?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(a===Id)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(a===Bd)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(a===Fd||a===zd||a===$c||a===Gd)if(c=t.get("EXT_texture_compression_rgtc"),c!==null){if(a===Fd)return c.COMPRESSED_RED_RGTC1_EXT;if(a===zd)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(a===$c)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(a===Gd)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return a===ol?r.UNSIGNED_INT_24_8:r[a]!==void 0?r[a]:null}return{convert:i}}const xA=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,_A=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class SA{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,i){if(this.texture===null){const a=new Ax(t.texture);(t.depthNear!==i.depthNear||t.depthFar!==i.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=a}}getMesh(t){if(this.texture!==null&&this.mesh===null){const i=t.cameras[0].viewport,a=new Qi({vertexShader:xA,fragmentShader:_A,uniforms:{depthColor:{value:this.texture},depthWidth:{value:i.z},depthHeight:{value:i.w}}});this.mesh=new qt(new Ea(20,20),a)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class yA extends Hs{constructor(t,i){super();const a=this;let l=null,c=1,f=null,p="local-floor",m=1,d=null,v=null,x=null,g=null,y=null,b=null;const C=typeof XRWebGLBinding<"u",S=new SA,_={},T=i.getContextAttributes();let D=null,U=null;const P=[],N=[],z=new De;let A=null;const O=new Mi;O.viewport=new fn;const k=new Mi;k.viewport=new fn;const G=[O,k],Y=new DM;let ct=null,ut=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let Mt=P[J];return Mt===void 0&&(Mt=new wh,P[J]=Mt),Mt.getTargetRaySpace()},this.getControllerGrip=function(J){let Mt=P[J];return Mt===void 0&&(Mt=new wh,P[J]=Mt),Mt.getGripSpace()},this.getHand=function(J){let Mt=P[J];return Mt===void 0&&(Mt=new wh,P[J]=Mt),Mt.getHandSpace()};function W(J){const Mt=N.indexOf(J.inputSource);if(Mt===-1)return;const pt=P[Mt];pt!==void 0&&(pt.update(J.inputSource,J.frame,d||f),pt.dispatchEvent({type:J.type,data:J.inputSource}))}function F(){l.removeEventListener("select",W),l.removeEventListener("selectstart",W),l.removeEventListener("selectend",W),l.removeEventListener("squeeze",W),l.removeEventListener("squeezestart",W),l.removeEventListener("squeezeend",W),l.removeEventListener("end",F),l.removeEventListener("inputsourceschange",V);for(let J=0;J<P.length;J++){const Mt=N[J];Mt!==null&&(N[J]=null,P[J].disconnect(Mt))}ct=null,ut=null,S.reset();for(const J in _)delete _[J];t.setRenderTarget(D),y=null,g=null,x=null,l=null,U=null,Tt.stop(),a.isPresenting=!1,t.setPixelRatio(A),t.setSize(z.width,z.height,!1),a.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){c=J,a.isPresenting===!0&&ae("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){p=J,a.isPresenting===!0&&ae("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return d||f},this.setReferenceSpace=function(J){d=J},this.getBaseLayer=function(){return g!==null?g:y},this.getBinding=function(){return x===null&&C&&(x=new XRWebGLBinding(l,i)),x},this.getFrame=function(){return b},this.getSession=function(){return l},this.setSession=async function(J){if(l=J,l!==null){if(D=t.getRenderTarget(),l.addEventListener("select",W),l.addEventListener("selectstart",W),l.addEventListener("selectend",W),l.addEventListener("squeeze",W),l.addEventListener("squeezestart",W),l.addEventListener("squeezeend",W),l.addEventListener("end",F),l.addEventListener("inputsourceschange",V),T.xrCompatible!==!0&&await i.makeXRCompatible(),A=t.getPixelRatio(),t.getSize(z),C&&"createProjectionLayer"in XRWebGLBinding.prototype){let pt=null,Ft=null,$t=null;T.depth&&($t=T.stencil?i.DEPTH24_STENCIL8:i.DEPTH_COMPONENT24,pt=T.stencil?Bs:Ra,Ft=T.stencil?ol:Ki);const Zt={colorFormat:i.RGBA8,depthFormat:$t,scaleFactor:c};x=this.getBinding(),g=x.createProjectionLayer(Zt),l.updateRenderState({layers:[g]}),t.setPixelRatio(1),t.setSize(g.textureWidth,g.textureHeight,!1),U=new Zi(g.textureWidth,g.textureHeight,{format:Li,type:hi,depthTexture:new kr(g.textureWidth,g.textureHeight,Ft,void 0,void 0,void 0,void 0,void 0,void 0,pt),stencilBuffer:T.stencil,colorSpace:t.outputColorSpace,samples:T.antialias?4:0,resolveDepthBuffer:g.ignoreDepthValues===!1,resolveStencilBuffer:g.ignoreDepthValues===!1})}else{const pt={antialias:T.antialias,alpha:!0,depth:T.depth,stencil:T.stencil,framebufferScaleFactor:c};y=new XRWebGLLayer(l,i,pt),l.updateRenderState({baseLayer:y}),t.setPixelRatio(1),t.setSize(y.framebufferWidth,y.framebufferHeight,!1),U=new Zi(y.framebufferWidth,y.framebufferHeight,{format:Li,type:hi,colorSpace:t.outputColorSpace,stencilBuffer:T.stencil,resolveDepthBuffer:y.ignoreDepthValues===!1,resolveStencilBuffer:y.ignoreDepthValues===!1})}U.isXRRenderTarget=!0,this.setFoveation(m),d=null,f=await l.requestReferenceSpace(p),Tt.setContext(l),Tt.start(),a.isPresenting=!0,a.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return S.getDepthTexture()};function V(J){for(let Mt=0;Mt<J.removed.length;Mt++){const pt=J.removed[Mt],Ft=N.indexOf(pt);Ft>=0&&(N[Ft]=null,P[Ft].disconnect(pt))}for(let Mt=0;Mt<J.added.length;Mt++){const pt=J.added[Mt];let Ft=N.indexOf(pt);if(Ft===-1){for(let Zt=0;Zt<P.length;Zt++)if(Zt>=N.length){N.push(pt),Ft=Zt;break}else if(N[Zt]===null){N[Zt]=pt,Ft=Zt;break}if(Ft===-1)break}const $t=P[Ft];$t&&$t.connect(pt)}}const rt=new K,gt=new K;function I(J,Mt,pt){rt.setFromMatrixPosition(Mt.matrixWorld),gt.setFromMatrixPosition(pt.matrixWorld);const Ft=rt.distanceTo(gt),$t=Mt.projectionMatrix.elements,Zt=pt.projectionMatrix.elements,Pe=$t[14]/($t[10]-1),le=$t[14]/($t[10]+1),Ne=($t[9]+1)/$t[5],jt=($t[9]-1)/$t[5],te=($t[8]-1)/$t[0],ee=(Zt[8]+1)/Zt[0],me=Pe*te,Ve=Pe*ee,j=Ft/(-te+ee),Ue=j*-te;if(Mt.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(Ue),J.translateZ(j),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert(),$t[10]===-1)J.projectionMatrix.copy(Mt.projectionMatrix),J.projectionMatrixInverse.copy(Mt.projectionMatrixInverse);else{const ge=Pe+j,ke=le+j,Pt=me-Ue,tn=Ve+(Ft-Ue),L=Ne*le/ke*ge,E=jt*le/ke*ge;J.projectionMatrix.makePerspective(Pt,tn,L,E,ge,ke),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}}function tt(J,Mt){Mt===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(Mt.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(l===null)return;let Mt=J.near,pt=J.far;S.texture!==null&&(S.depthNear>0&&(Mt=S.depthNear),S.depthFar>0&&(pt=S.depthFar)),Y.near=k.near=O.near=Mt,Y.far=k.far=O.far=pt,(ct!==Y.near||ut!==Y.far)&&(l.updateRenderState({depthNear:Y.near,depthFar:Y.far}),ct=Y.near,ut=Y.far),Y.layers.mask=J.layers.mask|6,O.layers.mask=Y.layers.mask&-5,k.layers.mask=Y.layers.mask&-3;const Ft=J.parent,$t=Y.cameras;tt(Y,Ft);for(let Zt=0;Zt<$t.length;Zt++)tt($t[Zt],Ft);$t.length===2?I(Y,O,k):Y.projectionMatrix.copy(O.projectionMatrix),dt(J,Y,Ft)};function dt(J,Mt,pt){pt===null?J.matrix.copy(Mt.matrixWorld):(J.matrix.copy(pt.matrixWorld),J.matrix.invert(),J.matrix.multiply(Mt.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(Mt.projectionMatrix),J.projectionMatrixInverse.copy(Mt.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=cl*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return Y},this.getFoveation=function(){if(!(g===null&&y===null))return m},this.setFoveation=function(J){m=J,g!==null&&(g.fixedFoveation=J),y!==null&&y.fixedFoveation!==void 0&&(y.fixedFoveation=J)},this.hasDepthSensing=function(){return S.texture!==null},this.getDepthSensingMesh=function(){return S.getMesh(Y)},this.getCameraTexture=function(J){return _[J]};let St=null;function Nt(J,Mt){if(v=Mt.getViewerPose(d||f),b=Mt,v!==null){const pt=v.views;y!==null&&(t.setRenderTargetFramebuffer(U,y.framebuffer),t.setRenderTarget(U));let Ft=!1;pt.length!==Y.cameras.length&&(Y.cameras.length=0,Ft=!0);for(let le=0;le<pt.length;le++){const Ne=pt[le];let jt=null;if(y!==null)jt=y.getViewport(Ne);else{const ee=x.getViewSubImage(g,Ne);jt=ee.viewport,le===0&&(t.setRenderTargetTextures(U,ee.colorTexture,ee.depthStencilTexture),t.setRenderTarget(U))}let te=G[le];te===void 0&&(te=new Mi,te.layers.enable(le),te.viewport=new fn,G[le]=te),te.matrix.fromArray(Ne.transform.matrix),te.matrix.decompose(te.position,te.quaternion,te.scale),te.projectionMatrix.fromArray(Ne.projectionMatrix),te.projectionMatrixInverse.copy(te.projectionMatrix).invert(),te.viewport.set(jt.x,jt.y,jt.width,jt.height),le===0&&(Y.matrix.copy(te.matrix),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale)),Ft===!0&&Y.cameras.push(te)}const $t=l.enabledFeatures;if($t&&$t.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&C){x=a.getBinding();const le=x.getDepthInformation(pt[0]);le&&le.isValid&&le.texture&&S.init(le,l.renderState)}if($t&&$t.includes("camera-access")&&C){t.state.unbindTexture(),x=a.getBinding();for(let le=0;le<pt.length;le++){const Ne=pt[le].camera;if(Ne){let jt=_[Ne];jt||(jt=new Ax,_[Ne]=jt);const te=x.getCameraImage(Ne);jt.sourceTexture=te}}}}for(let pt=0;pt<P.length;pt++){const Ft=N[pt],$t=P[pt];Ft!==null&&$t!==void 0&&$t.update(Ft,Mt,d||f)}St&&St(J,Mt),Mt.detectedPlanes&&a.dispatchEvent({type:"planesdetected",data:Mt}),b=null}const Tt=new Cx;Tt.setAnimationLoop(Nt),this.setAnimationLoop=function(J){St=J},this.dispose=function(){}}}const MA=new hn,Ix=new pe;Ix.set(-1,0,0,0,1,0,0,0,1);function bA(r,t){function i(S,_){S.matrixAutoUpdate===!0&&S.updateMatrix(),_.value.copy(S.matrix)}function a(S,_){_.color.getRGB(S.fogColor.value,wx(r)),_.isFog?(S.fogNear.value=_.near,S.fogFar.value=_.far):_.isFogExp2&&(S.fogDensity.value=_.density)}function l(S,_,T,D,U){_.isNodeMaterial?_.uniformsNeedUpdate=!1:_.isMeshBasicMaterial?c(S,_):_.isMeshLambertMaterial?(c(S,_),_.envMap&&(S.envMapIntensity.value=_.envMapIntensity)):_.isMeshToonMaterial?(c(S,_),x(S,_)):_.isMeshPhongMaterial?(c(S,_),v(S,_),_.envMap&&(S.envMapIntensity.value=_.envMapIntensity)):_.isMeshStandardMaterial?(c(S,_),g(S,_),_.isMeshPhysicalMaterial&&y(S,_,U)):_.isMeshMatcapMaterial?(c(S,_),b(S,_)):_.isMeshDepthMaterial?c(S,_):_.isMeshDistanceMaterial?(c(S,_),C(S,_)):_.isMeshNormalMaterial?c(S,_):_.isLineBasicMaterial?(f(S,_),_.isLineDashedMaterial&&p(S,_)):_.isPointsMaterial?m(S,_,T,D):_.isSpriteMaterial?d(S,_):_.isShadowMaterial?(S.color.value.copy(_.color),S.opacity.value=_.opacity):_.isShaderMaterial&&(_.uniformsNeedUpdate=!1)}function c(S,_){S.opacity.value=_.opacity,_.color&&S.diffuse.value.copy(_.color),_.emissive&&S.emissive.value.copy(_.emissive).multiplyScalar(_.emissiveIntensity),_.map&&(S.map.value=_.map,i(_.map,S.mapTransform)),_.alphaMap&&(S.alphaMap.value=_.alphaMap,i(_.alphaMap,S.alphaMapTransform)),_.bumpMap&&(S.bumpMap.value=_.bumpMap,i(_.bumpMap,S.bumpMapTransform),S.bumpScale.value=_.bumpScale,_.side===$n&&(S.bumpScale.value*=-1)),_.normalMap&&(S.normalMap.value=_.normalMap,i(_.normalMap,S.normalMapTransform),S.normalScale.value.copy(_.normalScale),_.side===$n&&S.normalScale.value.negate()),_.displacementMap&&(S.displacementMap.value=_.displacementMap,i(_.displacementMap,S.displacementMapTransform),S.displacementScale.value=_.displacementScale,S.displacementBias.value=_.displacementBias),_.emissiveMap&&(S.emissiveMap.value=_.emissiveMap,i(_.emissiveMap,S.emissiveMapTransform)),_.specularMap&&(S.specularMap.value=_.specularMap,i(_.specularMap,S.specularMapTransform)),_.alphaTest>0&&(S.alphaTest.value=_.alphaTest);const T=t.get(_),D=T.envMap,U=T.envMapRotation;D&&(S.envMap.value=D,S.envMapRotation.value.setFromMatrix4(MA.makeRotationFromEuler(U)).transpose(),D.isCubeTexture&&D.isRenderTargetTexture===!1&&S.envMapRotation.value.premultiply(Ix),S.reflectivity.value=_.reflectivity,S.ior.value=_.ior,S.refractionRatio.value=_.refractionRatio),_.lightMap&&(S.lightMap.value=_.lightMap,S.lightMapIntensity.value=_.lightMapIntensity,i(_.lightMap,S.lightMapTransform)),_.aoMap&&(S.aoMap.value=_.aoMap,S.aoMapIntensity.value=_.aoMapIntensity,i(_.aoMap,S.aoMapTransform))}function f(S,_){S.diffuse.value.copy(_.color),S.opacity.value=_.opacity,_.map&&(S.map.value=_.map,i(_.map,S.mapTransform))}function p(S,_){S.dashSize.value=_.dashSize,S.totalSize.value=_.dashSize+_.gapSize,S.scale.value=_.scale}function m(S,_,T,D){S.diffuse.value.copy(_.color),S.opacity.value=_.opacity,S.size.value=_.size*T,S.scale.value=D*.5,_.map&&(S.map.value=_.map,i(_.map,S.uvTransform)),_.alphaMap&&(S.alphaMap.value=_.alphaMap,i(_.alphaMap,S.alphaMapTransform)),_.alphaTest>0&&(S.alphaTest.value=_.alphaTest)}function d(S,_){S.diffuse.value.copy(_.color),S.opacity.value=_.opacity,S.rotation.value=_.rotation,_.map&&(S.map.value=_.map,i(_.map,S.mapTransform)),_.alphaMap&&(S.alphaMap.value=_.alphaMap,i(_.alphaMap,S.alphaMapTransform)),_.alphaTest>0&&(S.alphaTest.value=_.alphaTest)}function v(S,_){S.specular.value.copy(_.specular),S.shininess.value=Math.max(_.shininess,1e-4)}function x(S,_){_.gradientMap&&(S.gradientMap.value=_.gradientMap)}function g(S,_){S.metalness.value=_.metalness,_.metalnessMap&&(S.metalnessMap.value=_.metalnessMap,i(_.metalnessMap,S.metalnessMapTransform)),S.roughness.value=_.roughness,_.roughnessMap&&(S.roughnessMap.value=_.roughnessMap,i(_.roughnessMap,S.roughnessMapTransform)),_.envMap&&(S.envMapIntensity.value=_.envMapIntensity)}function y(S,_,T){S.ior.value=_.ior,_.sheen>0&&(S.sheenColor.value.copy(_.sheenColor).multiplyScalar(_.sheen),S.sheenRoughness.value=_.sheenRoughness,_.sheenColorMap&&(S.sheenColorMap.value=_.sheenColorMap,i(_.sheenColorMap,S.sheenColorMapTransform)),_.sheenRoughnessMap&&(S.sheenRoughnessMap.value=_.sheenRoughnessMap,i(_.sheenRoughnessMap,S.sheenRoughnessMapTransform))),_.clearcoat>0&&(S.clearcoat.value=_.clearcoat,S.clearcoatRoughness.value=_.clearcoatRoughness,_.clearcoatMap&&(S.clearcoatMap.value=_.clearcoatMap,i(_.clearcoatMap,S.clearcoatMapTransform)),_.clearcoatRoughnessMap&&(S.clearcoatRoughnessMap.value=_.clearcoatRoughnessMap,i(_.clearcoatRoughnessMap,S.clearcoatRoughnessMapTransform)),_.clearcoatNormalMap&&(S.clearcoatNormalMap.value=_.clearcoatNormalMap,i(_.clearcoatNormalMap,S.clearcoatNormalMapTransform),S.clearcoatNormalScale.value.copy(_.clearcoatNormalScale),_.side===$n&&S.clearcoatNormalScale.value.negate())),_.dispersion>0&&(S.dispersion.value=_.dispersion),_.iridescence>0&&(S.iridescence.value=_.iridescence,S.iridescenceIOR.value=_.iridescenceIOR,S.iridescenceThicknessMinimum.value=_.iridescenceThicknessRange[0],S.iridescenceThicknessMaximum.value=_.iridescenceThicknessRange[1],_.iridescenceMap&&(S.iridescenceMap.value=_.iridescenceMap,i(_.iridescenceMap,S.iridescenceMapTransform)),_.iridescenceThicknessMap&&(S.iridescenceThicknessMap.value=_.iridescenceThicknessMap,i(_.iridescenceThicknessMap,S.iridescenceThicknessMapTransform))),_.transmission>0&&(S.transmission.value=_.transmission,S.transmissionSamplerMap.value=T.texture,S.transmissionSamplerSize.value.set(T.width,T.height),_.transmissionMap&&(S.transmissionMap.value=_.transmissionMap,i(_.transmissionMap,S.transmissionMapTransform)),S.thickness.value=_.thickness,_.thicknessMap&&(S.thicknessMap.value=_.thicknessMap,i(_.thicknessMap,S.thicknessMapTransform)),S.attenuationDistance.value=_.attenuationDistance,S.attenuationColor.value.copy(_.attenuationColor)),_.anisotropy>0&&(S.anisotropyVector.value.set(_.anisotropy*Math.cos(_.anisotropyRotation),_.anisotropy*Math.sin(_.anisotropyRotation)),_.anisotropyMap&&(S.anisotropyMap.value=_.anisotropyMap,i(_.anisotropyMap,S.anisotropyMapTransform))),S.specularIntensity.value=_.specularIntensity,S.specularColor.value.copy(_.specularColor),_.specularColorMap&&(S.specularColorMap.value=_.specularColorMap,i(_.specularColorMap,S.specularColorMapTransform)),_.specularIntensityMap&&(S.specularIntensityMap.value=_.specularIntensityMap,i(_.specularIntensityMap,S.specularIntensityMapTransform))}function b(S,_){_.matcap&&(S.matcap.value=_.matcap)}function C(S,_){const T=t.get(_).light;S.referencePosition.value.setFromMatrixPosition(T.matrixWorld),S.nearDistance.value=T.shadow.camera.near,S.farDistance.value=T.shadow.camera.far}return{refreshFogUniforms:a,refreshMaterialUniforms:l}}function EA(r,t,i,a){let l={},c={},f=[];const p=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function m(T,D){const U=D.program;a.uniformBlockBinding(T,U)}function d(T,D){let U=l[T.id];U===void 0&&(b(T),U=v(T),l[T.id]=U,T.addEventListener("dispose",S));const P=D.program;a.updateUBOMapping(T,P);const N=t.render.frame;c[T.id]!==N&&(g(T),c[T.id]=N)}function v(T){const D=x();T.__bindingPointIndex=D;const U=r.createBuffer(),P=T.__size,N=T.usage;return r.bindBuffer(r.UNIFORM_BUFFER,U),r.bufferData(r.UNIFORM_BUFFER,P,N),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,D,U),U}function x(){for(let T=0;T<p;T++)if(f.indexOf(T)===-1)return f.push(T),T;return Oe("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function g(T){const D=l[T.id],U=T.uniforms,P=T.__cache;r.bindBuffer(r.UNIFORM_BUFFER,D);for(let N=0,z=U.length;N<z;N++){const A=Array.isArray(U[N])?U[N]:[U[N]];for(let O=0,k=A.length;O<k;O++){const G=A[O];if(y(G,N,O,P)===!0){const Y=G.__offset,ct=Array.isArray(G.value)?G.value:[G.value];let ut=0;for(let W=0;W<ct.length;W++){const F=ct[W],V=C(F);typeof F=="number"||typeof F=="boolean"?(G.__data[0]=F,r.bufferSubData(r.UNIFORM_BUFFER,Y+ut,G.__data)):F.isMatrix3?(G.__data[0]=F.elements[0],G.__data[1]=F.elements[1],G.__data[2]=F.elements[2],G.__data[3]=0,G.__data[4]=F.elements[3],G.__data[5]=F.elements[4],G.__data[6]=F.elements[5],G.__data[7]=0,G.__data[8]=F.elements[6],G.__data[9]=F.elements[7],G.__data[10]=F.elements[8],G.__data[11]=0):ArrayBuffer.isView(F)?G.__data.set(new F.constructor(F.buffer,F.byteOffset,G.__data.length)):(F.toArray(G.__data,ut),ut+=V.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,Y,G.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}function y(T,D,U,P){const N=T.value,z=D+"_"+U;if(P[z]===void 0)return typeof N=="number"||typeof N=="boolean"?P[z]=N:ArrayBuffer.isView(N)?P[z]=N.slice():P[z]=N.clone(),!0;{const A=P[z];if(typeof N=="number"||typeof N=="boolean"){if(A!==N)return P[z]=N,!0}else{if(ArrayBuffer.isView(N))return!0;if(A.equals(N)===!1)return A.copy(N),!0}}return!1}function b(T){const D=T.uniforms;let U=0;const P=16;for(let z=0,A=D.length;z<A;z++){const O=Array.isArray(D[z])?D[z]:[D[z]];for(let k=0,G=O.length;k<G;k++){const Y=O[k],ct=Array.isArray(Y.value)?Y.value:[Y.value];for(let ut=0,W=ct.length;ut<W;ut++){const F=ct[ut],V=C(F),rt=U%P,gt=rt%V.boundary,I=rt+gt;U+=gt,I!==0&&P-I<V.storage&&(U+=P-I),Y.__data=new Float32Array(V.storage/Float32Array.BYTES_PER_ELEMENT),Y.__offset=U,U+=V.storage}}}const N=U%P;return N>0&&(U+=P-N),T.__size=U,T.__cache={},this}function C(T){const D={boundary:0,storage:0};return typeof T=="number"||typeof T=="boolean"?(D.boundary=4,D.storage=4):T.isVector2?(D.boundary=8,D.storage=8):T.isVector3||T.isColor?(D.boundary=16,D.storage=12):T.isVector4?(D.boundary=16,D.storage=16):T.isMatrix3?(D.boundary=48,D.storage=48):T.isMatrix4?(D.boundary=64,D.storage=64):T.isTexture?ae("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(T)?(D.boundary=16,D.storage=T.byteLength):ae("WebGLRenderer: Unsupported uniform value type.",T),D}function S(T){const D=T.target;D.removeEventListener("dispose",S);const U=f.indexOf(D.__bindingPointIndex);f.splice(U,1),r.deleteBuffer(l[D.id]),delete l[D.id],delete c[D.id]}function _(){for(const T in l)r.deleteBuffer(l[T]);f=[],l={},c={}}return{bind:m,update:d,dispose:_}}const TA=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ki=null;function AA(){return ki===null&&(ki=new fM(TA,16,16,Gs,wa),ki.name="DFG_LUT",ki.minFilter=Gn,ki.magFilter=Gn,ki.wrapS=ba,ki.wrapT=ba,ki.generateMipmaps=!1,ki.needsUpdate=!0),ki}class wA{constructor(t={}){const{canvas:i=wy(),context:a=null,depth:l=!0,stencil:c=!1,alpha:f=!1,antialias:p=!1,premultipliedAlpha:m=!0,preserveDrawingBuffer:d=!1,powerPreference:v="default",failIfMajorPerformanceCaveat:x=!1,reversedDepthBuffer:g=!1,outputBufferType:y=hi}=t;this.isWebGLRenderer=!0;let b;if(a!==null){if(typeof WebGLRenderingContext<"u"&&a instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");b=a.getContextAttributes().alpha}else b=f;const C=y,S=new Set([tp,$d,Jd]),_=new Set([hi,Ki,rl,ol,Kd,Qd]),T=new Uint32Array(4),D=new Int32Array(4),U=new K;let P=null,N=null;const z=[],A=[];let O=null;this.domElement=i,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Yi,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const k=this;let G=!1,Y=null;this._outputColorSpace=fi;let ct=0,ut=0,W=null,F=-1,V=null;const rt=new fn,gt=new fn;let I=null;const tt=new de(0);let dt=0,St=i.width,Nt=i.height,Tt=1,J=null,Mt=null;const pt=new fn(0,0,St,Nt),Ft=new fn(0,0,St,Nt);let $t=!1;const Zt=new sp;let Pe=!1,le=!1;const Ne=new hn,jt=new K,te=new fn,ee={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let me=!1;function Ve(){return W===null?Tt:1}let j=a;function Ue(w,Z){return i.getContext(w,Z)}try{const w={alpha:!0,depth:l,stencil:c,antialias:p,premultipliedAlpha:m,preserveDrawingBuffer:d,powerPreference:v,failIfMajorPerformanceCaveat:x};if("setAttribute"in i&&i.setAttribute("data-engine",`three.js r${jd}`),i.addEventListener("webglcontextlost",bt,!1),i.addEventListener("webglcontextrestored",Kt,!1),i.addEventListener("webglcontextcreationerror",he,!1),j===null){const Z="webgl2";if(j=Ue(Z,w),j===null)throw Ue(Z)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(w){throw Oe("WebGLRenderer: "+w.message),w}let ge,ke,Pt,tn,L,E,$,ht,Et,wt,Ut,ft,xt,Lt,Gt,At,Rt,re,fe,we,X,Ct,mt;function zt(){ge=new AE(j),ge.init(),X=new vA(j,ge),ke=new xE(j,ge,t,X),Pt=new mA(j,ge),ke.reversedDepthBuffer&&g&&Pt.buffers.depth.setReversed(!0),tn=new CE(j),L=new eA,E=new gA(j,ge,Pt,L,ke,X,tn),$=new TE(k),ht=new LM(j),Ct=new gE(j,ht),Et=new wE(j,ht,tn,Ct),wt=new NE(j,Et,ht,Ct,tn),re=new DE(j,ke,E),Gt=new _E(L),Ut=new tA(k,$,ge,ke,Ct,Gt),ft=new bA(k,L),xt=new iA,Lt=new cA(ge),Rt=new mE(k,$,Pt,wt,b,m),At=new pA(k,wt,ke),mt=new EA(j,tn,ke,Pt),fe=new vE(j,ge,tn),we=new RE(j,ge,tn),tn.programs=Ut.programs,k.capabilities=ke,k.extensions=ge,k.properties=L,k.renderLists=xt,k.shadowMap=At,k.state=Pt,k.info=tn}zt(),C!==hi&&(O=new LE(C,i.width,i.height,l,c));const Dt=new yA(k,j);this.xr=Dt,this.getContext=function(){return j},this.getContextAttributes=function(){return j.getContextAttributes()},this.forceContextLoss=function(){const w=ge.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=ge.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return Tt},this.setPixelRatio=function(w){w!==void 0&&(Tt=w,this.setSize(St,Nt,!1))},this.getSize=function(w){return w.set(St,Nt)},this.setSize=function(w,Z,ot=!0){if(Dt.isPresenting){ae("WebGLRenderer: Can't change size while VR device is presenting.");return}St=w,Nt=Z,i.width=Math.floor(w*Tt),i.height=Math.floor(Z*Tt),ot===!0&&(i.style.width=w+"px",i.style.height=Z+"px"),O!==null&&O.setSize(i.width,i.height),this.setViewport(0,0,w,Z)},this.getDrawingBufferSize=function(w){return w.set(St*Tt,Nt*Tt).floor()},this.setDrawingBufferSize=function(w,Z,ot){St=w,Nt=Z,Tt=ot,i.width=Math.floor(w*ot),i.height=Math.floor(Z*ot),this.setViewport(0,0,w,Z)},this.setEffects=function(w){if(C===hi){Oe("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(w){for(let Z=0;Z<w.length;Z++)if(w[Z].isOutputPass===!0){ae("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}O.setEffects(w||[])},this.getCurrentViewport=function(w){return w.copy(rt)},this.getViewport=function(w){return w.copy(pt)},this.setViewport=function(w,Z,ot,at){w.isVector4?pt.set(w.x,w.y,w.z,w.w):pt.set(w,Z,ot,at),Pt.viewport(rt.copy(pt).multiplyScalar(Tt).round())},this.getScissor=function(w){return w.copy(Ft)},this.setScissor=function(w,Z,ot,at){w.isVector4?Ft.set(w.x,w.y,w.z,w.w):Ft.set(w,Z,ot,at),Pt.scissor(gt.copy(Ft).multiplyScalar(Tt).round())},this.getScissorTest=function(){return $t},this.setScissorTest=function(w){Pt.setScissorTest($t=w)},this.setOpaqueSort=function(w){J=w},this.setTransparentSort=function(w){Mt=w},this.getClearColor=function(w){return w.copy(Rt.getClearColor())},this.setClearColor=function(){Rt.setClearColor(...arguments)},this.getClearAlpha=function(){return Rt.getClearAlpha()},this.setClearAlpha=function(){Rt.setClearAlpha(...arguments)},this.clear=function(w=!0,Z=!0,ot=!0){let at=0;if(w){let nt=!1;if(W!==null){const Ot=W.texture.format;nt=S.has(Ot)}if(nt){const Ot=W.texture.type,Ht=_.has(Ot),It=Rt.getClearColor(),Yt=Rt.getClearAlpha(),Vt=It.r,ue=It.g,ve=It.b;Ht?(T[0]=Vt,T[1]=ue,T[2]=ve,T[3]=Yt,j.clearBufferuiv(j.COLOR,0,T)):(D[0]=Vt,D[1]=ue,D[2]=ve,D[3]=Yt,j.clearBufferiv(j.COLOR,0,D))}else at|=j.COLOR_BUFFER_BIT}Z&&(at|=j.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),ot&&(at|=j.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),at!==0&&j.clear(at)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(w){w.setRenderer(this),Y=w},this.dispose=function(){i.removeEventListener("webglcontextlost",bt,!1),i.removeEventListener("webglcontextrestored",Kt,!1),i.removeEventListener("webglcontextcreationerror",he,!1),Rt.dispose(),xt.dispose(),Lt.dispose(),L.dispose(),$.dispose(),wt.dispose(),Ct.dispose(),mt.dispose(),Ut.dispose(),Dt.dispose(),Dt.removeEventListener("sessionstart",fl),Dt.removeEventListener("sessionend",Zr),ti.stop()};function bt(w){w.preventDefault(),av("WebGLRenderer: Context Lost."),G=!0}function Kt(){av("WebGLRenderer: Context Restored."),G=!1;const w=tn.autoReset,Z=At.enabled,ot=At.autoUpdate,at=At.needsUpdate,nt=At.type;zt(),tn.autoReset=w,At.enabled=Z,At.autoUpdate=ot,At.needsUpdate=at,At.type=nt}function he(w){Oe("WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function Ge(w){const Z=w.target;Z.removeEventListener("dispose",Ge),ce(Z)}function ce(w){en(w),L.remove(w)}function en(w){const Z=L.get(w).programs;Z!==void 0&&(Z.forEach(function(ot){Ut.releaseProgram(ot)}),w.isShaderMaterial&&Ut.releaseShaderCache(w))}this.renderBufferDirect=function(w,Z,ot,at,nt,Ot){Z===null&&(Z=ee);const Ht=nt.isMesh&&nt.matrixWorld.determinant()<0,It=Ca(w,Z,ot,at,nt);Pt.setMaterial(at,Ht);let Yt=ot.index,Vt=1;if(at.wireframe===!0){if(Yt=Et.getWireframeAttribute(ot),Yt===void 0)return;Vt=2}const ue=ot.drawRange,ve=ot.attributes.position;let Qt=ue.start*Vt,Be=(ue.start+ue.count)*Vt;Ot!==null&&(Qt=Math.max(Qt,Ot.start*Vt),Be=Math.min(Be,(Ot.start+Ot.count)*Vt)),Yt!==null?(Qt=Math.max(Qt,0),Be=Math.min(Be,Yt.count)):ve!=null&&(Qt=Math.max(Qt,0),Be=Math.min(Be,ve.count));const Je=Be-Qt;if(Je<0||Je===1/0)return;Ct.setup(nt,at,It,ot,Yt);let nn,_e=fe;if(Yt!==null&&(nn=ht.get(Yt),_e=we,_e.setIndex(nn)),nt.isMesh)at.wireframe===!0?(Pt.setLineWidth(at.wireframeLinewidth*Ve()),_e.setMode(j.LINES)):_e.setMode(j.TRIANGLES);else if(nt.isLine){let gn=at.linewidth;gn===void 0&&(gn=1),Pt.setLineWidth(gn*Ve()),nt.isLineSegments?_e.setMode(j.LINES):nt.isLineLoop?_e.setMode(j.LINE_LOOP):_e.setMode(j.LINE_STRIP)}else nt.isPoints?_e.setMode(j.POINTS):nt.isSprite&&_e.setMode(j.TRIANGLES);if(nt.isBatchedMesh)if(ge.get("WEBGL_multi_draw"))_e.renderMultiDraw(nt._multiDrawStarts,nt._multiDrawCounts,nt._multiDrawCount);else{const gn=nt._multiDrawStarts,kt=nt._multiDrawCounts,Nn=nt._multiDrawCount,Se=Yt?ht.get(Yt).bytesPerElement:1,Hn=L.get(at).currentProgram.getUniforms();for(let ei=0;ei<Nn;ei++)Hn.setValue(j,"_gl_DrawID",ei),_e.render(gn[ei]/Se,kt[ei])}else if(nt.isInstancedMesh)_e.renderInstances(Qt,Je,nt.count);else if(ot.isInstancedBufferGeometry){const gn=ot._maxInstanceCount!==void 0?ot._maxInstanceCount:1/0,kt=Math.min(ot.instanceCount,gn);_e.renderInstances(Qt,Je,kt)}else _e.render(Qt,Je)};function Dn(w,Z,ot){w.transparent===!0&&w.side===Ma&&w.forceSinglePass===!1?(w.side=$n,w.needsUpdate=!0,rn(w,Z,ot),w.side=cs,w.needsUpdate=!0,rn(w,Z,ot),w.side=Ma):rn(w,Z,ot)}this.compile=function(w,Z,ot=null){ot===null&&(ot=w),N=Lt.get(ot),N.init(Z),A.push(N),ot.traverseVisible(function(nt){nt.isLight&&nt.layers.test(Z.layers)&&(N.pushLight(nt),nt.castShadow&&N.pushShadow(nt))}),w!==ot&&w.traverseVisible(function(nt){nt.isLight&&nt.layers.test(Z.layers)&&(N.pushLight(nt),nt.castShadow&&N.pushShadow(nt))}),N.setupLights();const at=new Set;return w.traverse(function(nt){if(!(nt.isMesh||nt.isPoints||nt.isLine||nt.isSprite))return;const Ot=nt.material;if(Ot)if(Array.isArray(Ot))for(let Ht=0;Ht<Ot.length;Ht++){const It=Ot[Ht];Dn(It,ot,nt),at.add(It)}else Dn(Ot,ot,nt),at.add(Ot)}),N=A.pop(),at},this.compileAsync=function(w,Z,ot=null){const at=this.compile(w,Z,ot);return new Promise(nt=>{function Ot(){if(at.forEach(function(Ht){L.get(Ht).currentProgram.isReady()&&at.delete(Ht)}),at.size===0){nt(w);return}setTimeout(Ot,10)}ge.get("KHR_parallel_shader_compile")!==null?Ot():setTimeout(Ot,10)})};let fs=null;function uu(w){fs&&fs(w)}function fl(){ti.stop()}function Zr(){ti.start()}const ti=new Cx;ti.setAnimationLoop(uu),typeof self<"u"&&ti.setContext(self),this.setAnimationLoop=function(w){fs=w,Dt.setAnimationLoop(w),w===null?ti.stop():ti.start()},Dt.addEventListener("sessionstart",fl),Dt.addEventListener("sessionend",Zr),this.render=function(w,Z){if(Z!==void 0&&Z.isCamera!==!0){Oe("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(G===!0)return;Y!==null&&Y.renderStart(w,Z);const ot=Dt.enabled===!0&&Dt.isPresenting===!0,at=O!==null&&(W===null||ot)&&O.begin(k,W);if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),Z.parent===null&&Z.matrixWorldAutoUpdate===!0&&Z.updateMatrixWorld(),Dt.enabled===!0&&Dt.isPresenting===!0&&(O===null||O.isCompositing()===!1)&&(Dt.cameraAutoUpdate===!0&&Dt.updateCamera(Z),Z=Dt.getCamera()),w.isScene===!0&&w.onBeforeRender(k,w,Z,W),N=Lt.get(w,A.length),N.init(Z),N.state.textureUnits=E.getTextureUnits(),A.push(N),Ne.multiplyMatrices(Z.projectionMatrix,Z.matrixWorldInverse),Zt.setFromProjectionMatrix(Ne,ji,Z.reversedDepth),le=this.localClippingEnabled,Pe=Gt.init(this.clippingPlanes,le),P=xt.get(w,z.length),P.init(),z.push(P),Dt.enabled===!0&&Dt.isPresenting===!0){const Ht=k.xr.getDepthSensingMesh();Ht!==null&&hs(Ht,Z,-1/0,k.sortObjects)}hs(w,Z,0,k.sortObjects),P.finish(),k.sortObjects===!0&&P.sort(J,Mt),me=Dt.enabled===!1||Dt.isPresenting===!1||Dt.hasDepthSensing()===!1,me&&Rt.addToRenderList(P,w),this.info.render.frame++,Pe===!0&&Gt.beginShadows();const nt=N.state.shadowsArray;if(At.render(nt,w,Z),Pe===!0&&Gt.endShadows(),this.info.autoReset===!0&&this.info.reset(),(at&&O.hasRenderPass())===!1){const Ht=P.opaque,It=P.transmissive;if(N.setupLights(),Z.isArrayCamera){const Yt=Z.cameras;if(It.length>0)for(let Vt=0,ue=Yt.length;Vt<ue;Vt++){const ve=Yt[Vt];$i(Ht,It,w,ve)}me&&Rt.render(w);for(let Vt=0,ue=Yt.length;Vt<ue;Vt++){const ve=Yt[Vt];Ji(P,w,ve,ve.viewport)}}else It.length>0&&$i(Ht,It,w,Z),me&&Rt.render(w),Ji(P,w,Z)}W!==null&&ut===0&&(E.updateMultisampleRenderTarget(W),E.updateRenderTargetMipmap(W)),at&&O.end(k),w.isScene===!0&&w.onAfterRender(k,w,Z),Ct.resetDefaultState(),F=-1,V=null,A.pop(),A.length>0?(N=A[A.length-1],E.setTextureUnits(N.state.textureUnits),Pe===!0&&Gt.setGlobalState(k.clippingPlanes,N.state.camera)):N=null,z.pop(),z.length>0?P=z[z.length-1]:P=null,Y!==null&&Y.renderEnd()};function hs(w,Z,ot,at){if(w.visible===!1)return;if(w.layers.test(Z.layers)){if(w.isGroup)ot=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(Z);else if(w.isLightProbeGrid)N.pushLightProbeGrid(w);else if(w.isLight)N.pushLight(w),w.castShadow&&N.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||Zt.intersectsSprite(w)){at&&te.setFromMatrixPosition(w.matrixWorld).applyMatrix4(Ne);const Ht=wt.update(w),It=w.material;It.visible&&P.push(w,Ht,It,ot,te.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||Zt.intersectsObject(w))){const Ht=wt.update(w),It=w.material;if(at&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),te.copy(w.boundingSphere.center)):(Ht.boundingSphere===null&&Ht.computeBoundingSphere(),te.copy(Ht.boundingSphere.center)),te.applyMatrix4(w.matrixWorld).applyMatrix4(Ne)),Array.isArray(It)){const Yt=Ht.groups;for(let Vt=0,ue=Yt.length;Vt<ue;Vt++){const ve=Yt[Vt],Qt=It[ve.materialIndex];Qt&&Qt.visible&&P.push(w,Ht,Qt,ot,te.z,ve)}}else It.visible&&P.push(w,Ht,It,ot,te.z,null)}}const Ot=w.children;for(let Ht=0,It=Ot.length;Ht<It;Ht++)hs(Ot[Ht],Z,ot,at)}function Ji(w,Z,ot,at){const{opaque:nt,transmissive:Ot,transparent:Ht}=w;N.setupLightsView(ot),Pe===!0&&Gt.setGlobalState(k.clippingPlanes,ot),at&&Pt.viewport(rt.copy(at)),nt.length>0&&Oi(nt,Z,ot),Ot.length>0&&Oi(Ot,Z,ot),Ht.length>0&&Oi(Ht,Z,ot),Pt.buffers.depth.setTest(!0),Pt.buffers.depth.setMask(!0),Pt.buffers.color.setMask(!0),Pt.setPolygonOffset(!1)}function $i(w,Z,ot,at){if((ot.isScene===!0?ot.overrideMaterial:null)!==null)return;if(N.state.transmissionRenderTarget[at.id]===void 0){const Qt=ge.has("EXT_color_buffer_half_float")||ge.has("EXT_color_buffer_float");N.state.transmissionRenderTarget[at.id]=new Zi(1,1,{generateMipmaps:!0,type:Qt?wa:hi,minFilter:Is,samples:Math.max(4,ke.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ce.workingColorSpace})}const Ot=N.state.transmissionRenderTarget[at.id],Ht=at.viewport||rt;Ot.setSize(Ht.z*k.transmissionResolutionScale,Ht.w*k.transmissionResolutionScale);const It=k.getRenderTarget(),Yt=k.getActiveCubeFace(),Vt=k.getActiveMipmapLevel();k.setRenderTarget(Ot),k.getClearColor(tt),dt=k.getClearAlpha(),dt<1&&k.setClearColor(16777215,.5),k.clear(),me&&Rt.render(ot);const ue=k.toneMapping;k.toneMapping=Yi;const ve=at.viewport;if(at.viewport!==void 0&&(at.viewport=void 0),N.setupLightsView(at),Pe===!0&&Gt.setGlobalState(k.clippingPlanes,at),Oi(w,ot,at),E.updateMultisampleRenderTarget(Ot),E.updateRenderTargetMipmap(Ot),ge.has("WEBGL_multisampled_render_to_texture")===!1){let Qt=!1;for(let Be=0,Je=Z.length;Be<Je;Be++){const nn=Z[Be],{object:_e,geometry:gn,material:kt,group:Nn}=nn;if(kt.side===Ma&&_e.layers.test(at.layers)){const Se=kt.side;kt.side=$n,kt.needsUpdate=!0,ta(_e,ot,at,gn,kt,Nn),kt.side=Se,kt.needsUpdate=!0,Qt=!0}}Qt===!0&&(E.updateMultisampleRenderTarget(Ot),E.updateRenderTargetMipmap(Ot))}k.setRenderTarget(It,Yt,Vt),k.setClearColor(tt,dt),ve!==void 0&&(at.viewport=ve),k.toneMapping=ue}function Oi(w,Z,ot){const at=Z.isScene===!0?Z.overrideMaterial:null;for(let nt=0,Ot=w.length;nt<Ot;nt++){const Ht=w[nt],{object:It,geometry:Yt,group:Vt}=Ht;let ue=Ht.material;ue.allowOverride===!0&&at!==null&&(ue=at),It.layers.test(ot.layers)&&ta(It,Z,ot,Yt,ue,Vt)}}function ta(w,Z,ot,at,nt,Ot){w.onBeforeRender(k,Z,ot,at,nt,Ot),w.modelViewMatrix.multiplyMatrices(ot.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),nt.onBeforeRender(k,Z,ot,at,w,Ot),nt.transparent===!0&&nt.side===Ma&&nt.forceSinglePass===!1?(nt.side=$n,nt.needsUpdate=!0,k.renderBufferDirect(ot,Z,at,nt,w,Ot),nt.side=cs,nt.needsUpdate=!0,k.renderBufferDirect(ot,Z,at,nt,w,Ot),nt.side=Ma):k.renderBufferDirect(ot,Z,at,nt,w,Ot),w.onAfterRender(k,Z,ot,at,nt,Ot)}function rn(w,Z,ot){Z.isScene!==!0&&(Z=ee);const at=L.get(w),nt=N.state.lights,Ot=N.state.shadowsArray,Ht=nt.state.version,It=Ut.getParameters(w,nt.state,Ot,Z,ot,N.state.lightProbeGridArray),Yt=Ut.getProgramCacheKey(It);let Vt=at.programs;at.environment=w.isMeshStandardMaterial||w.isMeshLambertMaterial||w.isMeshPhongMaterial?Z.environment:null,at.fog=Z.fog;const ue=w.isMeshStandardMaterial||w.isMeshLambertMaterial&&!w.envMap||w.isMeshPhongMaterial&&!w.envMap;at.envMap=$.get(w.envMap||at.environment,ue),at.envMapRotation=at.environment!==null&&w.envMap===null?Z.environmentRotation:w.envMapRotation,Vt===void 0&&(w.addEventListener("dispose",Ge),Vt=new Map,at.programs=Vt);let ve=Vt.get(Yt);if(ve!==void 0){if(at.currentProgram===ve&&at.lightsStateVersion===Ht)return Qr(w,It),ve}else It.uniforms=Ut.getUniforms(w),Y!==null&&w.isNodeMaterial&&Y.build(w,ot,It),w.onBeforeCompile(It,k),ve=Ut.acquireProgram(It,Yt),Vt.set(Yt,ve),at.uniforms=It.uniforms;const Qt=at.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(Qt.clippingPlanes=Gt.uniform),Qr(w,It),at.needsLights=hl(w),at.lightsStateVersion=Ht,at.needsLights&&(Qt.ambientLightColor.value=nt.state.ambient,Qt.lightProbe.value=nt.state.probe,Qt.directionalLights.value=nt.state.directional,Qt.directionalLightShadows.value=nt.state.directionalShadow,Qt.spotLights.value=nt.state.spot,Qt.spotLightShadows.value=nt.state.spotShadow,Qt.rectAreaLights.value=nt.state.rectArea,Qt.ltc_1.value=nt.state.rectAreaLTC1,Qt.ltc_2.value=nt.state.rectAreaLTC2,Qt.pointLights.value=nt.state.point,Qt.pointLightShadows.value=nt.state.pointShadow,Qt.hemisphereLights.value=nt.state.hemi,Qt.directionalShadowMatrix.value=nt.state.directionalShadowMatrix,Qt.spotLightMatrix.value=nt.state.spotLightMatrix,Qt.spotLightMap.value=nt.state.spotLightMap,Qt.pointShadowMatrix.value=nt.state.pointShadowMatrix),at.lightProbeGrid=N.state.lightProbeGridArray.length>0,at.currentProgram=ve,at.uniformsList=null,ve}function Kr(w){if(w.uniformsList===null){const Z=w.currentProgram.getUniforms();w.uniformsList=Qc.seqWithValue(Z.seq,w.uniforms)}return w.uniformsList}function Qr(w,Z){const ot=L.get(w);ot.outputColorSpace=Z.outputColorSpace,ot.batching=Z.batching,ot.batchingColor=Z.batchingColor,ot.instancing=Z.instancing,ot.instancingColor=Z.instancingColor,ot.instancingMorph=Z.instancingMorph,ot.skinning=Z.skinning,ot.morphTargets=Z.morphTargets,ot.morphNormals=Z.morphNormals,ot.morphColors=Z.morphColors,ot.morphTargetsCount=Z.morphTargetsCount,ot.numClippingPlanes=Z.numClippingPlanes,ot.numIntersection=Z.numClipIntersection,ot.vertexAlphas=Z.vertexAlphas,ot.vertexTangents=Z.vertexTangents,ot.toneMapping=Z.toneMapping}function ea(w,Z){if(w.length===0)return null;if(w.length===1)return w[0].texture!==null?w[0]:null;U.setFromMatrixPosition(Z.matrixWorld);for(let ot=0,at=w.length;ot<at;ot++){const nt=w[ot];if(nt.texture!==null&&nt.boundingBox.containsPoint(U))return nt}return null}function Ca(w,Z,ot,at,nt){Z.isScene!==!0&&(Z=ee),E.resetTextureUnits();const Ot=Z.fog,Ht=at.isMeshStandardMaterial||at.isMeshLambertMaterial||at.isMeshPhongMaterial?Z.environment:null,It=W===null?k.outputColorSpace:W.isXRRenderTarget===!0?W.texture.colorSpace:Ce.workingColorSpace,Yt=at.isMeshStandardMaterial||at.isMeshLambertMaterial&&!at.envMap||at.isMeshPhongMaterial&&!at.envMap,Vt=$.get(at.envMap||Ht,Yt),ue=at.vertexColors===!0&&!!ot.attributes.color&&ot.attributes.color.itemSize===4,ve=!!ot.attributes.tangent&&(!!at.normalMap||at.anisotropy>0),Qt=!!ot.morphAttributes.position,Be=!!ot.morphAttributes.normal,Je=!!ot.morphAttributes.color;let nn=Yi;at.toneMapped&&(W===null||W.isXRRenderTarget===!0)&&(nn=k.toneMapping);const _e=ot.morphAttributes.position||ot.morphAttributes.normal||ot.morphAttributes.color,gn=_e!==void 0?_e.length:0,kt=L.get(at),Nn=N.state.lights;if(Pe===!0&&(le===!0||w!==V)){const je=w===V&&at.id===F;Gt.setState(at,w,je)}let Se=!1;at.version===kt.__version?(kt.needsLights&&kt.lightsStateVersion!==Nn.state.version||kt.outputColorSpace!==It||nt.isBatchedMesh&&kt.batching===!1||!nt.isBatchedMesh&&kt.batching===!0||nt.isBatchedMesh&&kt.batchingColor===!0&&nt.colorTexture===null||nt.isBatchedMesh&&kt.batchingColor===!1&&nt.colorTexture!==null||nt.isInstancedMesh&&kt.instancing===!1||!nt.isInstancedMesh&&kt.instancing===!0||nt.isSkinnedMesh&&kt.skinning===!1||!nt.isSkinnedMesh&&kt.skinning===!0||nt.isInstancedMesh&&kt.instancingColor===!0&&nt.instanceColor===null||nt.isInstancedMesh&&kt.instancingColor===!1&&nt.instanceColor!==null||nt.isInstancedMesh&&kt.instancingMorph===!0&&nt.morphTexture===null||nt.isInstancedMesh&&kt.instancingMorph===!1&&nt.morphTexture!==null||kt.envMap!==Vt||at.fog===!0&&kt.fog!==Ot||kt.numClippingPlanes!==void 0&&(kt.numClippingPlanes!==Gt.numPlanes||kt.numIntersection!==Gt.numIntersection)||kt.vertexAlphas!==ue||kt.vertexTangents!==ve||kt.morphTargets!==Qt||kt.morphNormals!==Be||kt.morphColors!==Je||kt.toneMapping!==nn||kt.morphTargetsCount!==gn||!!kt.lightProbeGrid!=N.state.lightProbeGridArray.length>0)&&(Se=!0):(Se=!0,kt.__version=at.version);let Hn=kt.currentProgram;Se===!0&&(Hn=rn(at,Z,nt),Y&&at.isNodeMaterial&&Y.onUpdateProgram(at,Hn,kt));let ei=!1,Vn=!1,Da=!1;const He=Hn.getUniforms(),an=kt.uniforms;if(Pt.useProgram(Hn.program)&&(ei=!0,Vn=!0,Da=!0),at.id!==F&&(F=at.id,Vn=!0),kt.needsLights){const je=ea(N.state.lightProbeGridArray,nt);kt.lightProbeGrid!==je&&(kt.lightProbeGrid=je,Vn=!0)}if(ei||V!==w){Pt.buffers.depth.getReversed()&&w.reversedDepth!==!0&&(w._reversedDepth=!0,w.updateProjectionMatrix()),He.setValue(j,"projectionMatrix",w.projectionMatrix),He.setValue(j,"viewMatrix",w.matrixWorldInverse);const Ii=He.map.cameraPosition;Ii!==void 0&&Ii.setValue(j,jt.setFromMatrixPosition(w.matrixWorld)),ke.logarithmicDepthBuffer&&He.setValue(j,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(at.isMeshPhongMaterial||at.isMeshToonMaterial||at.isMeshLambertMaterial||at.isMeshBasicMaterial||at.isMeshStandardMaterial||at.isShaderMaterial)&&He.setValue(j,"isOrthographic",w.isOrthographicCamera===!0),V!==w&&(V=w,Vn=!0,Da=!0)}if(kt.needsLights&&(Nn.state.directionalShadowMap.length>0&&He.setValue(j,"directionalShadowMap",Nn.state.directionalShadowMap,E),Nn.state.spotShadowMap.length>0&&He.setValue(j,"spotShadowMap",Nn.state.spotShadowMap,E),Nn.state.pointShadowMap.length>0&&He.setValue(j,"pointShadowMap",Nn.state.pointShadowMap,E)),nt.isSkinnedMesh){He.setOptional(j,nt,"bindMatrix"),He.setOptional(j,nt,"bindMatrixInverse");const je=nt.skeleton;je&&(je.boneTexture===null&&je.computeBoneTexture(),He.setValue(j,"boneTexture",je.boneTexture,E))}nt.isBatchedMesh&&(He.setOptional(j,nt,"batchingTexture"),He.setValue(j,"batchingTexture",nt._matricesTexture,E),He.setOptional(j,nt,"batchingIdTexture"),He.setValue(j,"batchingIdTexture",nt._indirectTexture,E),He.setOptional(j,nt,"batchingColorTexture"),nt._colorsTexture!==null&&He.setValue(j,"batchingColorTexture",nt._colorsTexture,E));const di=ot.morphAttributes;if((di.position!==void 0||di.normal!==void 0||di.color!==void 0)&&re.update(nt,ot,Hn),(Vn||kt.receiveShadow!==nt.receiveShadow)&&(kt.receiveShadow=nt.receiveShadow,He.setValue(j,"receiveShadow",nt.receiveShadow)),(at.isMeshStandardMaterial||at.isMeshLambertMaterial||at.isMeshPhongMaterial)&&at.envMap===null&&Z.environment!==null&&(an.envMapIntensity.value=Z.environmentIntensity),an.dfgLUT!==void 0&&(an.dfgLUT.value=AA()),Vn){if(He.setValue(j,"toneMappingExposure",k.toneMappingExposure),kt.needsLights&&fu(an,Da),Ot&&at.fog===!0&&ft.refreshFogUniforms(an,Ot),ft.refreshMaterialUniforms(an,at,Tt,Nt,N.state.transmissionRenderTarget[w.id]),kt.needsLights&&kt.lightProbeGrid){const je=kt.lightProbeGrid;an.probesSH.value=je.texture,an.probesMin.value.copy(je.boundingBox.min),an.probesMax.value.copy(je.boundingBox.max),an.probesResolution.value.copy(je.resolution)}Qc.upload(j,Kr(kt),an,E)}if(at.isShaderMaterial&&at.uniformsNeedUpdate===!0&&(Qc.upload(j,Kr(kt),an,E),at.uniformsNeedUpdate=!1),at.isSpriteMaterial&&He.setValue(j,"center",nt.center),He.setValue(j,"modelViewMatrix",nt.modelViewMatrix),He.setValue(j,"normalMatrix",nt.normalMatrix),He.setValue(j,"modelMatrix",nt.matrixWorld),at.uniformsGroups!==void 0){const je=at.uniformsGroups;for(let Ii=0,bi=je.length;Ii<bi;Ii++){const ks=je[Ii];mt.update(ks,Hn),mt.bind(ks,Hn)}}return Hn}function fu(w,Z){w.ambientLightColor.needsUpdate=Z,w.lightProbe.needsUpdate=Z,w.directionalLights.needsUpdate=Z,w.directionalLightShadows.needsUpdate=Z,w.pointLights.needsUpdate=Z,w.pointLightShadows.needsUpdate=Z,w.spotLights.needsUpdate=Z,w.spotLightShadows.needsUpdate=Z,w.rectAreaLights.needsUpdate=Z,w.hemisphereLights.needsUpdate=Z}function hl(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return ct},this.getActiveMipmapLevel=function(){return ut},this.getRenderTarget=function(){return W},this.setRenderTargetTextures=function(w,Z,ot){const at=L.get(w);at.__autoAllocateDepthBuffer=w.resolveDepthBuffer===!1,at.__autoAllocateDepthBuffer===!1&&(at.__useRenderToTexture=!1),L.get(w.texture).__webglTexture=Z,L.get(w.depthTexture).__webglTexture=at.__autoAllocateDepthBuffer?void 0:ot,at.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(w,Z){const ot=L.get(w);ot.__webglFramebuffer=Z,ot.__useDefaultFramebuffer=Z===void 0};const dl=j.createFramebuffer();this.setRenderTarget=function(w,Z=0,ot=0){W=w,ct=Z,ut=ot;let at=null,nt=!1,Ot=!1;if(w){const It=L.get(w);if(It.__useDefaultFramebuffer!==void 0){Pt.bindFramebuffer(j.FRAMEBUFFER,It.__webglFramebuffer),rt.copy(w.viewport),gt.copy(w.scissor),I=w.scissorTest,Pt.viewport(rt),Pt.scissor(gt),Pt.setScissorTest(I),F=-1;return}else if(It.__webglFramebuffer===void 0)E.setupRenderTarget(w);else if(It.__hasExternalTextures)E.rebindTextures(w,L.get(w.texture).__webglTexture,L.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const ue=w.depthTexture;if(It.__boundDepthTexture!==ue){if(ue!==null&&L.has(ue)&&(w.width!==ue.image.width||w.height!==ue.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");E.setupDepthRenderbuffer(w)}}const Yt=w.texture;(Yt.isData3DTexture||Yt.isDataArrayTexture||Yt.isCompressedArrayTexture)&&(Ot=!0);const Vt=L.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(Vt[Z])?at=Vt[Z][ot]:at=Vt[Z],nt=!0):w.samples>0&&E.useMultisampledRTT(w)===!1?at=L.get(w).__webglMultisampledFramebuffer:Array.isArray(Vt)?at=Vt[ot]:at=Vt,rt.copy(w.viewport),gt.copy(w.scissor),I=w.scissorTest}else rt.copy(pt).multiplyScalar(Tt).floor(),gt.copy(Ft).multiplyScalar(Tt).floor(),I=$t;if(ot!==0&&(at=dl),Pt.bindFramebuffer(j.FRAMEBUFFER,at)&&Pt.drawBuffers(w,at),Pt.viewport(rt),Pt.scissor(gt),Pt.setScissorTest(I),nt){const It=L.get(w.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_CUBE_MAP_POSITIVE_X+Z,It.__webglTexture,ot)}else if(Ot){const It=Z;for(let Yt=0;Yt<w.textures.length;Yt++){const Vt=L.get(w.textures[Yt]);j.framebufferTextureLayer(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0+Yt,Vt.__webglTexture,ot,It)}}else if(w!==null&&ot!==0){const It=L.get(w.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,It.__webglTexture,ot)}F=-1},this.readRenderTargetPixels=function(w,Z,ot,at,nt,Ot,Ht,It=0){if(!(w&&w.isWebGLRenderTarget)){Oe("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Yt=L.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&Ht!==void 0&&(Yt=Yt[Ht]),Yt){Pt.bindFramebuffer(j.FRAMEBUFFER,Yt);try{const Vt=w.textures[It],ue=Vt.format,ve=Vt.type;if(w.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+It),!ke.textureFormatReadable(ue)){Oe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ke.textureTypeReadable(ve)){Oe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Z>=0&&Z<=w.width-at&&ot>=0&&ot<=w.height-nt&&j.readPixels(Z,ot,at,nt,X.convert(ue),X.convert(ve),Ot)}finally{const Vt=W!==null?L.get(W).__webglFramebuffer:null;Pt.bindFramebuffer(j.FRAMEBUFFER,Vt)}}},this.readRenderTargetPixelsAsync=async function(w,Z,ot,at,nt,Ot,Ht,It=0){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Yt=L.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&Ht!==void 0&&(Yt=Yt[Ht]),Yt)if(Z>=0&&Z<=w.width-at&&ot>=0&&ot<=w.height-nt){Pt.bindFramebuffer(j.FRAMEBUFFER,Yt);const Vt=w.textures[It],ue=Vt.format,ve=Vt.type;if(w.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+It),!ke.textureFormatReadable(ue))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ke.textureTypeReadable(ve))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Qt=j.createBuffer();j.bindBuffer(j.PIXEL_PACK_BUFFER,Qt),j.bufferData(j.PIXEL_PACK_BUFFER,Ot.byteLength,j.STREAM_READ),j.readPixels(Z,ot,at,nt,X.convert(ue),X.convert(ve),0);const Be=W!==null?L.get(W).__webglFramebuffer:null;Pt.bindFramebuffer(j.FRAMEBUFFER,Be);const Je=j.fenceSync(j.SYNC_GPU_COMMANDS_COMPLETE,0);return j.flush(),await Ry(j,Je,4),j.bindBuffer(j.PIXEL_PACK_BUFFER,Qt),j.getBufferSubData(j.PIXEL_PACK_BUFFER,0,Ot),j.deleteBuffer(Qt),j.deleteSync(Je),Ot}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(w,Z=null,ot=0){const at=Math.pow(2,-ot),nt=Math.floor(w.image.width*at),Ot=Math.floor(w.image.height*at),Ht=Z!==null?Z.x:0,It=Z!==null?Z.y:0;E.setTexture2D(w,0),j.copyTexSubImage2D(j.TEXTURE_2D,ot,0,0,Ht,It,nt,Ot),Pt.unbindTexture()};const hu=j.createFramebuffer(),Vs=j.createFramebuffer();this.copyTextureToTexture=function(w,Z,ot=null,at=null,nt=0,Ot=0){let Ht,It,Yt,Vt,ue,ve,Qt,Be,Je;const nn=w.isCompressedTexture?w.mipmaps[Ot]:w.image;if(ot!==null)Ht=ot.max.x-ot.min.x,It=ot.max.y-ot.min.y,Yt=ot.isBox3?ot.max.z-ot.min.z:1,Vt=ot.min.x,ue=ot.min.y,ve=ot.isBox3?ot.min.z:0;else{const an=Math.pow(2,-nt);Ht=Math.floor(nn.width*an),It=Math.floor(nn.height*an),w.isDataArrayTexture?Yt=nn.depth:w.isData3DTexture?Yt=Math.floor(nn.depth*an):Yt=1,Vt=0,ue=0,ve=0}at!==null?(Qt=at.x,Be=at.y,Je=at.z):(Qt=0,Be=0,Je=0);const _e=X.convert(Z.format),gn=X.convert(Z.type);let kt;Z.isData3DTexture?(E.setTexture3D(Z,0),kt=j.TEXTURE_3D):Z.isDataArrayTexture||Z.isCompressedArrayTexture?(E.setTexture2DArray(Z,0),kt=j.TEXTURE_2D_ARRAY):(E.setTexture2D(Z,0),kt=j.TEXTURE_2D),Pt.activeTexture(j.TEXTURE0),Pt.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,Z.flipY),Pt.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Z.premultiplyAlpha),Pt.pixelStorei(j.UNPACK_ALIGNMENT,Z.unpackAlignment);const Nn=Pt.getParameter(j.UNPACK_ROW_LENGTH),Se=Pt.getParameter(j.UNPACK_IMAGE_HEIGHT),Hn=Pt.getParameter(j.UNPACK_SKIP_PIXELS),ei=Pt.getParameter(j.UNPACK_SKIP_ROWS),Vn=Pt.getParameter(j.UNPACK_SKIP_IMAGES);Pt.pixelStorei(j.UNPACK_ROW_LENGTH,nn.width),Pt.pixelStorei(j.UNPACK_IMAGE_HEIGHT,nn.height),Pt.pixelStorei(j.UNPACK_SKIP_PIXELS,Vt),Pt.pixelStorei(j.UNPACK_SKIP_ROWS,ue),Pt.pixelStorei(j.UNPACK_SKIP_IMAGES,ve);const Da=w.isDataArrayTexture||w.isData3DTexture,He=Z.isDataArrayTexture||Z.isData3DTexture;if(w.isDepthTexture){const an=L.get(w),di=L.get(Z),je=L.get(an.__renderTarget),Ii=L.get(di.__renderTarget);Pt.bindFramebuffer(j.READ_FRAMEBUFFER,je.__webglFramebuffer),Pt.bindFramebuffer(j.DRAW_FRAMEBUFFER,Ii.__webglFramebuffer);for(let bi=0;bi<Yt;bi++)Da&&(j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,L.get(w).__webglTexture,nt,ve+bi),j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,L.get(Z).__webglTexture,Ot,Je+bi)),j.blitFramebuffer(Vt,ue,Ht,It,Qt,Be,Ht,It,j.DEPTH_BUFFER_BIT,j.NEAREST);Pt.bindFramebuffer(j.READ_FRAMEBUFFER,null),Pt.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else if(nt!==0||w.isRenderTargetTexture||L.has(w)){const an=L.get(w),di=L.get(Z);Pt.bindFramebuffer(j.READ_FRAMEBUFFER,hu),Pt.bindFramebuffer(j.DRAW_FRAMEBUFFER,Vs);for(let je=0;je<Yt;je++)Da?j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,an.__webglTexture,nt,ve+je):j.framebufferTexture2D(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,an.__webglTexture,nt),He?j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,di.__webglTexture,Ot,Je+je):j.framebufferTexture2D(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,di.__webglTexture,Ot),nt!==0?j.blitFramebuffer(Vt,ue,Ht,It,Qt,Be,Ht,It,j.COLOR_BUFFER_BIT,j.NEAREST):He?j.copyTexSubImage3D(kt,Ot,Qt,Be,Je+je,Vt,ue,Ht,It):j.copyTexSubImage2D(kt,Ot,Qt,Be,Vt,ue,Ht,It);Pt.bindFramebuffer(j.READ_FRAMEBUFFER,null),Pt.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else He?w.isDataTexture||w.isData3DTexture?j.texSubImage3D(kt,Ot,Qt,Be,Je,Ht,It,Yt,_e,gn,nn.data):Z.isCompressedArrayTexture?j.compressedTexSubImage3D(kt,Ot,Qt,Be,Je,Ht,It,Yt,_e,nn.data):j.texSubImage3D(kt,Ot,Qt,Be,Je,Ht,It,Yt,_e,gn,nn):w.isDataTexture?j.texSubImage2D(j.TEXTURE_2D,Ot,Qt,Be,Ht,It,_e,gn,nn.data):w.isCompressedTexture?j.compressedTexSubImage2D(j.TEXTURE_2D,Ot,Qt,Be,nn.width,nn.height,_e,nn.data):j.texSubImage2D(j.TEXTURE_2D,Ot,Qt,Be,Ht,It,_e,gn,nn);Pt.pixelStorei(j.UNPACK_ROW_LENGTH,Nn),Pt.pixelStorei(j.UNPACK_IMAGE_HEIGHT,Se),Pt.pixelStorei(j.UNPACK_SKIP_PIXELS,Hn),Pt.pixelStorei(j.UNPACK_SKIP_ROWS,ei),Pt.pixelStorei(j.UNPACK_SKIP_IMAGES,Vn),Ot===0&&Z.generateMipmaps&&j.generateMipmap(kt),Pt.unbindTexture()},this.initRenderTarget=function(w){L.get(w).__webglFramebuffer===void 0&&E.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?E.setTextureCube(w,0):w.isData3DTexture?E.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?E.setTexture2DArray(w,0):E.setTexture2D(w,0),Pt.unbindTexture()},this.resetState=function(){ct=0,ut=0,W=null,Pt.reset(),Ct.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ji}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const i=this.getContext();i.drawingBufferColorSpace=Ce._getDrawingBufferColorSpace(t),i.unpackColorSpace=Ce._getUnpackColorSpace()}}const Or=[-6,-2,2,6],Sn=8.5,un=40,Jv=12,$v=2,tx=240;function oe(r,t){return Math.random()*(t-r)+r}function Ni(r){return r[Math.floor(Math.random()*r.length)]}function ya(r,t,i){return r<t?t:r>i?i:r}const kc=[16722902,61695,16765952,16729122,6750054,16742912,10181887,16777215];function Qh(r){const t=new Fs,i=r.width,a=r.length,l=r.height,c=r.variant??(r.isMonster?"monster":r.isTruck?"truck":"sedan"),f=new be({color:r.color,roughness:.42,metalness:.6,emissive:new de(r.color).multiplyScalar(.08)}),p=new ze(i,l,a),m=new qt(p,f);m.position.y=l/2+.35,t.add(m);let d,v,x,g;switch(c){case"truck":d=l*.95,v=a*.32,x=i*.86,g=-a*.18;break;case"semi":d=l*1.15,v=a*.22,x=i*.92,g=-a*.32;break;case"monster":d=l*.7,v=a*.55,x=i*.84,g=-a*.05;break;case"tank":d=l*.55,v=a*.4,x=i*.78,g=-a*.04;break;case"police":d=l*.78,v=a*.5,x=i*.86,g=-a*.06;break;case"taxi":d=l*.78,v=a*.55,x=i*.86,g=-a*.04;break;case"van":d=l*1,v=a*.7,x=i*.92,g=-a*.02;break;case"sport":d=l*.5,v=a*.5,x=i*.82,g=-a*.05;break;default:d=l*.7,v=a*.55,x=i*.85,g=-a*.05}const y=new be({color:c==="police"||c==="taxi"?r.color:2236996,roughness:.55,metalness:.4}),b=new qt(new ze(x,d,v),y);b.position.set(0,l+d/2+.35,g),t.add(b);const C=new be({color:662058,roughness:.08,metalness:.9,emissive:2245768,emissiveIntensity:.45,transparent:!0,opacity:.85}),S=new qt(new ze(x*.92,d*.7,.08),C);S.position.set(0,l+d/2+.4,g+v/2+.02),S.rotation.x=-.18,t.add(S);const _=new qt(new ze(x*.92,d*.65,.08),C);_.position.set(0,l+d/2+.4,g-v/2-.02),_.rotation.x=.18,t.add(_);const T=new qt(new ze(.06,d*.55,v*.85),C);T.position.set(x/2+.01,l+d/2+.45,g),t.add(T);const D=T.clone();D.position.x=-x/2-.01,t.add(D);const U=new be({color:657930,roughness:.95}),P=new be({color:r.isPlayer?r.color:6710886,metalness:.85,roughness:.25,emissive:r.isPlayer?r.color:0,emissiveIntensity:r.isPlayer?.4:0}),N=c==="monster"?.78:c==="tank"?.65:c==="sport"?.32:.38,z=c==="monster"||c==="tank"?.42:.28,A=new Xi(N,N,z,12);A.rotateZ(Math.PI/2);const O=new Xi(N*.55,N*.55,z+.02,8);O.rotateZ(Math.PI/2);const k=i/2+.02,G=a/2-.7,Y=[[k,N,G],[-k,N,G],[k,N,-G],[-k,N,-G]];c==="semi"&&Y.push([k,N,-G+1.4],[-k,N,-G+1.4]);for(const Tt of Y){const J=new qt(A,U);J.position.set(Tt[0],Tt[1],Tt[2]),t.add(J);const Mt=new qt(O,P);Mt.position.set(Tt[0],Tt[1],Tt[2]),t.add(Mt)}const ct=new be({color:16777164,emissive:16777130,emissiveIntensity:2.2}),ut=new ze(.4,.22,.08),W=new qt(ut,ct);W.position.set(i/2-.4,.78,a/2+.02),t.add(W);const F=new qt(ut,ct);F.position.set(-i/2+.4,.78,a/2+.02),t.add(F);const V=new be({color:16720418,emissive:16711680,emissiveIntensity:1.6}),rt=new ze(.36,.18,.08),gt=new qt(rt,V);gt.position.set(i/2-.35,.78,-a/2-.02),t.add(gt);const I=new qt(rt,V);I.position.set(-i/2+.35,.78,-a/2-.02),t.add(I);const tt=new be({color:6710903,metalness:.95,roughness:.2}),dt=new ze(i+.05,.18,.25),St=new qt(dt,tt);St.position.set(0,.55,a/2+.05),t.add(St);const Nt=new qt(dt,tt);if(Nt.position.set(0,.55,-a/2-.05),t.add(Nt),c==="police"){const Tt=new be({color:16711680,emissive:16711680,emissiveIntensity:2.5}),J=new be({color:17663,emissive:17663,emissiveIntensity:2.5}),Mt=new ze(.5,.22,.6),pt=new qt(Mt,Tt);pt.position.set(-.4,l+d+.5,g),t.add(pt);const Ft=new qt(Mt,J);Ft.position.set(.4,l+d+.5,g),t.add(Ft)}else if(c==="taxi"){const Tt=new be({color:16765952,emissive:16765952,emissiveIntensity:1.6}),J=new qt(new ze(.7,.22,.5),Tt);J.position.set(0,l+d+.5,g),t.add(J);const Mt=new be({color:0,roughness:.5}),pt=new qt(new ze(i+.02,.05,.6),Mt);pt.position.set(0,l+.4,g+v/2+.6),t.add(pt)}else if(c==="semi"||c==="truck"){const Tt=new be({color:4473924,metalness:.9,roughness:.4}),J=new Xi(.16,.16,1.6,8),Mt=new qt(J,Tt);Mt.position.set(i/2-.3,l+d+.6,g),t.add(Mt);const pt=Mt.clone();if(pt.position.x=-i/2+.3,t.add(pt),c==="semi"){const Ft=new be({color:13421772,roughness:.6,metalness:.4}),$t=a*1.3,Zt=new qt(new ze(i*.95,l*1.5,$t),Ft);Zt.position.set(0,l*.85+.35,-a/2-$t/2+.2),t.add(Zt)}}else if(c==="monster"||c==="tank"){const Tt=new be({color:16729088,emissive:16729088,emissiveIntensity:.8}),J=new qt(new ze(i*.9,.08,a*.92),Tt);if(J.position.set(0,l+.34,0),t.add(J),c==="tank"){const Mt=new be({color:4478276,metalness:.7,roughness:.5}),pt=new qt(new Xi(.6,.7,.5,10),Mt);pt.position.set(0,l+d+.65,0),t.add(pt);const Ft=new qt(new Xi(.13,.13,1.6,8),Mt);Ft.rotation.x=Math.PI/2,Ft.position.set(0,l+d+.7,.7),t.add(Ft)}}else if(c==="sport"){const Tt=new be({color:1118481,metalness:.7,roughness:.3}),J=new qt(new ze(i*.9,.06,.45),Tt);J.position.set(0,l+d+.55,-a/2+.05),t.add(J);const Mt=new qt(new ze(.1,.45,.18),Tt);Mt.position.set(i/2-.5,l+d+.3,-a/2+.05),t.add(Mt);const pt=Mt.clone();pt.position.x=-i/2+.5,t.add(pt)}if(r.isPlayer){const Tt=r.underglow??r.color,J=new os({color:Tt,transparent:!0,opacity:.65}),Mt=new qt(new Ea(i*1.4,a*1.3),J);Mt.rotation.x=-Math.PI/2,Mt.position.set(0,.04,0),t.add(Mt);const pt=new be({color:Tt,emissive:Tt,emissiveIntensity:1.6}),Ft=new qt(new ze(x*.6,.06,.18),pt);Ft.position.set(0,l+d+.35,g),t.add(Ft);const $t=new be({color:10066329,metalness:.9,roughness:.3}),Zt=new Xi(.11,.13,.45,8);Zt.rotateX(Math.PI/2);const Pe=new qt(Zt,$t);Pe.position.set(i/2-.5,.45,-a/2-.18),t.add(Pe);const le=Pe.clone();le.position.x=-i/2+.5,t.add(le)}return{group:t,body:m,cab:b,damageMaterial:f}}const il=[{name:"Junker Sedan",width:1.9,length:4.4,height:1,isTruck:!1,isMonster:!1,baseHealth:100,baseSmash:1,cost:0,description:"Reliable wreck. Where it all begins."},{name:"Brawler Pickup",width:2.2,length:5.2,height:1.15,isTruck:!0,isMonster:!1,baseHealth:145,baseSmash:1.35,cost:800,description:"Heavier frame, meaner bumper."},{name:"Apex Monster",width:2.6,length:5.4,height:1.5,isTruck:!1,isMonster:!0,baseHealth:200,baseSmash:1.7,cost:3500,description:"Giant tires. Crushes rooftops."},{name:"Doom Tank Mk7",width:3,length:6.6,height:1.7,isTruck:!0,isMonster:!0,baseHealth:280,baseSmash:2.2,cost:1e4,description:"Apocalypse-grade rolling fortress."}],$o=[{name:"Neon City Dusk",shortName:"NEON CITY",fogColor:2755130,fogNear:60,fogFar:320,ambientColor:6702250,ambientIntensity:.55,dirColor:16755302,dirIntensity:.9,hemiSky:16742348,hemiGround:1114146,bgColor:1706022,roadColor:2236976,curbColor:16722902,buildingTints:[2758208,4203076,1712708],billboardColors:[16722902,61695,16765952,16729122,6750054],trafficSpeedMul:1,trafficDensityMul:.7,playerSpeedBonus:0,distance:1500},{name:"Toxic Wasteland",shortName:"TOXIC ZONE",fogColor:1718804,fogNear:50,fogFar:280,ambientColor:6728277,ambientIntensity:.5,dirColor:11206468,dirIntensity:.7,hemiSky:8978278,hemiGround:1120273,bgColor:924168,roadColor:1712664,curbColor:6750054,buildingTints:[1714200,2245666,1583636],billboardColors:[6750054,16776960,16742912,65450],trafficSpeedMul:1.1,trafficDensityMul:.85,playerSpeedBonus:6,distance:1800},{name:"Burning Highway",shortName:"INFERNO",fogColor:4854280,fogNear:40,fogFar:240,ambientColor:16733474,ambientIntensity:.65,dirColor:16746564,dirIntensity:1,hemiSky:16742195,hemiGround:2230272,bgColor:2755076,roadColor:2626576,curbColor:16742912,buildingTints:[4463124,5580832,3346440],billboardColors:[16742912,16720418,16765952,16729258],trafficSpeedMul:1.25,trafficDensityMul:1,playerSpeedBonus:12,distance:2200},{name:"Cyberpunk Megacity",shortName:"MEGACITY",fogColor:662090,fogNear:45,fogFar:300,ambientColor:4487167,ambientIntensity:.6,dirColor:11193599,dirIntensity:.85,hemiSky:6728447,hemiGround:526368,bgColor:526368,roadColor:1579050,curbColor:61695,buildingTints:[1450564,2245768,1581626],billboardColors:[61695,16722902,8978278,16777215],trafficSpeedMul:1.4,trafficDensityMul:1.15,playerSpeedBonus:18,distance:2600},{name:"Apocalypse Final",shortName:"APOCALYPSE",fogColor:4851744,fogNear:40,fogFar:220,ambientColor:16720452,ambientIntensity:.7,dirColor:16729224,dirIntensity:1.1,hemiSky:16720486,hemiGround:1704968,bgColor:1704976,roadColor:2232344,curbColor:16722902,buildingTints:[4463172,5574946,3344426],billboardColors:[16722902,16729122,16765952,61695,6750054],trafficSpeedMul:1.55,trafficDensityMul:1.3,playerSpeedBonus:26,distance:2400},{name:"Frostbite Pass",shortName:"FROSTBITE",fogColor:10410239,fogNear:35,fogFar:220,ambientColor:11193599,ambientIntensity:.7,dirColor:16777215,dirIntensity:1.1,hemiSky:14544639,hemiGround:4478310,bgColor:7247288,roadColor:3820117,curbColor:8969727,buildingTints:[5072504,6719658,8956603],billboardColors:[8969727,4500223,16777215,14544639,6737151],trafficSpeedMul:1.35,trafficDensityMul:1.05,playerSpeedBonus:14,distance:2200},{name:"Sandstorm Mirage",shortName:"DESERT",fogColor:13146709,fogNear:30,fogFar:200,ambientColor:16764023,ambientIntensity:.75,dirColor:16755285,dirIntensity:1.15,hemiSky:16755285,hemiGround:6702114,bgColor:9067048,roadColor:5913112,curbColor:16755251,buildingTints:[8934707,6702114,5583650],billboardColors:[16755251,16742912,16765952,16729122,16746581],trafficSpeedMul:1.3,trafficDensityMul:1,playerSpeedBonus:16,distance:2400},{name:"Galaxy Outrun",shortName:"GALAXY",fogColor:524312,fogNear:50,fogFar:320,ambientColor:6693580,ambientIntensity:.65,dirColor:13404415,dirIntensity:1,hemiSky:11158783,hemiGround:524320,bgColor:262160,roadColor:1181738,curbColor:11158783,buildingTints:[2756696,4465290,1574980],billboardColors:[11158783,16729309,4521966,16777215,6732799],trafficSpeedMul:1.5,trafficDensityMul:1.2,playerSpeedBonus:22,distance:2800}];class RA{container;callbacks;renderer;scene;camera;clock=new NM;ambient;dirLight;hemi;fog;playerGroup;playerParts;playerCarTier;playerHalfW=1;playerHalfL=2.2;playerX=0;playerZ=0;playerSpeed=22;maxSpeed=90;targetX=0;steerVel=0;health=100;maxHealth=100;scrap=0;score=0;chainCount=0;chainTimer=0;bestChain=0;boost=100;boostMax=100;boostActive=!1;nitroActive=0;megaActive=0;magnetActive=0;invuln=0;slowMo=0;hitFlash=0;smashMultiplier=1;status="idle";upgrades={bumper:0,engine:0,nitroTank:0,explosive:0,paint:0,car:0};startTime=0;elapsed=0;newHighFlag=!1;bestScoreAtStart=0;level=1;theme=$o[0];levelStartZ=0;segments=[];nextSegmentZ=0;firstSegmentZ=0;cityProps=[];starField;moon;moonGlow;gantryCounter=0;victoryTriggered=!1;themeMatCache=new Map;sharedMats=new Set;traffic=[];debris=[];particles=[];powers=[];scraps=[];barriers=[];trafficSpawnZ=60;powerSpawnZ=200;barrierSpawnZ=300;keys={};mobileSteer=0;mobileBoost=!1;mobileBrake=!1;mobilePower=!1;shakeAmount=0;rafId=null;resizeObs;sound;constructor(t,i,a){this.container=t,this.sound=i,this.callbacks=a;try{this.renderer=new wA({antialias:!0,powerPreference:"high-performance"})}catch(f){console.error("WebGL init failed:",f);const p=document.createElement("div");throw p.style.cssText="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#fff;font-family:sans-serif;text-align:center;padding:24px;",p.innerHTML='<div><h2 style="color:#ff2bd6;margin:0 0 12px">WebGL not available</h2><p style="opacity:.7">This browser/device does not support WebGL.<br/>Try Chrome, Firefox or Edge with hardware acceleration enabled.</p></div>',t.appendChild(p),f}this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));const l=t.getBoundingClientRect();this.renderer.setSize(l.width||window.innerWidth,l.height||window.innerHeight,!1),this.renderer.outputColorSpace=fi,this.renderer.toneMapping=Yd,this.renderer.toneMappingExposure=1.05,this.renderer.setClearColor(656914,1),this.renderer.domElement.classList.add("game-canvas"),t.appendChild(this.renderer.domElement),this.scene=new sM,this.fog=new iu(this.theme.fogColor,this.theme.fogNear,this.theme.fogFar),this.scene.fog=this.fog,this.scene.background=new de(this.theme.bgColor);const c=(l.width||window.innerWidth)/(l.height||window.innerHeight);this.camera=new Mi(62,c,.5,600),this.camera.position.set(0,7.5,-12),this.camera.lookAt(0,1.6,12),this.setupLights(),this.bindInput(),this.bindResize()}setUpgrades(t){this.upgrades=t}start(t,i,a){this.upgrades=t,this.bestScoreAtStart=a,this.scrap=i,this.level=1,this.theme=$o[0],this.levelStartZ=0,this.applyTheme(this.theme),this.resetWorld(),this.spawnPlayer(),this.applyUpgradeStats(),this.status="playing",this.callbacks.onStatus(this.status),this.startTime=performance.now(),this.clock.start(),this.sound.startEngine(),this.rafId||(this.rafId=requestAnimationFrame(this.loop))}pause(){this.status==="playing"&&(this.status="paused",this.callbacks.onStatus(this.status),this.sound.setEngineParams(0,0))}resume(){this.status==="paused"&&(this.status="playing",this.callbacks.onStatus(this.status),this.clock.getDelta())}endRun(){if(this.status==="gameover")return;this.status="gameover",this.callbacks.onStatus(this.status),this.sound.stopEngine();const t={distance:Math.floor(this.playerZ),score:Math.floor(this.score),scrap:this.runScrapEarned(),newHighScore:this.score>this.bestScoreAtStart,bestChain:this.bestChain,level:this.level};this.callbacks.onRunEnd(t)}destroy(){this.rafId&&cancelAnimationFrame(this.rafId),this.rafId=null,this.resizeObs?.disconnect(),window.removeEventListener("keydown",this.onKeyDown),window.removeEventListener("keyup",this.onKeyUp),this.sound.stopEngine(),this.renderer.dispose(),this.renderer.domElement.remove()}setMobileSteer(t){this.mobileSteer=ya(t,-1,1)}setMobileBrake(t){this.mobileBrake=t}setMobileBoost(t){this.mobileBoost=t}setMobilePower(t){this.mobilePower=t}triggerPower(){}setupLights(){this.ambient=new RM(this.theme.ambientColor,this.theme.ambientIntensity),this.scene.add(this.ambient),this.dirLight=new wM(this.theme.dirColor,this.theme.dirIntensity),this.dirLight.position.set(40,60,30),this.scene.add(this.dirLight),this.hemi=new EM(this.theme.hemiSky,this.theme.hemiGround,.5),this.scene.add(this.hemi),this.setupSky()}setupSky(){const i=new Yn,a=new Float32Array(320*3);for(let p=0;p<320;p++){const m=Math.random(),d=Math.random(),v=m*Math.PI*2,x=Math.acos(d*.7+.1),g=280+Math.random()*80;a[p*3+0]=g*Math.sin(x)*Math.cos(v),a[p*3+1]=60+g*Math.cos(x)*.6,a[p*3+2]=g*Math.sin(x)*Math.sin(v)}i.setAttribute("position",new Pi(a,3));const l=new Ex({color:16777215,size:1.1,sizeAttenuation:!1,transparent:!0,opacity:.85,depthWrite:!1,fog:!1});this.starField=new mM(i,l),this.scene.add(this.starField),this.sharedMats.add(l);const c=new os({color:16777215,fog:!1});this.moon=new qt(new ss(22,18,14),c),this.moon.position.set(-160,110,320),this.scene.add(this.moon),this.sharedMats.add(c);const f=new os({color:16746717,transparent:!0,opacity:.32,fog:!1});this.moonGlow=new qt(new ss(38,18,14),f),this.moonGlow.position.copy(this.moon.position),this.scene.add(this.moonGlow),this.sharedMats.add(f)}getThemeMats(t){const i=this.themeMatCache.get(t.shortName);if(i)return i;const a=new de(t.roadColor),l=new be({color:a,roughness:.92,metalness:.1,emissive:new de(t.roadColor).multiplyScalar(.18),emissiveIntensity:.18}),c=new be({color:new de(t.roadColor).multiplyScalar(.82),roughness:.97,metalness:.05,emissive:new de(t.roadColor).multiplyScalar(.12),emissiveIntensity:.12}),f=new be({color:16765952,emissive:16765952,emissiveIntensity:.7}),p=new be({color:16777215,emissive:16777215,emissiveIntensity:.4}),m=new be({color:t.curbColor,emissive:t.curbColor,emissiveIntensity:1.4}),d=new be({color:1577502,roughness:.92}),v=[];for(let _=0;_<4;_++){const T=t.buildingTints[_%t.buildingTints.length],D=t.billboardColors[_%t.billboardColors.length];v.push(new be({color:T,roughness:.85,metalness:.25,emissive:D,emissiveIntensity:.06}))}const x=[];for(const _ of t.billboardColors)x.push(new be({color:_,emissive:_,emissiveIntensity:1.7}));const g=new be({color:2236979,roughness:.7}),y=new be({color:16772795,emissive:16772795,emissiveIntensity:1.6}),b=new be({color:2236976,roughness:.6,metalness:.7}),C=new be({color:t.curbColor,emissive:t.curbColor,emissiveIntensity:1.5}),S={road:l,roadCracked:c,stripe:f,edgeLine:p,curb:m,sidewalk:d,buildings:v,billboards:x,lampPole:g,lampGlow:y,gantryFrame:b,gantryPanel:C};return[l,c,f,p,m,d,g,y,b,C,...v,...x].forEach(_=>this.sharedMats.add(_)),this.moonGlow&&this.moonGlow.material.color.setHex(t.hemiSky),this.themeMatCache.set(t.shortName,S),S}applyTheme(t){this.theme=t,this.fog?(this.fog.color.setHex(t.fogColor),this.fog.near=t.fogNear,this.fog.far=t.fogFar):(this.fog=new iu(t.fogColor,t.fogNear,t.fogFar),this.scene.fog=this.fog),this.scene.background=new de(t.bgColor),this.ambient&&(this.ambient.color.setHex(t.ambientColor),this.ambient.intensity=t.ambientIntensity),this.dirLight&&(this.dirLight.color.setHex(t.dirColor),this.dirLight.intensity=t.dirIntensity),this.hemi&&(this.hemi.color.setHex(t.hemiSky),this.hemi.groundColor.setHex(t.hemiGround))}checkLevelUp(){if(this.playerZ-this.levelStartZ<this.theme.distance)return;const i=$o[this.level];if(i){this.level+=1,this.levelStartZ=this.playerZ,this.applyTheme(i),this.sound.setMusicLevel(this.level);const a=25,l=50,c=500*this.level;this.boost=Math.min(this.boostMax,this.boost+l),this.health=Math.min(this.maxHealth,this.health+a),this.invuln=Math.max(this.invuln,1.8),this.score+=c,this.sound.powerup(),this.callbacks.onLevelUp(this.level,i.name,{health:a,boost:l,bonus:c})}else if(!this.victoryTriggered){this.victoryTriggered=!0;const a={distance:Math.floor(this.playerZ),score:Math.floor(this.score)+5e3,scrap:this.runScrapEarned(),newHighScore:this.score+5e3>this.bestScoreAtStart,bestChain:this.bestChain,level:this.level};this.score+=5e3,this.callbacks.onVictory?.(a),this.levelStartZ=this.playerZ,this.boost=this.boostMax,this.health=Math.min(this.maxHealth,this.health+50),this.invuln=2.5}}bindInput(){window.addEventListener("keydown",this.onKeyDown),window.addEventListener("keyup",this.onKeyUp)}onKeyDown=t=>{this.keys[t.code]=!0,this.status==="playing"&&(t.code==="Space"||t.code==="ShiftLeft"||t.code==="ShiftRight")&&t.preventDefault()};onKeyUp=t=>{this.keys[t.code]=!1};bindResize(){const t=()=>{const i=this.container.getBoundingClientRect(),a=i.width||window.innerWidth,l=i.height||window.innerHeight;this.renderer.setSize(a,l,!1),this.camera.aspect=a/l,this.camera.updateProjectionMatrix()};window.addEventListener("resize",t),typeof ResizeObserver<"u"&&(this.resizeObs=new ResizeObserver(t),this.resizeObs.observe(this.container))}resetWorld(){for(const t of this.traffic)this.scene.remove(t.parts.group);this.traffic.length=0;for(const t of this.debris)this.scene.remove(t.mesh);this.debris.length=0;for(const t of this.particles)this.scene.remove(t.mesh);this.particles.length=0;for(const t of this.powers)this.scene.remove(t.group);this.powers.length=0;for(const t of this.scraps)this.scene.remove(t.mesh);this.scraps.length=0;for(const t of this.barriers)this.scene.remove(t.mesh);this.barriers.length=0;for(const t of this.segments)this.scene.remove(t.group);this.segments.length=0;for(const t of this.cityProps)this.scene.remove(t);this.cityProps.length=0,this.playerX=0,this.playerZ=0,this.targetX=0,this.steerVel=0,this.playerSpeed=22,this.score=0,this.chainCount=0,this.chainTimer=0,this.bestChain=0,this.boost=this.boostMax,this.nitroActive=0,this.megaActive=0,this.magnetActive=0,this.invuln=1,this.slowMo=0,this.hitFlash=0,this.smashMultiplier=1,this.elapsed=0,this.newHighFlag=!1,this.level=1,this.theme=$o[0],this.levelStartZ=0,this.victoryTriggered=!1,this.trafficSpawnZ=80,this.powerSpawnZ=200,this.barrierSpawnZ=350,this.gantryCounter=0,this.firstSegmentZ=-un*2,this.nextSegmentZ=this.firstSegmentZ;for(let t=0;t<Jv+$v;t++)this.spawnSegment()}applyUpgradeStats(){const t=il[this.upgrades.car]??il[0];this.playerCarTier=t,this.maxHealth=t.baseHealth+this.upgrades.bumper*25,this.health=this.maxHealth,this.boostMax=100+this.upgrades.nitroTank*35,this.boost=this.boostMax,this.maxSpeed=78+this.upgrades.engine*6,this.smashMultiplier=t.baseSmash*(1+this.upgrades.bumper*.12+this.upgrades.explosive*.08)}spawnPlayer(){this.playerGroup&&this.scene.remove(this.playerGroup);const t=il[this.upgrades.car]??il[0],i=kc[this.upgrades.paint]??kc[0],a=t.isMonster&&t.isTruck?"tank":t.isMonster?"monster":t.isTruck?"truck":"sport",l=Qh({color:i,width:t.width,length:t.length,height:t.height,isTruck:t.isTruck,isMonster:t.isMonster,variant:a,isPlayer:!0,underglow:i});this.playerParts=l,this.playerCarTier=t,this.playerHalfW=t.width/2,this.playerHalfL=t.length/2,this.playerGroup=l.group,this.scene.add(this.playerGroup),this.playerGroup.position.set(0,0,0)}spawnSegment(){const t=new Fs,i=this.nextSegmentZ,a=this.getThemeMats(this.theme),l=new Ea(Sn*2,un),c=Math.random()<.4?a.roadCracked:a.road,f=new qt(l,c);f.rotation.x=-Math.PI/2,f.position.set(0,0,i+un/2),t.add(f);const p=new Ea(.18,un),m=new qt(p,a.edgeLine);m.rotation.x=-Math.PI/2,m.position.set(-Sn+.4,.015,i+un/2),t.add(m);const d=new qt(p,a.edgeLine);d.rotation.x=-Math.PI/2,d.position.set(Sn-.4,.015,i+un/2),t.add(d);const v=6,x=new Ea(.22,2.6);for(let D=0;D<3;D++){const U=-Sn+Sn*2*(D+1)/4;for(let P=0;P<v;P++){const N=new qt(x,a.stripe);N.rotation.x=-Math.PI/2,N.position.set(U,.02,i+(P+.5)*(un/v)),t.add(N)}}const g=new ze(.4,.25,un),y=new qt(g,a.curb);y.position.set(-Sn-.2,.12,i+un/2),t.add(y);const b=new qt(g,a.curb);b.position.set(Sn+.2,.12,i+un/2),t.add(b);const C=new Ea(4,un),S=new qt(C,a.sidewalk);S.rotation.x=-Math.PI/2,S.position.set(-Sn-2.4,0,i+un/2),t.add(S);const _=new qt(C,a.sidewalk);_.rotation.x=-Math.PI/2,_.position.set(Sn+2.4,0,i+un/2),t.add(_);const T=[];for(let D=-1;D<=1;D+=2){const U=1+Math.floor(Math.random()*3);for(let P=0;P<U;P++){const N=oe(4,9),z=oe(8,28),A=oe(4,9),O=a.buildings[Math.floor(Math.random()*a.buildings.length)],k=new qt(new ze(N,z,A),O),G=D*(Sn+6+Math.random()*18);if(k.position.set(G,z/2,i+Math.random()*un),t.add(k),T.push(k),Math.random()<.4){const Y=a.billboards[Math.floor(Math.random()*a.billboards.length)],ct=new ze(oe(2.5,5.5),oe(1.2,2.6),.2),ut=new qt(ct,Y);ut.position.set(G-D*(N/2+.15),oe(z*.3,z*.85),i+Math.random()*un),ut.rotation.y=D>0?-Math.PI/2:Math.PI/2,t.add(ut),T.push(ut)}}if(Math.random()<.65){const P=i+Math.random()*un,N=new qt(new Xi(.12,.12,6,6),a.lampPole);N.position.set(D*(Sn+1),3,P),t.add(N);const z=new qt(new ze(1.4,.12,.12),a.lampPole);z.position.set(D*(Sn+.5),5.9,P),t.add(z);const A=new qt(new ss(.42,8,6),a.lampGlow);A.position.set(D*(Sn+0),5.7,P),t.add(A),T.push(N,z,A)}if(Math.random()<.16){const P=Qh({color:Ni([4473924,2236979,5583650]),width:1.9,length:4.2,height:.95,isTruck:!1,isMonster:!1});P.group.position.set(D*(Sn+2.4),0,i+oe(2,un-2)),P.group.rotation.y=oe(-.5,.5)+Math.PI,P.group.rotation.z=oe(-.1,.1),t.add(P.group),T.push(P.group)}}if(this.gantryCounter+=1,this.gantryCounter>=4&&Math.random()<.5){this.gantryCounter=0;const D=i+un*.5,U=new qt(new ze(Sn*2+4,.7,.7),a.gantryFrame);U.position.set(0,7.6,D),t.add(U);const P=new qt(new ze(.55,7.6,.55),a.gantryFrame);P.position.set(-Sn-1.5,3.8,D),t.add(P);const N=new qt(new ze(.55,7.6,.55),a.gantryFrame);N.position.set(Sn+1.5,3.8,D),t.add(N);for(let z=0;z<4;z++){const A=-Sn+Sn*2*(z+.5)/4,O=new qt(new ze(2.5,.18,.18),a.gantryPanel);O.position.set(A,7.05,D),t.add(O)}T.push(U,P,N)}this.scene.add(t),this.segments.push({group:t,startZ:i,endZ:i+un,decorations:T}),this.nextSegmentZ+=un}recycleSegments(){for(;this.segments.length>0&&this.segments[0].endZ<this.playerZ-$v*un;){const t=this.segments.shift();this.scene.remove(t.group),t.group.traverse(i=>{const a=i;if(a.isMesh){a.geometry?.dispose?.();const l=a.material;Array.isArray(l)?l.forEach(c=>{this.sharedMats.has(c)||c.dispose()}):l&&!this.sharedMats.has(l)&&l.dispose?.()}}),this.spawnSegment()}}spawnTrafficUntil(t){const i=Math.min(1,this.playerZ/5e3),a=this.theme.trafficDensityMul,l=26/a,c=52/a;for(;this.trafficSpawnZ<t;){const f=oe(l,c)-i*6;this.trafficSpawnZ+=Math.max(14,f);const p=Math.random();let m;p<.62?m=1:p<.92?m=2:m=Math.min(3,2+Math.floor(i*1.5)),m=Math.min(m,Or.length-1);const d=[0,1,2,3];for(let x=d.length-1;x>0;x--){const g=Math.floor(Math.random()*(x+1));[d[x],d[g]]=[d[g],d[x]]}const v=d.slice(0,m);for(const x of v){const g=this.pickTrafficVariant(i),y=oe(-6,6);this.spawnTrafficCar(x,this.trafficSpawnZ+y,g)}}}pickTrafficVariant(t){const i=this.level,a=[{v:"sedan",w:28},{v:"taxi",w:13},{v:"muscle",w:10},{v:"van",w:11},{v:"police",w:7+i*2},{v:"sport",w:8+i*1.5},{v:"truck",w:8+t*6},{v:"bus",w:5+t*5+i*.5},{v:"semi",w:4+t*8+i},{v:"monster",w:i>=3?4+i:0},{v:"tank",w:i>=4?3+i:0}],l=a.reduce((f,p)=>f+p.w,0);let c=Math.random()*l;for(const f of a)if(c-=f.w,c<=0)return f.v;return"sedan"}spawnTrafficCar(t,i,a){let l,c,f,p,m;const d=[2764864,5583684,3364198,6702114,4465254,2245751,5588002,5583616,6955554,2245666];switch(a){case"police":l=2.05,c=4.7,f=1.1,p=50,m=1118515;break;case"taxi":l=2,c=4.6,f=1.1,p=35,m=16765952;break;case"van":l=2.15,c=5.2,f=1.55,p=60,m=Ni(d);break;case"sport":l=1.95,c=4.4,f=.85,p=30,m=Ni([16720418,16753920,61695,16777215,1118481]);break;case"truck":l=2.5,c=7.6,f=2.2,p=90,m=Ni(d);break;case"semi":l=2.6,c=8.4,f=2.4,p=130,m=Ni([13378082,2245751,2236962,5583616]);break;case"monster":l=2.5,c=5.4,f=1.5,p=110,m=Ni([4500002,11158562,2236996]);break;case"tank":l=2.9,c=6.4,f=1.7,p=180,m=Ni([4478276,6706500,3359795]);break;case"bus":l=2.5,c=9.2,f=2.6,p=110,m=Ni([16755234,13386786,2258773,2245751]);break;case"muscle":l=2.05,c=4.9,f=1.05,p=55,m=Ni([16720418,2236962,2245768,8930304,3836474,16755234]);break;default:l=2,c=4.5,f=1.05,p=35,m=Ni(d)}const v=["truck","semi","monster","tank","bus"].includes(a),x=Qh({color:m,width:l,length:c,height:f,isTruck:a==="truck"||a==="semi",isMonster:a==="monster"||a==="tank",variant:a}),g=Or[t];x.group.position.set(g,0,i),x.group.rotation.y=Math.PI,this.scene.add(x.group);const y=Math.random()<.65,b=a==="sport"?1.4:a==="muscle"?1.25:a==="police"?1.2:a==="semi"||a==="tank"?.7:a==="bus"?.75:a==="monster"?.85:1,C=(v?oe(8,16):oe(12,22))*b*this.theme.trafficSpeedMul,S=y?-C:C*.5;y||(x.group.rotation.y=0);const _={parts:x,laneIdx:t,position:x.group.position,velocity:new K(0,0,S),width:l,length:c,alive:!0,health:p,isLarge:v,swayPhase:Math.random()*Math.PI*2,swerveBias:oe(-.6,.6)};this.traffic.push(_)}spawnPowersUntil(t){for(;this.powerSpawnZ<t;){this.powerSpawnZ+=oe(70,140);const a=Ni(["nitro","magnet","repair","mega"]),l=Math.floor(Math.random()*Or.length);this.spawnPower(Or[l],this.powerSpawnZ,a)}}spawnPower(t,i,a){const l=new Fs,f={nitro:61695,magnet:16722902,repair:6225788,mega:16765952}[a],p=new be({color:f,emissive:f,emissiveIntensity:1.6,metalness:.3,roughness:.3}),m=new qt(new rp(.7,0),p);l.add(m);const d=new be({color:f,emissive:f,emissiveIntensity:1,transparent:!0,opacity:.7}),v=new qt(new lp(1.1,.08,6,18),d);v.rotation.x=Math.PI/2,l.add(v),l.position.set(t,1.4,i),this.scene.add(l),this.powers.push({group:l,position:l.position,kind:a,alive:!0,spinPhase:Math.random()*Math.PI*2})}spawnBarriersUntil(t){for(;this.barrierSpawnZ<t;){this.barrierSpawnZ+=oe(180,320);const i=Math.random()<.4?2:1,a=[0,1,2,3];for(let l=a.length-1;l>0;l--){const c=Math.floor(Math.random()*(l+1));[a[l],a[c]]=[a[c],a[l]]}for(let l=0;l<i;l++){const c=a[l];this.spawnBarrier(Or[c],this.barrierSpawnZ)}}}spawnBarrier(t,i){if(Math.random()<.55){const l=new be({color:16724736,emissive:16724736,emissiveIntensity:.6,roughness:.6}),c=new qt(new Xi(.55,.55,1.3,12),l);c.position.set(t,.65,i),this.scene.add(c),this.barriers.push({mesh:c,position:c.position,width:1.1,length:1.1,alive:!0,health:1})}else{const l=new be({color:16755234,emissive:16729088,emissiveIntensity:.4,roughness:.7}),c=new qt(new ze(1.6,1,1),l);c.position.set(t,.5,i),this.scene.add(c),this.barriers.push({mesh:c,position:c.position,width:1.6,length:1,alive:!0,health:2})}}loop=()=>{this.rafId=requestAnimationFrame(this.loop);let t=this.clock.getDelta();t>.08&&(t=.08),this.status==="playing"?this.updatePlaying(t):this.status==="paused"||(this.status==="gameover"?this.updatePostGame(t):this.updateIdle(t)),this.renderer.render(this.scene,this.camera)};updateIdle(t){this.elapsed+=t;const i=18;this.camera.position.x=Math.sin(this.elapsed*.25)*i,this.camera.position.z=-12+Math.cos(this.elapsed*.25)*5,this.camera.position.y=8,this.camera.lookAt(0,1.5,8)}updatePostGame(t){this.elapsed+=t,this.camera.position.y=wi.lerp(this.camera.position.y,14,t*1.4),this.camera.position.x=Math.sin(this.elapsed*.4)*7,this.camera.lookAt(this.playerGroup.position.x,1.5,this.playerGroup.position.z),this.updateDebris(t*.4),this.updateParticles(t*.4)}updatePlaying(t){this.elapsed+=t;let i=0;(this.keys.ArrowLeft||this.keys.KeyA)&&(i-=1),(this.keys.ArrowRight||this.keys.KeyD)&&(i+=1),i+=this.mobileSteer,i=ya(i,-1,1),i=-i;let a=!!(this.keys.Space||this.keys.ShiftLeft||this.keys.ShiftRight||this.mobileBoost);const l=!!(this.keys.KeyS||this.keys.ArrowDown||this.mobileBrake),c=this.slowMo>0?.4:1,f=t*c;this.slowMo>0&&(this.slowMo-=t);let p=1;a&&this.boost>5?(this.boost=Math.max(0,this.boost-28*t),p=1.55,this.boostActive=!0):(this.boostActive=!1,this.boost=Math.min(this.boostMax,this.boost+11*t)),this.nitroActive>0&&(this.nitroActive-=t,p=Math.max(p,1.85));const m=this.theme.playerSpeedBonus;let d=(this.maxSpeed+m)*p;l&&(d*=.45);const v=Math.min(1.4,1+this.playerZ/8e3),x=l?5.5:2.5;this.playerSpeed=wi.damp(this.playerSpeed,Math.min(d,22*v+(this.maxSpeed+m)*.55*p+18*(this.boostActive?1:0)),x,f),this.playerSpeed=ya(this.playerSpeed,l?12:16,160),this.playerZ+=this.playerSpeed*f,this.playerGroup.position.z=this.playerZ;const g=19+this.upgrades.engine*.6,y=i!==0?14:18,b=i*g;this.steerVel=wi.damp(this.steerVel,b,y,f),this.playerX+=this.steerVel*f;const C=Sn-this.playerHalfW+.4;this.playerX>C?(this.playerX=C,this.steerVel=Math.min(0,this.steerVel)*.4):this.playerX<-C&&(this.playerX=-C,this.steerVel=Math.max(0,this.steerVel)*.4),this.playerGroup.position.x=this.playerX;const S=ya(-this.steerVel/14,-.35,.35);this.playerGroup.rotation.z=wi.damp(this.playerGroup.rotation.z,S,8,f),this.playerGroup.rotation.y=wi.damp(this.playerGroup.rotation.y,ya(this.steerVel/30,-.18,.18),8,f);const _=this.megaActive>0?1.6:1;for(this.playerGroup.scale.setScalar(wi.damp(this.playerGroup.scale.x,_,6,f)),this.megaActive>0&&(this.megaActive-=t),this.magnetActive>0&&(this.magnetActive-=t),this.invuln>0&&(this.invuln-=t),this.hitFlash>0&&(this.hitFlash-=t),this.starField&&(this.starField.position.z=this.playerZ),this.moon&&(this.moon.position.z=this.playerZ+320),this.moonGlow&&(this.moonGlow.position.z=this.playerZ+320),this.recycleSegments();this.nextSegmentZ<this.playerZ+Jv*un;)this.spawnSegment();this.spawnTrafficUntil(this.playerZ+tx),this.spawnPowersUntil(this.playerZ+280),this.spawnBarriersUntil(this.playerZ+360),this.updateTraffic(f),this.updateScraps(f),this.updatePowers(f),this.updateBarriers(f),this.updateDebris(f),this.updateParticles(f),this.checkCollisions(),this.score+=this.playerSpeed*f*.9,this.chainTimer>0&&(this.chainTimer-=t,this.chainTimer<=0&&(this.chainCount>this.bestChain&&(this.bestChain=this.chainCount),this.chainCount=0));const T=6.5+(this.megaActive>0?2.5:0),D=-10-(this.boostActive||this.nitroActive>0?2:0),U=this.playerX*.55;this.camera.position.x=wi.damp(this.camera.position.x,U,4,t),this.camera.position.y=wi.damp(this.camera.position.y,T,4,t),this.camera.position.z=wi.damp(this.camera.position.z,this.playerZ+D,6,t),this.shakeAmount>1e-4?(this.camera.position.x+=(Math.random()-.5)*this.shakeAmount,this.camera.position.y+=(Math.random()-.5)*this.shakeAmount,this.shakeAmount*=Math.pow(8e-4,t)):this.shakeAmount=0,this.camera.lookAt(this.playerX,1.6,this.playerZ+18);const P=ya(this.playerSpeed/130,0,1);this.sound.setEngineParams(P,this.boostActive||this.nitroActive>0?1:0),this.checkLevelUp();const N=this.computeActivePower(),z=$o[this.level]?ya((this.playerZ-this.levelStartZ)/this.theme.distance,0,1):1;this.callbacks.onHud({distance:Math.floor(this.playerZ),score:Math.floor(this.score),multiplier:this.computeMultiplier(),health:this.health,maxHealth:this.maxHealth,scrap:this.scrap,boost:this.boost,boostMax:this.boostMax,speedKmh:Math.floor(this.playerSpeed*3.6),activePower:N,status:this.status,level:this.level,levelName:this.theme.shortName,levelProgress:z})}computeMultiplier(){return Math.max(1,this.chainCount>0?this.chainCount:1)}computeActivePower(){return this.megaActive>0?{kind:"mega",remaining:this.megaActive,duration:6}:this.nitroActive>0?{kind:"nitro",remaining:this.nitroActive,duration:4}:this.magnetActive>0?{kind:"magnet",remaining:this.magnetActive,duration:8}:null}runScrapEarned(){return this.scrap}updateTraffic(t){for(let i=this.traffic.length-1;i>=0;i--){const a=this.traffic[i];a.position.z+=a.velocity.z*t,a.swayPhase+=t*1.8;const l=Or[a.laneIdx]+Math.sin(a.swayPhase)*.15+a.swerveBias*0;a.position.x=wi.damp(a.position.x,l,4,t),(a.position.z<this.playerZ-60||a.position.z>this.playerZ+tx+60)&&(this.scene.remove(a.parts.group),this.disposeCarParts(a.parts),this.traffic.splice(i,1))}}updatePowers(t){for(let i=this.powers.length-1;i>=0;i--){const a=this.powers[i];a.spinPhase+=t,a.group.rotation.y+=t*1.8,a.group.position.y=1.4+Math.sin(a.spinPhase*2.2)*.25,(a.position.z<this.playerZ-30||!a.alive)&&(this.scene.remove(a.group),this.powers.splice(i,1))}}updateBarriers(t){for(let i=this.barriers.length-1;i>=0;i--){const a=this.barriers[i];(!a.alive||a.position.z<this.playerZ-30)&&(this.scene.remove(a.mesh),this.barriers.splice(i,1))}}updateScraps(t){for(let i=this.scraps.length-1;i>=0;i--){const a=this.scraps[i];a.age+=t;const l=this.playerX-a.position.x,c=this.playerZ-a.position.z,f=Math.hypot(l,c),p=this.magnetActive>0?22:5;if(f<p){const d=(this.magnetActive>0?60:18)/Math.max(1.5,f);a.velocity.x+=l/Math.max(.001,f)*d*t,a.velocity.z+=c/Math.max(.001,f)*d*t}a.velocity.y-=18*t,a.velocity.x*=Math.pow(.18,t),a.velocity.z=wi.lerp(a.velocity.z,this.playerSpeed*.6,.25*t),a.position.addScaledVector(a.velocity,t),a.position.y<.3&&(a.position.y=.3,a.velocity.y*=-.4),a.mesh.rotation.x+=t*4,a.mesh.rotation.y+=t*5,f<2.5&&Math.abs(a.position.y-1)<2&&(this.scrap+=a.value,this.score+=a.value*5,this.callbacks.onFloatingScore(`+${a.value} scrap`,"#5eff7c"),this.sound.pickup(1+Math.random()*.4),this.scene.remove(a.mesh),a.alive=!1),(!a.alive||a.age>12||a.position.z<this.playerZ-25)&&(a.alive&&this.scene.remove(a.mesh),this.scraps.splice(i,1))}}updateDebris(t){for(let i=this.debris.length-1;i>=0;i--){const a=this.debris[i];a.life-=t,a.velocity.y-=28*t,a.mesh.position.addScaledVector(a.velocity,t),a.mesh.rotation.x+=a.angularVelocity.x*t,a.mesh.rotation.y+=a.angularVelocity.y*t,a.mesh.rotation.z+=a.angularVelocity.z*t,a.mesh.position.y<.2&&(a.mesh.position.y=.2,a.velocity.y*=-.35,a.velocity.x*=.6,a.velocity.z*=.7),a.life<=0&&(this.scene.remove(a.mesh),a.mesh.geometry.dispose(),a.mesh.material.dispose(),this.debris.splice(i,1))}}updateParticles(t){for(let i=this.particles.length-1;i>=0;i--){const a=this.particles[i];a.life-=t,a.mesh.position.addScaledVector(a.velocity,t),a.velocity.multiplyScalar(Math.pow(.05,t)),a.velocity.y+=4*t;const l=ya(a.life/a.maxLife,0,1);a.mesh.scale.setScalar(l*a.shrink);const c=a.mesh.material;c.opacity=l*.95,a.life<=0&&(this.scene.remove(a.mesh),a.mesh.geometry.dispose(),c.dispose(),this.particles.splice(i,1))}}checkCollisions(){const t=this.playerX,i=this.playerZ,a=this.playerHalfW*(this.megaActive>0?1.6:1),l=this.playerHalfL*(this.megaActive>0?1.6:1);for(const c of this.traffic){if(!c.alive)continue;const f=c.position.x,p=c.position.z,m=c.width/2,d=c.length/2;Math.abs(t-f)<a+m-.05&&Math.abs(i-p)<l+d-.05&&this.onTrafficSmash(c)}for(const c of this.powers)c.alive&&Math.abs(t-c.position.x)<a+1.4&&Math.abs(i-c.position.z)<l+1.4&&this.onPowerCollect(c);for(const c of this.barriers)c.alive&&Math.abs(t-c.position.x)<a+c.width/2-.05&&Math.abs(i-c.position.z)<l+c.length/2-.05&&this.onBarrierSmash(c)}onTrafficSmash(t){if(!t.alive)return;const i=this.megaActive>0,a=(i?1e3:50)*this.smashMultiplier;t.health-=a;let l=t.isLarge?18:10;(this.invuln>0||i)&&(l=0),l=l*(1-this.upgrades.bumper*.08),l>0&&(this.health=Math.max(0,this.health-l),this.invuln=.35,this.hitFlash=.18,this.shakeAmount+=.6,this.callbacks.onShake(.6),this.sound.crash(.6),this.applyPlayerDamageVisual()),t.health<=0?this.destroyTrafficCar(t,i?1.4:1):(this.spawnDebris(t.position,t.isLarge?6:3,11184810,.6),this.sound.crash(.3)),this.health<=0&&this.killPlayer()}onBarrierSmash(t){if(t.alive){if(t.health-=1,t.health<=0){this.scene.remove(t.mesh),t.alive=!1;const i=t.position.clone();this.spawnExplosion(i,1),this.applyExplosionDamage(i,7+this.upgrades.explosive*1.4),this.sound.explosion(.8),this.score+=80+this.upgrades.explosive*10,this.callbacks.onFloatingScore(`+${80+this.upgrades.explosive*10}`,"#ffd400"),this.shakeAmount+=.8,this.callbacks.onShake(.8)}else this.sound.crash(.5),this.spawnDebris(t.position,4,16742195,.4);this.health=Math.max(0,this.health-4*(1-this.upgrades.bumper*.08)),this.health<=0&&this.killPlayer()}}destroyTrafficCar(t,i){if(!t.alive)return;t.alive=!1,this.scene.remove(t.parts.group),this.disposeCarParts(t.parts);const a=t.position.clone();a.y=1;const l=(t.isLarge?1.4:.9)*i;this.spawnExplosion(a,l),this.sound.explosion(.55+l*.4),this.chainCount+=1,this.chainTimer=1.6,this.chainCount>this.bestChain&&(this.bestChain=this.chainCount);const c=(t.isLarge?220:120)*this.smashMultiplier,f=Math.pow(this.chainCount,1.35),p=Math.floor(c*f*i);this.score+=p,this.callbacks.onFloatingScore(this.chainCount>=2?`x${this.chainCount} CHAIN! +${p}`:`+${p}`,this.chainCount>=5?"#ff2bd6":this.chainCount>=2?"#ffd400":"#ffffff"),this.chainCount>=5?(this.slowMo=.55,this.shakeAmount+=1.2,this.callbacks.onShake(1.2),this.callbacks.onChainEvent(this.chainCount)):this.chainCount>=3&&(this.shakeAmount+=.5,this.callbacks.onShake(.5),this.callbacks.onChainEvent(this.chainCount)),this.spawnDebris(a,t.isLarge?14:8,t.parts.body.material instanceof be?t.parts.body.material.color.getHex():8947848,1);const m=Math.floor((t.isLarge?4:2)+Math.random()*3);for(let v=0;v<m;v++)this.spawnScrap(a,t.isLarge?3:1);const d=(t.isLarge?7:5)+this.upgrades.explosive*1.2;this.applyExplosionDamage(a,d)}applyExplosionDamage(t,i){for(const a of this.traffic){if(!a.alive)continue;const l=a.position.x-t.x,c=a.position.z-t.z,f=Math.hypot(l,c);if(f<i){const p=(i-f)*22;a.health-=p,a.health<=0?this.destroyTrafficCar(a,1):(a.parts.group.rotation.z+=oe(-.2,.2),a.parts.body.material instanceof be&&a.parts.body.material.color.lerp(new de(2236962),.15))}}for(const a of this.barriers){if(!a.alive)continue;const l=a.position.x-t.x,c=a.position.z-t.z;Math.hypot(l,c)<i*.9&&(a.health=0,this.onBarrierSmash(a))}}onPowerCollect(t){switch(t.alive=!1,this.sound.powerup(),t.kind){case"nitro":this.nitroActive=4,this.boost=this.boostMax,this.sound.nitro(),this.callbacks.onFloatingScore("NITRO!","#00f0ff"),this.score+=150;break;case"magnet":this.magnetActive=8,this.callbacks.onFloatingScore("MAGNET!","#ff2bd6"),this.score+=100;break;case"repair":this.health=Math.min(this.maxHealth,this.health+45),this.callbacks.onFloatingScore("+REPAIR","#5eff7c"),this.score+=80;break;case"mega":this.megaActive=6,this.callbacks.onFloatingScore("MEGA SMASH!","#ffd400"),this.score+=250,this.shakeAmount+=.8,this.callbacks.onShake(.8);break}}killPlayer(){this.status==="playing"&&(this.spawnExplosion(this.playerGroup.position.clone().add(new K(0,1,0)),2.4),this.sound.explosion(1.4),this.shakeAmount+=2.5,this.callbacks.onShake(2.5),this.spawnDebris(this.playerGroup.position,30,kc[this.upgrades.paint]??16722902,1.6),this.playerGroup.visible=!1,this.chainCount>this.bestChain&&(this.bestChain=this.chainCount),this.endRun())}applyPlayerDamageVisual(){const t=ya(this.health/this.maxHealth,0,1);if(this.playerParts.damageMaterial){const i=this.playerParts.damageMaterial,a=new de(kc[this.upgrades.paint]??16722902),l=new de(1118481);i.color.copy(a).lerp(l,1-t),i.emissiveIntensity=.05+(1-t)*.4}this.playerParts.body.position.y=.85+(1-t)*.05+Math.random()*.04*(1-t),t<.4&&Math.random()<.6&&this.spawnParticleSmoke(this.playerGroup.position.clone().add(new K(oe(-.6,.6),1.4,-1.5)))}spawnExplosion(t,i){const a=new os({color:16755251,transparent:!0,opacity:.95}),l=new qt(new ss(2*i,10,8),a);l.position.copy(t),this.scene.add(l),this.particles.push({mesh:l,velocity:new K(0,1,0),life:.55,maxLife:.55,shrink:1.5});const c=Math.floor(14*i);for(let p=0;p<c;p++){const m=Math.random()<.5?16765952:16742912,d=new os({color:m,transparent:!0,opacity:1}),v=new ss(.18+Math.random()*.18,5,4),x=new qt(v,d);x.position.copy(t),this.scene.add(x),this.particles.push({mesh:x,velocity:new K(oe(-1,1),oe(.4,1.6),oe(-1,1)).multiplyScalar(oe(8,18)*i),life:oe(.5,1),maxLife:1,shrink:1})}const f=Math.floor(5*i);for(let p=0;p<f;p++)this.spawnParticleSmoke(t.clone().add(new K(oe(-.6,.6),oe(.3,1),oe(-.6,.6))))}spawnParticleSmoke(t){const i=new os({color:2236979,transparent:!0,opacity:.9}),a=new ss(oe(.4,.9),6,5),l=new qt(a,i);l.position.copy(t),this.scene.add(l),this.particles.push({mesh:l,velocity:new K(oe(-1,1),oe(.5,1.5),oe(-1,1)).multiplyScalar(oe(.6,1.6)),life:oe(.9,1.6),maxLife:1.5,shrink:2})}spawnDebris(t,i,a,l){for(let c=0;c<i;c++){const f=new be({color:a,roughness:.6,metalness:.4,emissive:a,emissiveIntensity:.18}),p=oe(.18,.55)*l,m=new ze(p,p*oe(.6,1.4),p*oe(.6,1.4)),d=new qt(m,f);d.position.copy(t),d.position.y+=oe(.2,1.5),this.scene.add(d),this.debris.push({mesh:d,velocity:new K(oe(-1,1),oe(.6,1.6),oe(-1,1)).multiplyScalar(oe(6,15)*l),angularVelocity:new K(oe(-6,6),oe(-6,6),oe(-6,6)),life:oe(1.2,2.5),maxLife:2.5})}}spawnScrap(t,i){const a=new be({color:6225788,emissive:6225788,emissiveIntensity:1.2,metalness:.4,roughness:.3}),l=new qt(new op(.32,0),a);l.position.copy(t),l.position.y+=.6,this.scene.add(l),this.scraps.push({mesh:l,position:l.position,velocity:new K(oe(-3,3),oe(2,5),oe(-1,3)),alive:!0,age:0,value:i})}disposeCarParts(t){t.group.traverse(i=>{const a=i;if(a.isMesh){a.geometry?.dispose?.();const l=a.material;Array.isArray(l)?l.forEach(c=>c.dispose()):l?.dispose?.()}})}}class CA{ctx=null;master=null;engineOsc=null;engineGain=null;engineFilter=null;muted=!1;started=!1;musicGain=null;musicTimer=null;musicLevel=1;musicBeat=0;constructor(t=!1){this.muted=t}ensure(){if(this.started&&!this.ctx)try{const t=(window.AudioContext??window.webkitAudioContext)||null;if(!t)return;this.ctx=new t,this.master=this.ctx.createGain(),this.master.gain.value=this.muted?0:.55,this.master.connect(this.ctx.destination)}catch{this.ctx=null}}start(){this.started=!0,this.ensure(),this.ctx&&this.ctx.state==="suspended"&&this.ctx.resume().catch(()=>{})}setMuted(t){this.muted=t,this.master&&(this.master.gain.value=t?0:.55)}startEngine(){if(this.ensure(),!this.ctx||!this.master||this.engineOsc)return;const t=this.ctx.createOscillator();t.type="sawtooth",t.frequency.value=70;const i=this.ctx.createBiquadFilter();i.type="lowpass",i.frequency.value=480,i.Q.value=6;const a=this.ctx.createGain();a.gain.value=0,t.connect(i),i.connect(a),a.connect(this.master),t.start(),this.engineOsc=t,this.engineGain=a,this.engineFilter=i}stopEngine(){if(this.engineOsc){try{this.engineOsc.stop()}catch{}this.engineOsc.disconnect(),this.engineOsc=null}this.engineGain&&(this.engineGain.disconnect(),this.engineGain=null),this.engineFilter&&(this.engineFilter.disconnect(),this.engineFilter=null)}setEngineParams(t,i){if(!this.engineOsc||!this.engineGain||!this.engineFilter||!this.ctx)return;const a=this.ctx.currentTime,l=60+t*220+i*90,c=380+t*1400+i*800,f=.05+t*.16+i*.12;this.engineOsc.frequency.linearRampToValueAtTime(l,a+.08),this.engineFilter.frequency.linearRampToValueAtTime(c,a+.08),this.engineGain.gain.linearRampToValueAtTime(f,a+.08)}crash(t=.6){if(this.ensure(),!this.ctx||!this.master)return;const i=this.ctx.currentTime,a=this.ctx.createOscillator();a.type="sine",a.frequency.setValueAtTime(160,i),a.frequency.exponentialRampToValueAtTime(40,i+.18);const l=this.ctx.createGain();l.gain.setValueAtTime(1e-4,i),l.gain.exponentialRampToValueAtTime(.6*t,i+.01),l.gain.exponentialRampToValueAtTime(1e-4,i+.4),a.connect(l),l.connect(this.master),a.start(i),a.stop(i+.45);const f=this.ctx.createBuffer(1,Math.floor(this.ctx.sampleRate*.25),this.ctx.sampleRate),p=f.getChannelData(0);for(let x=0;x<p.length;x++)p[x]=(Math.random()*2-1)*Math.pow(1-x/p.length,2);const m=this.ctx.createBufferSource();m.buffer=f;const d=this.ctx.createBiquadFilter();d.type="bandpass",d.frequency.value=1800+t*1200,d.Q.value=1.2;const v=this.ctx.createGain();v.gain.value=.45*t,m.connect(d),d.connect(v),v.connect(this.master),m.start(i)}explosion(t=1){if(this.ensure(),!this.ctx||!this.master)return;const i=this.ctx.currentTime,a=this.ctx.createOscillator();a.type="sine",a.frequency.setValueAtTime(110,i),a.frequency.exponentialRampToValueAtTime(28,i+.55);const l=this.ctx.createGain();l.gain.setValueAtTime(1e-4,i),l.gain.exponentialRampToValueAtTime(.85*t,i+.02),l.gain.exponentialRampToValueAtTime(1e-4,i+.7),a.connect(l),l.connect(this.master),a.start(i),a.stop(i+.75);const f=this.ctx.createBuffer(1,Math.floor(this.ctx.sampleRate*.6),this.ctx.sampleRate),p=f.getChannelData(0);for(let x=0;x<p.length;x++){const g=Math.pow(1-x/p.length,1.6);p[x]=(Math.random()*2-1)*g}const m=this.ctx.createBufferSource();m.buffer=f;const d=this.ctx.createBiquadFilter();d.type="lowpass",d.frequency.setValueAtTime(2200,i),d.frequency.exponentialRampToValueAtTime(220,i+.55);const v=this.ctx.createGain();v.gain.value=.55*t,m.connect(d),d.connect(v),v.connect(this.master),m.start(i)}pickup(t=1){if(this.ensure(),!this.ctx||!this.master)return;const i=this.ctx.currentTime,a=this.ctx.createOscillator();a.type="triangle",a.frequency.setValueAtTime(880*t,i),a.frequency.exponentialRampToValueAtTime(1400*t,i+.08);const l=this.ctx.createGain();l.gain.setValueAtTime(1e-4,i),l.gain.exponentialRampToValueAtTime(.35,i+.01),l.gain.exponentialRampToValueAtTime(1e-4,i+.18),a.connect(l),l.connect(this.master),a.start(i),a.stop(i+.2)}powerup(){if(this.ensure(),!this.ctx||!this.master)return;const t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="sawtooth",i.frequency.setValueAtTime(220,t),i.frequency.exponentialRampToValueAtTime(1200,t+.32);const a=this.ctx.createGain();a.gain.setValueAtTime(1e-4,t),a.gain.exponentialRampToValueAtTime(.32,t+.04),a.gain.exponentialRampToValueAtTime(1e-4,t+.42);const l=this.ctx.createBiquadFilter();l.type="bandpass",l.frequency.value=900,l.Q.value=4,i.connect(l),l.connect(a),a.connect(this.master),i.start(t),i.stop(t+.45)}nitro(){if(this.ensure(),!this.ctx||!this.master)return;const t=this.ctx.currentTime,a=this.ctx.createBuffer(1,Math.floor(this.ctx.sampleRate*.55),this.ctx.sampleRate),l=a.getChannelData(0);for(let m=0;m<l.length;m++)l[m]=(Math.random()*2-1)*(1-m/l.length);const c=this.ctx.createBufferSource();c.buffer=a;const f=this.ctx.createBiquadFilter();f.type="highpass",f.frequency.setValueAtTime(400,t),f.frequency.exponentialRampToValueAtTime(2400,t+.45);const p=this.ctx.createGain();p.gain.value=.3,c.connect(f),f.connect(p),p.connect(this.master),c.start(t)}startMusic(t=1){if(this.ensure(),!this.ctx||!this.master||(this.musicLevel=t,this.musicGain||this.musicTimer!==null))return;const i=this.ctx.createGain();i.gain.value=.18,i.connect(this.master),this.musicGain=i,this.musicBeat=0;const l=60/110,c=()=>{if(!this.ctx||!this.musicGain)return;const f=this.ctx.currentTime+.04,p=Math.max(0,Math.min(4,this.musicLevel-1)),d=[82.4,110,87.3,98,65.4][p],v=[0,12,7,12,0,15,7,10],x=this.musicBeat,g=v[x%v.length],y=d*Math.pow(2,g/12),b=this.ctx.createOscillator();b.type="sawtooth",b.frequency.value=y;const C=this.ctx.createGain();C.gain.setValueAtTime(1e-4,f),C.gain.exponentialRampToValueAtTime(.42,f+.01),C.gain.exponentialRampToValueAtTime(1e-4,f+l*.7);const S=this.ctx.createBiquadFilter();if(S.type="lowpass",S.frequency.value=520+p*140,S.Q.value=4,b.connect(S),S.connect(C),C.connect(this.musicGain),b.start(f),b.stop(f+l*.85),x%2===0){const _=this.ctx.createOscillator();_.type="sine",_.frequency.setValueAtTime(130,f),_.frequency.exponentialRampToValueAtTime(42,f+.16);const T=this.ctx.createGain();T.gain.setValueAtTime(1e-4,f),T.gain.exponentialRampToValueAtTime(.7,f+.005),T.gain.exponentialRampToValueAtTime(1e-4,f+.28),_.connect(T),T.connect(this.musicGain),_.start(f),_.stop(f+.32)}if(x%4===2){const T=this.ctx.createBuffer(1,Math.floor(this.ctx.sampleRate*.18),this.ctx.sampleRate),D=T.getChannelData(0);for(let z=0;z<D.length;z++)D[z]=(Math.random()*2-1)*Math.pow(1-z/D.length,1.5);const U=this.ctx.createBufferSource();U.buffer=T;const P=this.ctx.createBiquadFilter();P.type="bandpass",P.frequency.value=1800,P.Q.value=1.4;const N=this.ctx.createGain();N.gain.value=.32,U.connect(P),P.connect(N),N.connect(this.musicGain),U.start(f)}{const T=this.ctx.createBuffer(1,Math.floor(this.ctx.sampleRate*.05),this.ctx.sampleRate),D=T.getChannelData(0);for(let z=0;z<D.length;z++)D[z]=(Math.random()*2-1)*Math.pow(1-z/D.length,2);const U=this.ctx.createBufferSource();U.buffer=T;const P=this.ctx.createBiquadFilter();P.type="highpass",P.frequency.value=7e3;const N=this.ctx.createGain();N.gain.value=x%2===1?.18:.1,U.connect(P),P.connect(N),N.connect(this.musicGain),U.start(f)}if(x%8===0){const _=d*2,T=[0,3,7,10];for(const D of T){const U=_*Math.pow(2,D/12),P=this.ctx.createOscillator();P.type="triangle",P.frequency.value=U;const N=this.ctx.createGain();N.gain.setValueAtTime(1e-4,f),N.gain.linearRampToValueAtTime(.06,f+.5),N.gain.exponentialRampToValueAtTime(1e-4,f+l*8*.92),P.connect(N),N.connect(this.musicGain),P.start(f),P.stop(f+l*8)}}if(p>=2){const _=this.ctx.createOscillator();_.type="square",_.frequency.value=d*4*Math.pow(2,g/12);const T=this.ctx.createGain();T.gain.setValueAtTime(1e-4,f),T.gain.exponentialRampToValueAtTime(.05+p*.012,f+.005),T.gain.exponentialRampToValueAtTime(1e-4,f+l*.45);const D=this.ctx.createBiquadFilter();D.type="lowpass",D.frequency.value=2200+p*600,_.connect(D),D.connect(T),T.connect(this.musicGain),_.start(f),_.stop(f+l*.5)}this.musicBeat=(this.musicBeat+1)%64};c(),this.musicTimer=window.setInterval(c,l*1e3)}stopMusic(){if(this.musicTimer!==null&&(clearInterval(this.musicTimer),this.musicTimer=null),this.musicGain&&this.ctx){const t=this.musicGain,i=this.ctx.currentTime;try{t.gain.cancelScheduledValues(i),t.gain.setValueAtTime(t.gain.value,i),t.gain.linearRampToValueAtTime(0,i+.25),setTimeout(()=>{try{t.disconnect()}catch{}},350)}catch{try{t.disconnect()}catch{}}this.musicGain=null}this.musicBeat=0}setMusicLevel(t){this.musicLevel=t}uiClick(){if(this.ensure(),!this.ctx||!this.master)return;const t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="square",i.frequency.value=720;const a=this.ctx.createGain();a.gain.setValueAtTime(1e-4,t),a.gain.exponentialRampToValueAtTime(.18,t+.005),a.gain.exponentialRampToValueAtTime(1e-4,t+.06),i.connect(a),a.connect(this.master),i.start(t),i.stop(t+.07)}}const Bx="chs3d_save_v1",tl={highScore:0,totalScrap:0,lastDistance:0,upgrades:{bumper:0,engine:0,nitroTank:0,explosive:0,paint:0,car:0},muted:!1,playerEntries:[],lastPlayerName:""};function DA(){if(typeof window>"u")return{...tl};try{const r=window.localStorage.getItem(Bx);if(!r)return{...tl};const t=JSON.parse(r);return{...tl,...t,upgrades:{...tl.upgrades,...t.upgrades??{}},playerEntries:Array.isArray(t.playerEntries)?t.playerEntries.slice(0,50):[],lastPlayerName:typeof t.lastPlayerName=="string"?t.lastPlayerName:""}}catch{return{...tl}}}function Xc(r){if(!(typeof window>"u"))try{window.localStorage.setItem(Bx,JSON.stringify(r))}catch{}}function NA(r,t){const i={...t,ts:Date.now()},a=[...r.playerEntries,i].sort((l,c)=>c.score-l.score).slice(0,20);return{...r,playerEntries:a,lastPlayerName:t.name}}const Xn=["K1NG_W3CK","NeonRipper","JunkLord","SmashGod_99","ChaosKitten","BumperBaron","TurboMoth","NitroNyx","RoadRogue","MegaCrash","PixelPyre","SkidQueen","Voltride","DemoDuke","RustWraith"],UA=[{name:Xn[0],score:1842330,distance:18420,level:9},{name:Xn[1],score:1421900,distance:15210,level:8},{name:Xn[2],score:1188450,distance:13140,level:7},{name:Xn[3],score:989720,distance:11980,level:7},{name:Xn[4],score:812010,distance:10240,level:6},{name:Xn[5],score:645500,distance:8810,level:5},{name:Xn[6],score:512880,distance:7640,level:5},{name:Xn[7],score:410300,distance:6220,level:4},{name:Xn[8],score:332140,distance:5330,level:4},{name:Xn[9],score:267900,distance:4410,level:3},{name:Xn[10],score:218640,distance:3980,level:3},{name:Xn[11],score:174200,distance:3240,level:3},{name:Xn[12],score:138770,distance:2710,level:2},{name:Xn[13],score:98410,distance:2180,level:2},{name:Xn[14],score:64300,distance:1540,level:1}];function LA(r){const t=UA.map(c=>({...c,ts:0})),i=r.map(c=>({entry:c,isPlayer:!0})),a=t.map(c=>({entry:c,isPlayer:!1}));return[...i,...a].sort((c,f)=>f.entry.score-c.entry.score).slice(0,12).map((c,f)=>({...c.entry,isPlayer:c.isPlayer,rank:f+1}))}function PA(r,t){if(r<=0)return!1;if(t.length<10)return!0;const i=t.slice(0,10).reduce((a,l)=>Math.min(a,l.score),1/0);return r>i}function OA({save:r,onPlay:t,onShop:i,onLeaderboard:a,onToggleMute:l}){const[c,f]=Xt.useState(!1);return Xt.useEffect(()=>{const p=setTimeout(()=>f(!0),400);return()=>clearTimeout(p)},[]),B.jsx("div",{className:"absolute inset-0 flex flex-col items-center justify-center px-6 py-8 z-20",style:{background:"radial-gradient(ellipse at center, rgba(42, 10, 58, 0.85) 0%, rgba(10, 6, 18, 0.98) 75%)"},children:B.jsxs("div",{className:"w-full max-w-3xl flex flex-col items-center",children:[B.jsxs("div",{className:"text-center mb-2",children:[B.jsx("div",{className:"neon-text-cyan text-xs sm:text-sm tracking-[0.3em] mb-2",children:"POST-APOCALYPSE EDITION"}),B.jsx("h1",{className:"neon-title text-5xl sm:text-7xl md:text-8xl leading-none",children:"CHAOS"}),B.jsx("h1",{className:"neon-title text-5xl sm:text-7xl md:text-8xl leading-none -mt-1 sm:-mt-2",children:"HIGHWAY"}),B.jsx("h2",{className:"neon-text-yellow text-3xl sm:text-5xl md:text-6xl mt-1 font-black tracking-wider",children:"SMASH 3D"})]}),B.jsx("p",{className:"text-center text-white/85 text-sm sm:text-base max-w-xl mt-5 px-2 leading-snug",children:"Rampage through 8 wild biomes of endless traffic. Smash cars, trigger chain explosions, tear through Toxic, Inferno, Frostbite, Desert and Galaxy zones, upgrade your wrecking machine, and climb the leaderboard."}),B.jsx("div",{className:"flex flex-wrap justify-center gap-x-5 gap-y-1 mt-4 text-[11px] sm:text-xs text-white/60 uppercase tracking-widest max-w-xl",children:c&&B.jsxs(B.Fragment,{children:[B.jsx("span",{children:"3D"}),B.jsx("span",{children:"•"}),B.jsx("span",{children:"Car Destruction"}),B.jsx("span",{children:"•"}),B.jsx("span",{children:"8 Biomes"}),B.jsx("span",{children:"•"}),B.jsx("span",{children:"Smash"}),B.jsx("span",{children:"•"}),B.jsx("span",{children:"Physics"}),B.jsx("span",{children:"•"}),B.jsx("span",{children:"Apocalypse"}),B.jsx("span",{children:"•"}),B.jsx("span",{children:"High Score"})]})}),B.jsx("button",{onClick:t,className:"neon-btn mt-7 px-12 py-4 text-2xl sm:text-3xl rounded-md pulse-glow",children:"▶ PLAY"}),B.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-5 w-full max-w-md",children:[B.jsx("button",{onClick:i,className:"neon-btn neon-btn-yellow px-4 py-3 text-base rounded-md",children:"🔧 GARAGE / SHOP"}),B.jsx("button",{onClick:a,className:"neon-btn neon-btn-cyan px-4 py-3 text-base rounded-md",children:"🏆 LEADERBOARD"})]}),B.jsxs("div",{className:"grid grid-cols-3 gap-2 mt-6 w-full max-w-md text-center",children:[B.jsxs("div",{className:"hud-pill rounded-md py-2",children:[B.jsx("div",{className:"text-[10px] uppercase tracking-widest text-cyan-300/80",children:"High Score"}),B.jsx("div",{className:"text-xl neon-text-yellow font-black",children:r.highScore.toLocaleString()})]}),B.jsxs("div",{className:"hud-pill rounded-md py-2",children:[B.jsx("div",{className:"text-[10px] uppercase tracking-widest text-cyan-300/80",children:"Last Run"}),B.jsxs("div",{className:"text-xl neon-text-cyan font-black",children:[r.lastDistance.toLocaleString(),"m"]})]}),B.jsxs("div",{className:"hud-pill rounded-md py-2",children:[B.jsx("div",{className:"text-[10px] uppercase tracking-widest text-cyan-300/80",children:"Scrap"}),B.jsx("div",{className:"text-xl neon-text-green font-black",children:r.totalScrap.toLocaleString()})]})]}),B.jsxs("div",{className:"flex items-center justify-center gap-3 mt-6 text-xs text-white/55",children:[B.jsx("button",{onClick:l,className:"px-3 py-1.5 rounded border border-white/30 hover:border-white/70 hover:text-white transition",children:r.muted?"🔇 Sound: OFF":"🔊 Sound: ON"}),B.jsx("span",{className:"hidden sm:inline",children:"|"}),B.jsx("span",{className:"hidden sm:inline",children:"Desktop: A/D or ←/→ steer · S/↓ brake · Space boost"}),B.jsx("span",{className:"sm:hidden",children:"Mobile: joystick + BRAKE / BOOST"})]})]})})}function IA({save:r,onClose:t}){const i=Xt.useMemo(()=>LA(r.playerEntries),[r.playerEntries]),a=r.playerEntries.length;return B.jsx("div",{className:"absolute inset-0 z-30 flex items-center justify-center p-4",style:{background:"rgba(5, 2, 12, 0.78)"},children:B.jsxs("div",{className:"panel rounded-xl p-6 w-full max-w-lg",children:[B.jsxs("div",{className:"flex items-center justify-between mb-4",children:[B.jsx("h3",{className:"neon-text-yellow text-2xl font-black",children:"🏆 LEADERBOARD"}),B.jsx("button",{onClick:t,className:"text-white/70 hover:text-white text-2xl leading-none",children:"×"})]}),B.jsx("div",{className:"text-xs text-white/55 mb-3 uppercase tracking-widest",children:"Top wreckers worldwide"}),B.jsxs("div",{className:"grid grid-cols-12 gap-2 px-3 pb-1.5 text-[10px] uppercase tracking-widest text-white/40",children:[B.jsx("div",{className:"col-span-1",children:"#"}),B.jsx("div",{className:"col-span-5",children:"Driver"}),B.jsx("div",{className:"col-span-2 text-center",children:"Lvl"}),B.jsx("div",{className:"col-span-4 text-right",children:"Score"})]}),B.jsx("ul",{className:"space-y-1.5 max-h-[55vh] overflow-y-auto scrollbar-thin pr-1",children:i.map(l=>B.jsxs("li",{className:`grid grid-cols-12 gap-2 items-center rounded px-3 py-2 ${l.isPlayer?"neon-text-pink border border-pink-500/60":"border border-white/10"}`,style:l.isPlayer?{background:"rgba(255, 43, 214, 0.12)"}:{background:"rgba(255,255,255,0.03)"},children:[B.jsxs("span",{className:`col-span-1 font-black ${l.rank<=3?"neon-text-yellow":"text-white/60"}`,children:["#",l.rank]}),B.jsxs("span",{className:"col-span-5 font-bold truncate flex items-center gap-1.5",children:[l.isPlayer&&B.jsx("span",{className:"text-[9px] uppercase tracking-widest neon-text-pink",children:"YOU"}),B.jsx("span",{className:"truncate",children:l.name})]}),B.jsxs("span",{className:"col-span-2 text-center text-xs neon-text-cyan font-mono font-black",children:["L",l.level]}),B.jsx("span",{className:"col-span-4 font-mono text-sm text-right",children:l.score.toLocaleString()})]},`${l.name}-${l.ts}-${l.rank}`))}),B.jsx("div",{className:"text-[10px] text-white/40 mt-3 text-center italic",children:a===0?"Finish a run to enter your name on the board!":`${a} of your runs on the board • Online ranks shown for motivation.`})]})})}const Ir={nitro:{label:"NITRO",color:"#00f0ff"},magnet:{label:"MAGNET",color:"#ff2bd6"},repair:{label:"REPAIR",color:"#5eff7c"},mega:{label:"MEGA SMASH",color:"#ffd400"}},Br=[{title:"STEER",desktopBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Use ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"A / D"})," or ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"←/→"})," to swerve between lanes."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Avoid heavy trucks — smash little cars instead."})]}),mobileBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Drag the ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"joystick"})," left or right to steer."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Avoid heavy trucks — smash little cars instead."})]})},{title:"BRAKE",desktopBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Hold ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"S"})," or ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"↓"})," to brake."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Slow down through tight traffic to thread the needle."})]}),mobileBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Tap & hold the ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"BRAKE"})," button to slow down."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Useful when traffic gets crowded."})]})},{title:"BOOST",desktopBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Hold ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"SPACE"})," or ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"SHIFT"})," for nitro boost."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Boosting drains the blue meter — pickups refill it."})]}),mobileBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Hold the ",B.jsx("span",{className:"neon-text-cyan font-bold",children:"BOOST"})," button for nitro."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Boosting drains the blue meter — pickups refill it."})]})},{title:"SMASH!",desktopBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Ram cars to ",B.jsx("span",{className:"neon-text-pink font-bold",children:"smash"})," them and build a chain."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Each level cleared rewards HP, boost & bonus points!"})]}),mobileBody:B.jsxs(B.Fragment,{children:[B.jsxs("div",{children:["Ram cars to ",B.jsx("span",{className:"neon-text-pink font-bold",children:"smash"})," them and build a chain."]}),B.jsx("div",{className:"text-xs text-white/60 mt-1",children:"Each level cleared rewards HP, boost & bonus points!"})]})}];function BA({hud:r,onPause:t,showTutorial:i,onDismissTutorial:a}){const[l,c]=Xt.useState(0),f=Xt.useRef(1),[p,m]=Xt.useState(0);if(Xt.useEffect(()=>{i&&m(0)},[i]),Xt.useEffect(()=>{r&&(r.multiplier>1&&r.multiplier!==f.current&&(c(g=>g+1),f.current=r.multiplier),r.multiplier<=1&&(f.current=1))},[r]),!r)return null;const d=Math.max(0,r.health/r.maxHealth*100),v=Math.max(0,r.boost/r.boostMax*100),x=r.activePower;return B.jsxs("div",{className:"ui-layer",children:[B.jsxs("div",{className:"absolute top-2 sm:top-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 sm:gap-2 pointer-events-none",children:[B.jsxs("div",{className:"flex items-center gap-2 sm:gap-3",children:[B.jsxs("div",{className:"hud-pill rounded-md px-3 py-1.5 text-center",children:[B.jsx("div",{className:"text-[9px] sm:text-[10px] uppercase tracking-widest text-cyan-300/80",children:"Distance"}),B.jsxs("div",{className:"text-sm sm:text-lg font-black neon-text-cyan font-mono",children:[r.distance.toLocaleString(),"m"]})]}),B.jsxs("div",{className:"hud-pill rounded-md px-4 py-1.5 text-center",style:{borderColor:"rgba(255, 212, 0, 0.65)",boxShadow:"0 0 10px rgba(255, 212, 0, 0.4)"},children:[B.jsx("div",{className:"text-[9px] sm:text-[10px] uppercase tracking-widest text-yellow-300/80",children:"Score"}),B.jsx("div",{className:"text-base sm:text-xl font-black neon-text-yellow font-mono",children:r.score.toLocaleString()})]}),B.jsxs("div",{className:"hud-pill rounded-md px-3 py-1.5 text-center",style:{borderColor:"rgba(94, 255, 124, 0.65)",boxShadow:"0 0 10px rgba(94, 255, 124, 0.35)"},children:[B.jsx("div",{className:"text-[9px] sm:text-[10px] uppercase tracking-widest text-green-300/80",children:"Scrap"}),B.jsx("div",{className:"text-sm sm:text-lg font-black neon-text-green font-mono",children:r.scrap.toLocaleString()})]})]}),B.jsxs("div",{className:"hud-pill rounded-md px-3 py-1 flex items-center gap-2",style:{borderColor:"rgba(255, 43, 214, 0.65)",boxShadow:"0 0 10px rgba(255, 43, 214, 0.35)"},children:[B.jsxs("div",{className:"text-[10px] sm:text-xs neon-text-pink font-black tracking-widest",children:["LV ",r.level]}),B.jsx("div",{className:"text-[10px] sm:text-xs text-white/85 font-bold tracking-wider",children:r.levelName}),B.jsx("div",{className:"w-16 sm:w-24 h-1 bg-white/15 rounded overflow-hidden",children:B.jsx("div",{className:"h-full",style:{width:`${Math.round(r.levelProgress*100)}%`,background:"linear-gradient(90deg, #ff2bd6, #ffd400)",boxShadow:"0 0 6px #ff2bd6"}})})]})]}),B.jsx("button",{onClick:t,"aria-label":"Pause",className:"absolute top-2 right-2 sm:top-4 sm:right-4 hud-pill rounded-md px-3 py-2 text-white text-sm font-black hover:bg-white/10",children:"⏸"}),r.multiplier>1&&B.jsx("div",{className:"absolute left-1/2 top-20 sm:top-24 -translate-x-1/2 pointer-events-none",style:{animation:"floatUp 1.4s ease-out infinite"},children:B.jsxs("div",{className:"neon-text-pink text-3xl sm:text-5xl font-black tracking-widest",children:["x",r.multiplier," CHAIN!"]})},l),x&&B.jsxs("div",{className:"absolute top-16 sm:top-20 left-3 hud-pill rounded-md px-3 py-1.5 pointer-events-none",style:{borderColor:x&&Ir[x.kind].color,boxShadow:`0 0 14px ${Ir[x.kind].color}`},children:[B.jsx("div",{className:"text-[10px] uppercase tracking-widest text-white/70",children:"Active"}),B.jsx("div",{className:"font-black text-sm",style:{color:Ir[x.kind].color},children:Ir[x.kind].label}),B.jsx("div",{className:"w-24 h-1 bg-white/20 rounded mt-1 overflow-hidden",children:B.jsx("div",{className:"h-full",style:{width:`${Math.min(100,x.remaining/x.duration*100)}%`,background:Ir[x.kind].color,boxShadow:`0 0 6px ${Ir[x.kind].color}`}})})]}),B.jsxs("div",{className:"absolute bottom-3 left-3 sm:bottom-5 sm:left-5 w-[55%] max-w-xs space-y-2 pointer-events-none",children:[B.jsxs("div",{children:[B.jsxs("div",{className:"flex justify-between items-baseline",children:[B.jsx("span",{className:"text-[10px] uppercase tracking-widest text-white/70",children:"Hull"}),B.jsxs("span",{className:"text-xs font-mono text-white/80",children:[Math.ceil(r.health)," / ",r.maxHealth]})]}),B.jsx("div",{className:"health-bar-bg rounded-md h-3 overflow-hidden mt-0.5",children:B.jsx("div",{className:"health-bar-fill h-full",style:{width:`${d}%`}})})]}),B.jsxs("div",{children:[B.jsxs("div",{className:"flex justify-between items-baseline",children:[B.jsx("span",{className:"text-[10px] uppercase tracking-widest text-white/70",children:"Boost"}),B.jsx("span",{className:"text-xs font-mono text-white/80",children:Math.ceil(r.boost)})]}),B.jsx("div",{className:"health-bar-bg rounded-md h-2 overflow-hidden mt-0.5",style:{borderColor:"rgba(0, 240, 255, 0.7)"},children:B.jsx("div",{className:"boost-bar-fill h-full",style:{width:`${v}%`}})})]})]}),B.jsxs("div",{className:"absolute bottom-3 right-3 sm:bottom-5 sm:right-5 hud-pill rounded-md px-3 py-1.5 text-right pointer-events-none",children:[B.jsx("div",{className:"text-[10px] uppercase tracking-widest text-cyan-300/80",children:"Speed"}),B.jsx("div",{className:"text-lg sm:text-2xl font-mono neon-text-cyan font-black",children:r.speedKmh}),B.jsx("div",{className:"text-[9px] text-white/50",children:"km/h"})]}),i&&(()=>{const g=Br[p]??Br[0],y=p>=Br.length-1;return B.jsx("div",{className:"absolute inset-0 z-30 flex items-center justify-center pointer-events-auto",style:{background:"rgba(0,0,0,0.45)"},children:B.jsxs("div",{className:"panel rounded-xl px-6 py-5 text-center w-[88%] max-w-sm",onClick:b=>b.stopPropagation(),children:[B.jsxs("div",{className:"text-[10px] tracking-[0.4em] text-white/60 mb-1",children:["STEP ",p+1," / ",Br.length]}),B.jsx("div",{className:"neon-text-pink font-black text-2xl mb-3",children:g.title}),B.jsx("div",{className:"text-sm text-white/85 leading-relaxed desktop-only mb-1",children:g.desktopBody}),B.jsx("div",{className:"text-sm text-white/85 leading-relaxed mobile-only mb-1",children:g.mobileBody}),B.jsx("div",{className:"flex justify-center gap-1.5 my-3",children:Br.map((b,C)=>B.jsx("span",{className:"rounded-full",style:{width:8,height:8,background:C===p?"#ff2bd6":"rgba(255,255,255,0.25)",boxShadow:C===p?"0 0 8px #ff2bd6":"none"}},C))}),B.jsxs("div",{className:"flex gap-2 justify-center",children:[B.jsx("button",{onClick:a,className:"hud-pill rounded-md px-3 py-2 text-xs font-bold text-white/70 hover:bg-white/10",children:"Skip"}),y?B.jsx("button",{onClick:a,className:"hud-pill rounded-md px-5 py-2 text-sm font-black neon-text-yellow hover:bg-white/10",style:{borderColor:"rgba(255, 212, 0, 0.65)"},children:"LET'S GO!"}):B.jsx("button",{onClick:()=>m(b=>Math.min(Br.length-1,b+1)),className:"hud-pill rounded-md px-5 py-2 text-sm font-black neon-text-cyan hover:bg-white/10",style:{borderColor:"rgba(0, 240, 255, 0.65)"},children:"Next ▸"})]})]})})})()]})}const Jh=60,ex=28;function FA({onSteer:r,onBoostHold:t,onBrakeHold:i,onPower:a}){const l=Xt.useRef(null),c=Xt.useRef(null),[f,p]=Xt.useState(!1),m=Xt.useRef(null),d=Xt.useRef(null);Xt.useEffect(()=>{const x=y=>{if(m.current===null||!d.current||!c.current)return;let b=null;for(let N=0;N<y.touches.length;N++)if(y.touches[N].identifier===m.current){b=y.touches[N];break}if(!b)return;const C=b.clientX-d.current.x,S=b.clientY-d.current.y,_=Math.hypot(C,S),T=Jh,D=_>T?C/_*T:C,U=_>T?S/_*T:S;c.current.style.transform=`translate(${D}px, ${U}px)`;const P=D/T;r(P)},g=y=>{if(m.current===null)return;let b=!1;for(let C=0;C<y.touches.length;C++)if(y.touches[C].identifier===m.current){b=!0;break}b||(m.current=null,d.current=null,p(!1),c.current&&(c.current.style.transform="translate(0px, 0px)"),r(0))};return window.addEventListener("touchmove",x,{passive:!1}),window.addEventListener("touchend",g),window.addEventListener("touchcancel",g),()=>{window.removeEventListener("touchmove",x),window.removeEventListener("touchend",g),window.removeEventListener("touchcancel",g)}},[r]);const v=x=>{if(m.current!==null)return;const g=x.changedTouches[0];if(m.current=g.identifier,l.current){const y=l.current.getBoundingClientRect();d.current={x:y.left+y.width/2,y:y.top+y.height/2}}p(!0),x.preventDefault()};return B.jsxs("div",{className:"ui-layer mobile-only",children:[B.jsx("div",{className:"absolute bottom-24 left-6",children:B.jsx("div",{ref:l,onTouchStart:v,className:"joystick-base rounded-full flex items-center justify-center touch-none select-none",style:{width:Jh*2+10,height:Jh*2+10},children:B.jsx("div",{ref:c,className:"joystick-knob rounded-full pointer-events-none",style:{width:ex*2,height:ex*2,transform:"translate(0,0)",opacity:f?1:.85}})})}),B.jsxs("div",{className:"absolute bottom-24 right-5 flex flex-col items-end gap-3",children:[B.jsx("button",{onTouchStart:x=>{x.preventDefault(),t(!0)},onTouchEnd:x=>{x.preventDefault(),t(!1)},onTouchCancel:x=>{x.preventDefault(),t(!1)},className:"touch-btn rounded-full text-base",style:{width:92,height:92},children:"BOOST"}),B.jsxs("div",{className:"flex gap-2 items-center",children:[B.jsx("button",{onTouchStart:x=>{x.preventDefault(),i(!0)},onTouchEnd:x=>{x.preventDefault(),i(!1)},onTouchCancel:x=>{x.preventDefault(),i(!1)},className:"touch-btn touch-btn-pink rounded-full text-xs",style:{width:64,height:64},children:"BRAKE"}),B.jsx("button",{onTouchStart:x=>{x.preventDefault(),a()},className:"touch-btn touch-btn-cyan rounded-full text-xs",style:{width:64,height:64},children:"SMASH"})]})]})]})}function zA({onResume:r,onShop:t,onMenu:i,muted:a,onToggleMute:l}){return B.jsx("div",{className:"absolute inset-0 z-30 flex items-center justify-center p-4",style:{background:"rgba(5, 2, 12, 0.75)"},children:B.jsxs("div",{className:"panel rounded-xl p-7 w-full max-w-sm text-center",children:[B.jsx("h3",{className:"neon-text-pink text-3xl font-black mb-1",children:"PAUSED"}),B.jsx("p",{className:"text-white/60 text-xs mb-5 tracking-widest",children:"Catch your breath, driver."}),B.jsxs("div",{className:"flex flex-col gap-3",children:[B.jsx("button",{onClick:r,className:"neon-btn px-6 py-3 rounded-md text-lg",children:"▶ RESUME"}),B.jsx("button",{onClick:t,className:"neon-btn neon-btn-yellow px-6 py-3 rounded-md text-lg",children:"🔧 GARAGE"}),B.jsx("button",{onClick:i,className:"neon-btn neon-btn-cyan px-6 py-3 rounded-md text-lg",children:"⌂ MAIN MENU"}),B.jsx("button",{onClick:l,className:"text-xs text-white/60 hover:text-white mt-1",children:a?"🔇 Sound: OFF":"🔊 Sound: ON"})]})]})})}const GA=[{key:"bumper",label:"Reinforced Bumper",color:"#ff2bd6",desc:"+25 hull, +damage on smash, less self-damage.",maxLevel:5,cost:r=>80+r*100},{key:"engine",label:"Turbocharged Engine",color:"#00f0ff",desc:"Higher top speed and snappier steering.",maxLevel:5,cost:r=>120+r*130},{key:"nitroTank",label:"Bigger Nitro Tank",color:"#ffd400",desc:"+35 boost capacity per level.",maxLevel:5,cost:r=>100+r*110},{key:"explosive",label:"Explosive Bumper",color:"#ff7a00",desc:"Larger explosion radius & chain bonus.",maxLevel:5,cost:r=>140+r*150}],HA=["Hot Pink","Cyan","Yellow","Crimson","Toxic Green","Orange","Purple","Chrome"],VA=[0,80,80,100,120,120,150,250],$h=["#ff2bd6","#00f0ff","#ffd400","#ff4422","#66ff66","#ff7a00","#9b5cff","#ffffff"];function kA({scrap:r,upgrades:t,onClose:i,onApply:a}){const[l,c]=Xt.useState(r),[f,p]=Xt.useState(t),m=(g,y,b)=>{l<y||f[g]>=b||(c(l-y),p({...f,[g]:f[g]+1}))},d=(g,y)=>{f.car>=g||l<y||(c(l-y),p({...f,car:g}))},v=(g,y)=>{l<y||(c(l-y),p({...f,paint:g}))},x=()=>{a(l,f),i()};return B.jsx("div",{className:"absolute inset-0 z-30 flex items-center justify-center p-3",style:{background:"rgba(5, 2, 12, 0.85)"},children:B.jsxs("div",{className:"panel rounded-xl p-5 w-full max-w-2xl max-h-[92vh] overflow-y-auto scrollbar-thin",children:[B.jsxs("div",{className:"flex items-center justify-between mb-3",children:[B.jsxs("div",{children:[B.jsx("h3",{className:"neon-text-yellow text-2xl sm:text-3xl font-black",children:"🔧 GARAGE"}),B.jsx("div",{className:"text-[10px] uppercase tracking-widest text-white/60",children:"Upgrade your wrecking machine"})]}),B.jsxs("div",{className:"hud-pill rounded-md px-3 py-1.5 text-right",style:{borderColor:"rgba(94, 255, 124, 0.65)",boxShadow:"0 0 8px rgba(94, 255, 124, 0.4)"},children:[B.jsx("div",{className:"text-[10px] uppercase text-green-300/80",children:"Scrap"}),B.jsx("div",{className:"text-lg font-black neon-text-green font-mono",children:l.toLocaleString()})]})]}),B.jsx("h4",{className:"text-sm font-black neon-text-cyan tracking-widest mt-1 mb-2",children:"CHASSIS"}),B.jsx("div",{className:"grid grid-cols-2 gap-2 mb-4",children:il.map((g,y)=>{const b=f.car>=y,C=f.car===y,S=!b&&l>=g.cost;return B.jsxs("div",{className:"rounded-md p-3 border",style:{borderColor:C?"#ffd400":b?"rgba(0, 240, 255, 0.5)":"rgba(255,255,255,0.15)",background:C?"rgba(255, 212, 0, 0.07)":"rgba(0,0,0,0.3)",boxShadow:C?"0 0 12px rgba(255,212,0,0.4)":void 0},children:[B.jsxs("div",{className:"flex items-baseline justify-between",children:[B.jsx("div",{className:"font-black text-base text-white",children:g.name}),B.jsxs("div",{className:"text-[10px] uppercase text-white/55",children:["Tier ",y+1]})]}),B.jsx("div",{className:"text-xs text-white/65 mt-1 leading-snug",children:g.description}),B.jsxs("div",{className:"flex flex-wrap gap-2 text-[10px] text-white/70 mt-2",children:[B.jsxs("span",{children:["HP ",g.baseHealth]}),B.jsxs("span",{children:["Smash x",g.baseSmash.toFixed(2)]})]}),B.jsx("div",{className:"mt-2",children:C?B.jsx("div",{className:"text-xs neon-text-yellow font-black",children:"EQUIPPED"}):b?B.jsx("button",{onClick:()=>p({...f,car:y}),className:"neon-btn neon-btn-cyan rounded px-3 py-1 text-xs w-full",children:"EQUIP"}):B.jsxs("button",{onClick:()=>d(y,g.cost),disabled:!S,className:"neon-btn rounded px-3 py-1 text-xs w-full disabled:opacity-40 disabled:cursor-not-allowed",children:["BUY · ",g.cost.toLocaleString()," scrap"]})})]},g.name)})}),B.jsx("h4",{className:"text-sm font-black neon-text-pink tracking-widest mt-3 mb-2",children:"UPGRADES"}),B.jsx("div",{className:"space-y-2",children:GA.map(g=>{const y=f[g.key],b=g.maxLevel,C=g.cost(y),S=y>=b,_=!S&&l>=C;return B.jsxs("div",{className:"rounded-md p-3 border border-white/10 flex items-center gap-3",style:{background:"rgba(0,0,0,0.3)"},children:[B.jsxs("div",{className:"flex-1 min-w-0",children:[B.jsx("div",{className:"font-black text-sm",style:{color:g.color},children:g.label}),B.jsx("div",{className:"text-xs text-white/65 leading-snug",children:g.desc}),B.jsx("div",{className:"flex gap-1 mt-1.5",children:Array.from({length:b}).map((T,D)=>B.jsx("div",{className:"h-1.5 w-6 rounded",style:{background:D<y?g.color:"rgba(255,255,255,0.12)",boxShadow:D<y?`0 0 6px ${g.color}`:void 0}},D))})]}),B.jsx("button",{onClick:()=>m(g.key,C,b),disabled:!_,className:"neon-btn rounded px-3 py-2 text-xs flex-shrink-0 disabled:opacity-40 disabled:cursor-not-allowed",style:{borderColor:g.color,boxShadow:`0 0 10px ${g.color}55`},children:S?"MAXED":`+1 · ${C}`})]},g.key)})}),B.jsx("h4",{className:"text-sm font-black neon-text-yellow tracking-widest mt-4 mb-2",children:"PAINT JOBS"}),B.jsx("div",{className:"grid grid-cols-4 sm:grid-cols-8 gap-2",children:HA.map((g,y)=>{const b=f.paint===y,C=VA[y],S=l>=C;return B.jsxs("button",{onClick:()=>v(y,C),disabled:!b&&!S,title:`${g} · ${C} scrap`,className:"rounded p-1 border-2 hover-elevate disabled:opacity-30",style:{borderColor:b?"#fff":"rgba(255,255,255,0.15)",boxShadow:b?`0 0 14px ${$h[y]}`:void 0,background:"rgba(0,0,0,0.4)"},children:[B.jsx("div",{className:"rounded h-8 w-full",style:{background:$h[y],boxShadow:`0 0 8px ${$h[y]}`}}),B.jsx("div",{className:"text-[9px] mt-1 text-white/70",children:b?"ON":C===0?"FREE":C})]},g)})}),B.jsx("div",{className:"flex gap-2 mt-5",children:B.jsx("button",{onClick:x,className:"neon-btn neon-btn-cyan rounded px-5 py-3 text-base font-black flex-1",children:"✓ DONE"})})]})})}function XA({result:r,highScore:t,qualifiesForBoard:i,defaultName:a,alreadySubmitted:l,onSubmitName:c,onRetry:f,onShop:p,onMenu:m,onShare:d}){const[v,x]=Xt.useState(r.newHighScore),[g,y]=Xt.useState(a||""),[b,C]=Xt.useState(l),S=Xt.useRef(null);Xt.useEffect(()=>{if(r.newHighScore){x(!0);const T=setTimeout(()=>x(!1),3500);return()=>clearTimeout(T)}},[r.newHighScore]),Xt.useEffect(()=>{i&&!b&&setTimeout(()=>S.current?.focus(),100)},[i,b]);const _=()=>{const T=g.trim().slice(0,14)||"ANON";c(T),C(!0)};return B.jsxs("div",{className:"absolute inset-0 z-30 flex items-center justify-center p-4",style:{background:"rgba(5, 2, 12, 0.78)"},children:[v&&B.jsx("div",{className:"absolute inset-0 pointer-events-none overflow-hidden",children:Array.from({length:60}).map((T,D)=>{const U=["#ff2bd6","#00f0ff","#ffd400","#5eff7c","#ff7a00"],P=U[D%U.length],N=Math.random()*100,z=2.2+Math.random()*2.2,A=Math.random()*.6;return B.jsx("span",{className:"confetti-piece",style:{left:`${N}%`,background:P,animationDuration:`${z}s`,animationDelay:`${A}s`,boxShadow:`0 0 8px ${P}`}},D)})}),B.jsxs("div",{className:"panel rounded-xl p-6 sm:p-8 w-full max-w-md text-center relative",children:[B.jsx("h3",{className:"neon-text-pink text-3xl sm:text-4xl font-black mb-1",children:"WRECKED!"}),r.newHighScore?B.jsx("div",{className:"neon-text-yellow text-base sm:text-lg font-black mb-3 tracking-widest pulse-glow",children:"🎉 NEW HIGH SCORE!"}):B.jsx("div",{className:"text-white/60 text-xs sm:text-sm mb-3 uppercase tracking-widest",children:"Beat your high score!"}),B.jsxs("div",{className:"grid grid-cols-2 gap-2 my-4",children:[B.jsx(Wc,{label:"Distance",value:`${r.distance.toLocaleString()}m`,color:"#00f0ff"}),B.jsx(Wc,{label:"Score",value:r.score.toLocaleString(),color:"#ffd400",big:!0}),B.jsx(Wc,{label:"Reached Lv",value:`L${r.level}`,color:"#ff2bd6"}),B.jsx(Wc,{label:"Best Chain",value:`x${r.bestChain}`,color:"#5eff7c"})]}),B.jsxs("div",{className:"hud-pill rounded-md px-3 py-1 mb-3 text-xs text-white/70",children:["High Score: ",B.jsx("span",{className:"neon-text-yellow font-mono font-black ml-1",children:t.toLocaleString()})]}),i&&!b&&B.jsxs("div",{className:"rounded-md p-3 mb-3 border border-pink-500/50",style:{background:"rgba(255, 43, 214, 0.10)"},children:[B.jsx("div",{className:"neon-text-pink text-sm font-black tracking-widest mb-2",children:"🏆 LEADERBOARD QUALIFIED!"}),B.jsxs("div",{className:"flex gap-2",children:[B.jsx("input",{ref:S,value:g,onChange:T=>y(T.target.value.slice(0,14)),placeholder:"Your driver name",maxLength:14,onKeyDown:T=>{T.key==="Enter"&&_()},className:"flex-1 bg-black/40 border border-white/30 rounded px-3 py-2 text-white font-mono outline-none focus:border-pink-400"}),B.jsx("button",{onClick:_,className:"neon-btn neon-btn-yellow px-4 py-2 rounded text-sm font-black",children:"SAVE"})]})]}),b&&B.jsx("div",{className:"text-xs neon-text-green tracking-widest mb-3 font-black",children:"✓ ADDED TO LEADERBOARD"}),B.jsxs("div",{className:"flex flex-col gap-2.5",children:[B.jsx("button",{onClick:f,className:"neon-btn px-6 py-3 rounded-md text-xl",children:"🔄 PLAY AGAIN"}),B.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[B.jsx("button",{onClick:p,className:"neon-btn neon-btn-yellow px-3 py-2 rounded-md text-sm",children:"🔧 GARAGE"}),B.jsx("button",{onClick:m,className:"neon-btn neon-btn-cyan px-3 py-2 rounded-md text-sm",children:"⌂ MENU"})]}),B.jsx("button",{onClick:d,className:"text-xs text-white/60 hover:text-white mt-1 underline-offset-2 hover:underline",children:"📸 Share your score"})]})]})]})}function Wc({label:r,value:t,color:i,big:a}){return B.jsxs("div",{className:"hud-pill rounded-md px-3 py-2",style:{borderColor:`${i}aa`,boxShadow:`0 0 8px ${i}55`},children:[B.jsx("div",{className:"text-[10px] uppercase tracking-widest text-white/60",children:r}),B.jsx("div",{className:`font-black font-mono ${a?"text-xl":"text-base"}`,style:{color:i,textShadow:`0 0 8px ${i}`},children:t})]})}function WA(){const r=Xt.useRef(null),t=Xt.useRef(null),i=Xt.useRef(null),a=Xt.useRef(0),[l,c]=Xt.useState(()=>DA()),[f,p]=Xt.useState("menu"),[m,d]=Xt.useState("menu"),[v,x]=Xt.useState(null),[g,y]=Xt.useState(!1),[b,C]=Xt.useState([]),[S,_]=Xt.useState(0),[T,D]=Xt.useState(null),[U,P]=Xt.useState(null),[N,z]=Xt.useState(null),[A,O]=Xt.useState(!1),k=Xt.useRef(0),G=Xt.useRef(0),Y=Xt.useRef(0);Xt.useEffect(()=>{if(!r.current)return;const jt=new CA(l.muted);i.current=jt;let te;try{te=new RA(r.current,jt,{onHud:ee=>x(ee),onStatus:ee=>{},onFloatingScore:(ee,me)=>{const Ve=++k.current;C(j=>[...j,{id:Ve,text:ee,color:me}]),setTimeout(()=>{C(j=>j.filter(Ue=>Ue.id!==Ve))},1100)},onChainEvent:()=>{},onShake:ee=>{_(me=>me+1)},onLevelUp:(ee,me,Ve)=>{const j=++G.current;P({id:j,level:ee,themeName:me,reward:Ve}),_(Ue=>Ue+1),setTimeout(()=>{P(Ue=>Ue&&Ue.id===j?null:Ue)},3200)},onVictory:ee=>{const me=++Y.current;z({id:me,score:ee.score,distance:ee.distance}),_(Ve=>Ve+1),jt.powerup(),setTimeout(()=>{z(Ve=>Ve&&Ve.id===me?null:Ve)},5e3)},onRunEnd:ee=>{jt.stopMusic(),c(me=>{const Ve=(ct.current?.scrap??0)-a.current,j=me.totalScrap+Math.max(0,Ve),Ue=Math.max(me.highScore,ee.score),ge={...me,totalScrap:j,highScore:Ue,lastDistance:ee.distance};return Xc(ge),ge}),D(ee),O(!1),p("gameover")}})}catch(ee){console.error("Game init failed",ee);return}return t.current=te,()=>{te.destroy(),t.current=null}},[]);const ct=Xt.useRef(null);Xt.useEffect(()=>{ct.current=v},[v]),Xt.useEffect(()=>{i.current?.setMuted(l.muted)},[l.muted]),Xt.useEffect(()=>{const jt=()=>{document.hidden&&f==="playing"&&(t.current?.pause(),d("playing"),p("paused"))};return document.addEventListener("visibilitychange",jt),()=>document.removeEventListener("visibilitychange",jt)},[f]),Xt.useEffect(()=>{const jt=te=>{te.code==="Escape"&&(f==="playing"?(t.current?.pause(),d(f),p("paused")):f==="paused"&&(t.current?.resume(),p("playing")))};return window.addEventListener("keydown",jt),()=>window.removeEventListener("keydown",jt)},[f]);const ut=Xt.useCallback(()=>{i.current?.start(),i.current?.uiClick(),i.current?.startMusic(1),a.current=l.totalScrap,t.current?.start(l.upgrades,l.totalScrap,l.highScore),D(null),x(null),P(null),z(null),O(!1),p("playing"),window.localStorage.getItem("chs3d_tut_seen")||(y(!0),window.localStorage.setItem("chs3d_tut_seen","1"))},[l.upgrades,l.totalScrap,l.highScore]),W=Xt.useCallback(()=>{i.current?.uiClick(),i.current?.startMusic(1),a.current=l.totalScrap,t.current?.start(l.upgrades,l.totalScrap,l.highScore),D(null),x(null),P(null),z(null),O(!1),p("playing")},[l.upgrades,l.totalScrap,l.highScore]),F=Xt.useCallback(()=>{f==="playing"&&(t.current?.pause(),i.current?.uiClick(),d("playing"),p("paused"))},[f]),V=Xt.useCallback(()=>{i.current?.uiClick(),t.current?.resume(),p("playing")},[]),rt=Xt.useCallback(()=>{i.current?.start(),i.current?.uiClick(),d(f),p("shop")},[f]),gt=Xt.useCallback(()=>{i.current?.uiClick(),d("paused"),p("shop")},[]),I=Xt.useCallback(()=>{i.current?.uiClick(),d("gameover"),p("shop")},[]),tt=Xt.useCallback(()=>{i.current?.uiClick(),p(m==="paused"?"paused":m==="gameover"?"gameover":"menu")},[m]),dt=Xt.useCallback((jt,te)=>{c(ee=>{const me={...ee,totalScrap:jt,upgrades:te};return Xc(me),me})},[]),St=Xt.useCallback(()=>{i.current?.uiClick(),i.current?.stopMusic(),t.current?.endRun(),p("menu")},[]),Nt=Xt.useCallback(()=>{i.current?.start(),i.current?.uiClick(),d(f),p("leaderboard")},[f]),Tt=Xt.useCallback(()=>{i.current?.uiClick(),p(m)},[m]),J=Xt.useCallback(()=>{i.current?.uiClick(),c(jt=>{const te={...jt,muted:!jt.muted};return Xc(te),te})},[]),Mt=Xt.useCallback(async()=>{if(!T)return;const jt=`I just smashed ${T.score.toLocaleString()} points on Level ${T.level} of Chaos Highway Smash 3D! Distance: ${T.distance.toLocaleString()}m, best chain x${T.bestChain}. Try to beat me!`;try{navigator.share?await navigator.share({title:"Chaos Highway Smash 3D",text:jt}):(await navigator.clipboard.writeText(jt),alert("Score copied to clipboard! Share with friends."))}catch{}},[T]),pt=Xt.useCallback(jt=>{T&&(i.current?.uiClick(),c(te=>{const ee=NA(te,{name:jt,score:T.score,distance:T.distance,level:T.level});return Xc(ee),ee}),O(!0))},[T]),Ft=Xt.useCallback(jt=>t.current?.setMobileSteer(jt),[]),$t=Xt.useCallback(jt=>t.current?.setMobileBoost(jt),[]),Zt=Xt.useCallback(jt=>t.current?.setMobileBrake(jt),[]),Pe=Xt.useCallback(()=>t.current?.triggerPower(),[]),le=Xt.useMemo(()=>`game-root ${S>0?"shake":""}`,[S]);Xt.useEffect(()=>{if(S===0)return;const jt=setTimeout(()=>_(0),450);return()=>clearTimeout(jt)},[S]);const Ne=Xt.useMemo(()=>T?PA(T.score,l.playerEntries):!1,[T,l.playerEntries]);return B.jsxs("div",{className:le,children:[B.jsx("div",{ref:r,className:"absolute inset-0"}),B.jsx("div",{className:"ui-layer pointer-events-none",children:B.jsx("div",{className:"absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2",children:b.map((jt,te)=>B.jsx("div",{className:"absolute float-up font-black text-2xl sm:text-3xl whitespace-nowrap",style:{left:"50%",top:`${te*18}px`,color:jt.color,textShadow:`0 0 10px ${jt.color}, 0 0 20px ${jt.color}`,transform:"translate(-50%, 0)"},children:jt.text},jt.id))})}),U&&f==="playing"&&B.jsxs("div",{className:"absolute inset-x-0 top-1/4 z-40 flex flex-col items-center pointer-events-none",style:{animation:"levelBannerIn 0.6s ease-out"},children:[B.jsx("div",{className:"text-xs neon-text-cyan tracking-[0.5em] mb-1",children:"▸ LEVEL UP ◂"}),B.jsxs("div",{className:"neon-title text-5xl sm:text-7xl tracking-widest",children:["LEVEL ",U.level]}),B.jsx("div",{className:"neon-text-yellow text-2xl sm:text-3xl font-black tracking-widest mt-1 uppercase",children:U.themeName}),B.jsxs("div",{className:"mt-3 flex gap-4 text-sm sm:text-base font-bold",children:[B.jsxs("span",{className:"neon-text-pink",children:["+",U.reward.health," HP"]}),B.jsxs("span",{className:"neon-text-cyan",children:["+",U.reward.boost," BOOST"]}),B.jsxs("span",{className:"neon-text-yellow",children:["+",U.reward.bonus.toLocaleString()," PTS"]})]})]},U.id),N&&f==="playing"&&B.jsxs("div",{className:"absolute inset-x-0 top-1/4 z-40 flex flex-col items-center pointer-events-none",style:{animation:"levelBannerIn 0.6s ease-out"},children:[B.jsx("div",{className:"text-xs neon-text-yellow tracking-[0.5em] mb-1",children:"★ HIGHWAY CONQUERED ★"}),B.jsx("div",{className:"neon-title text-5xl sm:text-7xl tracking-widest",children:"VICTORY!"}),B.jsx("div",{className:"neon-text-cyan text-xl sm:text-2xl font-black tracking-widest mt-2 uppercase",children:"All 5 zones cleared"}),B.jsxs("div",{className:"mt-3 flex gap-4 text-sm sm:text-base font-bold",children:[B.jsx("span",{className:"neon-text-yellow",children:"+5,000 BONUS"}),B.jsx("span",{className:"neon-text-pink",children:"FULL REPAIR"})]}),B.jsx("div",{className:"mt-2 neon-text-cyan text-xs tracking-widest",children:"Endless mode unlocked — keep smashing!"})]},N.id),(f==="playing"||f==="paused")&&B.jsx(BA,{hud:v,onPause:F,showTutorial:g&&f==="playing",onDismissTutorial:()=>y(!1)}),f==="playing"&&B.jsx(FA,{onSteer:Ft,onBoostHold:$t,onBrakeHold:Zt,onPower:Pe}),f==="menu"&&B.jsx(OA,{save:l,onPlay:ut,onShop:rt,onLeaderboard:Nt,onToggleMute:J}),f==="paused"&&B.jsx(zA,{onResume:V,onShop:gt,onMenu:St,muted:l.muted,onToggleMute:J}),f==="shop"&&B.jsx(kA,{scrap:l.totalScrap,upgrades:l.upgrades,onClose:tt,onApply:dt}),f==="leaderboard"&&B.jsx(IA,{save:l,onClose:Tt}),f==="gameover"&&T&&B.jsx(XA,{result:T,highScore:l.highScore,qualifiesForBoard:Ne,defaultName:l.lastPlayerName,alreadySubmitted:A,onSubmitName:pt,onRetry:W,onShop:I,onMenu:St,onShare:Mt})]})}jS.createRoot(document.getElementById("root")).render(B.jsx(Xt.StrictMode,{children:B.jsx(WA,{})}));
